<?php
/**
 * Product Subsystem - View Product Details
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

$db = (new Database())->connect();
$id = (int)($_GET['id'] ?? 0);

try {
    // Fetch product details joined with category name
    $stmt = $db->prepare("SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id WHERE p.id = :id LIMIT 1");
    $stmt->execute(['id' => $id]);
    $product = $stmt->fetch();

    if (!$product) {
        $error_message = "Product profile not found in database.";
    } else {
        // Calculate Profit Metrics
        $purchase = (float)$product['purchase_price'];
        $sell = (float)$product['sell_price'];
        
        $profit_val = $sell - $purchase;
        $profit_percentage = $purchase > 0 ? ($profit_val / $purchase) * 100 : 0.00;
    }

} catch (PDOException $e) {
    $error_message = "Database query failure: " . $e->getMessage();
}

require_once 'includes/header.php';
?>

<!-- Action Notifications -->
<?php if (isset($error_message)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo $error_message; ?></span>
    </div>
    <div style="margin-top: 20px;">
        <a href="products.php" class="btn btn-sm btn-secondary" style="width: auto;">&larr; Back to Products</a>
    </div>
<?php else: ?>

    <div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
        <div>
            <a href="products.php" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
                <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Products catalog
            </a>
        </div>
        <div style="display: flex; gap: 10px;">
            <button type="button" class="btn btn-sm btn-secondary" style="width: auto;" onclick="window.print()">
                <i class="bx bx-printer"></i> Print Product Card
            </button>
        </div>
    </div>

    <!-- ==========================================
         PRODUCT DETAIL CARD LAYOUT
         ========================================== -->
    <div class="dashboard-grid" style="grid-template-columns: 1.1fr 1.9fr; gap: 30px;">
        
        <!-- Left: Product Image & Barcode visualizer -->
        <div class="card" style="text-align: center; display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 400px; padding: 30px;">
            <div style="width: 100%; height: 260px; background: var(--input-bg); border-radius: var(--radius-md); overflow: hidden; display: flex; align-items: center; justify-content: center; border: 1px solid var(--border-color); margin-bottom: 24px; position: relative;">
                
                <?php if (!empty($product['image_path']) && file_exists($product['image_path'])): ?>
                    <img src="<?php echo htmlspecialchars($product['image_path']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" style="max-width: 100%; max-height: 100%; object-fit: contain;">
                <?php else: ?>
                    <div style="color: var(--text-muted);">
                        <i class="bx bx-image" style="font-size: 80px; display: block; margin-bottom: 10px; color: var(--border-color);"></i>
                        <span>No Photo Uploaded</span>
                    </div>
                <?php endif; ?>
                
                <?php if ($product['stock_qty'] <= 0): ?>
                    <span style="position: absolute; top: 12px; right: 12px; font-size: 10.5px; font-weight: 700; background: var(--danger-glow); color: var(--danger); padding: 4px 10px; border-radius: var(--radius-full); text-transform: uppercase;">Sold Out</span>
                <?php elseif ($product['stock_qty'] <= $product['min_stock_qty']): ?>
                    <span style="position: absolute; top: 12px; right: 12px; font-size: 10.5px; font-weight: 700; background: var(--warning-glow); color: var(--warning); padding: 4px 10px; border-radius: var(--radius-full); text-transform: uppercase;">Low Stock</span>
                <?php else: ?>
                    <span style="position: absolute; top: 12px; right: 12px; font-size: 10.5px; font-weight: 700; background: var(--accent-glow); color: var(--accent); padding: 4px 10px; border-radius: var(--radius-full); text-transform: uppercase;">In Stock</span>
                <?php endif; ?>
            </div>

            <!-- Custom Barcode Mockup visualizer -->
            <div style="border: 1px solid var(--border-color); width: 100%; padding: 15px; border-radius: var(--radius-sm); background: #ffffff;">
                <span style="font-size: 10px; color: #64748b; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; display: block; margin-bottom: 8px;">Scannable Product Barcode</span>
                
                <div style="font-family: monospace; font-size: 28px; letter-spacing: 2px; color: #111; line-height: 1; padding: 8px 0; background: #f9fafb; border-radius: var(--radius-xs); border: 1.5px dashed #d1d5db;">
                    ||||||| | |||| |
                </div>
                
                <span style="font-size: 13px; font-weight: 600; font-family: monospace; color: #1f2937; display: block; margin-top: 6px;">
                    <?php echo htmlspecialchars($product['barcode'] ?: $product['sku']); ?>
                </span>
            </div>
        </div>

        <!-- Right: Technical parameters, description, markup calculations -->
        <div class="card" style="padding: 30px;">
            <span style="font-size: 11px; font-weight: 700; color: var(--accent); text-transform: uppercase; letter-spacing: 0.5px; display: block; margin-bottom: 6px;">
                <?php echo htmlspecialchars($product['category_name']); ?>
            </span>
            
            <h2 style="font-size: 24px; font-weight: 800; color: var(--text-main); margin-bottom: 8px; line-height: 1.3;">
                <?php echo htmlspecialchars($product['name']); ?>
            </h2>

            <div style="display: flex; gap: 20px; align-items: center; margin-bottom: 24px; flex-wrap: wrap;">
                <span style="font-size: 13px; color: var(--text-secondary);">SKU/Code: <strong><?php echo htmlspecialchars($product['sku']); ?></strong></span>
                <span style="height: 14px; width: 1.5px; background: var(--border-color);"></span>
                <span style="font-size: 13px; color: var(--text-secondary);">Brand: <strong><?php echo htmlspecialchars($product['brand'] ?: 'Generic'); ?></strong></span>
                <span style="height: 14px; width: 1.5px; background: var(--border-color);"></span>
                <span style="font-size: 13px; color: var(--text-secondary);">Added: <strong><?php echo format_date($product['created_at']); ?></strong></span>
            </div>

            <!-- Price Analysis metrics cards -->
            <div class="stats-grid" style="grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 28px;">
                <!-- Purchase Price -->
                <div style="background: var(--input-bg); border: 1px solid var(--border-color); border-radius: var(--radius-sm); padding: 14px; text-align: center;">
                    <span style="font-size: 10px; text-transform: uppercase; color: var(--text-muted); font-weight: 700; display: block; margin-bottom: 4px;">Purchase Cost</span>
                    <strong style="font-size: 16px; color: var(--text-main);"><?php echo format_currency($product['purchase_price']); ?></strong>
                </div>

                <!-- Retail Sale Price -->
                <div style="background: var(--input-bg); border: 1px solid var(--border-color); border-radius: var(--radius-sm); padding: 14px; text-align: center;">
                    <span style="font-size: 10px; text-transform: uppercase; color: var(--text-muted); font-weight: 700; display: block; margin-bottom: 4px;">Retail Sale Price</span>
                    <strong style="font-size: 16px; color: var(--accent);"><?php echo format_currency($product['sell_price']); ?></strong>
                </div>

                <!-- Profit Margin Markup -->
                <div style="background: var(--accent-glow); border: 1px solid var(--card-border-hover); border-radius: var(--radius-sm); padding: 14px; text-align: center;">
                    <span style="font-size: 10px; text-transform: uppercase; color: var(--accent); font-weight: 700; display: block; margin-bottom: 4px;">Profit Margin</span>
                    <strong style="font-size: 16px; color: var(--accent);"><?php echo format_currency($profit_val); ?> (<?php echo number_format($profit_percentage, 1); ?>%)</strong>
                </div>
            </div>

            <!-- Description -->
            <div style="margin-bottom: 28px;">
                <h4 style="font-size: 14px; font-weight: 700; color: var(--text-main); margin-bottom: 8px;">Product Description</h4>
                <p style="font-size: 13.5px; line-height: 1.6; color: var(--text-secondary); font-style: italic;">
                    <?php echo nl2br(htmlspecialchars($product['description'] ?: 'No description provided for this catalog product.')); ?>
                </p>
            </div>

            <!-- Details checklist table parameters -->
            <div style="border-top: 1px solid var(--border-color); padding-top: 20px;">
                <h4 style="font-size: 14px; font-weight: 700; color: var(--text-main); margin-bottom: 12px;">Warehouse Inventory Parameters</h4>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; font-size: 13.5px;">
                    <div>
                        <p style="margin-bottom: 8px; color: var(--text-secondary);">Current Physical Stock: <strong style="color: var(--text-main);"><?php echo $product['stock_qty']; ?> <?php echo htmlspecialchars($product['unit']); ?></strong></p>
                        <p style="margin-bottom: 8px; color: var(--text-secondary);">Minimum Reorder Quantity: <strong style="color: var(--text-main);"><?php echo $product['min_stock_qty']; ?> <?php echo htmlspecialchars($product['unit']); ?></strong></p>
                    </div>
                    <div>
                        <p style="margin-bottom: 8px; color: var(--text-secondary);">Supplier Name: <strong style="color: var(--text-main);"><?php echo htmlspecialchars($product['supplier_name'] ?: 'Local Vendor / Walk-in Procurement'); ?></strong></p>
                        <p style="margin-bottom: 8px; color: var(--text-secondary);">Active Registry Status: <strong style="color: <?php echo ($product['status'] === 'ACTIVE') ? 'var(--accent)' : 'var(--error)'; ?>;"><?php echo $product['status']; ?></strong></p>
                    </div>
                </div>
            </div>

        </div>

    </div>

<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
