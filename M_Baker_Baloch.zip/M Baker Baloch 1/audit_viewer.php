<?php
/**
  * Advanced Security & Audit Trail System - Change Snapshot Difference Explorer
  * Shop Name: M.BAKAR BALOCH
  */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';
require_once 'audit_logger.php';

// Enforce admin/executive role
if ($_SESSION['role'] !== 'SUPERADMIN' && $_SESSION['role'] !== 'ADMIN') {
    die("Access Denied: You do not have permissions to view system data audits.");
}

$db = (new Database())->connect();

$filter_table = isset($_GET['table_name']) ? sanitize($_GET['table_name']) : '';
$filter_action = isset($_GET['action_type']) ? sanitize($_GET['action_type']) : '';

// 1. Fetch audits with filters
$query = "SELECT at.*, u.name as operator_name, u.username as operator_username 
          FROM audit_trails at 
          LEFT JOIN users u ON at.user_id = u.id 
          WHERE 1=1";
$params = [];

if ($filter_table !== '') {
    $query .= " AND at.table_name = :tbl";
    $params['tbl'] = $filter_table;
}
if ($filter_action !== '') {
    $query .= " AND at.action_type = :act";
    $params['act'] = $filter_action;
}

$query .= " ORDER BY at.created_at DESC LIMIT 50";

$audits = [];
try {
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $audits = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Custom Styles -->
<link rel="stylesheet" href="settings.css">
<style>
    .diff-table {
        width: 100%;
        border-collapse: collapse;
        margin: 15px 0;
        font-size: 13px;
    }
    .diff-table th, .diff-table td {
        padding: 10px 12px;
        border: 1px solid var(--border-color);
        text-align: left;
    }
    .diff-table th {
        background: var(--bg-primary);
        font-weight: 700;
        color: var(--text-muted);
    }
    .diff-changed {
        background: var(--warning-glow);
        color: var(--warning);
        font-weight: 700;
    }
    .diff-added {
        background: var(--success-glow);
        color: var(--success);
    }
    .diff-removed {
        background: var(--danger-glow);
        color: var(--danger);
    }
    .badge-act {
        font-size: 10px;
        font-weight: 700;
        padding: 2px 6px;
        border-radius: 4px;
        display: inline-block;
    }
    .badge-act.insert { background: var(--success-glow); color: var(--success); }
    .badge-act.update { background: var(--warning-glow); color: var(--warning); }
    .badge-act.delete { background: var(--danger-glow); color: var(--danger); }
</style>

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="margin: 0; font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Change History Explorer</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Audit snapshots logging before vs after variations across system registers.</p>
    </div>
    <div style="display: flex; gap: 10px;">
        <a href="security_dashboard.php" class="btn btn-secondary btn-sm" style="width: auto;">
            <i class="bx bx-shield-quarter"></i> Security Dashboard
        </a>
    </div>
</div>

<!-- ==========================================
     FILTERS BAR
     ========================================== -->
<div class="card" style="margin-bottom: 24px;">
    <form method="GET" action="audit_viewer.php" style="display: flex; gap: 15px; align-items: end; flex-wrap: wrap;">
        
        <div style="flex-grow: 1; min-width: 200px;">
            <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">Register / Table</label>
            <select name="table_name" style="width: 100%; height: 38px; padding: 0 10px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none; cursor: pointer;">
                <option value="">All Database Registers</option>
                <option value="products" <?php echo $filter_table === 'products' ? 'selected' : ''; ?>>Products</option>
                <option value="customers" <?php echo $filter_table === 'customers' ? 'selected' : ''; ?>>Customers Directory</option>
                <option value="sales" <?php echo $filter_table === 'sales' ? 'selected' : ''; ?>>Sales Invoices</option>
                <option value="purchases" <?php echo $filter_table === 'purchases' ? 'selected' : ''; ?>>Restock Purchases</option>
            </select>
        </div>

        <div style="flex-grow: 1; min-width: 200px;">
            <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">Action Mode</label>
            <select name="action_type" style="width: 100%; height: 38px; padding: 0 10px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none; cursor: pointer;">
                <option value="">All Actions</option>
                <option value="INSERT" <?php echo $filter_action === 'INSERT' ? 'selected' : ''; ?>>INSERT (Creation)</option>
                <option value="UPDATE" <?php echo $filter_action === 'UPDATE' ? 'selected' : ''; ?>>UPDATE (Edits)</option>
                <option value="DELETE" <?php echo $filter_action === 'DELETE' ? 'selected' : ''; ?>>DELETE (Deletions)</option>
            </select>
        </div>

        <button type="submit" class="btn" style="height: 38px; width: 100px; background: var(--accent); border-color: var(--accent); color: #fff;">
            Filter
        </button>
    </form>
</div>

<!-- ==========================================
     CHANGES LIST & DIFFERENCES TABLES
     ========================================== -->
<?php if (empty($audits)): ?>
    <div class="card" style="text-align: center; padding: 40px; color: var(--text-muted);">
        <i class="bx bx-check-double" style="font-size: 48px; color: var(--success); margin-bottom: 10px; display: block;"></i>
        <span style="font-size: 14px;">No database modifications logged matching these parameters.</span>
    </div>
<?php else: ?>
    <?php foreach ($audits as $audit): 
        $before = json_decode($audit['before_snapshot'], true) ?: [];
        $after = json_decode($audit['after_snapshot'], true) ?: [];
        
        // Merge keys to identify deleted/added/updated columns
        $all_keys = array_unique(array_merge(array_keys($before), array_keys($after)));
        
        $badge_class = 'update';
        if ($audit['action_type'] === 'INSERT') $badge_class = 'insert';
        if ($audit['action_type'] === 'DELETE') $badge_class = 'delete';
    ?>
        <div class="card animate-fade" style="margin-bottom: 24px;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; padding-bottom: 12px; border-bottom: 1.5px dashed var(--border-color); margin-bottom: 15px;">
                <div>
                    <span class="badge-act <?php echo $badge_class; ?>"><?php echo htmlspecialchars($audit['action_type']); ?></span>
                    <strong style="margin-left: 10px; font-size: 14.5px; color: var(--text-main);">
                        Register: <?php echo strtoupper(htmlspecialchars($audit['table_name'])); ?> (ID: <?php echo (int)$audit['record_id']; ?>)
                    </strong>
                </div>
                <div style="font-size: 12px; color: var(--text-muted);">
                    <span>Operator: <strong><?php echo htmlspecialchars($audit['operator_name'] ?: 'System'); ?></strong> (@<?php echo htmlspecialchars($audit['operator_username'] ?: 'system'); ?>)</span>
                    <span style="margin-left: 15px; font-weight: 600;"><?php echo date('d M Y, h:i A', strtotime($audit['created_at'])); ?></span>
                </div>
            </div>

            <!-- Diff Table -->
            <div class="table-responsive">
                <table class="diff-table">
                    <thead>
                        <tr>
                            <th style="width: 250px;">Database Column</th>
                            <th>Before Value</th>
                            <th>After Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($all_keys as $key): 
                            if ($key === 'password' || $key === 'created_at' || $key === 'updated_at') continue;
                            
                            $b_val = isset($before[$key]) ? $before[$key] : null;
                            $a_val = isset($after[$key]) ? $after[$key] : null;
                            
                            $row_class = '';
                            if ($audit['action_type'] === 'UPDATE' && $b_val !== $a_val) {
                                $row_class = 'diff-changed';
                            } elseif ($audit['action_type'] === 'INSERT') {
                                $row_class = 'diff-added';
                            } elseif ($audit['action_type'] === 'DELETE') {
                                $row_class = 'diff-removed';
                            }
                        ?>
                            <tr class="<?php echo $row_class; ?>">
                                <td><code><?php echo htmlspecialchars($key); ?></code></td>
                                <td>
                                    <?php 
                                        if ($b_val === null) echo '<em style="opacity:0.6;">NULL</em>';
                                        elseif (is_array($b_val)) echo htmlspecialchars(json_encode($b_val));
                                        else echo htmlspecialchars($b_val);
                                    ?>
                                </td>
                                <td>
                                    <?php 
                                        if ($a_val === null) echo '<em style="opacity:0.6;">NULL</em>';
                                        elseif (is_array($a_val)) echo htmlspecialchars(json_encode($a_val));
                                        else echo htmlspecialchars($a_val);
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
