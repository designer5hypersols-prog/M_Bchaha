<?php
/**
 * Reports & Profit/Loss Subsystem - Purchase Report (Module 8)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = "";

// 1. FILTER PARAMETERS
$start_date = sanitize($_GET['start_date'] ?? '');
$end_date = sanitize($_GET['end_date'] ?? '');
$supplier_filter = (int)($_GET['supplier_id'] ?? 0);

$limit = 15; // Logs per page
$page = (int)($_GET['page'] ?? 1);
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

$query_base = "SELECT pi.*, pur.purchase_no, pur.purchase_date, s.name as supplier_name, p.name as product_name, p.sku as product_sku 
              FROM purchase_items pi 
              JOIN purchases pur ON pi.purchase_id = pur.id 
              JOIN products p ON pi.product_id = p.id 
              LEFT JOIN suppliers s ON pur.supplier_id = s.id 
              WHERE 1=1";
$params = [];

if (!empty($start_date) && !empty($end_date)) {
    $query_base .= " AND pur.purchase_date BETWEEN :start AND :end";
    $params['start'] = $start_date;
    $params['end'] = $end_date;
}

if ($supplier_filter > 0) {
    $query_base .= " AND pur.supplier_id = :sup";
    $params['sup'] = $supplier_filter;
}

// Calculate pagination parameters
try {
    $count_query = "SELECT COUNT(*) FROM (" . $query_base . ") as sub";
    $count_stmt = $db->prepare($count_query);
    $count_stmt->execute($params);
    $total_records = (int)$count_stmt->fetchColumn();
} catch (PDOException $e) {
    $total_records = 0;
}

$total_pages = ceil($total_records / $limit);
if ($total_pages < 1) $total_pages = 1;
if ($page > $total_pages) $page = $total_pages;
$offset = ($page - 1) * $limit;

// Load records
try {
    $load_query = $query_base . " ORDER BY pur.id DESC LIMIT $limit OFFSET $offset";
    $load_stmt = $db->prepare($load_query);
    $load_stmt->execute($params);
    $items = $load_stmt->fetchAll();
} catch (PDOException $e) {
    $items = [];
}

// Load metadata lists
$suppliers = [];
try {
    $suppliers = $db->query("SELECT id, name FROM suppliers ORDER BY name ASC")->fetchAll();
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="reports.css">

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <a href="reports.php" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
            <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Reports Hub
        </a>
    </div>
    
    <div style="display: flex; gap: 10px;">
        <button type="button" class="btn btn-sm btn-secondary" style="width: auto;" onclick="exportReportTableToCSV('purchaseReportTable', 'mbakar_baloch_purchases_procurement_report')">
            <i class="bx bx-download"></i> Export Report CSV
        </button>
    </div>
</div>

<!-- ==========================================
     ADVANCED PURCHASES REPORT FILTERS
     ========================================== -->
<div class="search-filter-section" style="margin-bottom: 24px;">
    <form method="GET" action="purchase_report.php" style="display: flex; flex-grow: 1; flex-wrap: wrap; gap: 15px; width: 100%;">
        
        <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap; width: 100%;">
            <!-- Date range picker -->
            <input type="date" name="start_date" class="form-control" style="width: 140px; height: 44px;" value="<?php echo htmlspecialchars($start_date); ?>">
            <span style="color:var(--text-muted);">to</span>
            <input type="date" name="end_date" class="form-control" style="width: 140px; height: 44px;" value="<?php echo htmlspecialchars($end_date); ?>">

            <!-- Supplier Filter dropdown -->
            <select name="supplier_id" class="select-control" style="width: auto; height: 44px;" onchange="this.form.submit()">
                <option value="">All Supplier Vendors</option>
                <?php foreach($suppliers as $s): ?>
                    <option value="<?php echo $s['id']; ?>" <?php echo $supplier_filter === $s['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($s['name']); ?></option>
                <?php endforeach; ?>
            </select>

            <button type="submit" class="btn btn-sm btn-secondary" style="height: 44px; width: auto; padding: 0 20px;">Filter Report</button>
        </div>
    </form>
</div>

<!-- ==========================================
     ITEMIZED PURCHASES DETAILS TABLE
     ========================================== -->
<div class="card">
    <div class="table-responsive">
        <table class="table" id="purchaseReportTable">
            <thead>
                <tr>
                    <th>Purchase No</th>
                    <th>Supplier Vendor</th>
                    <th>Purchase Date</th>
                    <th>Replenishing Item</th>
                    <th>SKU Code</th>
                    <th>Replenished Qty</th>
                    <th>Buying Unit Cost</th>
                    <th>Total Buying Cost</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($items)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 45px;">No itemized purchases match current filters.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach($items as $i): ?>
                        <tr class="animate-fade">
                            <td style="font-weight: 600; color: var(--accent);"><?php echo htmlspecialchars($i['purchase_no']); ?></td>
                            <td><strong><?php echo htmlspecialchars($i['supplier_name'] ?: 'Cash Supplier / Walk-in'); ?></strong></td>
                            <td><?php echo format_date($i['purchase_date']); ?></td>
                            <td><strong><?php echo htmlspecialchars($i['product_name']); ?></strong></td>
                            <td style="font-weight:600;"><?php echo htmlspecialchars($i['product_sku']); ?></td>
                            <td style="font-weight:600;"><?php echo $i['qty']; ?></td>
                            <td><?php echo format_currency($i['price']); ?></td>
                            <td style="font-weight: 700; color: var(--text-main);"><?php echo format_currency($i['total']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ==========================================
     PAGINATION CONTROL ROW FOOTER
     ========================================== -->
<div class="pagination" style="margin-top: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <span style="font-size: 13.5px; color: var(--text-secondary);">Showing <strong><?php echo count($items); ?></strong> of <strong><?php echo $total_records; ?></strong> transactions.</span>
    
    <div style="display: flex; gap: 5px;">
        <a href="purchase_report.php?page=<?php echo ($page - 1); ?>&start_date=<?php echo urlencode($start_date); ?>&end_date=<?php echo urlencode($end_date); ?>&supplier_id=<?php echo $supplier_filter; ?>" 
           class="btn btn-sm btn-secondary <?php echo ($page <= 1) ? 'disabled' : ''; ?>" 
           style="width: auto; padding: 6px 12px; pointer-events: <?php echo ($page <= 1) ? 'none' : 'auto'; ?>;">
           &larr; Prev
        </a>

        <?php for($k = 1; $k <= $total_pages; $k++): ?>
            <a href="purchase_report.php?page=<?php echo $k; ?>&start_date=<?php echo urlencode($start_date); ?>&end_date=<?php echo urlencode($end_date); ?>&supplier_id=<?php echo $supplier_filter; ?>" 
               class="btn btn-sm <?php echo ($page === $k) ? '' : 'btn-secondary'; ?>" 
               style="width: 32px; padding: 6px 0; text-align: center;">
               <?php echo $k; ?>
            </a>
        <?php endfor; ?>

        <a href="purchase_report.php?page=<?php echo ($page + 1); ?>&start_date=<?php echo urlencode($start_date); ?>&end_date=<?php echo urlencode($end_date); ?>&supplier_id=<?php echo $supplier_filter; ?>" 
           class="btn btn-sm btn-secondary <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>" 
           style="width: auto; padding: 6px 12px; pointer-events: <?php echo ($page >= $total_pages) ? 'none' : 'auto'; ?>;">
           Next &rarr;
        </a>
    </div>
</div>

<!-- Subsystem JS -->
<script src="reports.js"></script>

<?php require_once 'includes/footer.php'; ?>
