<?php
/**
  * Warehouse & Location-Based Inventory System - Logistics Dashboard Cockpit
  * Shop Name: M.BAKAR BALOCH
  */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';
require_once 'location_engine.php';

$db = (new Database())->connect();

// Gather stats
$total_warehouses = 0;
$total_locations = 0;
$total_stored_qty = 0;
$low_stock_shelves = [];
$occupancy_details = [];

try {
    $total_warehouses = (int)$db->query("SELECT COUNT(*) FROM warehouses WHERE status = 'ACTIVE'")->fetchColumn();
    $total_locations = (int)$db->query("SELECT COUNT(*) FROM locations WHERE status = 'ACTIVE'")->fetchColumn();
    $total_stored_qty = (int)$db->query("SELECT COALESCE(SUM(qty), 0) FROM product_locations")->fetchColumn();

    // Fetch shelves with low quantities (<= 5 pcs)
    $low_stock_shelves = $db->query("SELECT pl.qty, p.name as product_name, p.sku as product_sku, p.unit,
                                             w.name as warehouse_name, l.zone, l.rack, l.shelf 
                                      FROM product_locations pl
                                      JOIN products p ON pl.product_id = p.id
                                      JOIN warehouses w ON pl.warehouse_id = w.id
                                      JOIN locations l ON pl.location_id = l.id
                                      WHERE pl.qty <= 5 AND pl.qty > 0
                                      ORDER BY pl.qty ASC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

    // Fetch warehouse details for visual layout map
    $occupancy_details = $db->query("SELECT w.id, w.name, w.capacity, w.address,
                                            COALESCE(SUM(pl.qty), 0) as stored,
                                            COUNT(DISTINCT pl.product_id) as items_count,
                                            COUNT(DISTINCT l.id) as locations_count
                                     FROM warehouses w
                                     LEFT JOIN locations l ON w.id = l.warehouse_id
                                     LEFT JOIN product_locations pl ON w.id = pl.warehouse_id
                                     WHERE w.status = 'ACTIVE'
                                     GROUP BY w.id
                                     ORDER BY w.name ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Custom CSS -->
<link rel="stylesheet" href="settings.css">
<style>
    .logistics-card-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 20px;
        margin-top: 15px;
    }
    .layout-box {
        background: var(--bg-secondary);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-sm);
        padding: 24px;
        position: relative;
    }
    .grid-visualizer {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(40px, 1fr));
        gap: 8px;
        margin-top: 15px;
        padding: 10px;
        background: var(--bg-primary);
        border-radius: var(--radius-sm);
    }
    .grid-bin {
        aspect-ratio: 1;
        border-radius: 4px;
        background: var(--bg-secondary);
        border: 1px solid var(--border-color);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 9px;
        font-weight: 700;
        color: var(--text-muted);
        position: relative;
        transition: all 0.2s ease;
    }
    .grid-bin:hover {
        border-color: var(--accent);
        transform: scale(1.05);
    }
    .grid-bin.occupied {
        background: var(--accent-glow);
        border-color: var(--accent);
        color: var(--accent);
    }
    .grid-bin.stale {
        background: var(--danger-glow);
        border-color: var(--danger);
        color: var(--danger);
    }
</style>

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="margin: 0; font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Logistics Dashboard</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Visual shelf mapping metrics, capacity ratings, and physical occupancy allocations.</p>
    </div>
    <div style="display: flex; gap: 10px;">
        <a href="warehouse.php" class="btn btn-secondary btn-sm" style="width: auto;">
            <i class="bx bx-buildings"></i> Warehouses List
        </a>
        <a href="locations.php" class="btn btn-secondary btn-sm" style="width: auto;">
            <i class="bx bx-cabinet"></i> Coordinates Config
        </a>
        <a href="transfer_stock.php" class="btn btn-sm" style="width: auto; background: var(--accent); border-color: var(--accent); color: #fff;">
            <i class="bx bx-transfer-alt"></i> Relocate Stock
        </a>
    </div>
</div>

<!-- ==========================================
     I. OVERVIEW LOGISTICS STATS CARDS
     ========================================== -->
<div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); margin-bottom: 24px;">
    <!-- Warehouses -->
    <div class="stat-card primary">
        <div class="stat-info">
            <span>Operational Warehouses</span>
            <h2><?php echo $total_warehouses; ?> Active Centers</h2>
        </div>
        <div class="stat-icon">
            <i class="bx bx-buildings"></i>
        </div>
    </div>

    <!-- Shelf bins -->
    <div class="stat-card success">
        <div class="stat-info">
            <span>Shelf Coordinates Mapped</span>
            <h2><?php echo $total_locations; ?> Configured bins</h2>
        </div>
        <div class="stat-icon">
            <i class="bx bx-grid"></i>
        </div>
    </div>

    <!-- Stored volumes -->
    <div class="stat-card warning">
        <div class="stat-info">
            <span>Stored Inventory Volume</span>
            <h2><?php echo number_format($total_stored_qty); ?> units stored</h2>
        </div>
        <div class="stat-icon">
            <i class="bx bx-package"></i>
        </div>
    </div>
</div>

<!-- ==========================================
     II. WAREHOUSE CAPACITY LAYOUT & WARNINGS
     ========================================== -->
<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px; align-items: start; margin-bottom: 24px;">

    <!-- Left: Warehouse Layout Maps -->
    <div class="card">
        <div class="card-header" style="margin-bottom: 15px; padding-bottom: 8px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-map-alt" style="color:var(--accent);"></i>
                <span>Visual Warehouse Allocations</span>
            </div>
        </div>

        <div class="logistics-card-grid">
            <?php foreach ($occupancy_details as $det): 
                $pct = $det['capacity'] > 0 ? ($det['stored'] / $det['capacity']) * 100 : 0;
            ?>
                <div class="layout-box animate-fade">
                    <h3 style="margin: 0 0 4px 0; font-size: 15px; font-weight: 700; color: var(--text-main);"><?php echo htmlspecialchars($det['name']); ?></h3>
                    <span style="font-size: 11px; color: var(--text-muted); display: block; margin-bottom: 15px;">Locs: <?php echo $det['locations_count']; ?> coordinates &bull; Items: <?php echo $det['items_count']; ?> types</span>

                    <div style="font-size: 12.5px; color: var(--text-secondary); display:flex; justify-content:space-between; margin-bottom: 6px;">
                        <span>Stored Volume:</span>
                        <strong><?php echo number_format($det['stored']); ?> pcs</strong>
                    </div>

                    <!-- Visual occupancy bar -->
                    <div style="height: 6px; background: var(--bg-primary); border-radius:3px; overflow:hidden; margin-bottom:15px;">
                        <div style="height:100%; width: <?php echo min($pct, 100); ?>%; background: var(--accent); border-radius:3px;"></div>
                    </div>

                    <!-- Bin layout map demonstration -->
                    <div style="font-size: 11px; font-weight:600; color:var(--text-muted); margin-bottom: 5px;">Amazon Bin Map:</div>
                    <div class="grid-visualizer">
                        <?php 
                        // Draw some bins based on coordinates mapped, simulating physical grids
                        $grid_size = max(8, min(16, $det['locations_count']));
                        for ($i = 1; $i <= 10; $i++): 
                            $class = ($i <= $det['items_count']) ? 'occupied' : '';
                            if ($i === 3 && $det['stored'] > 1000) $class = 'stale';
                        ?>
                            <div class="grid-bin <?php echo $class; ?>" title="Coordinate Drawer <?php echo $i; ?>">
                                A<?php echo $i; ?>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Right: Low stock shelf coordinate warnings -->
    <div class="card">
        <div class="card-header" style="margin-bottom: 15px; padding-bottom: 8px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-bell" style="color:var(--danger);"></i>
                <span>Replenish Coordinates Alerts</span>
            </div>
        </div>

        <?php if (empty($low_stock_shelves)): ?>
            <div style="text-align: center; padding: 30px; color: var(--text-muted);">
                <i class="bx bx-check-double" style="font-size: 40px; color: var(--success); margin-bottom: 10px; display: block;"></i>
                <span style="font-size: 13px;">No coordinate drawer is low on stock!</span>
            </div>
        <?php else: ?>
            <div style="display: flex; flex-direction: column; gap: 12px;">
                <?php foreach ($low_stock_shelves as $low): ?>
                    <div class="animate-fade" style="padding: 12px; border: 1px solid var(--border-color); border-radius: var(--radius-sm); background: var(--danger-glow); border-left: 4px solid var(--danger);">
                        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 4px;">
                            <strong style="font-size: 13px; color: var(--text-main);"><?php echo htmlspecialchars($low['product_name']); ?></strong>
                            <span style="font-size: 12px; font-weight: 700; color: var(--danger);"><?php echo $low['qty']; ?> <?php echo htmlspecialchars($low['unit']); ?> left</span>
                        </div>
                        <span style="font-size: 11px; color: var(--text-muted); display: block;">
                            <i class="bx bx-cabinet"></i> coordinate: <?php echo htmlspecialchars($low['warehouse_name']); ?> &rarr; <?php echo htmlspecialchars($low['zone']); ?> &bull; <?php echo htmlspecialchars($low['rack']); ?> &bull; <?php echo htmlspecialchars($low['shelf']); ?>
                        </span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

</div>

<?php require_once 'includes/footer.php'; ?>
