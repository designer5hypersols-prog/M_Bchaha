<?php
/**
 * AI Smart Assistant - Floating UI Panel component (Module 1)
 * Shop Name: M.BAKAR BALOCH
 */
?>

<!-- 1. CSS Stylesheet Injection -->
<link rel="stylesheet" href="ai_styles.css">

<!-- ==========================================
     2. FLOATING TRIGGER BUTTON (PULSING GLOW)
     ========================================== -->
<button type="button" class="ai-chat-trigger" id="aiChatTrigger" title="Open AI Smart Assistant">
    <i class="bx bx-bot"></i>
</button>

<!-- ==========================================
     3. CHAT DRAWER PANEL OVERLAY
     ========================================== -->
<div class="ai-chat-panel" id="aiChatPanel">
    
    <!-- Header Block -->
    <div class="ai-chat-header">
        <div class="ai-chat-header-info">
            <div class="ai-avatar"><i class="bx bx-bot"></i></div>
            <div class="ai-title">
                <h4>AI Assistant</h4>
                <span class="ai-status-indicator">Connected</span>
            </div>
        </div>
        <i class="bx bx-chevron-down ai-chat-close" id="aiChatClose" title="Hide Assistant"></i>
    </div>

    <!-- Messages Body Frame -->
    <div class="ai-chat-messages" id="aiChatMessages">
        <!-- Initial Chat Message -->
        <div class="ai-message assistant animate-fade">
            Hello! Main aapka **M.BAKAR BALOCH AI Smart Assistant** hoon. Aaj shop par business kesa chal raha hai? 🙋‍♂️
            <br><br>
            Aap mujhse inventory stock levels, sales turnover, ledgers outstanding balances, ya profit margins ke baare mein puch sakte hain!
            <span class="ai-time"><?php echo date('H:i'); ?></span>
        </div>
    </div>

    <!-- Quick Suggestions Rail -->
    <div class="ai-quick-actions">
        <button type="button" class="ai-chip" onclick="submitAiQuickQuery('Today sales sum')">Today Sales 💵</button>
        <button type="button" class="ai-chip" onclick="submitAiQuickQuery('Low stock products')">Low Stock ⚠️</button>
        <button type="button" class="ai-chip" onclick="submitAiQuickQuery('This month profit overview')">Month Profit 💵</button>
        <button type="button" class="ai-chip" onclick="submitAiQuickQuery('Outstanding udhar customer balances')">Receivables 👤</button>
    </div>

    <!-- Text Input Area -->
    <div class="ai-chat-input-area">
        <input type="text" id="aiChatInput" class="ai-chat-input" placeholder="Type shop queries here..." autocomplete="off">
        <button type="button" class="ai-send-btn" id="aiSendBtn">
            <i class="bx bx-send"></i>
        </button>
    </div>

</div>

<!-- 4. Client-side Controller Integration -->
<script src="ai_chat.js"></script>
