<?php
/**
 * Multi-Branch ERP Subsystem - Branch Management Control (Module 1)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';
require_once 'multi_branch_engine.php';

$db = (new Database())->connect();
$engine = new MultiBranchEngine($db);

$error_message = "";
$success_message = "";

// Enforce Super Admin rights
if ($_SESSION['user_role'] !== 'SUPERADMIN' && $_SESSION['user_role'] !== 'ADMIN') {
    die("Access Denied: Only Super Administrators have authority to manage branches.");
}

// ==========================================
// PROCESS POST BRANCH ADDITION & STATUS TOGGLE
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = sanitize($_POST['action'] ?? '');

    if ($action === 'add') {
        $name = sanitize($_POST['name'] ?? '');
        $address = sanitize($_POST['address'] ?? '');
        $phone = sanitize($_POST['phone'] ?? '');

        if (!empty($name)) {
            try {
                $ins = $db->prepare("INSERT INTO branches (name, address, phone, status) VALUES (:name, :address, :phone, 'ACTIVE')");
                $ins->execute([
                    'name' => $name,
                    'address' => $address,
                    'phone' => $phone
                ]);
                $success_message = "New ERP branch outlet **\"$name\"** successfully registered.";
            } catch (PDOException $e) {
                $error_message = "Branch insertion failed: " . $e->getMessage();
            }
        } else {
            $error_message = "Please enter a valid branch name.";
        }
    }

    if ($action === 'toggle') {
        $branch_id = (int)($_POST['id'] ?? 0);
        $current_status = sanitize($_POST['status'] ?? 'ACTIVE');
        $new_status = ($current_status === 'ACTIVE') ? 'INACTIVE' : 'ACTIVE';

        if ($branch_id > 1) { // Head Office cannot be deactivated
            try {
                $upd = $db->prepare("UPDATE branches SET status = :status WHERE id = :id");
                $upd->execute(['status' => $new_status, 'id' => $branch_id]);
                $success_message = "Branch status updated to **$new_status** successfully.";
            } catch (PDOException $e) {
                $error_message = "Status toggle failed: " . $e->getMessage();
            }
        } else {
            $error_message = "Central Head Office must remain active for system operations.";
        }
    }
}

// ==========================================
// LOAD ALL BRANCH OUTLETS
// ==========================================
$branches = [];
try {
    $branches = $db->query("SELECT b.*, 
                                   (SELECT COUNT(*) FROM users u WHERE u.branch_id = b.id) as total_users,
                                   (SELECT COUNT(*) FROM products p WHERE p.branch_id = b.id) as total_products 
                            FROM branches b ORDER BY b.id ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<!-- Action Notifications -->
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo $error_message; ?></span>
    </div>
<?php endif; ?>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success">
        <i class="bx bx-check-circle"></i>
        <span><?php echo preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $success_message); ?></span>
    </div>
<?php endif; ?>

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <a href="settings.php#subsystems_link" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
            <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Settings Hub
        </a>
    </div>
</div>

<div style="display:grid; grid-template-columns:1.5fr 1fr; gap:24px; align-items:start;">

    <!-- ==========================================
         A. BRANCH DIRECTORY TABLE
         ========================================== -->
    <div class="card">
        <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-buildings" style="color:var(--accent);"></i>
                <span>Registered Branch Outlets</span>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Outlet / Name</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th style="text-align:center;">Users</th>
                        <th style="text-align:center;">Stock Items</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($branches as $b): ?>
                        <tr class="animate-fade">
                            <td><code>#<?php echo $b['id']; ?></code></td>
                            <td><strong><?php echo htmlspecialchars($b['name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($b['phone']); ?></td>
                            <td style="font-size:12px; color:var(--text-muted);"><?php echo htmlspecialchars($b['address']); ?></td>
                            <td style="text-align:center; font-weight:700;"><?php echo $b['total_users']; ?></td>
                            <td style="text-align:center; font-weight:700; color:var(--accent);"><?php echo $b['total_products']; ?></td>
                            <td>
                                <span style="font-size: 10px; font-weight:700; padding:2px 8px; border-radius:4px; 
                                    background: <?php echo ($b['status'] === 'ACTIVE') ? 'var(--success-glow)' : 'var(--danger-glow)'; ?>; 
                                    color: <?php echo ($b['status'] === 'ACTIVE') ? 'var(--success)' : 'var(--danger)'; ?>;">
                                    <?php echo $b['status']; ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($b['id'] > 1): ?>
                                    <form method="POST" action="branches.php" style="display:inline;">
                                        <input type="hidden" name="action" value="toggle">
                                        <input type="hidden" name="id" value="<?php echo $b['id']; ?>">
                                        <input type="hidden" name="status" value="<?php echo $b['status']; ?>">
                                        <button type="submit" class="btn btn-sm" style="height:28px; width:auto; font-size:11px; padding:0 8px; background:var(--bg-secondary); border-color:var(--border-color); color:var(--text-main);">
                                            Toggle Status
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span style="font-size:11px; color:var(--text-muted); font-style:italic;">Protected</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ==========================================
         B. REGISTER NEW BRANCH OUTLET
         ========================================== -->
    <div class="card" style="position:sticky; top:20px;">
        <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-plus-circle" style="color:var(--accent);"></i>
                <span>Register ERP Branch Outlet</span>
            </div>
        </div>

        <form method="POST" action="branches.php" style="display:flex; flex-direction:column; gap:16px;">
            <input type="hidden" name="action" value="add">

            <div>
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Branch Name *</label>
                <input type="text" name="name" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;" required placeholder="e.g. Gwadar Port Outlet">
            </div>

            <div>
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Branch Phone</label>
                <input type="text" name="phone" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;" placeholder="e.g. +92 300 1234567">
            </div>

            <div>
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Branch Location Address</label>
                <textarea name="address" style="width:100%; height:60px; padding:12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px; font-family:inherit; resize:none;" placeholder="Store physical coordinates..."></textarea>
            </div>

            <button type="submit" class="btn" style="background:var(--accent); border-color:var(--accent); height:40px; font-weight:700; width:100%;">
                <i class="bx bx-save" style="margin-right:4px;"></i> Save Branch
            </button>
        </form>
    </div>

</div>

<?php require_once 'includes/footer.php'; ?>
