<?php
/**
 * Multi-Branch ERP Subsystem - Central Routing Engine (Module 6)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

class MultiBranchEngine {
    private $db;

    public function __construct($dbConnection = null) {
        $this->db = $dbConnection ?: (new Database())->connect();
        $this->selfHealAndUpgradeSchema();
    }

    /**
     * Self-heals the branch tables and alters standard ERP schemas dynamically
     */
    private function selfHealAndUpgradeSchema() {
        try {
            $this->db->query("SELECT 1 FROM branches LIMIT 1");
        } catch (PDOException $e) {
            try {
                $this->db->exec("CREATE TABLE IF NOT EXISTS `branches` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `name` VARCHAR(100) NOT NULL,
                    `address` VARCHAR(255) DEFAULT NULL,
                    `phone` VARCHAR(50) DEFAULT NULL,
                    `status` ENUM('ACTIVE', 'INACTIVE') NOT NULL DEFAULT 'ACTIVE',
                    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

                $this->db->exec("INSERT IGNORE INTO `branches` (`id`, `name`, `address`, `phone`, `status`) VALUES 
                    (1, 'Central Head Office', 'Lahore, Pakistan', '+92 42 111-222-333', 'ACTIVE'),
                    (2, 'Karachi Branch', 'Clifton, Karachi, Pakistan', '+92 21 345-678-901', 'ACTIVE'),
                    (3, 'Quetta Branch', 'Jinnah Road, Quetta, Pakistan', '+92 81 234-567-890', 'ACTIVE')");

                // Safely update users, products, sales, and purchases
                $this->db->exec("ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `branch_id` INT NOT NULL DEFAULT 1");
                $this->db->exec("ALTER TABLE `products` ADD COLUMN IF NOT EXISTS `branch_id` INT NOT NULL DEFAULT 1");
                $this->db->exec("ALTER TABLE `sales` ADD COLUMN IF NOT EXISTS `branch_id` INT NOT NULL DEFAULT 1");
                $this->db->exec("ALTER TABLE `purchases` ADD COLUMN IF NOT EXISTS `branch_id` INT NOT NULL DEFAULT 1");
                $this->db->exec("ALTER TABLE `stock_history` ADD COLUMN IF NOT EXISTS `branch_id` INT NOT NULL DEFAULT 1");

                // Stock Transfers table
                $this->db->exec("CREATE TABLE IF NOT EXISTS `stock_transfers` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `product_id` INT NOT NULL,
                    `from_branch_id` INT NOT NULL,
                    `to_branch_id` INT NOT NULL,
                    `qty` INT NOT NULL,
                    `status` ENUM('PENDING', 'APPROVED', 'REJECTED') NOT NULL DEFAULT 'PENDING',
                    `reference_no` VARCHAR(100) DEFAULT NULL,
                    `transfer_date` DATE NOT NULL,
                    `notes` TEXT DEFAULT NULL,
                    `created_by` INT NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            } catch (PDOException $ex) {}
        }
    }

    /**
     * Restricts query parameters dynamically based on User's branch assignment
     */
    public function getBranchFilterClause($prefix = '') {
        if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] === 'SUPERADMIN') {
            return " 1=1 "; // Superadmins can view across all company records
        }
        $branch_id = (int)($_SESSION['branch_id'] ?? 1);
        $field = !empty($prefix) ? "$prefix.branch_id" : "branch_id";
        return " $field = $branch_id ";
    }

    /**
     * Safe Inter-Branch Stock Transfer Handler
     */
    public function executeStockTransfer($productId, $fromBranch, $toBranch, $qty, $notes = '', $createdBy = 1) {
        if ($fromBranch == $toBranch) {
            throw new Exception("Source and target branches cannot be identical.");
        }
        if ($qty <= 0) {
            throw new Exception("Please specify a positive quantity to transfer.");
        }

        try {
            $this->db->beginTransaction();

            // 1. VERIFY SOURCE WAREHOUSE STOCK QUANTITY
            $chk = $this->db->prepare("SELECT stock_qty, name, sku FROM products WHERE id = :id AND branch_id = :branch_id LIMIT 1");
            $chk->execute(['id' => $productId, 'branch_id' => $fromBranch]);
            $sourceProduct = $chk->fetch(PDO::FETCH_ASSOC);

            if (!$sourceProduct || $sourceProduct['stock_qty'] < $qty) {
                throw new Exception("Insufficient stock in source branch. Available: " . ($sourceProduct['stock_qty'] ?? 0) . " pcs.");
            }

            // 2. CREATE / RETRIEVE RECEIVING BRANCH PRODUCT INSTANCE
            $get_target = $this->db->prepare("SELECT id FROM products WHERE sku = :sku AND branch_id = :branch_id LIMIT 1");
            $get_target->execute(['sku' => $sourceProduct['sku'], 'branch_id' => $toBranch]);
            $targetProduct = $get_target->fetch(PDO::FETCH_ASSOC);

            if (!$targetProduct) {
                // Duplicate product registry mapping to the target branch (Data isolation standards)
                $ins_target = $this->db->prepare("INSERT INTO products (branch_id, name, sku, purchase_price, sell_price, stock_qty, min_stock, category, status) 
                                                  SELECT :to_branch, name, sku, purchase_price, sell_price, 0, min_stock, category, status 
                                                  FROM products WHERE id = :id LIMIT 1");
                $ins_target->execute(['to_branch' => $toBranch, 'id' => $productId]);
                $targetProductId = $this->db->lastInsertId();
            } else {
                $targetProductId = $targetProduct['id'];
            }

            // 3. SHIFT STOCKS safely
            // Decrement source branch
            $dec = $this->db->prepare("UPDATE products SET stock_qty = stock_qty - :qty WHERE id = :id");
            $dec->execute(['qty' => $qty, 'id' => $productId]);

            // Increment target branch
            $inc = $this->db->prepare("UPDATE products SET stock_qty = stock_qty + :qty WHERE id = :id");
            $inc->execute(['qty' => $qty, 'id' => $targetProductId]);

            // 4. WRITE TRANSFER LOG VOUCHERS
            $ref_no = 'TRF-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(2)));
            $ins_transfer = $this->db->prepare("INSERT INTO stock_transfers (product_id, from_branch_id, to_branch_id, qty, status, reference_no, transfer_date, notes, created_by) 
                                                VALUES (:p_id, :from_b, :to_b, :qty, 'APPROVED', :ref, CURRENT_DATE(), :notes, :user)");
            $ins_transfer->execute([
                'p_id' => $productId,
                'from_b' => $fromBranch,
                'to_b' => $toBranch,
                'qty' => $qty,
                'ref' => $ref_no,
                'notes' => $notes,
                'user' => $createdBy
            ]);

            // 5. UPDATE STOCK HISTORIES
            $log_stock = $this->db->prepare("INSERT INTO stock_history (product_id, branch_id, qty_change, type, description, user_id) VALUES (:p_id, :b_id, :qty, :type, :desc, :user)");
            
            // Log Source decrement
            $log_stock->execute([
                'p_id' => $productId,
                'b_id' => $fromBranch,
                'qty' => -$qty,
                'type' => 'OUT',
                'desc' => "Inter-Branch Transfer Out to branch #$toBranch. Ref: $ref_no",
                'user' => $createdBy
            ]);

            // Log Target increment
            $log_stock->execute([
                'p_id' => $targetProductId,
                'b_id' => $toBranch,
                'qty' => $qty,
                'type' => 'IN',
                'desc' => "Inter-Branch Transfer In from branch #$fromBranch. Ref: $ref_no",
                'user' => $createdBy
            ]);

            $this->db->commit();
            return $ref_no;
        } catch (Exception $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            throw $e;
        }
    }
}
