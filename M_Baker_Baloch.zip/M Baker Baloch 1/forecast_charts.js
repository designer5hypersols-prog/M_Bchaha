/**
 * AI-Powered Sales Prediction & Forecasting - ChartJS Binder (Module 3)
 * Shop Name: M.BAKAR BALOCH
 */

document.addEventListener('DOMContentLoaded', () => {
    // ==========================================
    // CHART 1: SALES TREND AND PREDICTION EXTENSION
    // ==========================================
    const trendCanvas = document.getElementById('forecastTrendChart');
    if (trendCanvas) {
        const months = JSON.parse(trendCanvas.getAttribute('data-months') || '[]');
        const sales = JSON.parse(trendCanvas.getAttribute('data-sales') || '[]').map(Number);
        const forecast = parseFloat(trendCanvas.getAttribute('data-forecast') || '0');

        // Append forecast month placeholder
        const nextMonth = getNextMonthLabel(months[months.length - 1] || '2026-05');
        const chartLabels = [...months, nextMonth + ' (AI Prediction)'];
        
        // Solid line for past months, null for forecast month to break solid line
        const pastDataset = [...sales, null];
        
        // Nulls for past months, forecast value for the end month to connect the line in dashed format
        const forecastDataset = Array(sales.length).fill(null);
        forecastDataset[sales.length - 1] = sales[sales.length - 1]; // connect the last point
        forecastDataset.push(forecast);

        const ctx = trendCanvas.getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: chartLabels,
                datasets: [
                    {
                        label: 'Historical Sales Turnover (Rs.)',
                        data: pastDataset,
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.05)',
                        borderWidth: 3,
                        pointBackgroundColor: '#10b981',
                        fill: true,
                        tension: 0.3
                    },
                    {
                        label: 'Predicted Sales Extension (Rs.)',
                        data: forecastDataset,
                        borderColor: '#0ea5e9',
                        borderDash: [6, 6],
                        borderWidth: 3,
                        pointBackgroundColor: '#0ea5e9',
                        pointRadius: 6,
                        fill: false,
                        tension: 0.3
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: { color: '#8292a6', font: { family: 'Plus Jakarta Sans', weight: '600' } }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Rs. ' + context.raw.toLocaleString();
                            }
                        }
                    }
                },
                scales: {
                    x: { ticks: { color: '#8292a6' }, grid: { display: false } },
                    y: { ticks: { color: '#8292a6' }, grid: { color: 'rgba(255,255,255,0.03)' } }
                }
            }
        });
    }

    // ==========================================
    // CHART 2: PRODUCT PERFORMANCE VELOCITIES
    // ==========================================
    const velocityCanvas = document.getElementById('productVelocityChart');
    if (velocityCanvas) {
        const names = JSON.parse(velocityCanvas.getAttribute('data-names') || '[]');
        const sold = JSON.parse(velocityCanvas.getAttribute('data-sold') || '[]').map(Number);

        // Truncate long product names for clean visual presentation
        const shortNames = names.map(n => n.length > 15 ? n.substring(0, 15) + '...' : n);

        const ctx = velocityCanvas.getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: shortNames,
                datasets: [{
                    label: 'Units Sold (Qty)',
                    data: sold,
                    backgroundColor: 'rgba(16, 185, 129, 0.85)',
                    hoverBackgroundColor: '#10b981',
                    borderRadius: 8,
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    x: { ticks: { color: '#8292a6' }, grid: { display: false } },
                    y: { ticks: { color: '#8292a6' }, grid: { color: 'rgba(255,255,255,0.03)' } }
                }
            }
        });
    }

    /**
     * Helper: Generate next month calendar label
     */
    function getNextMonthLabel(lastMonthStr) {
        try {
            const parts = lastMonthStr.split('-');
            let year = parseInt(parts[0]);
            let month = parseInt(parts[1]);

            month++;
            if (month > 12) {
                month = 1;
                year++;
            }

            const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            return monthNames[month - 1] + ' ' + year;
        } catch (e) {
            return 'Next Month';
        }
    }
});
