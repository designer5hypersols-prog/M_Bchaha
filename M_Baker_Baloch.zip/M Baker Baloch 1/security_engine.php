<?php
/**
  * Advanced Security & Audit Trail System - Security Engine
  * Shop Name: M.BAKAR BALOCH
  */

class SecurityEngine {
    private static $db = null;
    private static $lockout_threshold = 5;      // Lock login after 5 failed tries
    private static $lockout_duration = 900;     // Lockout duration: 15 minutes (900s)
    private static $session_timeout = 1800;     // Session timeout: 30 minutes (1800s)

    private static function initDB() {
        if (self::$db === null) {
            require_once __DIR__ . '/config/database.php';
            self::$db = (new Database())->connect();
            self::checkAndCreateTables();
        }
    }

    private static function checkAndCreateTables() {
        try {
            // 1. login_attempts table
            self::$db->exec("CREATE TABLE IF NOT EXISTS `login_attempts` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `username` VARCHAR(100) NOT NULL,
                `ip_address` VARCHAR(45) NOT NULL,
                `attempts_count` INT NOT NULL DEFAULT 1,
                `last_attempt_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                `locked_until` TIMESTAMP NULL DEFAULT NULL,
                UNIQUE KEY `user_ip` (`username`, `ip_address`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            // 2. user_sessions table
            self::$db->exec("CREATE TABLE IF NOT EXISTS `user_sessions` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT NOT NULL,
                `session_token` VARCHAR(255) NOT NULL UNIQUE,
                `ip_address` VARCHAR(45) NOT NULL,
                `device_info` TEXT NOT NULL,
                `login_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `last_active_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                `is_forced_logout` TINYINT(1) NOT NULL DEFAULT 0,
                FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        } catch (PDOException $e) {}
    }

    /**
     * Check if the user/IP is currently locked out
     */
    public static function checkLoginLimits($username, $ip) {
        self::initDB();
        try {
            $stmt = self::$db->prepare("SELECT attempts_count, locked_until FROM login_attempts WHERE username = :u AND ip_address = :ip LIMIT 1");
            $stmt->execute(['u' => $username, 'ip' => $ip]);
            $row = $stmt->fetch();

            if ($row) {
                if ($row['locked_until'] !== null) {
                    $locked_time = strtotime($row['locked_until']);
                    if (time() < $locked_time) {
                        return [
                            'is_locked' => true,
                            'remaining' => $locked_time - time()
                        ];
                    } else {
                        // Lock expired, reset attempts
                        self::clearAttempts($username, $ip);
                    }
                }
            }
        } catch (PDOException $e) {}

        return ['is_locked' => false, 'remaining' => 0];
    }

    /**
     * Record a failed login attempt, lock account if threshold reached
     */
    public static function recordFailedAttempt($username, $ip) {
        self::initDB();
        try {
            $stmt = self::$db->prepare("SELECT id, attempts_count FROM login_attempts WHERE username = :u AND ip_address = :ip LIMIT 1");
            $stmt->execute(['u' => $username, 'ip' => $ip]);
            $row = $stmt->fetch();

            if ($row) {
                $new_count = $row['attempts_count'] + 1;
                $locked_until = null;

                if ($new_count >= self::$lockout_threshold) {
                    $locked_until = date('Y-m-d H:i:s', time() + self::$lockout_duration);
                }

                $update = self::$db->prepare("UPDATE login_attempts 
                                             SET attempts_count = :cnt, locked_until = :lck 
                                             WHERE id = :id");
                $update->execute([
                    'cnt' => $new_count,
                    'lck' => $locked_until,
                    'id' => $row['id']
                ]);
            } else {
                $insert = self::$db->prepare("INSERT INTO login_attempts (username, ip_address, attempts_count, locked_until) 
                                             VALUES (:u, :ip, 1, NULL)");
                $insert->execute(['u' => $username, 'ip' => $ip]);
            }
        } catch (PDOException $e) {}
    }

    /**
     * Clear login attempts upon successful login
     */
    public static function clearAttempts($username, $ip) {
        self::initDB();
        try {
            $stmt = self::$db->prepare("DELETE FROM login_attempts WHERE username = :u AND ip_address = :ip");
            $stmt->execute(['u' => $username, 'ip' => $ip]);
        } catch (PDOException $e) {}
    }

    /**
     * Register a new user session upon successful login
     */
    public static function registerSession($userId, $token) {
        self::initDB();
        require_once __DIR__ . '/audit_logger.php';
        $ip = AuditLogger::getIP();
        $dev = AuditLogger::getDeviceInfo();

        try {
            $stmt = self::$db->prepare("INSERT INTO user_sessions (user_id, session_token, ip_address, device_info) 
                                        VALUES (:uid, :tok, :ip, :dev)");
            $stmt->execute([
                'uid' => (int)$userId,
                'tok' => $token,
                'ip' => $ip,
                'dev' => $dev
            ]);
        } catch (PDOException $e) {}
    }

    /**
     * Verify session state, enforce inactivity timeout, and check force-logout status
     */
    public static function verifySessionState() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['user_id']) || !isset($_SESSION['session_token'])) {
            return;
        }

        self::initDB();
        $token = $_SESSION['session_token'];

        try {
            $stmt = self::$db->prepare("SELECT is_forced_logout, last_active_time FROM user_sessions WHERE session_token = :tok LIMIT 1");
            $stmt->execute(['tok' => $token]);
            $session = $stmt->fetch();

            if (!$session) {
                // Session token not in db, destroy
                self::forceClearLocalSession();
                return;
            }

            // 1. Check Force Logout Status
            if ($session['is_forced_logout'] == 1) {
                self::removeSessionFromDB($token);
                self::forceClearLocalSession("Your session was terminated remotely by an administrator.");
                return;
            }

            // 2. Check Idle Inactivity Timeout
            $last_active = strtotime($session['last_active_time']);
            if ((time() - $last_active) > self::$session_timeout) {
                self::removeSessionFromDB($token);
                self::forceClearLocalSession("Session expired due to inactivity. Please log in again.");
                return;
            }

            // Session is active: update last active timestamp
            $upd = self::$db->prepare("UPDATE user_sessions SET last_active_time = CURRENT_TIMESTAMP WHERE session_token = :tok");
            $upd->execute(['tok' => $token]);

        } catch (PDOException $e) {}
    }

    /**
     * Terminate session remotely
     */
    public static function terminateSession($sessionId) {
        self::initDB();
        try {
            $stmt = self::$db->prepare("UPDATE user_sessions SET is_forced_logout = 1 WHERE id = :id");
            $stmt->execute(['id' => (int)$sessionId]);
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Terminate all other sessions except current
     */
    public static function terminateAllSessions($userId, $exceptToken) {
        self::initDB();
        try {
            $stmt = self::$db->prepare("UPDATE user_sessions SET is_forced_logout = 1 WHERE user_id = :uid AND session_token != :tok");
            $stmt->execute(['uid' => (int)$userId, 'tok' => $exceptToken]);
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Remove session token from database
     */
    public static function removeSessionFromDB($token) {
        self::initDB();
        try {
            $stmt = self::$db->prepare("DELETE FROM user_sessions WHERE session_token = :tok");
            $stmt->execute(['tok' => $token]);
        } catch (PDOException $e) {}
    }

    /**
     * Helper to clear local cookie variables and forward to login page
     */
    private static function forceClearLocalSession($message = "") {
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
        
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if (!empty($message)) {
            $_SESSION['login_error'] = $message;
        }
        header("Location: login.php");
        exit;
    }

    /**
     * Validate password complexity criteria
     */
    public static function validatePasswordStrength($password) {
        if (strlen($password) < 8) {
            return "Password must be at least 8 characters long.";
        }
        if (!preg_match('/[A-Z]/', $password)) {
            return "Password must contain at least one uppercase letter.";
        }
        if (!preg_match('/[a-z]/', $password)) {
            return "Password must contain at least one lowercase letter.";
        }
        if (!preg_match('/[0-9]/', $password)) {
            return "Password must contain at least one numeric digit.";
        }
        if (!preg_match('/[^A-Za-z0-9]/', $password)) {
            return "Password must contain at least one special character.";
        }
        return true;
    }
}
