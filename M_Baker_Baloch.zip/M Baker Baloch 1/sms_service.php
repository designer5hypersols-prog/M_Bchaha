<?php
/**
 * Automated Notifications Subsystem - SMS Dispatcher (Module 2)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

class SMSService {
    private $db;
    private $sms_api_key;
    private $sms_sender_id;

    public function __construct($dbConnection = null) {
        $this->db = $dbConnection ?: (new Database())->connect();

        try {
            $raw = $this->db->query("SELECT key_name, key_value FROM settings WHERE key_name LIKE 'sms_%'")->fetchAll();
            $settings = [];
            foreach ($raw as $r) {
                $settings[$r['key_name']] = $r['key_value'];
            }
            $this->sms_api_key = $settings['sms_api_key'] ?? 'KEY_MOCK_SMS_API_MBAKAR';
            $this->sms_sender_id = $settings['sms_sender_id'] ?? 'MBAKAR';
        } catch(PDOException $e) {
            $this->sms_api_key = 'KEY_MOCK_SMS_API_MBAKAR';
            $this->sms_sender_id = 'MBAKAR';
        }
    }

    /**
     * Send fallback text message
     */
    public function sendSMSMessage($customerId, $recipient, $messageText) {
        // Normalize number format (remove starting 0 and prefix +92 for Pakistan)
        $normalized_phone = preg_replace('/^0/', '+92', trim($recipient));
        if (!str_starts_with($normalized_phone, '+')) {
            $normalized_phone = '+' . $normalized_phone;
        }

        // 1. INSERT MESSAGE IN QUEUE
        $msg_id = 0;
        try {
            $ins = $this->db->prepare("INSERT INTO messages (customer_id, recipient_number, channel, message_text, status) 
                                       VALUES (:c_id, :phone, 'SMS', :msg, 'PENDING')");
            $ins->execute([
                'c_id' => $customerId ?: null,
                'phone' => $normalized_phone,
                'msg' => $messageText
            ]);
            $msg_id = $this->db->lastInsertId();
        } catch(PDOException $e) {}

        // If mock API key is set, simulate successful delivery (zero cost local simulation)
        if ($this->sms_api_key === 'KEY_MOCK_SMS_API_MBAKAR') {
            $this->logDelivery($msg_id, 'SENT', 'Local SMS Gateway Simulation Successful.');
            return true;
        }

        // 2. DISPATCH ACTUAL HTTP REQUEST (SMS GATEWAY INTEGRATION EXAMPLE)
        // Adjust endpoint URL depending on regional local SMS gateways
        $url = "https://api.sms-gateway-example.com/v1/send";
        $data = [
            'api_key' => $this->sms_api_key,
            'sender' => $this->sms_sender_id,
            'to' => $normalized_phone,
            'message' => $messageText
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($http_code === 200) {
            $this->logDelivery($msg_id, 'SENT', $response);
            return true;
        } else {
            $this->logDelivery($msg_id, 'FAILED', "SMS Gateway status $http_code: $response");
            return false;
        }
    }

    /**
     * Log details of message dispatch response
     */
    private function logDelivery($msgId, $status, $response) {
        if ($msgId <= 0) return;
        try {
            // Update queue status
            $upd = $this->db->prepare("UPDATE messages SET status = :status WHERE id = :id");
            $upd->execute(['status' => $status, 'id' => $msgId]);

            // Save log details
            $log = $this->db->prepare("INSERT INTO message_logs (message_id, gateway_response, status) VALUES (:m_id, :resp, :status)");
            $log->execute([
                'm_id' => $msgId,
                'resp' => substr($response, 0, 500),
                'status' => $status
            ]);
        } catch(PDOException $e) {}
    }
}
