<?php
/**
 * Automated Notifications Subsystem - Message Scheduler (Module 3)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'whatsapp_service.php';

class MessageScheduler {
    private $db;
    private $whatsapp;

    public function __construct($dbConnection = null) {
        $this->db = $dbConnection ?: (new Database())->connect();
        $this->whatsapp = new WhatsAppService($this->db);
    }

    /**
     * Dispatch automated reminders to all customers with outstanding udhar (dues)
     */
    public function dispatchDueReminders() {
        $log = "";
        try {
            // 1. FETCH ALL CUSTOMERS WITH PENDING BALANCES
            $stmt = $this->db->query("SELECT id, name, phone, balance FROM customers WHERE balance > 0");
            $debtors = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (empty($debtors)) {
                return "Scheduler run: No customers found with outstanding receivables.\n";
            }

            // 2. FETCH THE DUE REMINDER TEMPLATE
            $t_stmt = $this->db->prepare("SELECT message_body FROM templates WHERE template_key = 'DUE_REMINDER' LIMIT 1");
            $t_stmt->execute();
            $template = $t_stmt->fetchColumn();

            if (!$template) {
                $template = "Dear {{customer_name}}, you have a pending outstanding balance of Rs. {{balance}} at {{shop_name}}. Please settle it soon. Thank you!";
            }

            // 3. COMPILE AND SEND PERSONALIZED NOTIFICATIONS
            $sent_count = 0;
            foreach ($debtors as $debtor) {
                if (empty($debtor['phone'])) continue;

                // Replace placeholders
                $body = str_replace(
                    ['{{customer_name}}', '{{balance}}', '{{shop_name}}'],
                    [$debtor['name'], number_format($debtor['balance'], 2), 'M.BAKAR BALOCH'],
                    $template
                );

                // Dispatch WhatsApp Message (will automatically fallback to SMS if Twilio fails)
                $success = $this->whatsapp->sendWhatsAppMessage($debtor['id'], $debtor['phone'], $body);
                if ($success) {
                    $sent_count++;
                    $log .= "Sent reminder to " . $debtor['name'] . " (" . $debtor['phone'] . ") for Rs. " . number_format($debtor['balance'], 2) . "\n";
                }
            }

            return "Scheduler run complete: Successfully dispatched $sent_count out of " . count($debtors) . " outstanding balance reminders.\nDetails:\n" . $log;

        } catch (PDOException $e) {
            return "Scheduler run failed: " . $e->getMessage() . "\n";
        }
    }
}
