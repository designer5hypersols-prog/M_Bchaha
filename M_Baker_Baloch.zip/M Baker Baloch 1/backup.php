<?php
/**
 * Settings & Admin Control Subsystem - Backup & Restore Manager (Module 6)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = sanitize($_GET['success'] ?? '');

// Enforce Admin Rights
if ($_SESSION['user_role'] !== 'ADMIN') {
    die("Access Denied: You must be an Administrator to access backup systems.");
}

// ==========================================
// ROUTE A: EXPORT DATABASE BACKUP (GET TRIGGER)
// ==========================================
if (isset($_GET['action']) && $_GET['action'] === 'download') {
    try {
        $tables = [];
        $result = $db->query("SHOW TABLES");
        while ($row = $result->fetch(PDO::FETCH_NUM)) {
            $tables[] = $row[0];
        }

        $sql_dump = "-- ==========================================================\n";
        $sql_dump .= "-- M.BAKAR BALOCH SHOP MANAGEMENT SYSTEM - DATABASE BACKUP\n";
        $sql_dump .= "-- Date Compiled: " . date('Y-m-d H:i:s') . "\n";
        $sql_dump .= "-- ==========================================================\n\n";
        $sql_dump .= "SET FOREIGN_KEY_CHECKS=0;\n\n";

        foreach ($tables as $table) {
            // Fetch CREATE TABLE statement
            $stmt = $db->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_ASSOC);
            $sql_dump .= "DROP TABLE IF EXISTS `$table`;\n";
            $sql_dump .= $stmt['Create Table'] . ";\n\n";

            // Fetch table rows
            $rows_stmt = $db->query("SELECT * FROM `$table`");
            while ($row = $rows_stmt->fetch(PDO::FETCH_ASSOC)) {
                $keys = array_map(function($k) { return "`$k`"; }, array_keys($row));
                $values = array_map(function($v) use ($db) {
                    if ($v === null) return "NULL";
                    return $db->quote($v);
                }, array_values($row));

                $sql_dump .= "INSERT INTO `$table` (" . implode(', ', $keys) . ") VALUES (" . implode(', ', $values) . ");\n";
            }
            $sql_dump .= "\n";
        }

        $sql_dump .= "SET FOREIGN_KEY_CHECKS=1;\n";

        // Force browser download
        $filename = "mbakar_baloch_backup_" . date('Y-m-d_His') . ".sql";
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($sql_dump));
        echo $sql_dump;
        
        // Log administrative activity
        $log = $db->prepare("INSERT INTO activity_logs (user_id, action, target) VALUES (:user_id, 'DOWNLOAD_BACKUP', :target)");
        $log->execute(['user_id' => $_SESSION['user_id'], 'target' => $filename]);
        exit;

    } catch (Exception $e) {
        $error_message = "Backup compile failed: " . $e->getMessage();
    }
}

// ==========================================
// ROUTE B: IMPORT DATABASE RESTORE (POST TRIGGER)
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'restore') {
    if (!isset($_FILES['backup_file']) || $_FILES['backup_file']['error'] !== UPLOAD_ERR_OK) {
        $error_message = "Please upload a valid SQL database backup file.";
    } else {
        $file_path = $_FILES['backup_file']['tmp_name'];
        try {
            $sql_content = file_get_contents($file_path);
            
            // Execute statements
            $db->exec("SET FOREIGN_KEY_CHECKS=0;");
            
            // Simple split by semicolon (since standard dumps use semi-colons for endings)
            // Splitting safely ignoring semicolons inside strings is complex, but standard PDO allows running raw blocks!
            $db->exec($sql_content);
            $db->exec("SET FOREIGN_KEY_CHECKS=1;");

            // Log administrative activity
            $log = $db->prepare("INSERT INTO activity_logs (user_id, action, target) VALUES (:user_id, 'RESTORE_BACKUP', :target)");
            $log->execute(['user_id' => $_SESSION['user_id'], 'target' => $_FILES['backup_file']['name']]);

            header("Location: backup.php?success=" . urlencode("Database backup successfully restored. Current inventories and billing logs updated."));
            exit;

        } catch (Exception $e) {
            $error_message = "Database restore failed: " . $e->getMessage();
        }
    }
}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<!-- Action Notifications -->
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo $error_message; ?></span>
    </div>
<?php endif; ?>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success">
        <i class="bx bx-check-circle"></i>
        <span><?php echo $success_message; ?></span>
    </div>
<?php endif; ?>

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <a href="settings.php#subsystems_link" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
            <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Settings Hub
        </a>
    </div>
</div>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
    
    <!-- Left panel: Database Backup -->
    <div class="card">
        <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-cloud-download" style="color:var(--accent);"></i>
                <span>One-Click Database Backup</span>
            </div>
        </div>

        <p style="font-size:13.5px; color:var(--text-secondary); line-height:1.6; margin-bottom:20px;">
            Compile and download a complete structural and data backup of your entire <strong>M.BAKAR BALOCH</strong> database. 
            This backup file (.sql) includes products, stock logs, customers ledgers, suppliers ledgers, cashier settings, and invoices logs.
        </p>

        <div style="background:var(--input-bg); padding:12px; border:1px solid var(--border-color); border-radius:var(--radius-sm); margin-bottom:25px; font-size:12.5px; color:var(--text-secondary);">
            <i class="bx bx-info-circle" style="color:var(--accent); margin-right:4px;"></i> It is highly recommended to download database backups daily to secure your inventory logs.
        </div>

        <a href="backup.php?action=download" class="btn" style="text-decoration:none; display:inline-flex; align-items:center; justify-content:center; height:46px; font-weight:700; width:100%;">
            <i class="bx bx-download" style="margin-right:8px; font-size:18px;"></i> Download Backup File (.SQL)
        </a>
    </div>

    <!-- Right panel: Database Restore -->
    <div class="card" style="border-left:4px solid var(--error);">
        <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-cloud-upload" style="color:var(--error);"></i>
                <span style="color:var(--error);">Restore Database from File</span>
            </div>
        </div>

        <p style="font-size:13.5px; color:var(--text-secondary); line-height:1.6; margin-bottom:20px;">
            Upload an existing database backup file (.sql) to restore the system state. 
            <strong>WARNING!</strong> This operation will completely drop current tables and restore the selected data backup files.
        </p>

        <form method="POST" action="backup.php" enctype="multipart/form-data" onsubmit="return confirmDatabaseRestore()">
            <input type="hidden" name="action" value="restore">

            <div class="form-group" style="margin-bottom:25px;">
                <label class="form-label">Upload Backup SQL File *</label>
                <input type="file" name="backup_file" class="form-control" style="padding-top:10px; height:46px;" required accept=".sql">
            </div>

            <button type="submit" class="btn" style="background:var(--error); border-color:var(--error); height:46px; font-weight:700; width:100%;">
                <i class="bx bx-refresh" style="margin-right:8px; font-size:18px;"></i> Restore System Now
            </button>
        </form>
    </div>

</div>

<!-- Subsystem JS -->
<script src="settings.js"></script>

<?php require_once 'includes/footer.php'; ?>
