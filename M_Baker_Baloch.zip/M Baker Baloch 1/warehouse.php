<?php
/**
  * Warehouse & Location-Based Inventory System - Warehouses CRUD Registry
  * Shop Name: M.BAKAR BALOCH
  */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';
require_once 'location_engine.php';
require_once 'audit_logger.php';

// Enforce admin/manager role
if ($_SESSION['role'] !== 'SUPERADMIN' && $_SESSION['role'] !== 'ADMIN' && $_SESSION['role'] !== 'MANAGER') {
    die("Access Denied: You do not have permissions to manage warehouse structures.");
}

$db = (new Database())->connect();
$message = '';
$error = '';

// Programmatic initialization
$loc_engine = new LocationEngine();

// Handle Add Warehouse
if (isset($_POST['action']) && $_POST['action'] === 'add') {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        $error = "CSRF Token Validation Failed.";
    } else {
        $name = sanitize($_POST['name']);
        $address = sanitize($_POST['address']);
        $capacity = (int)$_POST['capacity'];
        $branch_id = isset($_SESSION['branch_id']) && $_SESSION['branch_id'] > 0 ? (int)$_SESSION['branch_id'] : null;

        if (empty($name)) {
            $error = "Warehouse Name cannot be empty.";
        } else {
            try {
                $stmt = $db->prepare("INSERT INTO warehouses (name, address, capacity, branch_id, status) VALUES (:name, :addr, :cap, :bid, 'ACTIVE')");
                $stmt->execute([
                    'name' => $name,
                    'addr' => $address,
                    'cap' => $capacity,
                    'bid' => $branch_id
                ]);
                AuditLogger::logActivity("CREATE", "Registered new warehouse storehouse: " . $name . " with capacity " . $capacity);
                $message = "Warehouse registered successfully!";
            } catch (PDOException $e) {
                $error = "Failed to register warehouse: " . $e->getMessage();
            }
        }
    }
}

// Fetch Warehouses and their current occupancy levels
$warehouses = [];
try {
    $stmt = $db->query("SELECT w.*, 
                               COALESCE(SUM(pl.qty), 0) as current_occupancy,
                               COUNT(DISTINCT pl.product_id) as unique_products_count
                        FROM warehouses w
                        LEFT JOIN product_locations pl ON w.id = pl.warehouse_id
                        GROUP BY w.id
                        ORDER BY w.name ASC");
    $warehouses = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Custom CSS -->
<link rel="stylesheet" href="settings.css">
<style>
    .wh-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
        gap: 20px;
    }
    .wh-card {
        background: var(--bg-secondary);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-sm);
        padding: 24px;
        position: relative;
        transition: all 0.2s ease;
    }
    .wh-card:hover {
        border-color: var(--accent);
        box-shadow: 0 4px 15px rgba(0,0,0,0.02);
    }
    .progress-bar-container {
        width: 100%;
        height: 8px;
        background: var(--bg-primary);
        border-radius: 4px;
        overflow: hidden;
        margin: 15px 0 6px 0;
    }
    .progress-bar-fill {
        height: 100%;
        background: var(--accent);
        border-radius: 4px;
        transition: width 0.4s ease;
    }
    .progress-bar-fill.warning { background: var(--warning); }
    .progress-bar-fill.danger { background: var(--danger); }
</style>

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="margin: 0; font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Warehouses Registry</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Manage physical stock locations, address records, and storage limits.</p>
    </div>
    <div style="display: flex; gap: 10px;">
        <a href="locations.php" class="btn btn-secondary btn-sm" style="width: auto;">
            <i class="bx bx-cabinet"></i> Shelves Divider Grid
        </a>
        <a href="warehouse_dashboard.php" class="btn btn-secondary btn-sm" style="width: auto;">
            <i class="bx bx-map-alt"></i> Logistics Dashboard
        </a>
    </div>
</div>

<!-- Alerts -->
<?php if ($message): ?>
    <div class="alert alert-success animate-fade"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-danger animate-fade"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<!-- ==========================================
     LAYOUT: CRUD & REGISTRY
     ========================================== -->
<div style="display: grid; grid-template-columns: 1fr 2fr; gap: 24px; align-items: start;">

    <!-- Left: Add form -->
    <div class="card">
        <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-plus-circle" style="color:var(--accent);"></i>
                <span>Register Warehouse</span>
            </div>
        </div>

        <form method="POST" action="warehouse.php" style="display:flex; flex-direction:column; gap:16px;">
            <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
            <input type="hidden" name="action" value="add">

            <div>
                <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">Warehouse Name</label>
                <input type="text" name="name" required placeholder="e.g. Central Box Depot" style="width: 100%; height: 38px; padding: 0 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none;">
            </div>

            <div>
                <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">Physical Address</label>
                <textarea name="address" rows="3" placeholder="Street details, town location..." style="width: 100%; padding: 10px 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none; font-family:inherit;"></textarea>
            </div>

            <div>
                <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">Storage Limit / Capacity (pcs)</label>
                <input type="number" name="capacity" value="10000" min="100" required style="width: 100%; height: 38px; padding: 0 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none;">
            </div>

            <button type="submit" class="btn" style="background: var(--accent); border-color: var(--accent); color: #fff;">
                Save Warehouse
            </button>
        </form>
    </div>

    <!-- Right: List Grid -->
    <div class="wh-grid">
        <?php foreach ($warehouses as $wh): 
            $pct = $wh['capacity'] > 0 ? ($wh['current_occupancy'] / $wh['capacity']) * 100 : 0;
            
            // Progress color
            $bar_class = '';
            if ($pct >= 90) $bar_class = 'danger';
            elseif ($pct >= 75) $bar_class = 'warning';
        ?>
            <div class="wh-card animate-fade">
                <h3 style="margin: 0 0 6px 0; font-size: 16px; font-weight: 700; color: var(--text-main);">
                    <?php echo htmlspecialchars($wh['name']); ?>
                </h3>
                <span style="font-size: 11.5px; color: var(--text-muted); display: block; margin-bottom: 12px;">
                    <i class="bx bx-map"></i> <?php echo htmlspecialchars($wh['address'] ?: 'No address specified'); ?>
                </span>

                <div style="font-size: 13px; color: var(--text-secondary); display: flex; flex-direction: column; gap: 6px;">
                    <div>Unique Items Cataloged: <strong><?php echo $wh['unique_products_count']; ?> articles</strong></div>
                    <div>Consolidated Volume: <strong><?php echo number_format($wh['current_occupancy']); ?> / <?php echo number_format($wh['capacity']); ?> units</strong></div>
                </div>

                <div class="progress-bar-container">
                    <div class="progress-bar-fill <?php echo $bar_class; ?>" style="width: <?php echo min($pct, 100); ?>%;"></div>
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 11px; color: var(--text-muted); font-weight: 600;">
                    <span>Occupancy Ratios</span>
                    <span><?php echo number_format($pct, 1); ?>% Filled</span>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

</div>

<?php require_once 'includes/footer.php'; ?>
