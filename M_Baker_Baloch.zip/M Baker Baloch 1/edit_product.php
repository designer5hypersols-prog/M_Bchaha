<?php
/**
 * Product Subsystem - Edit Product Processor
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = (new Database())->connect();

    $id = (int)($_POST['id'] ?? 0);
    $sku = sanitize($_POST['sku'] ?? '');
    $barcode = sanitize($_POST['barcode'] ?? '');
    $name = sanitize($_POST['name'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0);
    $brand = sanitize($_POST['brand'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    
    $purchase_price = (float)($_POST['purchase_price'] ?? 0);
    $sell_price = (float)($_POST['sell_price'] ?? 0);
    $stock_qty = (int)($_POST['stock_qty'] ?? 0);
    $min_stock_qty = (int)($_POST['min_stock_qty'] ?? 5);
    $unit = sanitize($_POST['unit'] ?? 'pcs');
    $supplier_name = sanitize($_POST['supplier_name'] ?? '');
    $status = sanitize($_POST['status'] ?? 'ACTIVE');

    // 1. Validations
    if ($id <= 0 || empty($sku) || empty($name) || $category_id <= 0 || $purchase_price <= 0 || $sell_price <= 0) {
        header("Location: products.php?error=" . urlencode("Please fill in SKU, Name, Category, and positive Prices."));
        exit;
    }

    try {
        // Check if SKU is used by another product
        $chk = $db->prepare("SELECT COUNT(*) FROM products WHERE sku = :sku AND id != :id");
        $chk->execute(['sku' => $sku, 'id' => $id]);
        if ($chk->fetchColumn() > 0) {
            header("Location: products.php?error=" . urlencode("A product with SKU '$sku' already exists in your registry."));
            exit;
        }

        // Fetch current product to check for existing image file
        $get_old = $db->prepare("SELECT image_path FROM products WHERE id = :id LIMIT 1");
        $get_old->execute(['id' => $id]);
        $old_img = $get_old->fetchColumn();

        // 2. Handle File Upload (New Image)
        $image_path = $old_img; // Default to keep existing image path
        if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            $file_extension = strtolower(pathinfo($_FILES['product_image']['name'], PATHINFO_EXTENSION));
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'webp'];

            if (in_array($file_extension, $allowed_extensions)) {
                $new_filename = uniqid('prod_', true) . '.' . $file_extension;
                $target_file = $upload_dir . $new_filename;

                if (move_uploaded_file($_FILES['product_image']['tmp_name'], $target_file)) {
                    $image_path = $target_file;

                    // Clean up old file to optimize disk space!
                    if (!empty($old_img) && file_exists($old_img)) {
                        unlink($old_img);
                    }
                }
            }
        }

        // 3. Database Prepared statement update
        $upd = $db->prepare("UPDATE products SET sku = :sku, barcode = :barcode, name = :name, category_id = :category_id, brand = :brand, purchase_price = :purchase, sell_price = :sell, stock_qty = :stock, min_stock_qty = :min_stock, unit = :unit, description = :desc, image_path = :image_path, supplier_name = :supplier_name, status = :status WHERE id = :id");
        
        $upd->execute([
            'sku' => $sku,
            'barcode' => $barcode,
            'name' => $name,
            'category_id' => $category_id,
            'brand' => $brand,
            'purchase' => $purchase_price,
            'sell' => $sell_price,
            'stock' => $stock_qty,
            'min_stock' => $min_stock_qty,
            'unit' => $unit,
            'desc' => $description,
            'image_path' => $image_path,
            'supplier_name' => $supplier_name,
            'status' => $status,
            'id' => $id
        ]);

        header("Location: products.php?success=" . urlencode("Product '$name' updated successfully."));
        exit;

    } catch (PDOException $e) {
        header("Location: products.php?error=" . urlencode("Database update failure: " . $e->getMessage()));
        exit;
    }
} else {
    header("Location: products.php");
    exit;
}
