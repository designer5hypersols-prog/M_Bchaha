<?php
/**
 * Cloud-Based Multi-Device Sync Subsystem - Token Authentication (Module 3)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

class AuthTokenSystem {
    private $db;

    public function __construct($dbConnection = null) {
        $this->db = $dbConnection ?: (new Database())->connect();
    }

    /**
     * Generate cryptographically secure API Token for client login
     */
    public function issueToken($userId, $expiryDays = 30) {
        $token = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', strtotime("+$expiryDays days"));

        try {
            $stmt = $this->db->prepare("INSERT INTO user_tokens (user_id, token, expires_at) VALUES (:u_id, :token, :expires)");
            $stmt->execute(['u_id' => $userId, 'token' => $token, 'expires' => $expiry]);
            return $token;
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Validate incoming REST API Bearer Token
     */
    public function validateRequestToken() {
        $token = $this->getBearerToken();
        if (!$token) {
            // Check fallback parameter
            $token = sanitize($_GET['api_token'] ?? $_POST['api_token'] ?? '');
        }

        if (empty($token)) {
            return false;
        }

        try {
            $stmt = $this->db->prepare("SELECT ut.*, u.id as u_id, u.username, u.role, u.status 
                                        FROM user_tokens ut 
                                        JOIN users u ON ut.user_id = u.id 
                                        WHERE ut.token = :token AND ut.expires_at > NOW() AND u.status = 'ACTIVE' 
                                        LIMIT 1");
            $stmt->execute(['token' => $token]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // Return authenticated user profile parameters
                return [
                    'id' => (int)$user['u_id'],
                    'username' => $user['username'],
                    'role' => $user['role']
                ];
            }
        } catch (PDOException $e) {}

        return false;
    }

    /**
     * Helper: Extract Bearer Token from HTTP Headers
     */
    private function getBearerToken() {
        $headers = $this->getAuthorizationHeader();
        if (!empty($headers)) {
            if (preg_match('/Bearer\s(\S+)/', $headers, $matches)) {
                return $matches[1];
            }
        }
        return null;
    }

    /**
     * Helper: Fetch HTTP Authorization Headers
     */
    private function getAuthorizationHeader() {
        $headers = null;
        if (isset($_SERVER['Authorization'])) {
            $headers = trim($_SERVER["Authorization"]);
        } elseif (isset($_SERVER['HTTP_AUTHORIZATION'])) {
            $headers = trim($_SERVER["HTTP_AUTHORIZATION"]);
        } elseif (function_exists('apache_request_headers')) {
            $requestHeaders = apache_request_headers();
            $requestHeaders = array_change_key_case($requestHeaders, CASE_UPPER);
            if (isset($requestHeaders['AUTHORIZATION'])) {
                $headers = trim($requestHeaders['AUTHORIZATION']);
            }
        }
        return $headers;
    }
}
