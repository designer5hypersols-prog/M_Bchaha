<?php
/**
 * Settings & Admin Control Subsystem - Central Settings (Module 10)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = "";

// 1. SELF-HEALING DATABASE MIGRATION CHECK FOR PERMISSIONS
try {
    $db->query("SELECT 1 FROM permissions LIMIT 1");
} catch (PDOException $e) {
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS `permissions` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `role` ENUM('ADMIN', 'MANAGER', 'CASHIER') NOT NULL,
            `module_name` VARCHAR(50) NOT NULL,
            `can_read` TINYINT(1) DEFAULT 1,
            `can_write` TINYINT(1) DEFAULT 0,
            `can_delete` TINYINT(1) DEFAULT 0,
            UNIQUE KEY `role_module` (`role`, `module_name`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        
        // Seed default permission nodes
        $db->exec("INSERT IGNORE INTO permissions (role, module_name, can_read, can_write, can_delete) VALUES 
            ('ADMIN', 'Dashboard', 1, 1, 1),
            ('ADMIN', 'Products', 1, 1, 1),
            ('ADMIN', 'Sales', 1, 1, 1),
            ('ADMIN', 'Purchases', 1, 1, 1),
            ('ADMIN', 'Reports', 1, 1, 1),
            ('ADMIN', 'Settings', 1, 1, 1),
            ('MANAGER', 'Dashboard', 1, 1, 0),
            ('MANAGER', 'Products', 1, 1, 0),
            ('MANAGER', 'Sales', 1, 1, 0),
            ('CASHIER', 'Dashboard', 1, 0, 0),
            ('CASHIER', 'Sales', 1, 1, 0)");
    } catch(PDOException $ex) {}
}

// 2. FORCE ADMINS ACCESS ONLY FOR GLOBAL CONFIGS
if ($_SESSION['user_role'] !== 'ADMIN') {
    die("Access Denied: You must be an Administrator to alter system settings.");
}

// 3. PROCESS POST SUBMISSIONS
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = sanitize($_POST['action'] ?? '');

    // Action A: General settings
    if ($action === 'general') {
        $configs = [
            'shop_name' => sanitize($_POST['shop_name'] ?? BRAND_NAME),
            'shop_phone' => sanitize($_POST['shop_phone'] ?? ''),
            'shop_email' => sanitize($_POST['shop_email'] ?? ''),
            'shop_address' => sanitize($_POST['shop_address'] ?? ''),
            'invoice_footer' => sanitize($_POST['invoice_footer'] ?? ''),
            'tax_rate' => (float)($_POST['tax_rate'] ?? 0.00)
        ];

        try {
            $upd = $db->prepare("INSERT INTO settings (key_name, key_value) VALUES (:key, :val) ON DUPLICATE KEY UPDATE key_value = :val");
            foreach ($configs as $k => $v) {
                $upd->execute(['key' => $k, 'val' => $v]);
            }
            
            // Log administrative activity
            $log = $db->prepare("INSERT INTO activity_logs (user_id, action, target) VALUES (:user_id, 'UPDATE_SETTINGS', 'General Shop Settings')");
            $log->execute(['user_id' => $_SESSION['user_id']]);

            $success_message = "General settings updated successfully.";
        } catch (PDOException $e) {
            $error_message = "Update failed: " . $e->getMessage();
        }
    }

    // Action B: Security Passwords modification
    if ($action === 'security') {
        $old_pass = $_POST['old_password'] ?? '';
        $new_pass = $_POST['new_password'] ?? '';
        
        try {
            $chk = $db->prepare("SELECT password FROM users WHERE id = :id LIMIT 1");
            $chk->execute(['id' => $_SESSION['user_id']]);
            $hash = $chk->fetchColumn();

            if (!password_verify($old_pass, $hash)) {
                $error_message = "Your current password verification failed. Please enter the correct password.";
            } else {
                $new_hash = password_hash($new_pass, PASSWORD_BCRYPT);
                $upd_p = $db->prepare("UPDATE users SET password = :hash WHERE id = :id");
                $upd_p->execute(['hash' => $new_hash, 'id' => $_SESSION['user_id']]);

                // Log administrative activity
                $log = $db->prepare("INSERT INTO activity_logs (user_id, action, target) VALUES (:user_id, 'CHANGE_PASSWORD', 'Admin Security Keys')");
                $log->execute(['user_id' => $_SESSION['user_id']]);

                $success_message = "Admin password updated successfully. Your new credentials are active.";
            }
        } catch (PDOException $e) {
            $error_message = "Password change failed: " . $e->getMessage();
        }
    }
}

// 4. LOAD GLOBAL KEY-VALUE CONFIGS
$settings = [];
try {
    $raw = $db->query("SELECT key_name, key_value FROM settings")->fetchAll();
    foreach ($raw as $row) {
        $settings[$row['key_name']] = $row['key_value'];
    }
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<!-- Action Notifications -->
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo $error_message; ?></span>
    </div>
<?php endif; ?>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success">
        <i class="bx bx-check-circle"></i>
        <span><?php echo $success_message; ?></span>
    </div>
<?php endif; ?>

<!-- ==========================================
     SETTINGS TABBED NAVIGATION PANEL
     ========================================== -->
<div class="settings-tabs-container">
    
    <!-- Left settings tabs list -->
    <div class="settings-tab-list">
        <button type="button" class="settings-tab-btn active" onclick="switchSettingsTab('general_settings')">
            <i class="bx bx-cog"></i> General Settings
        </button>
        <button type="button" class="settings-tab-btn" onclick="switchSettingsTab('security_settings')">
            <i class="bx bx-lock-alt"></i> Security & Keys
        </button>
        <button type="button" class="settings-tab-btn" onclick="switchSettingsTab('subsystems_link')">
            <i class="bx bx-grid-alt"></i> Subsystem Modules
        </button>
    </div>

    <!-- Right settings panel contents -->
    <div class="settings-tab-content" id="general_settings" style="display: block;">
        <h3 style="font-size:15px; font-weight:700; margin-bottom:15px; border-bottom:1.5px dashed var(--border-color); padding-bottom:8px;">General Configurations</h3>
        
        <form method="POST" action="settings.php">
            <input type="hidden" name="action" value="general">

            <div class="form-group">
                <label class="form-label">Shop Name / Business Title</label>
                <input type="text" name="shop_name" class="form-control" style="padding-left:12px; height:44px;" value="<?php echo htmlspecialchars($settings['shop_name'] ?? BRAND_NAME); ?>" required>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <div class="form-group">
                    <label class="form-label">Active Support Phone Number</label>
                    <input type="text" name="shop_phone" class="form-control" style="padding-left:12px; height:44px;" value="<?php echo htmlspecialchars($settings['shop_phone'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Business Email Address</label>
                    <input type="email" name="shop_email" class="form-control" style="padding-left:12px; height:44px;" value="<?php echo htmlspecialchars($settings['shop_email'] ?? ''); ?>">
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1.5fr 0.5fr; gap: 12px;">
                <div class="form-group">
                    <label class="form-label">Shop Address</label>
                    <input type="text" name="shop_address" class="form-control" style="padding-left:12px; height:44px;" value="<?php echo htmlspecialchars($settings['shop_address'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Global Tax Rate (%)</label>
                    <input type="number" step="0.01" name="tax_rate" class="form-control" style="padding-left:12px; height:44px;" value="<?php echo htmlspecialchars($settings['tax_rate'] ?? '0.00'); ?>" min="0">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Invoice Footer Greetings / Terms</label>
                <textarea name="invoice_footer" class="form-control" style="padding:10px; height:60px; resize:none;" placeholder="Thank you for shopping! Please keep this invoice receipt for returns."><?php echo htmlspecialchars($settings['invoice_footer'] ?? ''); ?></textarea>
            </div>

            <button type="submit" class="btn" style="height:46px; font-weight:700; width: auto; padding: 0 30px;">Save General Settings</button>
        </form>
    </div>

    <!-- Tab 2: Security & Password panel -->
    <div class="settings-tab-content" id="security_settings" style="display: none;">
        <h3 style="font-size:15px; font-weight:700; margin-bottom:15px; border-bottom:1.5px dashed var(--border-color); padding-bottom:8px;">Change Security Password</h3>
        
        <form method="POST" action="settings.php" onsubmit="return checkSettingsPasswordMatch(event)">
            <input type="hidden" name="action" value="security">

            <div class="form-group">
                <label class="form-label">Current Password *</label>
                <input type="password" name="old_password" class="form-control" style="padding-left:12px; height:44px;" required placeholder="Type current active password">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <div class="form-group">
                    <label class="form-label">New Password *</label>
                    <input type="password" id="new_password" name="new_password" class="form-control" style="padding-left:12px; height:44px;" required placeholder="Minimum 6 characters">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Verify New Password *</label>
                    <input type="password" id="confirm_password" class="form-control" style="padding-left:12px; height:44px;" required placeholder="Retype new password">
                </div>
            </div>

            <button type="submit" class="btn" style="height:46px; font-weight:700; width: auto; padding: 0 30px;">Update Password</button>
        </form>
    </div>

    <!-- Tab 3: Subsystem link modules panel -->
    <div class="settings-tab-content" id="subsystems_link" style="display: none;">
        <h3 style="font-size:15px; font-weight:700; margin-bottom:15px; border-bottom:1.5px dashed var(--border-color); padding-bottom:8px;">Subsystem Administrative Controls</h3>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 15px;">
            <!-- Users -->
            <a href="users.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-user" style="font-size: 28px; color: var(--accent);"></i>
                <span>User Registers Directory</span>
            </a>
            
            <!-- Permissions -->
            <a href="roles_permissions.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-shield-quarter" style="font-size: 28px; color: var(--accent);"></i>
                <span>Roles & Modules Rights</span>
            </a>

            <!-- Backups -->
            <a href="backup.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-cloud-download" style="font-size: 28px; color: var(--accent);"></i>
                <span>DB Backup & Restore</span>
            </a>

            <!-- Activity Logs -->
            <a href="logs.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-history" style="font-size: 28px; color: var(--accent);"></i>
                <span>Activity Audit Logs</span>
            </a>
        </div>

        <h3 style="font-size:15px; font-weight:700; margin-top:30px; margin-bottom:15px; border-bottom:1.5px dashed var(--border-color); padding-bottom:8px;">
            <i class="bx bx-calculator" style="color:var(--accent);"></i> Double Entry Accounting & Bookkeeping Ledger
        </h3>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 15px;">
            <!-- Chart of Accounts -->
            <a href="chart_of_accounts.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-book-bookmark" style="font-size: 28px; color: var(--accent);"></i>
                <span>Chart of Accounts</span>
            </a>

            <!-- Journal Entries -->
            <a href="journal_entries.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-receipt" style="font-size: 28px; color: var(--accent);"></i>
                <span>Journal Vouchers</span>
            </a>

            <!-- General Ledger -->
            <a href="general_ledger.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-list-ol" style="font-size: 28px; color: var(--accent);"></i>
                <span>General Ledger</span>
            </a>

            <!-- Trial Balance -->
            <a href="trial_balance.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-select-multiple" style="font-size: 28px; color: var(--accent);"></i>
                <span>Trial Balance</span>
            </a>

            <!-- Income Statement -->
            <a href="profit_loss_statement.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-file" style="font-size: 28px; color: var(--accent);"></i>
                <span>Profit & Loss</span>
            </a>

            <!-- Balance Sheet -->
            <a href="balance_sheet.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-chart" style="font-size: 28px; color: var(--accent);"></i>
                <span>Balance Sheet</span>
            </a>

            <!-- Cash Flow -->
            <a href="cash_flow.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-transfer-alt" style="font-size: 28px; color: var(--accent);"></i>
                <span>Cash Flow Statement</span>
            </a>
        </div>

        <h3 style="font-size:15px; font-weight:700; margin-top:30px; margin-bottom:15px; border-bottom:1.5px dashed var(--border-color); padding-bottom:8px;">
            <i class="bx bx-git-branch" style="color:var(--accent);"></i> Corporate Multi-Branch ERP Console
        </h3>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 15px;">
            <!-- Branch registry -->
            <a href="branches.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-buildings" style="font-size: 28px; color: var(--accent);"></i>
                <span>Branch Registry Outlets</span>
            </a>

            <!-- Stock Shift -->
            <a href="stock_transfer.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-transfer-alt" style="font-size: 28px; color: var(--accent);"></i>
                <span>Inter-Branch Stock Shift</span>
            </a>

            <!-- Corporate Dashboards -->
            <a href="central_dashboard.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-grid-alt" style="font-size: 28px; color: var(--accent);"></i>
                <span>Executive Central Board</span>
            </a>

            <!-- Comparative Audit reports -->
            <a href="branch_reports.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-analyse" style="font-size: 28px; color: var(--accent);"></i>
                <span>Corporate Comparative Audits</span>
            </a>
        </div>

        <h3 style="font-size:15px; font-weight:700; margin-top:30px; margin-bottom:15px; border-bottom:1.5px dashed var(--border-color); padding-bottom:8px;">
            <i class="bx bx-map-alt" style="color:var(--accent);"></i> Warehouse & Location-Based Logistics System
        </h3>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 15px;">
            <a href="warehouse_dashboard.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-map-alt" style="font-size: 28px; color: var(--accent);"></i>
                <span>Logistics Cockpit</span>
            </a>
            <a href="warehouse.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-buildings" style="font-size: 28px; color: var(--accent);"></i>
                <span>Warehouse Registry</span>
            </a>
            <a href="locations.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-grid" style="font-size: 28px; color: var(--accent);"></i>
                <span>Shelves Configuration</span>
            </a>
            <a href="stock_by_location.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-list-ul" style="font-size: 28px; color: var(--accent);"></i>
                <span>Shelf Placements</span>
            </a>
            <a href="transfer_stock.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-transfer-alt" style="font-size: 28px; color: var(--accent);"></i>
                <span>Stock Relocation Terminal</span>
            </a>
        </div>

        <h3 style="font-size:15px; font-weight:700; margin-top:30px; margin-bottom:15px; border-bottom:1.5px dashed var(--border-color); padding-bottom:8px;">
            <i class="bx bx-recode" style="color:var(--accent);"></i> Smart Procurement & Auto Reorder System
        </h3>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 15px;">
            <a href="auto_reorder.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-recode" style="font-size: 28px; color: var(--accent);"></i>
                <span>Auto Reorder Suggestions</span>
            </a>
        </div>

        <h3 style="font-size:15px; font-weight:700; margin-top:30px; margin-bottom:15px; border-bottom:1.5px dashed var(--border-color); padding-bottom:8px;">
            <i class="bx bx-shield-quarter" style="color:var(--accent);"></i> Advanced Auditing & Security Rooms
        </h3>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 15px;">
            <a href="security_dashboard.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-shield-quarter" style="font-size: 28px; color: var(--accent);"></i>
                <span>Security Health & Posture</span>
            </a>
            <a href="activity_logs.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-history" style="font-size: 28px; color: var(--accent);"></i>
                <span>Operator Activity Logs</span>
            </a>
            <a href="user_sessions.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-devices" style="font-size: 28px; color: var(--accent);"></i>
                <span>Active Staff Sessions</span>
            </a>
            <a href="audit_viewer.php" class="settings-tab-btn" style="text-decoration:none; display:flex; justify-content:center; align-items:center; flex-direction:column; gap:12px; height:120px;">
                <i class="bx bx-analyse" style="font-size: 28px; color: var(--accent);"></i>
                <span>Change History Explorer</span>
            </a>
        </div>
    </div>

</div>

<!-- Subsystem JS -->
<script src="settings.js"></script>

<?php require_once 'includes/footer.php'; ?>
