<?php
/**
 * Customer & Supplier Ledger Subsystem - Customers CRM Listing (Module 6)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = sanitize($_GET['success'] ?? '');

// 1. SELF-HEALING DATABASE MIGRATION CHECK
try {
    $db->query("SELECT 1 FROM customer_payments LIMIT 1");
} catch (PDOException $e) {
    // Table doesn't exist, execute migrations!
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS `customer_payments` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `customer_id` INT NOT NULL,
            `amount` DECIMAL(10, 2) NOT NULL,
            `payment_date` DATE NOT NULL,
            `payment_method` ENUM('CASH', 'BANK') NOT NULL DEFAULT 'CASH',
            `notes` TEXT DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (PDOException $ex) {}
}

// 2. PROCESS POST ADD CUSTOMER PROFILE
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $name = sanitize($_POST['name'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $address = sanitize($_POST['address'] ?? '');
    $balance = (float)($_POST['balance'] ?? 0.00);

    if (empty($name)) {
        $error_message = "Please input the customer full name.";
    } else {
        try {
            $ins = $db->prepare("INSERT INTO customers (name, phone, email, address, balance) VALUES (:name, :phone, :email, :address, :balance)");
            $ins->execute([
                'name' => $name,
                'phone' => $phone,
                'email' => $email,
                'address' => $address,
                'balance' => $balance
            ]);
            $success_message = "Customer '$name' registered successfully in databases.";
        } catch (PDOException $e) {
            $error_message = "Insert failure: " . $e->getMessage();
        }
    }
}

// 3. LOAD CUSTOMER PROFILES AND AGGREGATE LEDGERS
$search = sanitize($_GET['search'] ?? '');
$customers = [];
try {
    $query = "SELECT * FROM customers WHERE 1=1";
    $params = [];

    if (!empty($search)) {
        $query .= " AND (name LIKE :search OR phone LIKE :search OR address LIKE :search)";
        $params['search'] = "%$search%";
    }
    
    $query .= " ORDER BY name ASC";
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $raw_customers = $stmt->fetchAll();

    // Map aggregates
    foreach ($raw_customers as $c) {
        $id = $c['id'];
        
        // Sum total purchases invoices
        $total_purchases = $db->query("SELECT SUM(payable_amount) FROM sales WHERE customer_id = $id")->fetchColumn() ?: 0.00;
        
        // Sum total paid invoices + separate clearings installments
        $paid_invoices = $db->query("SELECT SUM(paid_amount) FROM sales WHERE customer_id = $id")->fetchColumn() ?: 0.00;
        $paid_clearings = $db->query("SELECT SUM(amount) FROM customer_payments WHERE customer_id = $id")->fetchColumn() ?: 0.00;
        
        $total_paid = $paid_invoices + $paid_clearings;

        $customers[] = [
            'id' => $id,
            'name' => $c['name'],
            'phone' => $c['phone'],
            'address' => $c['address'],
            'balance' => (float)$c['balance'],
            'total_purchases' => $total_purchases,
            'total_paid' => $total_paid
        ];
    }

    // AR Receivable
    $ar_dues = $db->query("SELECT SUM(balance) FROM customers")->fetchColumn() ?: 0.00;

} catch (PDOException $e) {
    $ar_dues = 0;
}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="ledger.css">

<!-- Action Notifications -->
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo $error_message; ?></span>
    </div>
<?php endif; ?>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success">
        <i class="bx bx-check-circle"></i>
        <span><?php echo $success_message; ?></span>
    </div>
<?php endif; ?>

<!-- ==========================================
     RECEIVABLES STAT CARD & ACTION HUB
     ========================================== -->
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 24px; align-items: center; flex-wrap: wrap;">
    <div class="stat-card danger" style="margin-bottom:0; max-width: 320px;">
        <div class="stat-info">
            <span>Outstanding Accounts Receivable</span>
            <h2><?php echo format_currency($ar_dues); ?></h2>
        </div>
        <div class="stat-icon"><i class="bx bx-wallet-toggle"></i></div>
    </div>
    
    <div style="display: flex; gap: 10px; justify-content: flex-end; height: 48px;">
        <button type="button" class="btn btn-secondary" style="width: auto;" onclick="openModal('settleCustomerModal')">
            <i class="bx bx-wallet"></i> Settle Due Installment
        </button>
        <button type="button" class="btn" style="width: auto;" onclick="openModal('addCustomerModal')">
            <i class="bx bx-plus-circle"></i> Register Customer Profile
        </button>
    </div>
</div>

<!-- Search box filter -->
<div class="search-filter-section" style="margin-bottom: 24px;">
    <form method="GET" action="customers.php" style="display: flex; width:100%;">
        <div class="search-input-group" style="max-width:100%;">
            <i class="bx bx-search"></i>
            <input type="text" name="search" class="search-control" placeholder="Search customer name, contact phone..." value="<?php echo htmlspecialchars($search); ?>">
        </div>
    </form>
</div>

<!-- ==========================================
     CUSTOMERS CRM RECORDS DIRECTORY GRID
     ========================================== -->
<div class="card">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Customer Name</th>
                    <th>Phone</th>
                    <th>Billing Address</th>
                    <th>Total Purchases</th>
                    <th>Total Paid</th>
                    <th>Remaining Balance (Dues)</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($customers)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; color: var(--text-muted); padding: 40px;">No customer records registered in databases.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach($customers as $c): ?>
                        <tr class="animate-fade">
                            <td><strong><?php echo htmlspecialchars($c['name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($c['phone'] ?: '-'); ?></td>
                            <td><span style="font-size: 12.5px; color:var(--text-secondary);"><?php echo htmlspecialchars($c['address'] ?: '-'); ?></span></td>
                            <td style="font-weight:600;"><?php echo format_currency($c['total_purchases']); ?></td>
                            <td style="font-weight:600; color:var(--accent);"><?php echo format_currency($c['total_paid']); ?></td>
                            <td>
                                <?php if ($c['balance'] > 0): ?>
                                    <span class="status-indicator due">Dues: <?php echo format_currency($c['balance']); ?></span>
                                <?php else: ?>
                                    <span class="status-indicator paid">Cleared</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="action-btns">
                                    <a href="customer_ledger.php?id=<?php echo $c['id']; ?>" class="btn-action" title="View Statement Ledger Timeline" style="display:inline-flex; align-items:center; justify-content:center; text-decoration:none;">
                                        <i class="bx bx-receipt"></i>
                                    </a>
                                    <button type="button" class="btn-action" title="WhatsApp Pay reminder alert" onclick="copyPaymentReminder('<?php echo addslashes($c['name']); ?>', '<?php echo $c['phone']; ?>', <?php echo $c['balance']; ?>)">
                                        <i class="bx bx-bell"></i>
                                    </button>
                                    <button type="button" class="btn-action" title="Quick pay dues settlement" onclick="triggerCustomerPayModal(<?php echo $c['id']; ?>, <?php echo $c['balance']; ?>)">
                                        <i class="bx bx-wallet"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ==========================================
     ADD CUSTOMER REGISTER MODAL OVERLAY
     ========================================== -->
<div id="addCustomerModal" class="modal-overlay">
    <div class="modal-content" style="max-width: 520px;">
        <div class="modal-header">
            <h3>Register New Customer Profile</h3>
            <i class="bx bx-x modal-close" onclick="closeModal('addCustomerModal')"></i>
        </div>

        <form method="POST" action="customers.php">
            <input type="hidden" name="action" value="add">

            <div class="form-group">
                <label class="form-label">Customer Full Name *</label>
                <input type="text" name="name" class="form-control" style="padding-left:12px; height:44px;" required placeholder="e.g. Muhammad Ali Baloch">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div class="form-group">
                    <label class="form-label">Phone Number</label>
                    <input type="text" name="phone" class="form-control" style="padding-left:12px; height:44px;" placeholder="03XXXXXXXXX">
                </div>
                <div class="form-group">
                    <label class="form-label">Email Address</label>
                    <input type="email" name="email" class="form-control" style="padding-left:12px; height:44px;" placeholder="ali@gmail.com">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Opening Credit Balance (Udhar Dues)</label>
                <input type="number" step="0.01" name="balance" class="form-control" style="padding-left:12px; height:44px;" value="0.00">
            </div>

            <div class="form-group">
                <label class="form-label">Business Address</label>
                <textarea name="address" class="form-control" style="padding:10px; height:60px; resize:none;" placeholder="Billing address..."></textarea>
            </div>

            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px; border-top:1.5px dashed var(--border-color); padding-top:15px;">
                <button type="button" class="btn btn-sm btn-secondary" onclick="closeModal('addCustomerModal')">Cancel</button>
                <button type="submit" class="btn btn-sm" style="width: auto;">Save Profile</button>
            </div>
        </form>
    </div>
</div>

<!-- ==========================================
     SETTLE CUSTOMER DUE MODAL OVERLAY
     ========================================== -->
<div id="settleCustomerModal" class="modal-overlay">
    <div class="modal-content" style="max-width: 520px;">
        <div class="modal-header">
            <h3>Settle Customer Due Balance installment</h3>
            <i class="bx bx-x modal-close" onclick="closeModal('settleCustomerModal')"></i>
        </div>

        <form method="POST" action="payments.php">
            <input type="hidden" name="type" value="customer">

            <div class="form-group">
                <label class="form-label">Select Registered Customer *</label>
                <select id="settle_customer_select" name="person_id" class="select-control" style="width:100%; height:44px;" required onchange="updateSelectedCustomerDues()">
                    <option value="">-- Choose Client Profile --</option>
                    <?php foreach($customers as $c): ?>
                        <option value="<?php echo $c['id']; ?>" data-dues="<?php echo $c['balance']; ?>">
                            <?php echo htmlspecialchars($c['name']); ?> [Credit Dues: <?php echo format_currency($c['balance']); ?>]
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group" style="padding: 10px; background:var(--input-bg); border:1px solid var(--border-color); border-radius:var(--radius-sm); margin-bottom:15px;">
                <span>Total Outstanding Credit Dues Balance:</span>
                <strong id="settleDuesLabel" style="color:var(--error); display:block; font-size:16px; margin-top:4px;">PKR 0.00</strong>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div class="form-group">
                    <label class="form-label">Received Cash Installment (PKR) *</label>
                    <input type="number" step="0.01" id="settle_payout_amount" name="amount" class="form-control" style="padding-left:12px; height:44px;" required placeholder="0.00">
                </div>
                <div class="form-group">
                    <label class="form-label">Payment Method</label>
                    <select name="payment_method" class="select-control" style="width:100%; height:44px;">
                        <option value="CASH">Cash Installment</option>
                        <option value="BANK">Online Bank / Card</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Installment Notes / Voucher Ref</label>
                <input type="text" name="notes" class="form-control" style="padding-left:12px; height:44px;" placeholder="Receipt voucher number...">
            </div>

            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px; border-top:1.5px dashed var(--border-color); padding-top:15px;">
                <button type="button" class="btn btn-sm btn-secondary" onclick="closeModal('settleCustomerModal')">Cancel</button>
                <button type="submit" class="btn btn-sm" style="width: auto;">Apply Payout</button>
            </div>
        </form>
    </div>
</div>

<script>
/**
 * Update selected client credit balance dues labels
 */
function updateSelectedCustomerDues() {
    const selector = document.getElementById('settle_customer_select');
    if (!selector) return;

    const opt = selector.options[selector.selectedIndex];
    if (!opt || opt.value === '') {
        document.getElementById('settleDuesLabel').innerText = 'PKR 0.00';
        return;
    }

    const dues = parseFloat(opt.getAttribute('data-dues') || 0);
    document.getElementById('settleDuesLabel').innerText = 'PKR ' + dues.toFixed(2);
    document.getElementById('settle_payout_amount').value = dues.toFixed(2);
}

/**
 * Quick trigger
 */
function triggerCustomerPayModal(id, balance) {
    document.getElementById('settle_customer_select').value = id;
    document.getElementById('settleDuesLabel').innerText = 'PKR ' + balance.toFixed(2);
    document.getElementById('settle_payout_amount').value = balance.toFixed(2);
    openModal('settleCustomerModal');
}
</script>

<!-- Subsystem JS -->
<script src="ledger.js"></script>

<?php require_once 'includes/footer.php'; ?>
