<?php
/**
 * Multi-Branch ERP Subsystem - Branch Comparative Reports (Module 5)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();

// Enforce Central Admin Access
if ($_SESSION['user_role'] !== 'SUPERADMIN' && $_SESSION['user_role'] !== 'ADMIN') {
    die("Access Denied: You must be a Super Administrator to view corporate central reports.");
}

$selected_branch_id = (int)($_GET['branch_id'] ?? 1);
$start_date = sanitize($_GET['start_date'] ?? date('Y-m-01'));
$end_date = sanitize($_GET['end_date'] ?? date('Y-m-d'));

$branch_details = null;
$branches = [];

$branch_revenue = 0.00;
$branch_purchases = 0.00;
$branch_expenses = 0.00;
$branch_sales_history = [];

try {
    $branches = $db->query("SELECT id, name FROM branches WHERE status = 'ACTIVE' ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

    // Fetch target branch info
    $b_stmt = $db->prepare("SELECT * FROM branches WHERE id = :id LIMIT 1");
    $b_stmt->execute(['id' => $selected_branch_id]);
    $branch_details = $b_stmt->fetch(PDO::FETCH_ASSOC);

    if ($branch_details) {
        // 1. Gather isolated sales revenues
        $s_stmt = $db->prepare("SELECT COALESCE(SUM(payable_amount), 0.00) FROM sales WHERE branch_id = :bid AND sale_date BETWEEN :start AND :end");
        $s_stmt->execute(['bid' => $selected_branch_id, 'start' => $start_date, 'end' => $end_date]);
        $branch_revenue = (float)$s_stmt->fetchColumn();

        // 2. Gather isolated stock procurement costings
        $p_stmt = $db->prepare("SELECT COALESCE(SUM(payable_amount), 0.00) FROM purchases WHERE branch_id = :bid AND purchase_date BETWEEN :start AND :end");
        $p_stmt->execute(['bid' => $selected_branch_id, 'start' => $start_date, 'end' => $end_date]);
        $branch_purchases = (float)$p_stmt->fetchColumn();

        // 3. Gather local operating expenses (mapped as operating expenses)
        $e_stmt = $db->prepare("SELECT COALESCE(SUM(amount), 0.00) FROM expenses WHERE expense_date BETWEEN :start AND :end");
        $e_stmt->execute(['start' => $start_date, 'end' => $end_date]);
        // For multi-branch isolated setups, rent/utilities are apportioned by branches, we can mock a local percentage or apportion evenly
        $total_active_branches = (int)$db->query("SELECT COUNT(*) FROM branches WHERE status = 'ACTIVE'")->fetchColumn() ?: 1;
        $branch_expenses = ((float)$e_stmt->fetchColumn()) / $total_active_branches; // apportioned operating expenses

        // 4. Fetch sales velocity timeline
        $sh_stmt = $db->prepare("SELECT sale_date, COUNT(*) as orders, SUM(payable_amount) as amount 
                                 FROM sales 
                                 WHERE branch_id = :bid AND sale_date BETWEEN :start AND :end 
                                 GROUP BY sale_date ORDER BY sale_date DESC LIMIT 30");
        $sh_stmt->execute(['bid' => $selected_branch_id, 'start' => $start_date, 'end' => $end_date]);
        $branch_sales_history = $sh_stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {}

$branch_net_profit = $branch_revenue - ($branch_purchases + $branch_expenses);

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<!-- ==========================================
     A. BRANCH SELECTOR BAR
     ========================================== -->
<div class="card" style="margin-bottom:24px; padding:16px;">
    <form method="GET" action="branch_reports.php" style="display:flex; gap:16px; align-items:flex-end; flex-wrap:wrap;">
        <div style="flex-grow:2; min-width:200px;">
            <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Select Branch Outlet</label>
            <select name="branch_id" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px; cursor:pointer;" required>
                <?php foreach($branches as $b): ?>
                    <option value="<?php echo $b['id']; ?>" <?php echo ($selected_branch_id == $b['id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($b['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div style="flex-grow:1; min-width:150px;">
            <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Start Date</label>
            <input type="date" name="start_date" value="<?php echo $start_date; ?>" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;">
        </div>

        <div style="flex-grow:1; min-width:150px;">
            <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">End Date</label>
            <input type="date" name="end_date" value="<?php echo $end_date; ?>" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;">
        </div>

        <div>
            <button type="submit" class="btn" style="background:var(--accent); border-color:var(--accent); height:40px; width:auto; font-size:13.5px; padding:0 24px;">
                <i class="bx bx-analyse" style="margin-right:4px;"></i> Compile Reports
            </button>
        </div>
    </form>
</div>

<!-- ==========================================
     B. REPORT SUMMARY VIEW
     ========================================== -->
<?php if ($branch_details): ?>
    <div style="display:grid; grid-template-columns: 1.5fr 1fr; gap: 24px; align-items:start;">

        <!-- Left: Sales Velocity Timeline -->
        <div class="card">
            <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color); display:flex; justify-content:space-between; align-items:center;">
                <div class="card-title">
                    <i class="bx bx-list-ol" style="color:var(--accent);"></i>
                    <span>Sales Velocity Timeline: <?php echo htmlspecialchars($branch_details['name']); ?></span>
                </div>
                <button type="button" class="btn btn-sm" onclick="window.print()" style="background:var(--bg-secondary); border-color:var(--border-color); height:30px; width:auto; font-size:11px; padding:0 12px; color:var(--text-main);">
                    <i class="bx bx-printer" style="margin-right:4px;"></i> Print
                </button>
            </div>

            <div class="table-responsive">
                <table class="table" style="--table-padding: 10px 12px; font-size: 13px;">
                    <thead>
                        <tr>
                            <th>Sales Date</th>
                            <th style="text-align:center;">Transactions</th>
                            <th style="text-align:right;">Turnover (Rs.)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($branch_sales_history)): ?>
                            <tr>
                                <td colspan="3" style="text-align: center; color: var(--text-muted); padding: 30px;">No sales checkouts recorded in this date range.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach($branch_sales_history as $hist): ?>
                                <tr class="animate-fade">
                                    <td><strong><?php echo format_date($hist['sale_date']); ?></strong></td>
                                    <td style="text-align:center; font-weight:700;"><?php echo $hist['orders']; ?> orders</td>
                                    <td style="text-align:right; font-weight:800; color:var(--accent);">
                                        Rs. <?php echo number_format($hist['amount'], 2); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Right: Branch Income Statement -->
        <div class="card" style="position:sticky; top:20px;">
            <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
                <div class="card-title">
                    <i class="bx bx-file" style="color:var(--accent);"></i>
                    <span>Branch Performance Audit</span>
                </div>
            </div>

            <div style="display:flex; flex-direction:column; gap:14px; font-size:13.5px;">
                <div style="display:flex; justify-content:space-between; border-bottom:1px solid var(--border-color); padding-bottom:6px;">
                    <span>Branch Operating Turnover:</span>
                    <strong>Rs. <?php echo number_format($branch_revenue, 2); ?></strong>
                </div>

                <div style="display:flex; justify-content:space-between; border-bottom:1px solid var(--border-color); padding-bottom:6px;">
                    <span>Branch Stock Purchases:</span>
                    <strong style="color:var(--warning);">- Rs. <?php echo number_format($branch_purchases, 2); ?></strong>
                </div>

                <div style="display:flex; justify-content:space-between; border-bottom:1px solid var(--border-color); padding-bottom:6px;">
                    <span>Branch Allocated Expenses:</span>
                    <strong style="color:var(--warning);">- Rs. <?php echo number_format($branch_expenses, 2); ?></strong>
                </div>

                <div style="display:flex; justify-content:space-between; padding:16px; background:var(--bg-secondary); border-radius:var(--radius-sm); border:1.5px solid <?php echo ($branch_net_profit >= 0) ? 'var(--accent)' : 'var(--danger)'; ?>; margin-top:20px;">
                    <strong style="font-size:14px;">Net contribution:</strong>
                    <strong style="font-size:18px; color:<?php echo ($branch_net_profit >= 0) ? 'var(--accent)' : 'var(--danger)'; ?>;">
                        Rs. <?php echo number_format($branch_net_profit, 2); ?>
                    </strong>
                </div>
            </div>
        </div>

    </div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
