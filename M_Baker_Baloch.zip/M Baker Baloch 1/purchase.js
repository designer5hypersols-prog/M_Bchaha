/**
 * Purchase & Stock Management Client Script
 * Shop Name: M.BAKAR BALOCH
 */

let purchaseCart = [];

document.addEventListener('DOMContentLoaded', () => {
    //
});

/**
 * Add item to active restocks cart
 */
function addProductToPurchase() {
    const selector = document.getElementById('purchaseProductSelect');
    if (!selector) return;

    const opt = selector.options[selector.selectedIndex];
    if (!opt || opt.value === '') return;

    const id = parseInt(opt.value);
    const name = opt.getAttribute('data-name');
    const sku = opt.getAttribute('data-sku');
    const cost = parseFloat(opt.getAttribute('data-cost') || 0);

    // Prevent duplicates in procurement lines
    const existing = purchaseCart.find(item => item.id === id);
    if (existing) {
        alert("This product is already added to the procurement list below.");
        return;
    }

    purchaseCart.push({
        id: id,
        name: name,
        sku: sku,
        cost: cost,
        qty: 1
    });

    renderPurchaseCart();
}

function removePurchaseItem(id) {
    purchaseCart = purchaseCart.filter(item => item.id !== id);
    renderPurchaseCart();
}

function updatePurchaseQty(id, value) {
    const item = purchaseCart.find(item => item.id === id);
    if (item) {
        item.qty = parseInt(value) || 1;
        if (item.qty < 1) item.qty = 1;
        recalculatePurchaseTotals();
    }
}

function updatePurchaseCost(id, value) {
    const item = purchaseCart.find(item => item.id === id);
    if (item) {
        item.cost = parseFloat(value) || 0.00;
        if (item.cost < 0) item.cost = 0;
        recalculatePurchaseTotals();
    }
}

/**
 * Output restocks to DOM table
 */
function renderPurchaseCart() {
    const list = document.getElementById('purchaseItemsList');
    if (!list) return;

    if (purchaseCart.length === 0) {
        list.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--text-muted); padding: 30px;">No products added to procurement sheet.</td></tr>`;
        recalculatePurchaseTotals();
        return;
    }

    list.innerHTML = '';
    purchaseCart.forEach(item => {
        const lineTotal = item.cost * item.qty;
        list.innerHTML += `
            <tr class="animate-fade">
                <td>
                    <strong>${item.name}</strong>
                    <span style="display:block; font-size:10px; color:var(--text-muted);">${item.sku}</span>
                </td>
                <td>
                    <input type="number" class="form-control" style="width: 80px; height: 36px; padding-left: 8px;" value="${item.qty}" min="1" onchange="updatePurchaseQty(${item.id}, this.value)">
                </td>
                <td>
                    <input type="number" step="0.01" class="form-control" style="width: 100px; height: 36px; padding-left: 8px;" value="${item.cost.toFixed(2)}" min="0" onchange="updatePurchaseCost(${item.id}, this.value)">
                </td>
                <td style="font-weight: 600;">PKR ${lineTotal.toFixed(2)}</td>
                <td>
                    <i class="bx bx-trash" style="color:var(--error); cursor:pointer;" onclick="removePurchaseItem(${item.id})"></i>
                </td>
            </tr>
        `;
    });

    recalculatePurchaseTotals();
}

/**
 * Live math calculations
 */
function recalculatePurchaseTotals() {
    let subtotal = 0;
    purchaseCart.forEach(item => {
        subtotal += item.cost * item.qty;
    });

    const discount = parseFloat(document.getElementById('discountInput').value) || 0;
    
    let grandTotal = subtotal - discount;
    if (grandTotal < 0) grandTotal = 0;

    const paid = parseFloat(document.getElementById('paidInput').value) || 0;
    const due = grandTotal - paid;

    // Fill UI
    document.getElementById('subtotalLabel').innerText = 'PKR ' + subtotal.toFixed(2);
    document.getElementById('payableLabel').innerText = 'PKR ' + grandTotal.toFixed(2);
    
    const dueLabel = document.getElementById('dueLabel');
    if (dueLabel) {
        if (due >= 0) {
            dueLabel.innerText = 'Dues Owed: PKR ' + due.toFixed(2);
            dueLabel.style.color = 'var(--error)';
        } else {
            dueLabel.innerText = 'Surplus Paid: PKR ' + Math.abs(due).toFixed(2);
            dueLabel.style.color = 'var(--accent)';
        }
    }

    // Sync input variables for submission
    document.getElementById('purchaseItemsInput').value = JSON.stringify(purchaseCart);
}
