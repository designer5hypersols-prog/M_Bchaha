<?php
/**
 * Purchase & Stock Subsystem - Core Purchase Landing Hub (Module 5)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = "";

// Calculate dynamic procurement statistics
try {
    // 1. Total Purchasing Costs (Current month)
    $monthly_purchases = $db->query("SELECT SUM(payable_amount) FROM purchases WHERE MONTH(purchase_date) = MONTH(CURRENT_DATE()) AND YEAR(purchase_date) = YEAR(CURRENT_DATE())")->fetchColumn() ?: 0.00;

    // 2. Outstanding Supplier Dues
    $supplier_dues = $db->query("SELECT SUM(balance) FROM suppliers")->fetchColumn() ?: 0.00;

    // 3. Overall Inbound Logs Count (Stock history IN entries)
    $inbound_logs = $db->query("SELECT COUNT(*) FROM stock_history WHERE type = 'IN'")->fetchColumn() ?: 0;

    // 4. Recent Purchases (last 10 records)
    $recent_purchases = $db->query("SELECT p.*, s.name as supplier_name FROM purchases p LEFT JOIN suppliers s ON p.supplier_id = s.id ORDER BY p.id DESC LIMIT 10")->fetchAll();

} catch (PDOException $e) {
    $monthly_purchases = $supplier_dues = $inbound_logs = 0;
    $recent_purchases = [];
}

require_once 'includes/header.php';
?>

<!-- Include Subsystem Styles -->
<link rel="stylesheet" href="purchase.css">

<!-- ==========================================
     PURCHASE HUB OVERVIEW METRICS GRID
     ========================================== -->
<div class="purchase-stats-grid">
    
    <!-- Monthly procurement cost -->
    <div class="stat-card success" style="border-left: 4px solid var(--accent);">
        <div class="stat-info">
            <span>Monthly Restocks Cost</span>
            <h2><?php echo format_currency($monthly_purchases); ?></h2>
        </div>
        <div class="stat-icon"><i class="bx bx-cart-add"></i></div>
    </div>
    
    <!-- Outstanding Supplier dues -->
    <div class="stat-card danger">
        <div class="stat-info">
            <span>Outstanding Supplier Dues</span>
            <h2><?php echo format_currency($supplier_dues); ?></h2>
        </div>
        <div class="stat-icon"><i class="bx bx-truck"></i></div>
    </div>
    
    <!-- Inbound Stock entries -->
    <div class="stat-card primary">
        <div class="stat-info">
            <span>Warehouse Inbounds Log</span>
            <h2><?php echo $inbound_logs; ?> <span style="font-size:12px; font-weight:400; color:var(--text-muted);">records</span></h2>
        </div>
        <div class="stat-icon"><i class="bx bx-cabinet"></i></div>
    </div>
</div>

<!-- ==========================================
     PROCUREMENT ACTIONS TERMINAL LINKS
     ========================================== -->
<div style="display: flex; gap: 15px; margin-bottom: 30px; flex-wrap: wrap;">
    <a href="add_purchase.php" class="btn" style="width: auto; height: 52px; display: inline-flex; align-items: center; justify-content: center; text-decoration: none; padding: 0 30px; font-weight: 700;">
        <i class="bx bx-plus-circle" style="font-size: 20px; margin-right: 8px;"></i> Launch Restocking Terminal [New Purchase]
    </a>
    <a href="purchase_history.php" class="btn btn-secondary" style="width: auto; height: 52px; display: inline-flex; align-items: center; justify-content: center; text-decoration: none; padding: 0 30px; font-weight: 600;">
        <i class="bx bx-history" style="font-size: 20px; margin-right: 8px;"></i> Purchase History Ledger
    </a>
    <a href="stock_logs.php" class="btn btn-secondary" style="width: auto; height: 52px; display: inline-flex; align-items: center; justify-content: center; text-decoration: none; padding: 0 30px; font-weight: 600;">
        <i class="bx bx-cabinet" style="font-size: 20px; margin-right: 8px;"></i> Stock Movement History
    </a>
</div>

<!-- ==========================================
     RECENT PURCHASES INVOICES AUDIT LIST
     ========================================== -->
<div class="card">
    <div class="card-header" style="margin-bottom: 20px; padding-bottom: 12px;">
        <div class="card-title">
            <i class="bx bx-history"></i>
            <span>Recent Incoming Warehouse Procurements</span>
        </div>
        <span style="font-size:11px; color:var(--text-muted);">Audited log</span>
    </div>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Purchase No</th>
                    <th>Supplier Vendor</th>
                    <th>Purchase Date</th>
                    <th>Grand Total</th>
                    <th>Paid Amount</th>
                    <th>Payment Status</th>
                    <th>Method</th>
                    <th>Notes</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($recent_purchases)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 40px;">No incoming stock purchases logged.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach($recent_purchases as $pur): 
                        $status_badge = get_payment_status($pur['payment_status']);
                    ?>
                        <tr class="animate-fade">
                            <td style="font-weight: 600; color: var(--accent);"><?php echo htmlspecialchars($pur['purchase_no']); ?></td>
                            <td><strong><?php echo htmlspecialchars($pur['supplier_name'] ?: 'Cash Supplier / Walk-in'); ?></strong></td>
                            <td><?php echo format_date($pur['purchase_date']); ?></td>
                            <td style="font-weight: 700; color: var(--text-main);"><?php echo format_currency($pur['payable_amount']); ?></td>
                            <td><?php echo format_currency($pur['paid_amount']); ?></td>
                            <td>
                                <span class="status-pill <?php echo $status_badge['class']; ?>"><?php echo $status_badge['label']; ?></span>
                            </td>
                            <td style="text-transform: uppercase; font-size:12px;"><strong><?php echo htmlspecialchars($pur['payment_method']); ?></strong></td>
                            <td><?php echo htmlspecialchars($pur['notes'] ?: '-'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
