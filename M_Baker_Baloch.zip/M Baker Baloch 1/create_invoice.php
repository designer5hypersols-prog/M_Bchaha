<?php
/**
 * POS Billing Terminal - Create New Invoice
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = "";

// 1. Fetch Dynamic tax rate and store configurations
$tax_rate = 0.00;
try {
    $tax_rate_val = $db->query("SELECT key_value FROM settings WHERE key_name = 'tax_rate' LIMIT 1")->fetchColumn();
    $tax_rate = (float)($tax_rate_val ?: 0.00);
} catch (PDOException $e) {}

// 2. Process POST Invoice checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_id = (int)($_POST['customer_id'] ?? 1); // Walk-in customer default
    $discount = (float)($_POST['discount'] ?? 0);
    $paid_amount = (float)($_POST['paid_amount'] ?? 0);
    $payment_method = sanitize($_POST['payment_method'] ?? 'CASH');
    $notes = sanitize($_POST['notes'] ?? 'POS Billing');

    $cart_data = $_POST['cart_items'] ?? '[]';
    $cart_items = json_decode($cart_data, true);

    if (empty($cart_items)) {
        $error_message = "Your billing cart is empty. Please select products first.";
    } else {
        try {
            $db->beginTransaction();

            $total_amount = 0;
            $items_to_insert = [];

            foreach ($cart_items as $item) {
                $p_id = (int)$item['id'];
                $qty = (int)$item['qty'];

                // Verify stock availability
                $chk_stmt = $db->prepare("SELECT name, sell_price, stock_qty FROM products WHERE id = :id FOR UPDATE");
                $chk_stmt->execute(['id' => $p_id]);
                $prod = $chk_stmt->fetch();

                if (!$prod) {
                    throw new Exception("Product ID " . $p_id . " does not exist in your registry.");
                }
                if ($prod['stock_qty'] < $qty) {
                    throw new Exception("Insufficient stock for '" . $prod['name'] . "'. Requested: " . $qty . ", Available: " . $prod['stock_qty']);
                }

                $price = (float)$prod['sell_price'];
                $subtotal = $price * $qty;
                $total_amount += $subtotal;

                $items_to_insert[] = [
                    'product_id' => $p_id,
                    'qty' => $qty,
                    'price' => $price,
                    'total' => $subtotal
                ];
            }

            // Calculate tax and payable net values
            $tax_amount = $total_amount * ($tax_rate / 100);
            $payable_amount = $total_amount + $tax_amount - $discount;
            if ($payable_amount < 0) $payable_amount = 0;

            // Payment Status Tag
            $payment_status = 'UNPAID';
            if ($paid_amount >= $payable_amount) {
                $payment_status = 'PAID';
            } elseif ($paid_amount > 0) {
                $payment_status = 'PARTIAL';
            }

            // Auto Generate Unique Invoice code (e.g. INV-YYYYMMDD-HEX)
            $invoice_no = 'INV-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(2)));

            // 1. Insert Sales Invoice Header
            $ins_sale = $db->prepare("INSERT INTO sales (invoice_no, customer_id, sale_date, total_amount, discount, payable_amount, paid_amount, payment_status, payment_method, notes) VALUES (:inv_no, :cust_id, CURRENT_DATE(), :total, :disc, :payable, :paid, :status, :method, :notes)");
            $ins_sale->execute([
                'inv_no' => $invoice_no,
                'cust_id' => $customer_id,
                'total' => $total_amount,
                'disc' => $discount,
                'payable' => $payable_amount,
                'paid' => $paid_amount,
                'status' => $payment_status,
                'method' => $payment_method,
                'notes' => $notes
            ]);
            $sale_id = $db->lastInsertId();

            // 2. Insert items and subtract warehouse quantities
            $ins_item = $db->prepare("INSERT INTO sale_items (sale_id, product_id, price, qty, total) VALUES (:sale_id, :prod_id, :price, :qty, :total)");
            $deduct_stock = $db->prepare("UPDATE products SET stock_qty = stock_qty - :qty WHERE id = :id");
            $log_stock = $db->prepare("INSERT INTO stock_history (product_id, type, qty, reference_id, remarks) VALUES (:prod_id, 'OUT', :qty, :ref_id, :remarks)");

            foreach ($items_to_insert as $item) {
                $ins_item->execute([
                    'sale_id' => $sale_id,
                    'prod_id' => $item['product_id'],
                    'price' => $item['price'],
                    'qty' => $item['qty'],
                    'total' => $item['total']
                ]);

                $deduct_stock->execute([
                    'qty' => $item['qty'],
                    'id' => $item['product_id']
                ]);

                $log_stock->execute([
                    'prod_id' => $item['product_id'],
                    'qty' => $item['qty'],
                    'ref_id' => $sale_id,
                    'remarks' => "POS Invoice: $invoice_no"
                ]);
            }

            // 3. Update customer outstanding balance if credit was used
            $remaining_debt = $payable_amount - $paid_amount;
            if ($remaining_debt > 0 && $customer_id > 1) {
                $upd_cust = $db->prepare("UPDATE customers SET balance = balance + :debt WHERE id = :id");
                $upd_cust->execute(['debt' => $remaining_debt, 'id' => $customer_id]);
            }

            $db->commit();
            
            // Redirect immediately to thermal print view!
            header("Location: print_invoice.php?id=" . $sale_id);
            exit;

        } catch (Exception $e) {
            $db->rollBack();
            $error_message = "Checkout failed: " . $e->getMessage();
        }
    }
}

// 3. Load Customers and Products active grids
$customers = [];
$products = [];
try {
    $customers = $db->query("SELECT id, name, phone, balance FROM customers ORDER BY name ASC")->fetchAll();
    $products = $db->query("SELECT * FROM products WHERE status = 'ACTIVE' ORDER BY name ASC")->fetchAll();
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="invoice.css">

<!-- Action Notifications -->
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo $error_message; ?></span>
    </div>
<?php endif; ?>

<!-- ==========================================
     SPLIT POS VIEWPORT BILLING GRID
     ========================================== -->
<div class="pos-billing-grid">
    
    <!-- Left panel: Search & Product lists cards -->
    <div class="pos-search-panel">
        <div style="display: flex; gap: 10px; align-items: center;">
            <div class="search-input-group" style="max-width: 100%;">
                <i class="bx bx-search"></i>
                <input type="text" id="posSearch" class="search-control" placeholder="Scan Barcode / Search plastic products... [F2]" autocomplete="off">
            </div>
        </div>

        <div class="pos-items-grid" id="posProductsList">
            <?php foreach($products as $p): ?>
                <div class="pos-item-card <?php echo ($p['stock_qty'] <= 0) ? 'out-of-stock' : ''; ?>" 
                     data-id="<?php echo $p['id']; ?>" 
                     data-name="<?php echo htmlspecialchars($p['name']); ?>" 
                     data-sku="<?php echo htmlspecialchars($p['sku']); ?>" 
                     data-barcode="<?php echo htmlspecialchars($p['barcode'] ?: ''); ?>"
                     data-price="<?php echo $p['sell_price']; ?>" 
                     data-stock="<?php echo $p['stock_qty']; ?>"
                     onclick="addToPosCart(this)">
                    
                    <div>
                        <span class="pos-item-title"><?php echo htmlspecialchars($p['name']); ?></span>
                        <span class="pos-item-code">SKU: <?php echo htmlspecialchars($p['sku']); ?></span>
                    </div>

                    <div class="pos-item-bottom">
                        <span class="pos-item-price"><?php echo format_currency($p['sell_price']); ?></span>
                        
                        <?php if ($p['stock_qty'] <= 0): ?>
                            <span class="pos-item-qty-tag" style="background:var(--danger-glow); color:var(--danger);">Out</span>
                        <?php elseif ($p['stock_qty'] <= $p['min_stock_qty']): ?>
                            <span class="pos-item-qty-tag" style="background:var(--warning-glow); color:var(--warning);">Low: <?php echo $p['stock_qty']; ?></span>
                        <?php else: ?>
                            <span class="pos-item-qty-tag" style="background:var(--accent-glow); color:var(--accent);">Qty: <?php echo $p['stock_qty']; ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Right panel: Checkout shopping cart list -->
    <div class="pos-cart-panel">
        <div>
            <div class="card-header" style="margin-bottom: 12px; padding-bottom: 8px;">
                <div class="card-title">
                    <i class="bx bx-cart"></i>
                    <span>Checkout Cart Line</span>
                </div>
                <button type="button" class="btn btn-sm btn-danger" onclick="clearPosCart()" style="width: auto; padding: 4px 10px;">Clear</button>
            </div>

            <!-- Cart list -->
            <div class="table-responsive" style="max-height: 250px; border: none; margin-bottom: 15px;">
                <table class="table" style="font-size: 13px;">
                    <thead>
                        <tr style="background: var(--bg-primary);">
                            <th>Item Name</th>
                            <th>Qty</th>
                            <th>Subtotal</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="cartItemsList">
                        <tr>
                            <td colspan="4" style="text-align: center; color: var(--text-muted); padding: 40px;">No items added to billing receipt.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Submission billing details form -->
        <form id="checkoutForm" method="POST" action="create_invoice.php" data-tax-rate="<?php echo $tax_rate; ?>">
            <input type="hidden" id="cartItemsInput" name="cart_items">

            <!-- Customer directory link dropdown -->
            <div class="form-group">
                <label class="form-label">Active Customer</label>
                <select name="customer_id" class="select-control" style="width:100%; height:44px;" required>
                    <?php foreach($customers as $c): ?>
                        <option value="<?php echo $c['id']; ?>">
                            <?php echo htmlspecialchars($c['name']); ?> 
                            <?php echo ($c['balance'] > 0) ? ' [Credit Dues: ' . format_currency($c['balance']) . ']' : ''; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div class="form-group">
                    <label class="form-label">Discount Flat (PKR)</label>
                    <input type="number" id="discountInput" name="discount" class="form-control" style="padding-left:12px; height:44px;" value="0" min="0" onkeyup="recalculatePosTotals()">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Payment Method</label>
                    <select name="payment_method" class="select-control" style="width:100%; height:44px;">
                        <option value="CASH">Cash Payment</option>
                        <option value="BANK">Bank Transfer / Card</option>
                        <option value="CREDIT">Accounts Dues (Credit)</option>
                    </select>
                </div>
            </div>

            <!-- Mathematical tallies -->
            <div class="pos-totals" style="padding: 10px; background:var(--input-bg); border-radius:var(--radius-sm); border:1px solid var(--border-color); margin-bottom:12px;">
                <div class="pos-totals-row" style="font-size:12px; margin-bottom:4px;">
                    <span>Gross Subtotal:</span>
                    <strong id="subtotalLabel">PKR 0.00</strong>
                </div>
                <div class="pos-totals-row" style="font-size:12px; margin-bottom:4px;">
                    <span>Estimated Tax Amount:</span>
                    <strong id="taxLabel">PKR 0.00 (<?php echo $tax_rate; ?>%)</strong>
                </div>
                <div class="pos-totals-row" style="font-size:12px; margin-bottom:4px; color:var(--error);">
                    <span>Discount Deductions:</span>
                    <strong id="discountLabel">- PKR 0.00</strong>
                </div>
                <div class="pos-totals-row grand-total" style="font-size:15px; font-weight:700; border-top:1px solid var(--border-color); padding-top:6px; color:var(--accent);">
                    <span>Total Payable:</span>
                    <strong id="payableLabel">PKR 0.00</strong>
                </div>
            </div>

            <!-- Payment entries -->
            <div class="form-group">
                <label class="form-label">Paid Amount (PKR) *</label>
                <input type="number" step="0.01" id="paidAmountInput" name="paid_amount" class="form-control" style="padding-left:12px; height:44px;" required placeholder="0.00" onkeyup="recalculatePosTotals()">
            </div>

            <div class="pos-totals-row" style="margin-bottom: 12px; font-weight:600;">
                <span>Change / Return dues:</span>
                <strong id="changeLabel">PKR 0.00</strong>
            </div>

            <button type="submit" class="btn" style="height:48px; font-weight:700; font-size:14px;">
                <i class="bx bx-check-shield"></i> Complete Sale & Print [F8]
            </button>
        </form>
    </div>

</div>

<!-- ==========================================
     SHORTCUT BADGES FLOAT BAR
     ========================================== -->
<div class="keyboard-shortcuts-bar">
    <div><span class="shortcut-badge">F2</span> Focus Search / Scanner</div>
    <div><span class="shortcut-badge">F8</span> Complete Invoice Checkout</div>
    <div><span class="shortcut-badge">Esc</span> Clear Checkout Cart Lines</div>
    <div style="margin-left: auto;">Powered by M.BAKAR BALOCH billing software</div>
</div>

<script>
// Quick live catalog search filtering
const searchInput = document.getElementById('posSearch');
if (searchInput) {
    searchInput.addEventListener('keyup', () => {
        const query = searchInput.value.toLowerCase();
        const cards = document.querySelectorAll('.pos-item-card');

        cards.forEach(card => {
            const name = card.getAttribute('data-name').toLowerCase();
            const sku = card.getAttribute('data-sku').toLowerCase();
            const barcode = card.getAttribute('data-barcode').toLowerCase();
            if (name.includes(query) || sku.includes(query) || barcode.includes(query)) {
                card.style.display = 'flex';
            } else {
                card.style.display = 'none';
            }
        });
    });
}
</script>

<!-- Subsystem JS -->
<script src="invoice.js"></script>

<?php require_once 'includes/footer.php'; ?>
