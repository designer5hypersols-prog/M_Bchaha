<?php
/**
 * Double Entry Accounting Subsystem - Chart of Accounts (Module 1)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';
require_once 'accounting_engine.php';

$db = (new Database())->connect();
$engine = new AccountingEngine($db);

$error_message = "";
$success_message = "";

// Enforce Admin Rights
if ($_SESSION['user_role'] !== 'ADMIN' && $_SESSION['user_role'] !== 'MANAGER') {
    die("Access Denied: You must be an Administrator or Manager to access corporate ledger indices.");
}

// ==========================================
// PROCESS POST CUSTOM ACCOUNT CREATION
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = sanitize($_POST['code'] ?? '');
    $name = sanitize($_POST['name'] ?? '');
    $type = sanitize($_POST['type'] ?? 'ASSET');
    $desc = sanitize($_POST['description'] ?? '');

    if (!empty($code) && !empty($name)) {
        try {
            $ins = $db->prepare("INSERT INTO accounts (code, name, type, description) VALUES (:code, :name, :type, :desc)");
            $ins->execute([
                'code' => $code,
                'name' => $name,
                'type' => $type,
                'desc' => $desc
            ]);
            $success_message = "New ledger account **\"$name ($code)\"** successfully created and seeded into accounting books.";
        } catch (PDOException $e) {
            $error_message = "Account registration failed: Account code already exists.";
        }
    } else {
        $error_message = "Please input a valid account code and full account name.";
    }
}

// ==========================================
// LOAD CHART OF ACCOUNTS (BY CATEGORY)
// ==========================================
$accounts = [];
try {
    $stmt = $db->query("SELECT * FROM accounts ORDER BY code ASC");
    $accounts = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<!-- Action Notifications -->
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo $error_message; ?></span>
    </div>
<?php endif; ?>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success">
        <i class="bx bx-check-circle"></i>
        <span><?php echo preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $success_message); ?></span>
    </div>
<?php endif; ?>

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <a href="settings.php#subsystems_link" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
            <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Settings Hub
        </a>
    </div>
</div>

<div style="display:grid; grid-template-columns:1.5fr 1fr; gap:24px; align-items:start;">

    <!-- ==========================================
         A. ACCOUNT REGISTER DIRECTORY
         ========================================== -->
    <div class="card">
        <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-book-bookmark" style="color:var(--accent);"></i>
                <span>Corporate Chart of Accounts (GAAP Directory)</span>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Account Name</th>
                        <th>Classification</th>
                        <th>Notes / Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($accounts as $acc): 
                        $badge_class = 'primary';
                        if ($acc['type'] === 'LIABILITY') $badge_class = 'danger';
                        elseif ($acc['type'] === 'EQUITY') $badge_class = 'warning';
                        elseif ($acc['type'] === 'INCOME') $badge_class = 'success';
                        elseif ($acc['type'] === 'EXPENSE') $badge_class = 'info';
                    ?>
                        <tr class="animate-fade">
                            <td><code style="font-size:12.5px; font-weight:700;"><?php echo htmlspecialchars($acc['code']); ?></code></td>
                            <td><strong><?php echo htmlspecialchars($acc['name']); ?></strong></td>
                            <td>
                                <span style="font-size: 10px; font-weight:700; padding:2px 8px; border-radius:4px; 
                                    background: var(--<?php echo $badge_class; ?>-glow); 
                                    color: var(--<?php echo $badge_class; ?>);">
                                    <?php echo $acc['type']; ?>
                                </span>
                            </td>
                            <td style="font-size:12px; color:var(--text-muted); max-width:200px;"><?php echo htmlspecialchars($acc['description']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ==========================================
         B. ADD CUSTOM ACCOUNT FORM
         ========================================== -->
    <div class="card" style="position:sticky; top:20px;">
        <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-plus-circle" style="color:var(--accent);"></i>
                <span>Register Custom Account</span>
            </div>
        </div>

        <form method="POST" action="chart_of_accounts.php" style="display:flex; flex-direction:column; gap:16px;">
            <div>
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Account Code (e.g. 1015)</label>
                <input type="text" name="code" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;" required placeholder="Unique numerical code index">
            </div>

            <div>
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Account Name</label>
                <input type="text" name="name" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;" required placeholder="e.g. Meezan Bank Asset">
            </div>

            <div>
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Classification Type</label>
                <select name="type" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px; cursor:pointer;">
                    <option value="ASSET">ASSET (Receivables, Reserves)</option>
                    <option value="LIABILITY">LIABILITY (Debts, Payables)</option>
                    <option value="EQUITY">EQUITY (Investments, Capital)</option>
                    <option value="INCOME">INCOME (POS Sales, Revenues)</option>
                    <option value="EXPENSE">EXPENSE (Costings, COGS, Bills)</option>
                </select>
            </div>

            <div>
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Account description</label>
                <textarea name="description" style="width:100%; height:60px; padding:12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px; font-family:inherit; resize:none;" placeholder="Notes regarding cash flows..."></textarea>
            </div>

            <button type="submit" class="btn" style="background:var(--accent); border-color:var(--accent); height:40px; font-weight:700; width:100%;">
                <i class="bx bx-save" style="margin-right:4px;"></i> Register Account
            </button>
        </form>
    </div>

</div>

<?php require_once 'includes/footer.php'; ?>
