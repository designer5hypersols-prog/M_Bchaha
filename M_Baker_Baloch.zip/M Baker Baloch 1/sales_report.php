<?php
/**
 * Reports & Profit/Loss Subsystem - Sales Report (Module 7)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = "";

// 1. FILTER PARAMETERS
$start_date = sanitize($_GET['start_date'] ?? '');
$end_date = sanitize($_GET['end_date'] ?? '');
$category_filter = sanitize($_GET['category'] ?? '');
$customer_filter = (int)($_GET['customer_id'] ?? 0);

$limit = 15; // Logs per page
$page = (int)($_GET['page'] ?? 1);
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

$query_base = "SELECT si.*, s.invoice_no, s.sale_date, c.name as customer_name, p.name as product_name, p.sku as product_sku, p.category as product_category 
              FROM sale_items si 
              JOIN sales s ON si.sale_id = s.id 
              JOIN products p ON si.product_id = p.id 
              LEFT JOIN customers c ON s.customer_id = c.id 
              WHERE 1=1";
$params = [];

if (!empty($start_date) && !empty($end_date)) {
    $query_base .= " AND s.sale_date BETWEEN :start AND :end";
    $params['start'] = $start_date;
    $params['end'] = $end_date;
}

if (!empty($category_filter)) {
    $query_base .= " AND p.category = :cat";
    $params['cat'] = $category_filter;
}

if ($customer_filter > 0) {
    $query_base .= " AND s.customer_id = :cust";
    $params['cust'] = $customer_filter;
}

// Calculate pagination parameters
try {
    $count_query = "SELECT COUNT(*) FROM (" . $query_base . ") as sub";
    $count_stmt = $db->prepare($count_query);
    $count_stmt->execute($params);
    $total_records = (int)$count_stmt->fetchColumn();
} catch (PDOException $e) {
    $total_records = 0;
}

$total_pages = ceil($total_records / $limit);
if ($total_pages < 1) $total_pages = 1;
if ($page > $total_pages) $page = $total_pages;
$offset = ($page - 1) * $limit;

// Load records
try {
    $load_query = $query_base . " ORDER BY s.id DESC LIMIT $limit OFFSET $offset";
    $load_stmt = $db->prepare($load_query);
    $load_stmt->execute($params);
    $items = $load_stmt->fetchAll();
} catch (PDOException $e) {
    $items = [];
}

// Load metadata lists
$categories = [];
$customers = [];
try {
    $categories = $db->query("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != ''")->fetchAll(PDO::FETCH_COLUMN);
    $customers = $db->query("SELECT id, name FROM customers ORDER BY name ASC")->fetchAll();
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="reports.css">

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <a href="reports.php" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
            <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Reports Hub
        </a>
    </div>
    
    <div style="display: flex; gap: 10px;">
        <button type="button" class="btn btn-sm btn-secondary" style="width: auto;" onclick="exportReportTableToCSV('salesReportTable', 'mbakar_baloch_sales_turnover_report')">
            <i class="bx bx-download"></i> Export Report CSV
        </button>
    </div>
</div>

<!-- ==========================================
     ADVANCED SALES REPORT FILTERS
     ========================================== -->
<div class="search-filter-section" style="margin-bottom: 24px;">
    <form method="GET" action="sales_report.php" style="display: flex; flex-grow: 1; flex-wrap: wrap; gap: 15px; width: 100%;">
        
        <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap; width: 100%;">
            <!-- Date range picker -->
            <input type="date" name="start_date" class="form-control" style="width: 140px; height: 44px;" value="<?php echo htmlspecialchars($start_date); ?>">
            <span style="color:var(--text-muted);">to</span>
            <input type="date" name="end_date" class="form-control" style="width: 140px; height: 44px;" value="<?php echo htmlspecialchars($end_date); ?>">

            <!-- Category Filter dropdown -->
            <select name="category" class="select-control" style="width: auto; height: 44px;" onchange="this.form.submit()">
                <option value="">All Catalog Categories</option>
                <?php foreach($categories as $cat): ?>
                    <option value="<?php echo htmlspecialchars($cat); ?>" <?php echo $category_filter === $cat ? 'selected' : ''; ?>><?php echo htmlspecialchars($cat); ?></option>
                <?php endforeach; ?>
            </select>

            <!-- Customer Filter dropdown -->
            <select name="customer_id" class="select-control" style="width: auto; height: 44px;" onchange="this.form.submit()">
                <option value="">All Billing Customers</option>
                <?php foreach($customers as $c): ?>
                    <option value="<?php echo $c['id']; ?>" <?php echo $customer_filter === $c['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($c['name']); ?></option>
                <?php endforeach; ?>
            </select>

            <button type="submit" class="btn btn-sm btn-secondary" style="height: 44px; width: auto; padding: 0 20px;">Filter Report</button>
        </div>
    </form>
</div>

<!-- ==========================================
     ITEMIZED SALES DETAILS TABLE
     ========================================== -->
<div class="card">
    <div class="table-responsive">
        <table class="table" id="salesReportTable">
            <thead>
                <tr>
                    <th>Invoice No</th>
                    <th>Customer Name</th>
                    <th>Sale Date</th>
                    <th>Replenishing Item</th>
                    <th>SKU Code</th>
                    <th>Category</th>
                    <th>Sold Qty</th>
                    <th>Selling Unit Price</th>
                    <th>Total Turnover</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($items)): ?>
                    <tr>
                        <td colspan="9" style="text-align: center; color: var(--text-muted); padding: 45px;">No itemized sales match current filters.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach($items as $i): ?>
                        <tr class="animate-fade">
                            <td style="font-weight: 600; color: var(--accent);"><?php echo htmlspecialchars($i['invoice_no']); ?></td>
                            <td><strong><?php echo htmlspecialchars($i['customer_name'] ?: 'Walk-in Customer'); ?></strong></td>
                            <td><?php echo format_date($i['sale_date']); ?></td>
                            <td><strong><?php echo htmlspecialchars($i['product_name']); ?></strong></td>
                            <td style="font-weight:600;"><?php echo htmlspecialchars($i['product_sku']); ?></td>
                            <td><span class="status-pill info"><?php echo htmlspecialchars($i['product_category']); ?></span></td>
                            <td style="font-weight:600;"><?php echo $i['qty']; ?></td>
                            <td><?php echo format_currency($i['price']); ?></td>
                            <td style="font-weight: 700; color: var(--text-main);"><?php echo format_currency($i['total']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ==========================================
     PAGINATION CONTROL ROW FOOTER
     ========================================== -->
<div class="pagination" style="margin-top: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <span style="font-size: 13.5px; color: var(--text-secondary);">Showing <strong><?php echo count($items); ?></strong> of <strong><?php echo $total_records; ?></strong> transactions.</span>
    
    <div style="display: flex; gap: 5px;">
        <a href="sales_report.php?page=<?php echo ($page - 1); ?>&start_date=<?php echo urlencode($start_date); ?>&end_date=<?php echo urlencode($end_date); ?>&category=<?php echo urlencode($category_filter); ?>&customer_id=<?php echo $customer_filter; ?>" 
           class="btn btn-sm btn-secondary <?php echo ($page <= 1) ? 'disabled' : ''; ?>" 
           style="width: auto; padding: 6px 12px; pointer-events: <?php echo ($page <= 1) ? 'none' : 'auto'; ?>;">
           &larr; Prev
        </a>

        <?php for($k = 1; $k <= $total_pages; $k++): ?>
            <a href="sales_report.php?page=<?php echo $k; ?>&start_date=<?php echo urlencode($start_date); ?>&end_date=<?php echo urlencode($end_date); ?>&category=<?php echo urlencode($category_filter); ?>&customer_id=<?php echo $customer_filter; ?>" 
               class="btn btn-sm <?php echo ($page === $k) ? '' : 'btn-secondary'; ?>" 
               style="width: 32px; padding: 6px 0; text-align: center;">
               <?php echo $k; ?>
            </a>
        <?php endfor; ?>

        <a href="sales_report.php?page=<?php echo ($page + 1); ?>&start_date=<?php echo urlencode($start_date); ?>&end_date=<?php echo urlencode($end_date); ?>&category=<?php echo urlencode($category_filter); ?>&customer_id=<?php echo $customer_filter; ?>" 
           class="btn btn-sm btn-secondary <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>" 
           style="width: auto; padding: 6px 12px; pointer-events: <?php echo ($page >= $total_pages) ? 'none' : 'auto'; ?>;">
           Next &rarr;
        </a>
    </div>
</div>

<!-- Subsystem JS -->
<script src="reports.js"></script>

<?php require_once 'includes/footer.php'; ?>
