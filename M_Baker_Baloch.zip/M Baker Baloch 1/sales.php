<?php
/**
 * Sales Subsystem - Core Sales & Billing Landing Hub (Module 4)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = "";

// Calculate dynamic Sales metrics
try {
    // 1. Today's Turnover Sales
    $todays_sales = $db->query("SELECT SUM(payable_amount) FROM sales WHERE sale_date = CURRENT_DATE()")->fetchColumn() ?: 0.00;

    // 2. Monthly Turnover Sales
    $monthly_sales = $db->query("SELECT SUM(payable_amount) FROM sales WHERE MONTH(sale_date) = MONTH(CURRENT_DATE()) AND YEAR(sale_date) = YEAR(CURRENT_DATE())")->fetchColumn() ?: 0.00;

    // 3. Accounts Receivables (outstanding credit dues from customers)
    $credit_dues = $db->query("SELECT SUM(balance) FROM customers")->fetchColumn() ?: 0.00;

    // 4. Total Invoices Count
    $total_invoices = $db->query("SELECT COUNT(*) FROM sales")->fetchColumn() ?: 0;

    // 5. Recent Invoices (last 10 records)
    $recent_invoices = $db->query("SELECT s.*, c.name as customer_name FROM sales s LEFT JOIN customers c ON s.customer_id = c.id ORDER BY s.id DESC LIMIT 10")->fetchAll();

} catch (PDOException $e) {
    $todays_sales = $monthly_sales = $credit_dues = $total_invoices = 0;
    $recent_invoices = [];
}

require_once 'includes/header.php';
?>

<!-- Include Subsystem Styles -->
<link rel="stylesheet" href="invoice.css">

<!-- ==========================================
     SALES HUB OVERVIEW METRICS GRID
     ========================================== -->
<div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); margin-bottom: 30px;">
    
    <!-- Today's turnover -->
    <div class="stat-card success">
        <div class="stat-info">
            <span>Today's Sales</span>
            <h2><?php echo format_currency($todays_sales); ?></h2>
        </div>
        <div class="stat-icon"><i class="bx bx-receipt"></i></div>
    </div>
    
    <!-- Monthly turnover -->
    <div class="stat-card success" style="border-left: 4px solid var(--accent);">
        <div class="stat-info">
            <span>Monthly Sales</span>
            <h2><?php echo format_currency($monthly_sales); ?></h2>
        </div>
        <div class="stat-icon"><i class="bx bx-line-chart"></i></div>
    </div>
    
    <!-- Outstanding credit receivables -->
    <div class="stat-card danger">
        <div class="stat-info">
            <span>Accounts Receivable</span>
            <h2><?php echo format_currency($credit_dues); ?></h2>
        </div>
        <div class="stat-icon"><i class="bx bx-wallet-toggle"></i></div>
    </div>
    
    <!-- Overall Invoices -->
    <div class="stat-card primary">
        <div class="stat-info">
            <span>Overall Invoices</span>
            <h2><?php echo $total_invoices; ?> <span style="font-size:12px; font-weight:400; color:var(--text-muted);">bills</span></h2>
        </div>
        <div class="stat-icon"><i class="bx bx-file"></i></div>
    </div>
</div>

<!-- ==========================================
     BILLING QUICK ACTIONS BAR
     ========================================== -->
<div style="display: flex; gap: 15px; margin-bottom: 30px; flex-wrap: wrap;">
    <a href="create_invoice.php" class="btn" style="width: auto; height: 52px; display: inline-flex; align-items: center; justify-content: center; text-decoration: none; padding: 0 30px; font-weight: 700;">
        <i class="bx bx-plus-circle" style="font-size: 20px; margin-right: 8px;"></i> Launch POS Billing Terminal [New Invoice]
    </a>
    <a href="invoice_history.php" class="btn btn-secondary" style="width: auto; height: 52px; display: inline-flex; align-items: center; justify-content: center; text-decoration: none; padding: 0 30px; font-weight: 600;">
        <i class="bx bx-history" style="font-size: 20px; margin-right: 8px;"></i> Invoice History Ledger
    </a>
</div>

<!-- ==========================================
     RECENT SALES INVOICES AUDIT LIST
     ========================================== -->
<div class="card">
    <div class="card-header" style="margin-bottom: 20px; padding-bottom: 12px;">
        <div class="card-title">
            <i class="bx bx-history"></i>
            <span>Recent Invoiced Sales Transactions</span>
        </div>
        <span style="font-size:11px; color:var(--text-muted);">Audited log</span>
    </div>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Invoice No</th>
                    <th>Customer Name</th>
                    <th>Invoice Date</th>
                    <th>Grand Total</th>
                    <th>Paid Amount</th>
                    <th>Method</th>
                    <th>Payment Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($recent_invoices)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 40px;">No sales transactions have been logged.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach($recent_invoices as $inv): 
                        $status_badge = get_payment_status($inv['payment_status']);
                    ?>
                        <tr class="animate-fade">
                            <td style="font-weight: 600; color: var(--accent);"><?php echo htmlspecialchars($inv['invoice_no']); ?></td>
                            <td><strong><?php echo htmlspecialchars($inv['customer_name'] ?: 'Walk-in Customer'); ?></strong></td>
                            <td><?php echo format_date($inv['sale_date']); ?></td>
                            <td style="font-weight: 700; color: var(--text-main);"><?php echo format_currency($inv['payable_amount']); ?></td>
                            <td><?php echo format_currency($inv['paid_amount']); ?></td>
                            <td><?php echo htmlspecialchars($inv['payment_method']); ?></td>
                            <td>
                                <span class="status-pill <?php echo $status_badge['class']; ?>"><?php echo $status_badge['label']; ?></span>
                            </td>
                            <td>
                                <div class="action-btns">
                                    <a href="print_invoice.php?id=<?php echo $inv['id']; ?>" class="btn-action" title="View Print Receipt" target="_blank" style="display:inline-flex; align-items:center; justify-content:center; text-decoration:none;">
                                        <i class="bx bx-printer"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
