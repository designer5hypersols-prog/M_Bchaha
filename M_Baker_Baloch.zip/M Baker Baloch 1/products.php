<?php
/**
 * Complete Product Management Subsystem (Module 2)
 * Shop Management System: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'multi_branch_engine.php';

$db = (new Database())->connect();
$mb_engine = new MultiBranchEngine($db);
$branch_filter = $mb_engine->getBranchFilterClause('p');

$error_message = sanitize($_GET['error'] ?? '');
$success_message = sanitize($_GET['success'] ?? '');

// 1. SELF-HEALING DATABASE STRUCTURAL MIGRATION CHECK
try {
    $chk_col = $db->query("SHOW COLUMNS FROM products LIKE 'barcode'")->fetch();
    if (!$chk_col) {
        $db->exec("ALTER TABLE products ADD COLUMN barcode VARCHAR(100) DEFAULT NULL AFTER sku");
        $db->exec("ALTER TABLE products ADD COLUMN brand VARCHAR(100) DEFAULT NULL AFTER category_id");
        $db->exec("ALTER TABLE products ADD COLUMN image_path VARCHAR(255) DEFAULT NULL AFTER description");
        $db->exec("ALTER TABLE products ADD COLUMN supplier_name VARCHAR(150) DEFAULT NULL AFTER image_path");
    }
} catch (PDOException $e) {
    // Database check already run or table already updated
}

// 2. PAGINATION, SEARCH, AND CATEGORY FILTER LOGIC
$search = sanitize($_GET['search'] ?? '');
$filter_cat = (int)($_GET['category'] ?? 0);

$limit = 8; // Products per page
$page = (int)($_GET['page'] ?? 1);
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

$query_base = "SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id WHERE $branch_filter";
$params = [];

if (!empty($search)) {
    $query_base .= " AND (p.name LIKE :search OR p.sku LIKE :search OR p.barcode LIKE :search OR p.brand LIKE :search)";
    $params['search'] = "%$search%";
}

if ($filter_cat > 0) {
    $query_base .= " AND p.category_id = :cat_id";
    $params['cat_id'] = $filter_cat;
}

// Get overall count for pagination
try {
    $count_query = str_replace("p.*, c.name as category_name", "COUNT(*)", $query_base);
    $count_stmt = $db->prepare($count_query);
    $count_stmt->execute($params);
    $total_records = (int)$count_stmt->fetchColumn();
} catch (PDOException $e) {
    $total_records = 0;
}

$total_pages = ceil($total_records / $limit);
if ($total_pages < 1) $total_pages = 1;
if ($page > $total_pages) $page = $total_pages;
$offset = ($page - 1) * $limit;

// Load limited catalog items
try {
    $load_query = $query_base . " ORDER BY p.id DESC LIMIT $limit OFFSET $offset";
    $load_stmt = $db->prepare($load_query);
    $load_stmt->execute($params);
    $products = $load_stmt->fetchAll();
} catch (PDOException $e) {
    $products = [];
}

// 3. Load Categories and Suppliers Lists for Add/Edit forms dropdowns
$categories = [];
$suppliers = [];
try {
    $categories = $db->query("SELECT id, name FROM categories ORDER BY name ASC")->fetchAll();
    $suppliers = $db->query("SELECT id, name FROM suppliers ORDER BY name ASC")->fetchAll();
} catch (PDOException $e) {
    //
}

require_once 'includes/header.php';
?>

<!-- Include Products Subsystem Styles -->
<link rel="stylesheet" href="products.css">

<!-- Action Notifications -->
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo htmlspecialchars($error_message); ?></span>
    </div>
<?php endif; ?>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success">
        <i class="bx bx-check-circle"></i>
        <span><?php echo htmlspecialchars($success_message); ?></span>
    </div>
<?php endif; ?>

<!-- ==========================================
     ADVANCED FILTERS & LAYOUT ACTIONS
     ========================================== -->
<div class="search-filter-section" style="margin-bottom: 24px;">
    <form method="GET" action="products.php" style="display: flex; flex-grow: 1; flex-wrap: wrap; gap: 15px; width: 100%;">
        
        <div class="search-input-group">
            <i class="bx bx-search"></i>
            <input type="text" name="search" class="search-control" placeholder="Search SKU, name, brand, barcode..." value="<?php echo htmlspecialchars($search); ?>">
        </div>

        <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
            <select name="category" class="select-control" style="width: auto; height: 44px;" onchange="this.form.submit()">
                <option value="0">All Categories</option>
                <?php foreach($categories as $cat): ?>
                    <option value="<?php echo $cat['id']; ?>" <?php echo $filter_cat === (int)$cat['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($cat['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-sm btn-secondary" style="height: 44px;">Filter</button>
        </div>

        <div class="filter-actions" style="flex-grow: 1; display: flex; justify-content: flex-end; align-items: center; gap: 12px;">
            <!-- View toggler grids -->
            <div class="view-modes">
                <button type="button" class="view-btn" id="viewModeTable" title="Table View List"><i class="bx bx-list-ul"></i></button>
                <button type="button" class="view-btn" id="viewModeGrid" title="Cards Grid View"><i class="bx bx-grid-alt"></i></button>
            </div>

            <button type="button" class="btn btn-sm btn-secondary" style="width: auto; height:44px;" onclick="exportProductsToCSV('excelExportTable')">
                <i class="bx bx-download"></i> Export CSV
            </button>
            
            <button type="button" class="btn btn-sm" style="width: auto; height:44px;" onclick="openModal('addProductModal')">
                <i class="bx bx-plus-circle"></i> Add Product
            </button>
        </div>
    </form>
</div>

<!-- Hidden table used for flawless Excel CSV exports (includes all products loaded) -->
<table id="excelExportTable" style="display: none;">
    <thead>
        <tr>
            <th>SKU</th>
            <th>Barcode</th>
            <th>Name</th>
            <th>Category</th>
            <th>Brand</th>
            <th>Purchase Price</th>
            <th>Retail Sale Price</th>
            <th>Quantity</th>
            <th>Unit</th>
            <th>Supplier</th>
        </tr>
    </thead>
    <tbody>
        <?php
        try {
            $all_exp = $db->query("SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id WHERE $branch_filter ORDER BY p.id DESC")->fetchAll();
            foreach($all_exp as $p_exp) {
                echo "<tr>";
                echo "<td>" . $p_exp['sku'] . "</td>";
                echo "<td>" . $p_exp['barcode'] . "</td>";
                echo "<td>" . $p_exp['name'] . "</td>";
                echo "<td>" . $p_exp['category_name'] . "</td>";
                echo "<td>" . $p_exp['brand'] . "</td>";
                echo "<td>" . $p_exp['purchase_price'] . "</td>";
                echo "<td>" . $p_exp['sell_price'] . "</td>";
                echo "<td>" . $p_exp['stock_qty'] . "</td>";
                echo "<td>" . $p_exp['unit'] . "</td>";
                echo "<td>" . $p_exp['supplier_name'] . "</td>";
                echo "</tr>";
            }
        } catch(PDOException $e) {}
        ?>
    </tbody>
</table>

<!-- ==========================================
     PRESENTATION 1: PRODUCT LISTS TABLE
     ========================================== -->
<div id="productsTableContainer" class="card" style="display: block;">
    <div class="table-responsive">
        <table class="table" id="masterProductsListTable">
            <thead>
                <tr>
                    <th>Photo</th>
                    <th>SKU / Code</th>
                    <th>Barcode</th>
                    <th>Product Name</th>
                    <th>Category</th>
                    <th>Brand</th>
                    <th>Cost</th>
                    <th>Sale Price</th>
                    <th>Qty</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($products)): ?>
                    <tr>
                        <td colspan="10" style="text-align: center; color: var(--text-muted); padding: 45px;">No products match search criteria.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach($products as $p): ?>
                        <tr class="animate-fade">
                            <td>
                                <div style="width: 40px; height: 40px; background: var(--input-bg); border-radius: var(--radius-xs); border: 1px solid var(--border-color); display: flex; align-items: center; justify-content: center; overflow: hidden;">
                                    <?php if (!empty($p['image_path']) && file_exists($p['image_path'])): ?>
                                        <img src="<?php echo htmlspecialchars($p['image_path']); ?>" alt="Photo" style="max-width: 100%; max-height: 100%; object-fit: contain;">
                                    <?php else: ?>
                                        <i class="bx bx-image" style="color: var(--text-muted); font-size: 20px;"></i>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td style="font-weight: 600; color: var(--accent);"><?php echo htmlspecialchars($p['sku']); ?></td>
                            <td style="font-family: monospace; font-size: 13px;"><?php echo htmlspecialchars($p['barcode'] ?: '-'); ?></td>
                            <td><strong><?php echo htmlspecialchars($p['name']); ?></strong></td>
                            <td><span style="font-size: 11.5px; font-weight: 600; padding: 3px 8px; background: var(--input-bg); border-radius: var(--radius-xs);"><?php echo htmlspecialchars($p['category_name']); ?></span></td>
                            <td><?php echo htmlspecialchars($p['brand'] ?: '-'); ?></td>
                            <td><?php echo format_currency($p['purchase_price']); ?></td>
                            <td style="font-weight: 600; color: var(--accent);"><?php echo format_currency($p['sell_price']); ?></td>
                            <td>
                                <?php if ($p['stock_qty'] <= 0): ?>
                                    <span style="color: var(--error); font-weight: 700;">Sold Out</span>
                                <?php elseif ($p['stock_qty'] <= $p['min_stock_qty']): ?>
                                    <span style="color: var(--warning); font-weight: 700;">Low: <?php echo $p['stock_qty']; ?> <?php echo htmlspecialchars($p['unit']); ?></span>
                                <?php else: ?>
                                    <strong><?php echo $p['stock_qty']; ?></strong> <?php echo htmlspecialchars($p['unit']); ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="action-btns">
                                    <a href="product_details.php?id=<?php echo $p['id']; ?>" class="btn-action" title="View details profile" style="display: inline-flex; align-items: center; justify-content: center; text-decoration: none;">
                                        <i class="bx bx-show"></i>
                                    </a>
                                    <button type="button" class="btn-action" title="Edit dynamic parameters" onclick="triggerQuickEditProduct(<?php echo htmlspecialchars(json_encode($p)); ?>)">
                                        <i class="bx bx-edit"></i>
                                    </button>
                                    <form method="POST" action="delete_product.php" onsubmit="return confirm('Are you sure you want to permanently delete this product? All image files will be purged!')" style="display: inline;">
                                        <input type="hidden" name="id" value="<?php echo $p['id']; ?>">
                                        <button type="submit" class="btn-action btn-action-delete" title="Delete Product"><i class="bx bx-trash"></i></button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ==========================================
     PRESENTATION 2: PRODUCT METADATA CARDS GRID
     ========================================== -->
<div id="productsGridContainer" class="products-cards-grid" style="display: none;">
    <?php if (empty($products)): ?>
        <div class="card" style="grid-column: 1/-1; text-align: center; color: var(--text-muted); padding: 45px;">No products match filters.</div>
    <?php else: ?>
        <?php foreach($products as $p): ?>
            <div class="product-item-card animate-fade">
                <div>
                    <div class="product-card-image-box">
                        <?php if (!empty($p['image_path']) && file_exists($p['image_path'])): ?>
                            <img src="<?php echo htmlspecialchars($p['image_path']); ?>" alt="<?php echo htmlspecialchars($p['name']); ?>" class="product-card-img">
                        <?php else: ?>
                            <div class="no-image-placeholder">
                                <i class="bx bx-image"></i>
                                <span>No Image Available</span>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="product-card-meta">
                        <span style="font-size:10px; font-weight:700; text-transform:uppercase; color:var(--accent);"><?php echo htmlspecialchars($p['category_name']); ?></span>
                        <h4 class="product-card-title"><?php echo htmlspecialchars($p['name']); ?></h4>
                        <span class="product-card-sku">SKU: <?php echo htmlspecialchars($p['sku']); ?></span>
                    </div>
                </div>

                <div>
                    <div class="product-card-prices">
                        <div class="price-block">
                            <span class="price-title">Buying cost</span>
                            <span class="price-val"><?php echo format_currency($p['purchase_price']); ?></span>
                        </div>
                        <div class="price-block" style="text-align: right;">
                            <span class="price-title">Retail sale</span>
                            <span class="price-val sell"><?php echo format_currency($p['sell_price']); ?></span>
                        </div>
                    </div>

                    <div class="product-card-stock-row">
                        <span>Stock:</span>
                        <?php if ($p['stock_qty'] <= 0): ?>
                            <strong style="color: var(--error);">Sold Out</strong>
                        <?php elseif ($p['stock_qty'] <= $p['min_stock_qty']): ?>
                            <strong style="color: var(--warning);">Low (<?php echo $p['stock_qty']; ?>)</strong>
                        <?php else: ?>
                            <strong><?php echo $p['stock_qty']; ?> <?php echo htmlspecialchars($p['unit']); ?></strong>
                        <?php endif; ?>
                    </div>

                    <div style="border-top:1px solid var(--border-color); margin-top:12px; padding-top:10px; display:flex; gap:10px;">
                        <a href="product_details.php?id=<?php echo $p['id']; ?>" class="btn btn-sm btn-secondary" style="padding: 6px 12px; text-decoration:none; text-align:center; font-size:12px;">Profile</a>
                        <button type="button" class="btn btn-sm" style="padding: 6px 12px; font-size:12px;" onclick="triggerQuickEditProduct(<?php echo htmlspecialchars(json_encode($p)); ?>)">Edit</button>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- ==========================================
     REAL-TIME PAGINATION CONTROLLERS FOOTER
     ========================================== -->
<div class="pagination" style="margin-top: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <span style="font-size: 13.5px; color: var(--text-secondary);">Showing <strong><?php echo count($products); ?></strong> of <strong><?php echo $total_records; ?></strong> catalog products.</span>
    
    <div style="display: flex; gap: 5px;">
        <!-- Previous -->
        <a href="products.php?page=<?php echo ($page - 1); ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $filter_cat; ?>" 
           class="btn btn-sm btn-secondary <?php echo ($page <= 1) ? 'disabled' : ''; ?>" 
           style="width: auto; padding: 6px 12px; pointer-events: <?php echo ($page <= 1) ? 'none' : 'auto'; ?>;">
           &larr; Prev
        </a>

        <!-- Page index numbers -->
        <?php for($i = 1; $i <= $total_pages; $i++): ?>
            <a href="products.php?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $filter_cat; ?>" 
               class="btn btn-sm <?php echo ($page === $i) ? '' : 'btn-secondary'; ?>" 
               style="width: 32px; padding: 6px 0; text-align: center;">
               <?php echo $i; ?>
            </a>
        <?php endfor; ?>

        <!-- Next -->
        <a href="products.php?page=<?php echo ($page + 1); ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $filter_cat; ?>" 
           class="btn btn-sm btn-secondary <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>" 
           style="width: auto; padding: 6px 12px; pointer-events: <?php echo ($page >= $total_pages) ? 'none' : 'auto'; ?>;">
           Next &rarr;
        </a>
    </div>
</div>

<!-- ==========================================
     ADD PRODUCT OVERLAY DIALOG MODAL
     ========================================== -->
<div id="addProductModal" class="modal-overlay">
    <div class="modal-content" style="max-width: 720px;">
        <div class="modal-header">
            <h3>Register New Product</h3>
            <i class="bx bx-x modal-close" onclick="closeModal('addProductModal')"></i>
        </div>

        <form method="POST" action="add_product.php" enctype="multipart/form-data">
            
            <div style="display: grid; grid-template-columns: 1fr 1.2fr; gap: 20px;">
                
                <!-- Left form fields -->
                <div>
                    <div class="form-group">
                        <label class="form-label">Product Name *</label>
                        <input type="text" name="name" class="form-control" style="padding-left:12px; height:44px;" required placeholder="e.g. Toilet Washing Brush">
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div class="form-group">
                            <label class="form-label">SKU / Code *</label>
                            <input type="text" id="add_sku" name="sku" class="form-control" style="padding-left:12px; height:44px;" required placeholder="SKU-001">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Barcode (Numeric)</label>
                            <div style="display: flex; gap: 5px;">
                                <input type="text" id="add_barcode" name="barcode" class="form-control" style="padding-left:12px; height:44px;" placeholder="EAN-13 mockup">
                                <button type="button" class="btn btn-sm btn-secondary" title="Auto Barcode" onclick="generateRandomBarcode('add_barcode')" style="width: 44px; height:44px; display: flex; align-items: center; justify-content: center; padding: 0;"><i class="bx bx-barcode-reader" style="font-size:22px;"></i></button>
                            </div>
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div class="form-group">
                            <label class="form-label">Select Category *</label>
                            <select name="category_id" class="select-control" style="width:100%; height:44px;" required>
                                <?php foreach($categories as $cat): ?>
                                    <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Brand Name</label>
                            <input type="text" name="brand" class="form-control" style="padding-left:12px; height:44px;" placeholder="Generic / Custom">
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div class="form-group">
                            <label class="form-label">Buying Cost (PKR) *</label>
                            <input type="number" step="0.01" name="purchase_price" class="form-control" style="padding-left:12px; height:44px;" required placeholder="0.00">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Sale Price (PKR) *</label>
                            <input type="number" step="0.01" name="sell_price" class="form-control" style="padding-left:12px; height:44px;" required placeholder="0.00">
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div class="form-group">
                            <label class="form-label">Qty *</label>
                            <input type="number" name="stock_qty" class="form-control" style="padding-left:12px; height:44px;" value="0" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Unit *</label>
                            <select name="unit" class="select-control" style="width:100%; height:44px;">
                                <option value="pcs">Pieces (pcs)</option>
                                <option value="set">Set (set)</option>
                                <option value="dozen">Dozen (dozen)</option>
                                <option value="pack">Packet (pack)</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Right image upload & supplier fields -->
                <div>
                    <div class="form-group">
                        <label class="form-label">Procured Supplier Vendor</label>
                        <select name="supplier_name" class="select-control" style="width:100%; height:44px;">
                            <option value="">Walk-in / Cash purchase</option>
                            <?php foreach($suppliers as $sup): ?>
                                <option value="<?php echo htmlspecialchars($sup['name']); ?>"><?php echo htmlspecialchars($sup['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Product Description</label>
                        <textarea name="description" class="form-control" style="padding:10px; height:60px; resize:none;" placeholder="Detail specifications..."></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Upload Product Image (JPG, PNG, WEBP)</label>
                        <div class="upload-dropzone" onclick="document.getElementById('productImageAdd').click()">
                            <i class="bx bx-cloud-upload"></i>
                            <p style="font-size: 12px; color: var(--text-muted);">Click to browse image files</p>
                            <input type="file" id="productImageAdd" name="product_image" style="display:none;" accept="image/*">
                            <img id="imgPreviewAdd" class="image-preview-frame" alt="Preview Photo">
                        </div>
                    </div>
                </div>

            </div>

            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px; border-top:1.5px dashed var(--border-color); padding-top:15px;">
                <button type="button" class="btn btn-sm btn-secondary" onclick="closeModal('addProductModal')">Cancel</button>
                <button type="submit" class="btn btn-sm" style="width: auto;">Save Product</button>
            </div>
        </form>
    </div>
</div>

<!-- ==========================================
     EDIT PRODUCT OVERLAY DIALOG MODAL
     ========================================== -->
<div id="editProductModal" class="modal-overlay">
    <div class="modal-content" style="max-width: 720px;">
        <div class="modal-header">
            <h3>Modify Product Parameters</h3>
            <i class="bx bx-x modal-close" onclick="closeModal('editProductModal')"></i>
        </div>

        <form method="POST" action="edit_product.php" enctype="multipart/form-data">
            <input type="hidden" id="edit_product_id" name="id">

            <div style="display: grid; grid-template-columns: 1fr 1.2fr; gap: 20px;">
                
                <!-- Left fields -->
                <div>
                    <div class="form-group">
                        <label class="form-label">Product Name *</label>
                        <input type="text" id="edit_name" name="name" class="form-control" style="padding-left:12px; height:44px;" required>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div class="form-group">
                            <label class="form-label">SKU / Code *</label>
                            <input type="text" id="edit_sku" name="sku" class="form-control" style="padding-left:12px; height:44px;" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Barcode (Numeric)</label>
                            <div style="display: flex; gap: 5px;">
                                <input type="text" id="edit_barcode" name="barcode" class="form-control" style="padding-left:12px; height:44px;">
                                <button type="button" class="btn btn-sm btn-secondary" title="Auto Barcode" onclick="generateRandomBarcode('edit_barcode')" style="width: 44px; height:44px; display: flex; align-items: center; justify-content: center; padding: 0;"><i class="bx bx-barcode-reader" style="font-size:22px;"></i></button>
                            </div>
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div class="form-group">
                            <label class="form-label">Select Category *</label>
                            <select id="edit_category_id" name="category_id" class="select-control" style="width:100%; height:44px;" required>
                                <?php foreach($categories as $cat): ?>
                                    <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Brand Name</label>
                            <input type="text" id="edit_brand" name="brand" class="form-control" style="padding-left:12px; height:44px;">
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div class="form-group">
                            <label class="form-label">Buying Cost (PKR) *</label>
                            <input type="number" step="0.01" id="edit_purchase_price" name="purchase_price" class="form-control" style="padding-left:12px; height:44px;" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Sale Price (PKR) *</label>
                            <input type="number" step="0.01" id="edit_sell_price" name="sell_price" class="form-control" style="padding-left:12px; height:44px;" required>
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div class="form-group">
                            <label class="form-label">Stock Qty *</label>
                            <input type="number" id="edit_stock_qty" name="stock_qty" class="form-control" style="padding-left:12px; height:44px;" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Unit *</label>
                            <select id="edit_unit" name="unit" class="select-control" style="width:100%; height:44px;">
                                <option value="pcs">Pieces (pcs)</option>
                                <option value="set">Set (set)</option>
                                <option value="dozen">Dozen (dozen)</option>
                                <option value="pack">Packet (pack)</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Right image upload & supplier -->
                <div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div class="form-group">
                            <label class="form-label">Registry Status *</label>
                            <select id="edit_status" name="status" class="select-control" style="width:100%; height:44px;" required>
                                <option value="ACTIVE">Active (In Stock)</option>
                                <option value="INACTIVE">Inactive (Disabled)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Min Threshold Qty</label>
                            <input type="number" id="edit_min_stock_qty" name="min_stock_qty" class="form-control" style="padding-left:12px; height:44px;">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Supplier Vendor Name</label>
                        <select id="edit_supplier_name" name="supplier_name" class="select-control" style="width:100%; height:44px;">
                            <option value="">Walk-in / Cash Procurement</option>
                            <?php foreach($suppliers as $sup): ?>
                                <option value="<?php echo htmlspecialchars($sup['name']); ?>"><?php echo htmlspecialchars($sup['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Product Description</label>
                        <textarea id="edit_description" name="description" class="form-control" style="padding:10px; height:60px; resize:none;"></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Upload New Photo (Replaces Existing)</label>
                        <div class="upload-dropzone" onclick="document.getElementById('productImageEdit').click()">
                            <i class="bx bx-cloud-upload"></i>
                            <p style="font-size: 12px; color: var(--text-muted);">Choose file to replace</p>
                            <input type="file" id="productImageEdit" name="product_image" style="display:none;" accept="image/*">
                            <img id="imgPreviewEdit" class="image-preview-frame" alt="Preview Photo">
                        </div>
                    </div>
                </div>

            </div>

            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px; border-top:1.5px dashed var(--border-color); padding-top:15px;">
                <button type="button" class="btn btn-sm btn-secondary" onclick="closeModal('editProductModal')">Cancel</button>
                <button type="submit" class="btn btn-sm" style="width: auto;">Apply Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
/**
 * Populate Edit Product modal fields dynamically
 */
function triggerQuickEditProduct(p) {
    document.getElementById('edit_product_id').value = p.id;
    document.getElementById('edit_name').value = p.name;
    document.getElementById('edit_sku').value = p.sku;
    document.getElementById('edit_barcode').value = p.barcode || '';
    document.getElementById('edit_category_id').value = p.category_id;
    document.getElementById('edit_brand').value = p.brand || '';
    document.getElementById('edit_purchase_price').value = p.purchase_price;
    document.getElementById('edit_sell_price').value = p.sell_price;
    document.getElementById('edit_stock_qty').value = p.stock_qty;
    document.getElementById('edit_unit').value = p.unit || 'pcs';
    document.getElementById('edit_min_stock_qty').value = p.min_stock_qty || 5;
    document.getElementById('edit_status').value = p.status || 'ACTIVE';
    document.getElementById('edit_supplier_name').value = p.supplier_name || '';
    document.getElementById('edit_description').value = p.description || '';

    // If an image exists, set the preview source
    const preview = document.getElementById('imgPreviewEdit');
    if (p.image_path) {
        preview.setAttribute('src', p.image_path);
        preview.style.display = 'block';
    } else {
        preview.style.display = 'none';
    }

    openModal('editProductModal');
}
</script>

<!-- Subsystem js loader -->
<script src="products.js"></script>

<?php require_once 'includes/header.php'; ?>
