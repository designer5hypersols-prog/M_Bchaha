<?php
/**
 * Double Entry Accounting Subsystem - Profit & Loss Statement (Module 6)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();

// Enforce Access
if ($_SESSION['user_role'] !== 'ADMIN' && $_SESSION['user_role'] !== 'MANAGER') {
    die("Access Denied: You must be an Administrator or Manager to compile financial statements.");
}

$start_date = sanitize($_GET['start_date'] ?? date('Y-m-01'));
$end_date = sanitize($_GET['end_date'] ?? date('Y-m-d'));

$revenues = [];
$cogs_val = 0.00;
$expenses = [];

$total_revenue = 0.00;
$total_expenses = 0.00;

try {
    // 1. GATHER INCOME REVENUES
    $stmt = $db->prepare("SELECT a.name, a.code, COALESCE(SUM(ji.credit) - SUM(ji.debit), 0.00) as balance 
                          FROM accounts a 
                          LEFT JOIN journal_items ji ON a.id = ji.account_id 
                          LEFT JOIN journal_entries je ON ji.journal_entry_id = je.id
                          WHERE a.type = 'INCOME' AND je.entry_date BETWEEN :start AND :end
                          GROUP BY a.id");
    $stmt->execute(['start' => $start_date, 'end' => $end_date]);
    $revenues = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $total_revenue = array_sum(array_column($revenues, 'balance'));

    // 2. GATHER COGS (5100)
    $stmt_c = $db->prepare("SELECT COALESCE(SUM(ji.debit) - SUM(ji.credit), 0.00) as balance 
                            FROM journal_items ji 
                            JOIN accounts a ON ji.account_id = a.id
                            LEFT JOIN journal_entries je ON ji.journal_entry_id = je.id
                            WHERE a.code = '5100' AND je.entry_date BETWEEN :start AND :end");
    $stmt_c->execute(['start' => $start_date, 'end' => $end_date]);
    $cogs_val = (float)$stmt_c->fetchColumn();

    // 3. GATHER OPERATING EXPENSES (5200)
    $stmt_e = $db->prepare("SELECT a.name, a.code, COALESCE(SUM(ji.debit) - SUM(ji.credit), 0.00) as balance 
                            FROM accounts a 
                            LEFT JOIN journal_items ji ON a.id = ji.account_id 
                            LEFT JOIN journal_entries je ON ji.journal_entry_id = je.id
                            WHERE a.type = 'EXPENSE' AND a.code != '5100' AND je.entry_date BETWEEN :start AND :end
                            GROUP BY a.id");
    $stmt_e->execute(['start' => $start_date, 'end' => $end_date]);
    $expenses = $stmt_e->fetchAll(PDO::FETCH_ASSOC);
    $total_expenses = array_sum(array_column($expenses, 'balance'));

} catch(PDOException $e) {}

$gross_profit = $total_revenue - $cogs_val;
$net_profit = $gross_profit - $total_expenses;

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<!-- ==========================================
     A. DATE RANGE SELECTOR BAR
     ========================================== -->
<div class="card" style="margin-bottom:24px; padding:16px;">
    <form method="GET" action="profit_loss_statement.php" style="display:flex; gap:16px; align-items:flex-end; flex-wrap:wrap;">
        <div style="flex-grow:1; min-width:200px;">
            <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Start Date</label>
            <input type="date" name="start_date" value="<?php echo $start_date; ?>" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;">
        </div>

        <div style="flex-grow:1; min-width:200px;">
            <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">End Date</label>
            <input type="date" name="end_date" value="<?php echo $end_date; ?>" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;">
        </div>

        <div>
            <button type="submit" class="btn" style="background:var(--accent); border-color:var(--accent); height:40px; width:auto; font-size:13.5px; padding:0 24px;">
                <i class="bx bx-filter" style="margin-right:4px;"></i> Filter Statement
            </button>
        </div>
    </form>
</div>

<!-- ==========================================
     B. PROFIT AND LOSS STATEMENTS CARD
     ========================================== -->
<div class="card" style="max-width: 800px; margin: 0 auto;">
    <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color); display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
        <div class="card-title">
            <i class="bx bx-file" style="color:var(--accent);"></i>
            <span>Corporate Income Statement (Profit & Loss)</span>
        </div>
        <button type="button" class="btn btn-sm" onclick="window.print()" style="background:var(--bg-secondary); border-color:var(--border-color); height:30px; width:auto; font-size:11px; padding:0 12px; color:var(--text-main);">
            <i class="bx bx-printer" style="margin-right:4px;"></i> Print
        </button>
    </div>

    <!-- P&L Sheet Items -->
    <div style="display:flex; flex-direction:column; gap:12px; font-size:14px;">
        
        <!-- 1. Revenue Block -->
        <div style="font-weight:800; font-size:15px; color:var(--text-main); border-bottom:1px solid var(--border-color); padding-bottom:4px; margin-top:10px;">OPERATING REVENUES</div>
        <?php foreach($revenues as $rev): ?>
            <div style="display:flex; justify-content:space-between; padding-left:20px;">
                <span><?php echo htmlspecialchars($rev['name']); ?> (<?php echo $rev['code']; ?>)</span>
                <strong>Rs. <?php echo number_format($rev['balance'], 2); ?></strong>
            </div>
        <?php endforeach; ?>
        <div style="display:flex; justify-content:space-between; border-bottom: 1.5px solid var(--border-color); padding-bottom:6px; font-weight:700;">
            <span>Gross Revenue Total</span>
            <span>Rs. <?php echo number_format($total_revenue, 2); ?></span>
        </div>

        <!-- 2. Cost of Goods Block -->
        <div style="font-weight:800; font-size:15px; color:var(--text-main); border-bottom:1px solid var(--border-color); padding-bottom:4px; margin-top:15px;">COST OF GOODS SOLD</div>
        <div style="display:flex; justify-content:space-between; padding-left:20px;">
            <span>Inventory restock deductions (5100)</span>
            <strong>Rs. <?php echo number_format($cogs_val, 2); ?></strong>
        </div>
        <div style="display:flex; justify-content:space-between; border-bottom: 2px solid var(--border-color); padding-bottom:6px; font-weight:800; color:var(--text-main);">
            <span>GROSS PROFIT MARGIN</span>
            <span style="color:var(--accent);">Rs. <?php echo number_format($gross_profit, 2); ?></span>
        </div>

        <!-- 3. Expenses Block -->
        <div style="font-weight:800; font-size:15px; color:var(--text-main); border-bottom:1px solid var(--border-color); padding-bottom:4px; margin-top:15px;">OPERATING EXPENSES</div>
        <?php foreach($expenses as $exp): ?>
            <div style="display:flex; justify-content:space-between; padding-left:20px;">
                <span><?php echo htmlspecialchars($exp['name']); ?> (<?php echo $exp['code']; ?>)</span>
                <strong>Rs. <?php echo number_format($exp['balance'], 2); ?></strong>
            </div>
        <?php endforeach; ?>
        <div style="display:flex; justify-content:space-between; border-bottom: 1.5px solid var(--border-color); padding-bottom:6px; font-weight:700;">
            <span>Operating Expenses Total</span>
            <span>Rs. <?php echo number_format($total_expenses, 2); ?></span>
        </div>

        <!-- 4. Net Profit Block -->
        <div style="display:flex; justify-content:space-between; margin-top:20px; padding:16px; background:var(--bg-secondary); border-radius:var(--radius-sm); border:1.5px solid <?php echo ($net_profit >= 0) ? 'var(--accent)' : 'var(--danger)'; ?>;">
            <strong style="font-size:16px; color:var(--text-main);">NET INCOME / (LOSS) PROJECTIONS</strong>
            <strong style="font-size:20px; color:<?php echo ($net_profit >= 0) ? 'var(--accent)' : 'var(--danger)'; ?>;">
                Rs. <?php echo number_format($net_profit, 2); ?>
            </strong>
        </div>

    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
