<?php
/**
 * Multi-Branch ERP Subsystem - Super Admin Central Control Dashboard (Module 3)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();

// Enforce Central Admin Access
if ($_SESSION['user_role'] !== 'SUPERADMIN' && $_SESSION['user_role'] !== 'ADMIN') {
    die("Access Denied: You must be a Super Administrator to view corporate central dashboards.");
}

// ==========================================
// 1. CALCULATE COMPANY-WIDE KPIs
// ==========================================
$total_revenue = 0.00;
$total_branches_count = 0;
$total_products_count = 0;

try {
    // Total company revenue sum
    $total_revenue = (float)$db->query("SELECT SUM(payable_amount) FROM sales")->fetchColumn();

    // Total branches count
    $total_branches_count = (int)$db->query("SELECT COUNT(*) FROM branches WHERE status = 'ACTIVE'")->fetchColumn();

    // Total products count
    $total_products_count = (int)$db->query("SELECT COUNT(*) FROM products")->fetchColumn();
} catch (PDOException $e) {}

// ==========================================
// 2. GATHER COMPARATIVE PERFORMANCE PER BRANCH
// ==========================================
$branch_performance = [];
$chart_names = [];
$chart_sales = [];

try {
    $branches = $db->query("SELECT id, name FROM branches WHERE status = 'ACTIVE'")->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($branches as $b) {
        $bid = $b['id'];
        
        // Sales total
        $sales_stmt = $db->prepare("SELECT COALESCE(SUM(payable_amount), 0.00) FROM sales WHERE branch_id = :bid");
        $sales_stmt->execute(['bid' => $bid]);
        $sales_sum = (float)$sales_stmt->fetchColumn();

        // Transaction count
        $txn_stmt = $db->prepare("SELECT COUNT(*) FROM sales WHERE branch_id = :bid");
        $txn_stmt->execute(['bid' => $bid]);
        $txns_count = (int)$txn_stmt->fetchColumn();

        // Stock count
        $stock_stmt = $db->prepare("SELECT COALESCE(SUM(stock_qty), 0) FROM products WHERE branch_id = :bid");
        $stock_stmt->execute(['bid' => $bid]);
        $stocks_sum = (int)$stock_stmt->fetchColumn();

        $branch_performance[] = [
            'id' => $bid,
            'name' => $b['name'],
            'sales' => $sales_sum,
            'transactions' => $txns_count,
            'stocks' => $stocks_sum
        ];

        $chart_names[] = $b['name'];
        $chart_sales[] = $sales_sum;
    }
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<!-- ==========================================
     A. EXECUTIVE STAT CARDS
     ========================================== -->
<div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); margin-bottom: 24px;">
    
    <!-- Total Company Sales -->
    <div class="stat-card success">
        <div class="stat-info">
            <span>Overall Company Turnover</span>
            <h2>Rs. <?php echo number_format($total_revenue, 2); ?></h2>
        </div>
        <div class="stat-icon">
            <i class="bx bx-bar-chart-square"></i>
        </div>
    </div>

    <!-- Active Branches count -->
    <div class="stat-card primary">
        <div class="stat-info">
            <span>Active Operational Outlets</span>
            <h2><?php echo $total_branches_count; ?> Branches</h2>
        </div>
        <div class="stat-icon">
            <i class="bx bx-buildings"></i>
        </div>
    </div>

    <!-- Total Company Stock lines -->
    <div class="stat-card warning">
        <div class="stat-info">
            <span>System Stock Varieties</span>
            <h2><?php echo $total_products_count; ?> Products</h2>
        </div>
        <div class="stat-icon">
            <i class="bx bx-cabinet"></i>
        </div>
    </div>

</div>

<!-- ==========================================
     B. SPLIT LAYOUT: CHART VS DIRECTORY SUMMARY
     ========================================== -->
<div style="display:grid; grid-template-columns: 1.5fr 1fr; gap: 24px; align-items:start;">

    <!-- Left: Branch Performance Matrix table -->
    <div class="card">
        <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-grid-alt" style="color:var(--accent);"></i>
                <span>Outlets Performance Comparison Matrix</span>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table" style="--table-padding: 12px 14px;">
                <thead>
                    <tr>
                        <th>Branch Outlet</th>
                        <th style="text-align:right;">Sales Revenue (Rs.)</th>
                        <th style="text-align:center;">Transactions</th>
                        <th style="text-align:center;">Warehouse stock (Qty)</th>
                        <th style="text-align:center;">Options</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($branch_performance as $bp): ?>
                        <tr class="animate-fade">
                            <td><strong><?php echo htmlspecialchars($bp['name']); ?></strong></td>
                            <td style="text-align:right; font-weight:800; color:var(--accent);">
                                Rs. <?php echo number_format($bp['sales'], 2); ?>
                            </td>
                            <td style="text-align:center; font-weight:700;"><?php echo $bp['transactions']; ?> orders</td>
                            <td style="text-align:center; font-weight:700;"><?php echo number_format($bp['stocks']); ?> pcs</td>
                            <td style="text-align:center;">
                                <a href="branch_reports.php?branch_id=<?php echo $bp['id']; ?>" class="btn btn-sm" style="height:28px; width:auto; font-size:11px; padding:0 10px; background:var(--bg-secondary); border-color:var(--border-color); color:var(--text-main); text-decoration:none;">
                                    View Reports
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Right: ChartJS comparative analytics -->
    <div class="card" style="height: 100%;">
        <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-pie-chart-alt" style="color:var(--accent);"></i>
                <span>Outlets Sales Turnover chart</span>
            </div>
        </div>

        <div style="position:relative; height: 260px;">
            <canvas id="branchSalesChart" 
                    data-names="<?php echo htmlspecialchars(json_encode($chart_names)); ?>" 
                    data-sales="<?php echo htmlspecialchars(json_encode($chart_sales)); ?>">
            </canvas>
        </div>
    </div>

</div>

<!-- ChartJS dynamic binder script -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('branchSalesChart');
    if (canvas) {
        const names = JSON.parse(canvas.getAttribute('data-names') || '[]');
        const sales = JSON.parse(canvas.getAttribute('data-sales') || '[]').map(Number);

        const ctx = canvas.getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: names,
                datasets: [{
                    label: 'Turnover (Rs.)',
                    data: sales,
                    backgroundColor: 'rgba(16, 185, 129, 0.85)',
                    hoverBackgroundColor: '#10b981',
                    borderRadius: 8,
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    x: { ticks: { color: '#8292a6' }, grid: { display: false } },
                    y: { ticks: { color: '#8292a6' }, grid: { color: 'rgba(255,255,255,0.03)' } }
                }
            }
        });
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>
