<?php
/**
 * Automated Notifications Subsystem - WhatsApp Dispatcher (Module 1)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'sms_service.php';

class WhatsAppService {
    private $db;
    private $twilio_sid;
    private $twilio_token;
    private $twilio_number;

    public function __construct($dbConnection = null) {
        $this->db = $dbConnection ?: (new Database())->connect();
        
        // 1. SELF-HEALING DATABASE MIGRATION CHECK FOR TABLES
        try {
            $this->db->query("SELECT 1 FROM templates LIMIT 1");
        } catch (PDOException $e) {
            try {
                $this->db->exec("CREATE TABLE IF NOT EXISTS `templates` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `template_key` VARCHAR(50) NOT NULL UNIQUE,
                    `template_name` VARCHAR(100) NOT NULL,
                    `language` ENUM('ENGLISH', 'URDU') NOT NULL DEFAULT 'ENGLISH',
                    `message_body` TEXT NOT NULL,
                    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

                $this->db->exec("CREATE TABLE IF NOT EXISTS `messages` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `customer_id` INT DEFAULT NULL,
                    `recipient_number` VARCHAR(20) NOT NULL,
                    `channel` ENUM('WHATSAPP', 'SMS') NOT NULL DEFAULT 'WHATSAPP',
                    `message_text` TEXT NOT NULL,
                    `status` ENUM('PENDING', 'SENT', 'FAILED') NOT NULL DEFAULT 'PENDING',
                    `retry_count` INT DEFAULT 0,
                    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

                $this->db->exec("CREATE TABLE IF NOT EXISTS `message_logs` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `message_id` INT DEFAULT NULL,
                    `gateway_response` TEXT DEFAULT NULL,
                    `status` ENUM('SENT', 'FAILED') NOT NULL,
                    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

                // Seed Default message templates
                $this->db->exec("INSERT IGNORE INTO templates (template_key, template_name, language, message_body) VALUES 
                    ('SALE_INVOICE', 'Sales Receipt (English)', 'ENGLISH', 'Dear {{customer_name}}, thank you for shopping at M.BAKAR BALOCH! Your Invoice #{{invoice_no}} total is Rs. {{payable_amount}}. Visit again!'),
                    ('PAYMENT_RECEIPT', 'Payment Confirmation (Urdu)', 'URDU', 'Pyare {{customer_name}}, aap ki payment Rs. {{amount}} M.BAKAR BALOCH par wasool ho chuki hai. Aap ka baqi outstanding balance Rs. {{balance}} hai. Shukriya!'),
                    ('DUE_REMINDER', 'Due Payment Reminder', 'URDU', 'Aap se guzarish hai ke aap ka outstanding balance Rs. {{balance}} jald az jald M.BAKAR BALOCH shop par jama karayein. Shukriya!')");
            } catch(PDOException $ex) {}
        }

        // Fetch Twilio API settings from the global settings database if present, else use placeholders
        try {
            $raw = $this->db->query("SELECT key_name, key_value FROM settings WHERE key_name LIKE 'twilio_%'")->fetchAll();
            $settings = [];
            foreach ($raw as $r) {
                $settings[$r['key_name']] = $r['key_value'];
            }
            $this->twilio_sid = $settings['twilio_sid'] ?? 'AC_MOCK_TWILIO_SID_MBAKAR';
            $this->twilio_token = $settings['twilio_token'] ?? 'TOKEN_MOCK_TWILIO_TOKEN_MBAKAR';
            $this->twilio_number = $settings['twilio_number'] ?? '+14155238886'; // Twilio Sandbox
        } catch(PDOException $e) {
            $this->twilio_sid = 'AC_MOCK_TWILIO_SID_MBAKAR';
            $this->twilio_token = 'TOKEN_MOCK_TWILIO_TOKEN_MBAKAR';
            $this->twilio_number = '+14155238886';
        }
    }

    /**
     * Send Automated WhatsApp Message with Fallback System
     */
    public function sendWhatsAppMessage($customerId, $recipient, $messageText) {
        // Normalize number format (remove starting 0 and prefix +92 for Pakistan)
        $normalized_phone = preg_replace('/^0/', '+92', trim($recipient));
        if (!str_starts_with($normalized_phone, '+')) {
            $normalized_phone = '+' . $normalized_phone;
        }

        // 1. INSERT MESSAGE IN QUEUE
        $msg_id = 0;
        try {
            $ins = $this->db->prepare("INSERT INTO messages (customer_id, recipient_number, channel, message_text, status) 
                                       VALUES (:c_id, :phone, 'WHATSAPP', :msg, 'PENDING')");
            $ins->execute([
                'c_id' => $customerId ?: null,
                'phone' => $normalized_phone,
                'msg' => $messageText
            ]);
            $msg_id = $this->db->lastInsertId();
        } catch(PDOException $e) {}

        // If mock API sid is set, simulate successful delivery (zero cost local simulation)
        if ($this->twilio_sid === 'AC_MOCK_TWILIO_SID_MBAKAR') {
            $this->logDelivery($msg_id, 'SENT', 'Local Twilio Sandbox Simulation Successful.');
            return true;
        }

        // 2. DISPATCH ACTUAL HTTP REQUEST (TWILIO API INTEGRATION)
        $url = "https://api.twilio.com/2010-04-01/Accounts/" . $this->twilio_sid . "/Messages.json";
        $data = [
            'From' => 'whatsapp:' . $this->twilio_number,
            'To' => 'whatsapp:' . $normalized_phone,
            'Body' => $messageText
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_USERPWD, $this->twilio_sid . ":" . $this->twilio_token);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($http_code === 201) {
            $this->logDelivery($msg_id, 'SENT', $response);
            return true;
        } else {
            // WHATSAPP DISPATCH FAILED - TRIGGER AUTOMATIC SMS FALLBACK!
            $this->logDelivery($msg_id, 'FAILED', "WhatsApp API HTTP status $http_code: $response");
            
            // Invoke SMS fallback channel
            $sms = new SMSService($this->db);
            return $sms->sendSMSMessage($customerId, $recipient, $messageText . " (M.BAKAR BALOCH)");
        }
    }

    /**
     * Log details of message dispatch response
     */
    private function logDelivery($msgId, $status, $response) {
        if ($msgId <= 0) return;
        try {
            // Update queue status
            $upd = $this->db->prepare("UPDATE messages SET status = :status WHERE id = :id");
            $upd->execute(['status' => $status, 'id' => $msgId]);

            // Save log details
            $log = $this->db->prepare("INSERT INTO message_logs (message_id, gateway_response, status) VALUES (:m_id, :resp, :status)");
            $log->execute([
                'm_id' => $msgId,
                'resp' => substr($response, 0, 500),
                'status' => $status
            ]);
        } catch(PDOException $e) {}
    }
}
