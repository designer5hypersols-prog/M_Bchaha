<?php
/**
 * Double Entry Accounting Subsystem - Journal Entries Book (Module 2)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';
require_once 'accounting_engine.php';

$db = (new Database())->connect();
$engine = new AccountingEngine($db);

$error_message = "";
$success_message = "";

// Enforce Admin Rights
if ($_SESSION['user_role'] !== 'ADMIN' && $_SESSION['user_role'] !== 'MANAGER') {
    die("Access Denied: You must be an Administrator or Manager to post journal entries.");
}

// ==========================================
// PROCESS POST MANUAL JOURNAL ENTRY
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $entry_date = sanitize($_POST['entry_date'] ?? date('Y-m-d'));
    $ref_no = sanitize($_POST['reference_no'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    
    // Arrays of items
    $acc_codes = $_POST['acc_code'] ?? [];
    $debits = $_POST['debit'] ?? [];
    $credits = $_POST['credit'] ?? [];

    $items = [];
    for ($i = 0; $i < count($acc_codes); $i++) {
        if (empty($acc_codes[$i])) continue;
        $items[] = [
            'code' => sanitize($acc_codes[$i]),
            'debit' => (float)($debits[$i] ?? 0.00),
            'credit' => (float)($credits[$i] ?? 0.00)
        ];
    }

    if (!empty($items)) {
        try {
            $engine->postJournalEntry($entry_date, $ref_no, $description, $items);
            $success_message = "Double Entry Journal has been posted successfully and reflected in all ledger accounts.";
        } catch (Exception $e) {
            $error_message = $e->getMessage();
        }
    } else {
        $error_message = "Please add at least two ledger entry lines to post.";
    }
}

// ==========================================
// LOAD CHART OF ACCOUNTS FOR SELECTIONS
// ==========================================
$accounts = [];
try {
    $accounts = $db->query("SELECT code, name FROM accounts ORDER BY code ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {}

// ==========================================
// LOAD JOURNAL ENTRIES BOOK HISTORY
// ==========================================
$entries = [];
try {
    $stmt = $db->query("SELECT je.*, ji.debit, ji.credit, a.code as acc_code, a.name as acc_name 
                        FROM journal_entries je 
                        JOIN journal_items ji ON je.id = ji.journal_entry_id 
                        JOIN accounts a ON ji.account_id = a.id 
                        ORDER BY je.id DESC, ji.id ASC LIMIT 100");
    
    // Group items by journal_entry_id
    $raw_entries = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($raw_entries as $row) {
        $eid = $row['id'];
        if (!isset($entries[$eid])) {
            $entries[$eid] = [
                'id' => $row['id'],
                'entry_date' => $row['entry_date'],
                'reference_no' => $row['reference_no'],
                'description' => $row['description'],
                'items' => []
            ];
        }
        $entries[$eid]['items'][] = [
            'code' => $row['acc_code'],
            'name' => $row['acc_name'],
            'debit' => $row['debit'],
            'credit' => $row['credit']
        ];
    }
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<!-- Action Notifications -->
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo $error_message; ?></span>
    </div>
<?php endif; ?>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success">
        <i class="bx bx-check-circle"></i>
        <span><?php echo $success_message; ?></span>
    </div>
<?php endif; ?>

<div style="margin-bottom: 24px;">
    <a href="settings.php#subsystems_link" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
        <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Settings Hub
    </a>
</div>

<div style="display:grid; grid-template-columns:1.5fr 1fr; gap:24px; align-items:start;">

    <!-- ==========================================
         A. JOURNAL ENTRIES HISTORY LIST
         ========================================== -->
    <div class="card">
        <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-receipt" style="color:var(--accent);"></i>
                <span>Historical Journal Entries Book</span>
            </div>
        </div>

        <div style="display:flex; flex-direction:column; gap:20px;">
            <?php if (empty($entries)): ?>
                <div style="text-align: center; color: var(--text-muted); padding: 40px;">No journal entries posted yet.</div>
            <?php else: ?>
                <?php foreach($entries as $e): ?>
                    <div style="background:var(--bg-base); border:1px solid var(--border-color); padding:16px; border-radius:var(--radius-sm);">
                        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:12px; border-bottom:1.5px dashed var(--border-color); padding-bottom:8px;">
                            <div>
                                <strong style="color:var(--accent);">Ref: <?php echo htmlspecialchars($e['reference_no'] ?: 'GEN-ENTRY'); ?></strong>
                                <span style="font-size:11px; color:var(--text-muted); margin-left:12px;"><?php echo format_date($e['entry_date']); ?></span>
                            </div>
                            <span style="font-size:11px; font-weight:700; color:var(--text-muted);">Entry ID: #<?php echo $e['id']; ?></span>
                        </div>

                        <p style="font-size:13px; color:var(--text-secondary); margin-bottom:12px;"><strong>Memo:</strong> <?php echo htmlspecialchars($e['description']); ?></p>

                        <table class="table" style="--table-padding: 6px 8px; font-size:12.5px;">
                            <thead>
                                <tr>
                                    <th>Account Code</th>
                                    <th>Account Description</th>
                                    <th style="text-align:right;">Debit</th>
                                    <th style="text-align:right;">Credit</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($e['items'] as $item): ?>
                                    <tr>
                                        <td><code><?php echo htmlspecialchars($item['code']); ?></code></td>
                                        <td>
                                            <?php if ($item['credit'] > 0): ?>
                                                <span style="display:inline-block; margin-left: 20px;">&rarr; <?php echo htmlspecialchars($item['name']); ?></span>
                                            <?php else: ?>
                                                <strong><?php echo htmlspecialchars($item['name']); ?></strong>
                                            <?php endif; ?>
                                        </td>
                                        <td style="text-align:right; font-weight:<?php echo ($item['debit'] > 0) ? '700' : '400'; ?>;">
                                            <?php echo ($item['debit'] > 0) ? 'Rs. ' . number_format($item['debit'], 2) : '-'; ?>
                                        </td>
                                        <td style="text-align:right; font-weight:<?php echo ($item['credit'] > 0) ? '700' : '400'; ?>;">
                                            <?php echo ($item['credit'] > 0) ? 'Rs. ' . number_format($item['credit'], 2) : '-'; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- ==========================================
         B. JOURNAL ENTRY CREATION FORM
         ========================================== -->
    <div class="card" style="position:sticky; top:20px;">
        <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-plus-circle" style="color:var(--accent);"></i>
                <span>Post Manual Journal Entry</span>
            </div>
        </div>

        <form method="POST" action="journal_entries.php" style="display:flex; flex-direction:column; gap:16px;">
            <div>
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Entry Date</label>
                <input type="date" name="entry_date" value="<?php echo date('Y-m-d'); ?>" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;" required>
            </div>

            <div>
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Reference No / Voucher</label>
                <input type="text" name="reference_no" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;" required placeholder="e.g. JV-001">
            </div>

            <div>
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Description / Memo</label>
                <textarea name="description" style="width:100%; height:50px; padding:12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px; font-family:inherit; resize:none;" placeholder="Notes regarding capital flows..."></textarea>
            </div>

            <!-- Double Entry dynamic line rows -->
            <div style="border-top:1px dashed var(--border-color); padding-top:12px;">
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:10px; text-transform:uppercase;">Entry Lines (Debit vs Credit)</label>
                
                <div id="entryLinesContainer" style="display:flex; flex-direction:column; gap:10px;">
                    <!-- Line Row 1 -->
                    <div style="display:grid; grid-template-columns:1.5fr 1fr 1fr; gap:8px;">
                        <select name="acc_code[]" style="height:38px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:12.5px; padding:0 8px;">
                            <option value="">Select Account</option>
                            <?php foreach($accounts as $acc): ?>
                                <option value="<?php echo $acc['code']; ?>"><?php echo $acc['code']; ?> - <?php echo $acc['name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="number" step="0.01" name="debit[]" placeholder="Debit" style="height:38px; padding:0 8px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:12.5px;">
                        <input type="number" step="0.01" name="credit[]" placeholder="Credit" style="height:38px; padding:0 8px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:12.5px;">
                    </div>

                    <!-- Line Row 2 -->
                    <div style="display:grid; grid-template-columns:1.5fr 1fr 1fr; gap:8px;">
                        <select name="acc_code[]" style="height:38px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:12.5px; padding:0 8px;">
                            <option value="">Select Account</option>
                            <?php foreach($accounts as $acc): ?>
                                <option value="<?php echo $acc['code']; ?>"><?php echo $acc['code']; ?> - <?php echo $acc['name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="number" step="0.01" name="debit[]" placeholder="Debit" style="height:38px; padding:0 8px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:12.5px;">
                        <input type="number" step="0.01" name="credit[]" placeholder="Credit" style="height:38px; padding:0 8px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:12.5px;">
                    </div>
                </div>

                <div style="margin-top:10px; display:flex; justify-content:space-between; align-items:center;">
                    <button type="button" class="btn btn-sm" onclick="addNewEntryRow()" style="height:28px; width:auto; font-size:11.5px; padding:0 10px; background:var(--bg-secondary); border-color:var(--border-color);">
                        <i class="bx bx-plus"></i> Add Line Row
                    </button>
                </div>
            </div>

            <button type="submit" class="btn" style="background:var(--accent); border-color:var(--accent); height:40px; font-weight:700; width:100%;">
                <i class="bx bx-check-circle" style="margin-right:4px;"></i> Post Voucher Entry
            </button>
        </form>
    </div>

</div>

<!-- JavaScript to append rows dynamically -->
<script>
function addNewEntryRow() {
    const container = document.getElementById('entryLinesContainer');
    const newRow = document.createElement('div');
    newRow.style.display = 'grid';
    newRow.style.gridTemplateColumns = '1.5fr 1fr 1fr';
    newRow.style.gap = '8px';
    
    // Copy options from first select
    const firstSelect = container.querySelector('select');
    const optionsHtml = firstSelect ? firstSelect.innerHTML : '<option value="">Select Account</option>';

    newRow.innerHTML = `
        <select name="acc_code[]" style="height:38px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:12.5px; padding:0 8px;">
            ${optionsHtml}
        </select>
        <input type="number" step="0.01" name="debit[]" placeholder="Debit" style="height:38px; padding:0 8px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:12.5px;">
        <input type="number" step="0.01" name="credit[]" placeholder="Credit" style="height:38px; padding:0 8px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:12.5px;">
    `;
    container.appendChild(newRow);
}
</script>

<?php require_once 'includes/footer.php'; ?>
