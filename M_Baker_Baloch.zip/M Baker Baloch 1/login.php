<?php
/**
 * SaaS Auth Entrance Portal - UI Screen
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect to dashboard if session token exists
if (isset($_SESSION['user_id'])) {
    header("Location: modules/dashboard/index.php");
    exit;
}

$error_message = "";
if (isset($_SESSION['login_error'])) {
    $error_message = $_SESSION['login_error'];
    unset($_SESSION['login_error']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In - M.BAKAR BALOCH ERP SaaS</title>
    <!-- Boxicons CDN -->
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <style>
        :root {
            --bg-dark: #0f172a;
            --primary: #10b981;
            --primary-hover: #059669;
            --card-bg: rgba(30, 41, 59, 0.7);
            --border: rgba(255, 255, 255, 0.08);
            --text-main: #f8fafc;
            --text-secondary: #94a3b8;
            --danger: #ef4444;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: radial-gradient(circle at top right, #022c22 0%, var(--bg-dark) 60%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            color: var(--text-main);
            overflow-x: hidden;
        }

        .auth-container {
            width: 100%;
            max-width: 440px;
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 40px;
            backdrop-filter: blur(12px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
            animation: fadeIn 0.6s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .auth-header {
            text-align: center;
            margin-bottom: 32px;
        }

        .brand-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, var(--primary), var(--primary-hover));
            border-radius: 12px;
            color: #fff;
            font-size: 24px;
            font-weight: 800;
            box-shadow: 0 4px 20px rgba(16, 185, 129, 0.3);
            margin-bottom: 16px;
        }

        .auth-header h1 {
            font-size: 22px;
            font-weight: 700;
            letter-spacing: -0.5px;
            margin-bottom: 6px;
        }

        .auth-header p {
            font-size: 13.5px;
            color: var(--text-secondary);
        }

        .alert {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.2);
            color: var(--danger);
            font-size: 13px;
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: var(--text-secondary);
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .input-wrapper {
            position: relative;
        }

        .input-wrapper i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-secondary);
            font-size: 18px;
        }

        .form-control {
            width: 100%;
            background: rgba(15, 23, 42, 0.6);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 12px 14px 12px 42px;
            color: var(--text-main);
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.15);
        }

        .btn-submit {
            width: 100%;
            background: linear-gradient(135deg, var(--primary), var(--primary-hover));
            border: none;
            color: #fff;
            font-weight: 600;
            font-size: 14.5px;
            padding: 14px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.2);
            margin-top: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-submit:hover {
            transform: translateY(-1px);
            box-shadow: 0 6px 16px rgba(16, 185, 129, 0.3);
        }

        .demo-guide {
            margin-top: 24px;
            padding-top: 20px;
            border-top: 1px dashed var(--border);
            text-align: center;
            font-size: 12.5px;
            color: var(--text-secondary);
        }

        .demo-credentials {
            background: rgba(15, 23, 42, 0.4);
            border: 1px solid var(--border);
            padding: 10px;
            border-radius: 6px;
            margin-top: 8px;
            text-align: left;
            font-family: monospace;
            font-size: 11.5px;
            color: var(--text-main);
        }
    </style>
</head>
<body>

<div class="auth-container">
    <div class="auth-header">
        <div class="brand-badge">MB</div>
        <h1>ERP Cloud Portal</h1>
        <p>Sign in to launch your retail dashboard</p>
    </div>

    <?php if (!empty($error_message)): ?>
        <div class="alert">
            <i class="bx bx-error-circle"></i>
            <span><?php echo htmlspecialchars($error_message); ?></span>
        </div>
    <?php endif; ?>

    <form action="auth/login.php" method="POST">
        <!-- Email Input -->
        <div class="form-group">
            <label for="email">Email Address</label>
            <div class="input-wrapper">
                <i class="bx bx-envelope"></i>
                <input type="email" id="email" name="email" class="form-control" placeholder="name@business.com" required autocomplete="email">
            </div>
        </div>

        <!-- Password Input -->
        <div class="form-group">
            <label for="password">Security Password</label>
            <div class="input-wrapper">
                <i class="bx bx-lock-alt"></i>
                <input type="password" id="password" name="password" class="form-control" placeholder="••••••••" required>
            </div>
        </div>

        <!-- Submit Button -->
        <button type="submit" class="btn-submit">
            <span>Secure Log In</span>
            <i class="bx bx-right-arrow-alt"></i>
        </button>
    </form>

    <div class="demo-guide">
        <i class="bx bx-info-circle"></i> Try Multi-Tenant Demo credentials:
        <div class="demo-credentials">
            <strong>Tenant 1 (M.Bakar Baloch):</strong><br>
            Email: <code>admin@mbakar.com</code><br>
            Password: <code>admin123</code>
            <div style="margin-top:6px; border-top:1px dashed var(--border); padding-top:6px;"></div>
            <strong>Tenant 2 (Quetta Dry Fruits):</strong><br>
            Email: <code>admin@quetta.com</code><br>
            Password: <code>admin123</code>
        </div>
    </div>
</div>

</body>
</html>
