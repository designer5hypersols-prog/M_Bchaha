<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/database.php';

$db = Database::getInstance();
$tenant_id = Auth::tenantId();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'checkout') {
    // AJAX Checkout Logic
    $cart = json_decode($_POST['cart'], true);
    $total = 0;
    foreach($cart as $item) { $total += $item['price'] * $item['qty']; }
    
    $stmt = $db->prepare("INSERT INTO sales (tenant_id, invoice_no, customer_name, total, grand_total, paid) VALUES (?, ?, ?, ?, ?, ?)");
    $invoice_no = 'INV-' . time();
    $stmt->execute([$tenant_id, $invoice_no, 'Walk-in', $total, $total, $total]);
    $sale_id = $db->lastInsertId();

    $itemStmt = $db->prepare("INSERT INTO sale_items (sale_id, product_id, product_name, price, quantity, subtotal) VALUES (?, ?, ?, ?, ?, ?)");
    $stockStmt = $db->prepare("UPDATE products SET stock = stock - ? WHERE id = ? AND tenant_id = ?");

    foreach($cart as $item) {
        $sub = $item['price'] * $item['qty'];
        $itemStmt->execute([$sale_id, $item['id'], $item['name'], $item['price'], $item['qty'], $sub]);
        $stockStmt->execute([$item['qty'], $item['id'], $tenant_id]);
    }
    
    echo json_encode(['success' => true, 'invoice' => $invoice_no]);
    exit;
}

$stmt = $db->prepare("SELECT * FROM products WHERE tenant_id = ? AND stock > 0");
$stmt->execute([$tenant_id]);
$products = $stmt->fetchAll();
?>
<div class="row">
    <div class="col-md-8">
        <h4>Products</h4>
        <div class="row">
            <?php foreach($products as $p): ?>
            <div class="col-md-3 mb-3">
                <div class="card p-3 shadow-sm border-0 cursor-pointer" onclick="addToCart(<?= $p['id'] ?>, '<?= addslashes(htmlspecialchars($p['name'])) ?>', <?= $p['price'] ?>)">
                    <h6 class="mb-1"><?= htmlspecialchars($p['name']) ?></h6>
                    <div class="text-success fw-bold">Rs. <?= $p['price'] ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm border-0 p-3 bg-white h-100">
            <h4>Cart</h4>
            <div id="cart-items" class="flex-grow-1" style="min-height:300px; overflow-y:auto;"></div>
            <div class="border-top pt-3 mt-3">
                <div class="d-flex justify-content-between fs-5 fw-bold">
                    <span>Total:</span>
                    <span id="cart-total">Rs. 0.00</span>
                </div>
                <button class="btn btn-success w-100 mt-3" onclick="checkout()">Complete Sale</button>
            </div>
        </div>
    </div>
</div>
<script>
let cart = [];
function addToCart(id, name, price) {
    let item = cart.find(i => i.id === id);
    if(item) { item.qty++; } else { cart.push({id, name, price, qty:1}); }
    renderCart();
}
function renderCart() {
    let html = ''; let total = 0;
    cart.forEach((i, idx) => {
        let sub = i.price * i.qty; total += sub;
        html += `<div class="d-flex justify-content-between mb-2 pb-2 border-bottom">
            <div>${i.name} <br><small class="text-muted">${i.qty} x Rs. ${i.price}</small></div>
            <div class="fw-bold">Rs. ${sub.toFixed(2)}</div>
        </div>`;
    });
    document.getElementById('cart-items').innerHTML = html;
    document.getElementById('cart-total').innerText = 'Rs. ' + total.toFixed(2);
}
function checkout() {
    if(cart.length === 0) return alert('Cart is empty!');
    let formData = new FormData();
    formData.append('action', 'checkout');
    formData.append('cart', JSON.stringify(cart));
    fetch('pos.php', { method: 'POST', body: formData })
    .then(r => r.json())
    .then(data => {
        if(data.success) {
            alert('Sale Completed! Invoice: ' + data.invoice);
            cart = []; renderCart(); location.reload();
        }
    });
}
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
