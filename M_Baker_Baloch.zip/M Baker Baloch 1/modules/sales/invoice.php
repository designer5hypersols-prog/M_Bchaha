<?php
/**
 * POS Print Receipt Layout
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 1. Session Protection Gate
if (!isset($_SESSION['user_id']) || !isset($_SESSION['tenant_id'])) {
    header("Location: /login.php");
    exit;
}

require_once __DIR__ . '/../../config/db.php';

$tenant_id = $_SESSION['tenant_id'];
$sale_id = (int)($_GET['id'] ?? 0);

// Resolve Tenant details
$tenant_name = "M.BAKAR BALOCH Shop";
$tenant_phone = "+92 300 1234567";
$tenant_address = "Main Market Chowk, Quetta, Pakistan";

if ($tenant_id == 2) {
    $tenant_name = "Quetta Dry Fruits";
    $tenant_phone = "+92 321 7654321";
    $tenant_address = "Dry Fruit Market Area, Quetta, Pakistan";
}

try {
    $db = SaaSDB::getConnection();
    
    // 2. Fetch Sales details matching tenant ownership
    $s_stmt = $db->prepare("SELECT * FROM `sales` WHERE `id` = :id AND `tenant_id` = :tenant LIMIT 1");
    $s_stmt->execute(['id' => $sale_id, 'tenant' => $tenant_id]);
    $sale = $s_stmt->fetch();

    if (!$sale) {
        die("<div style='padding:40px; text-align:center; color:#ef4444; font-family:sans-serif;'>
                <h2>🚫 Record Denied</h2>
                <p>This transaction invoice does not exist or you do not have permission to view it.</p>
             </div>");
    }

    // 3. Fetch item lists
    $si_stmt = $db->prepare("SELECT * FROM `sale_items` WHERE `sale_id` = :sale_id");
    $si_stmt->execute(['sale_id' => $sale_id]);
    $items = $si_stmt->fetchAll();

} catch (PDOException $e) {
    die("Invoice retrieval failed: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice <?php echo htmlspecialchars($sale['invoice_no']); ?></title>
    <!-- Boxicons Icon CDN -->
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Courier New', Courier, monospace; /* Thermal styled fonts */
            color: #000;
        }

        body {
            background-color: #f1f5f9;
            padding: 40px 20px;
            display: flex;
            justify-content: center;
        }

        .receipt-container {
            width: 380px; /* Thermal slip width */
            background: #fff;
            padding: 24px;
            border: 1px solid #e2e8f0;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            position: relative;
        }

        .receipt-header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 1px dashed #000;
            padding-bottom: 15px;
        }

        .receipt-header h1 {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 4px;
            text-transform: uppercase;
        }

        .receipt-header p {
            font-size: 11px;
            color: #555;
            line-height: 1.4;
        }

        .meta-row {
            display: flex;
            justify-content: space-between;
            font-size: 11px;
            margin-bottom: 6px;
        }

        .items-divider {
            border-top: 1px dashed #000;
            margin: 10px 0;
        }

        .receipt-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 11px;
        }

        .receipt-table th {
            text-align: left;
            padding: 6px 0;
            border-bottom: 1px solid #000;
        }

        .receipt-table td {
            padding: 8px 0;
            border-bottom: 1px dashed #eee;
        }

        .totals-section {
            margin-top: 15px;
            border-top: 1px dashed #000;
            padding-top: 12px;
            font-size: 11px;
        }

        .totals-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 6px;
        }

        .totals-row.grand {
            font-size: 13px;
            font-weight: bold;
            border-top: 1px solid #000;
            padding-top: 6px;
            margin-top: 6px;
        }

        .receipt-footer {
            text-align: center;
            margin-top: 24px;
            padding-top: 15px;
            border-top: 1px dashed #000;
            font-size: 10px;
        }

        /* Action Menu (Not printed) */
        .actions-menu {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            justify-content: center;
        }

        .btn-action {
            font-family: sans-serif;
            background: #10b981;
            color: #fff;
            border: none;
            padding: 10px 18px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-action.back {
            background: #475569;
        }

        @media print {
            body {
                background: #fff;
                padding: 0;
                display: block;
            }
            .receipt-container {
                width: 100%;
                box-shadow: none;
                border: none;
                padding: 0;
            }
            .actions-menu {
                display: none !important;
            }
        }
    </style>
</head>
<body>

<div>
    <div class="receipt-container">
        <!-- Brand Headers -->
        <div class="receipt-header">
            <h1><?php echo htmlspecialchars($tenant_name); ?></h1>
            <p><?php echo htmlspecialchars($tenant_address); ?></p>
            <p>Tel: <?php echo htmlspecialchars($tenant_phone); ?></p>
        </div>

        <!-- Meta Details -->
        <div class="meta-row">
            <span><strong>INVOICE NO:</strong></span>
            <span><?php echo htmlspecialchars($sale['invoice_no']); ?></span>
        </div>
        <div class="meta-row">
            <span><strong>DATE/TIME:</strong></span>
            <span><?php echo date('d-M-Y h:i A', strtotime($sale['created_at'])); ?></span>
        </div>
        <div class="meta-row">
            <span><strong>CUSTOMER:</strong></span>
            <span><?php echo htmlspecialchars($sale['customer_name']); ?></span>
        </div>

        <div class="items-divider"></div>

        <!-- Catalog items register -->
        <table class="receipt-table">
            <thead>
                <tr>
                    <th>Item</th>
                    <th style="text-align: center; width: 60px;">Qty</th>
                    <th style="text-align: right; width: 90px;">Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                    <tr>
                        <td>
                            <?php echo htmlspecialchars($item['product_name']); ?><br>
                            <span style="color:#666; font-size:10px;">@ Rs. <?php echo number_format($item['price'], 2); ?></span>
                        </td>
                        <td style="text-align: center;"><?php echo $item['quantity']; ?></td>
                        <td style="text-align: right;">Rs. <?php echo number_format($item['subtotal'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Totals summary slip -->
        <div class="totals-section">
            <div class="totals-row">
                <span>Subtotal:</span>
                <span>Rs. <?php echo number_format($sale['total'], 2); ?></span>
            </div>
            <div class="totals-row">
                <span>Discount:</span>
                <span>-Rs. <?php echo number_format($sale['discount'], 2); ?></span>
            </div>
            <div class="totals-row grand">
                <span>Net Total:</span>
                <span>Rs. <?php echo number_format($sale['grand_total'], 2); ?></span>
            </div>
            <div class="totals-row" style="margin-top: 6px;">
                <span>Paid Cash:</span>
                <span>Rs. <?php echo number_format($sale['paid'], 2); ?></span>
            </div>
            <div class="totals-row">
                <span>Due Balance:</span>
                <span>Rs. <?php echo number_format($sale['due'], 2); ?></span>
            </div>
        </div>

        <!-- Receipt Footnotes -->
        <div class="receipt-footer">
            <p>Thank you for shopping at our outlet!</p>
            <p>Computerized SaaS POS System</p>
        </div>
    </div>

    <!-- Action panel (Automatically excluded during browser printing commands) -->
    <div class="actions-menu">
        <button onclick="window.print()" class="btn-action">
            <i class="bx bx-printer"></i> Print slip
        </button>
        <a href="pos.php" class="btn-action back">
            <i class="bx bx-arrow-back"></i> Back to POS
        </a>
    </div>
</div>

</body>
</html>
