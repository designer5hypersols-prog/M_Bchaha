<?php
/**
 * POS Billing Post Transaction Processor
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 1. Session Protection Gate
if (!isset($_SESSION['user_id']) || !isset($_SESSION['tenant_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access. Log in to initiate transactions.']);
    exit;
}

require_once __DIR__ . '/../../config/db.php';

$tenant_id = $_SESSION['tenant_id'];

// 2. Direct Access Gate (strictly POST queries)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

// Decode JSON Payload
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || empty($input['items'])) {
    echo json_encode(['success' => false, 'message' => 'No checkout items detected.']);
    exit;
}

$customer_name = trim($input['customer_name'] ?? 'Walk-in Customer');
$discount_input = (float)($input['discount'] ?? 0.00);
$paid_input = (float)($input['paid'] ?? 0.00);
$items = $input['items'];

try {
    $db = SaaSDB::getConnection();
    
    // 3. Initiate Transaction Lock
    $db->beginTransaction();

    // 4. Generate Unique Invoice Number (Format: MBB-YYYYMMDD-XXXX)
    $today_prefix = 'MBB-' . date('Ymd') . '-';
    $stmt = $db->prepare("SELECT COUNT(*) FROM `sales` WHERE `invoice_no` LIKE :prefix AND `tenant_id` = :tenant");
    $stmt->execute(['prefix' => $today_prefix . '%', 'tenant' => $tenant_id]);
    $today_count = $stmt->fetchColumn() ?: 0;
    $sequence = str_pad($today_count + 1, 4, '0', STR_PAD_LEFT);
    $invoice_no = $today_prefix . $sequence;

    // 5. Audit Stock & Calculate Sums Locally
    $subtotal = 0.00;
    $processed_items = [];

    foreach ($items as $item) {
        $product_id = (int)$item['product_id'];
        $qty = (int)$item['quantity'];

        if ($qty <= 0) {
            $db->rollBack();
            echo json_encode(['success' => false, 'message' => 'Invalid quantity found for selected items.']);
            exit;
        }

        // Fetch product particulars from active tenant context
        $p_stmt = $db->prepare("SELECT * FROM `products` WHERE `id` = :id AND `tenant_id` = :tenant FOR UPDATE");
        $p_stmt->execute(['id' => $product_id, 'tenant' => $tenant_id]);
        $product = $p_stmt->fetch();

        if (!$product) {
            $db->rollBack();
            echo json_encode(['success' => false, 'message' => "Item ID #$product_id is missing in your catalog partition."]);
            exit;
        }

        // Enforce stock check
        if ($product['stock'] < $qty) {
            $db->rollBack();
            echo json_encode([
                'success' => false, 
                'message' => "Stock Alert: '{$product['name']}' only has {$product['stock']} units left. Adjust cart levels."
            ]);
            exit;
        }

        $item_subtotal = $product['price'] * $qty;
        $subtotal += $item_subtotal;

        $processed_items[] = [
            'product_id' => $product_id,
            'name' => $product['name'],
            'price' => $product['price'],
            'quantity' => $qty,
            'subtotal' => $item_subtotal
        ];
    }

    // Calculations
    $grand_total = max(0.00, $subtotal - $discount_input);
    $due = max(0.00, $grand_total - $paid_input);

    // 6. Write record into `sales` table
    $s_stmt = $db->prepare("INSERT INTO `sales` (`invoice_no`, `customer_name`, `total`, `discount`, `grand_total`, `paid`, `due`, `tenant_id`) 
                            VALUES (:inv, :cust, :tot, :disc, :grand, :paid, :due, :tenant)");
    $s_stmt->execute([
        'inv' => $invoice_no,
        'cust' => $customer_name,
        'tot' => $subtotal,
        'disc' => $discount_input,
        'grand' => $grand_total,
        'paid' => $paid_input,
        'due' => $due,
        'tenant' => $tenant_id
    ]);
    
    $sale_id = $db->lastInsertId();

    // 7. Write records into `sale_items` & update inventories
    $si_stmt = $db->prepare("INSERT INTO `sale_items` (`sale_id`, `product_id`, `product_name`, `price`, `quantity`, `subtotal`) 
                             VALUES (:sale, :prod, :name, :price, :qty, :sub)");
    
    $stock_stmt = $db->prepare("UPDATE `products` SET `stock` = `stock` - :qty WHERE `id` = :id AND `tenant_id` = :tenant");

    $log_stmt = $db->prepare("INSERT INTO `stock_logs` (`product_id`, `type`, `quantity`, `reference`, `tenant_id`) 
                              VALUES (:prod, 'OUT', :qty, :ref, :tenant)");

    foreach ($processed_items as $pi) {
        // Insert sale item details
        $si_stmt->execute([
            'sale' => $sale_id,
            'prod' => $pi['product_id'],
            'name' => $pi['name'],
            'price' => $pi['price'],
            'qty' => $pi['quantity'],
            'sub' => $pi['subtotal']
        ]);

        // Decrement product inventory safely
        $stock_stmt->execute([
            'qty' => $pi['quantity'],
            'id' => $pi['product_id'],
            'tenant' => $tenant_id
        ]);

        // Log this inventory outtake inside stock_logs table
        $log_stmt->execute([
            'prod' => $pi['product_id'],
            'qty' => $pi['quantity'],
            'ref' => "Sales Invoice #{$invoice_no}",
            'tenant' => $tenant_id
        ]);
    }

    // 7.5. Record entry inside customer ledger
    $bal_stmt = $db->prepare("SELECT SUM(`debit`) - SUM(`credit`) FROM `ledger` 
                              WHERE `tenant_id` = :tenant AND `type` = 'customer' AND `party_name` = :name");
    $bal_stmt->execute(['tenant' => $tenant_id, 'name' => $customer_name]);
    $prev_balance = (float)$bal_stmt->fetchColumn() ?: 0.00;
    $new_balance = $prev_balance + ($grand_total - $paid_input);

    $ledger_stmt = $db->prepare("INSERT INTO `ledger` (`tenant_id`, `type`, `party_name`, `party_id`, `debit`, `credit`, `balance`, `reference`) 
                                 VALUES (:tenant, 'customer', :party, NULL, :debit, :credit, :balance, :ref)");
    $ledger_stmt->execute([
        'tenant' => $tenant_id,
        'party' => $customer_name,
        'debit' => $grand_total,
        'credit' => $paid_input,
        'balance' => $new_balance,
        'ref' => "Sales Checkout - Invoice #{$invoice_no}"
    ]);

    // 7.7. Auto Post balanced Double-Entry Journal Entry
    require_once __DIR__ . '/../accounting/helper.php';
    
    $journal_items = [];
    
    // Credit Sales Revenue
    $journal_items[] = [
        'code' => '4001',
        'debit' => 0.00,
        'credit' => $grand_total
    ];
    
    // Debit Cash (if paid cash during checkout)
    if ($paid_input > 0) {
        $journal_items[] = [
            'code' => '1001',
            'debit' => $paid_input,
            'credit' => 0.00
        ];
    }
    
    // Debit Accounts Receivable (if balance remaining due)
    $due_amount = $grand_total - $paid_input;
    if ($due_amount > 0) {
        $journal_items[] = [
            'code' => '1003',
            'debit' => $due_amount,
            'credit' => 0.00
        ];
    }
    
    postJournalEntry($db, $tenant_id, date('Y-m-d'), "Sales POS Checkout - Invoice #{$invoice_no} ({$customer_name})", $invoice_no, $journal_items);

    // 8. Commit POS transaction
    $db->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Sale registered successfully!',
        'sale_id' => $sale_id
    ]);

} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }
    echo json_encode(['success' => false, 'message' => 'Transaction failure: ' . $e->getMessage()]);
}
