<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../core/Session.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = Database::getInstance();
    $stmt = $db->prepare("INSERT INTO products (tenant_id, name, price, stock, min_stock_level) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([
        Auth::tenantId(),
        $_POST['name'],
        $_POST['price'],
        $_POST['stock'],
        $_POST['min_stock']
    ]);
    Session::setFlash('success', 'Product added successfully.');
    header('Location: index.php');
    exit;
}
?>
<h2>Add Product</h2>
<div class="card shadow-sm border-0 p-4 mt-3" style="max-width: 600px;">
    <form method="POST">
        <div class="mb-3">
            <label>Product Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Price</label>
            <input type="number" step="0.01" name="price" class="form-control" required>
        </div>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label>Initial Stock</label>
                <input type="number" name="stock" class="form-control" required>
            </div>
            <div class="col-md-6 mb-3">
                <label>Min Stock Level</label>
                <input type="number" name="min_stock" class="form-control" value="5" required>
            </div>
        </div>
        <button class="btn btn-primary"><i class='bx bx-save'></i> Save Product</button>
    </form>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
