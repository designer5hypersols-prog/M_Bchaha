<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../core/Session.php';

$db = Database::getInstance();
$tenant_id = Auth::tenantId();

if (isset($_GET['delete'])) {
    $stmt = $db->prepare("DELETE FROM products WHERE id = ? AND tenant_id = ?");
    $stmt->execute([$_GET['delete'], $tenant_id]);
    Session::setFlash('success', 'Product deleted.');
    header('Location: index.php');
    exit;
}

$stmt = $db->prepare("SELECT * FROM products WHERE tenant_id = ? ORDER BY id DESC");
$stmt->execute([$tenant_id]);
$products = $stmt->fetchAll();
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Products</h2>
    <a href="add.php" class="btn btn-primary"><i class='bx bx-plus'></i> Add Product</a>
</div>
<?php if($msg = Session::getFlash('success')): ?>
    <div class="alert alert-success"><?= $msg ?></div>
<?php endif; ?>
<div class="card shadow-sm border-0">
    <div class="card-body">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th><th>Name</th><th>Price</th><th>Stock</th><th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($products as $p): ?>
                <tr>
                    <td><?= $p['id'] ?></td>
                    <td><?= htmlspecialchars($p['name']) ?></td>
                    <td>Rs. <?= number_format($p['price'], 2) ?></td>
                    <td><?= $p['stock'] ?></td>
                    <td>
                        <a href="?delete=<?= $p['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?');"><i class='bx bx-trash'></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
