<?php
/**
 * POS Ledger Payments Collection & Payout terminal
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/db.php';

$tenant_id = $_SESSION['tenant_id'];
$pre_name = trim($_GET['name'] ?? '');
$pre_type = trim($_GET['type'] ?? 'customer');
$pre_amount = (float)($_GET['amount'] ?? 0.00);

$success_msg = '';
$error_msg = '';

$customers = [];
$suppliers = [];

try {
    $db = SaaSDB::getConnection();
    
    // Fetch unique party names to help selection
    $stmt = $db->prepare("SELECT DISTINCT `party_name` FROM `ledger` WHERE `tenant_id` = :tenant AND `type` = 'customer'");
    $stmt->execute(['tenant' => $tenant_id]);
    $customers = $stmt->fetchAll(PDO::FETCH_COLUMN);

    $stmt = $db->prepare("SELECT DISTINCT `party_name` FROM `ledger` WHERE `tenant_id` = :tenant AND `type` = 'supplier'");
    $stmt->execute(['tenant' => $tenant_id]);
    $suppliers = $stmt->fetchAll(PDO::FETCH_COLUMN);

} catch (PDOException $e) {
    die("Party names sync failure: " . $e->getMessage());
}

// Handle payment form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'] ?? 'customer'; // 'customer' or 'supplier'
    $party_name = trim($_POST['party_name'] ?? '');
    $custom_name = trim($_POST['custom_name'] ?? '');
    $amount = (float)($_POST['amount'] ?? 0.00);
    $method = $_POST['payment_method'] ?? 'Cash';
    $notes = trim($_POST['reference'] ?? '');

    // Resolve party name
    if (empty($party_name) && !empty($custom_name)) {
        $party_name = $custom_name;
    }

    if (empty($party_name) || $amount <= 0 || !in_array($type, ['customer', 'supplier'])) {
        $error_msg = "🚫 Please provide valid inputs for all fields.";
    } else {
        try {
            // Begin transactional double-entry posting
            $db->beginTransaction();

            // 1. Insert into `payments` table
            $p_stmt = $db->prepare("INSERT INTO `payments` (`tenant_id`, `type`, `party_name`, `amount`, `payment_method`, `reference`) 
                                    VALUES (:tenant, :type, :party_name, :amount, :method, :ref)");
            $ref_string = "Payment Voucher - Method: " . htmlspecialchars($method) . (!empty($notes) ? " (" . htmlspecialchars($notes) . ")" : "");
            $p_stmt->execute([
                'tenant' => $tenant_id,
                'type' => $type,
                'party_name' => $party_name,
                'amount' => $amount,
                'payment_method' => $method,
                'reference' => $notes
            ]);

            // 2. Compute ledger columns and balances
            if ($type === 'customer') {
                $debit = 0.00;
                $credit = $amount;
                
                // Query previous net balance
                $bal_stmt = $db->prepare("SELECT SUM(`debit`) - SUM(`credit`) FROM `ledger` WHERE `tenant_id` = :tenant AND `type` = 'customer' AND `party_name` = :name");
                $bal_stmt->execute(['tenant' => $tenant_id, 'name' => $party_name]);
                $prev_balance = (float)$bal_stmt->fetchColumn() ?: 0.00;
                $new_running_balance = $prev_balance - $amount;
            } else {
                $debit = $amount;
                $credit = 0.00;
                
                // Query previous net balance
                $bal_stmt = $db->prepare("SELECT SUM(`credit`) - SUM(`debit`) FROM `ledger` WHERE `tenant_id` = :tenant AND `type` = 'supplier' AND `party_name` = :name");
                $bal_stmt->execute(['tenant' => $tenant_id, 'name' => $party_name]);
                $prev_balance = (float)$bal_stmt->fetchColumn() ?: 0.00;
                $new_running_balance = $prev_balance - $amount;
            }

            // 3. Write double entry record into `ledger` table
            $l_stmt = $db->prepare("INSERT INTO `ledger` (`tenant_id`, `type`, `party_name`, `party_id`, `debit`, `credit`, `balance`, `reference`) 
                                    VALUES (:tenant, :type, :party_name, :party_id, :debit, :credit, :balance, :ref)");
            $l_stmt->execute([
                'tenant' => $tenant_id,
                'type' => $type,
                'party_name' => $party_name,
                'party_id' => null,
                'debit' => $debit,
                'credit' => $credit,
                'balance' => $new_running_balance,
                'ref' => $ref_string
            ]);

            // 3.5. Post double-entry journal items automatically
            require_once __DIR__ . '/../accounting/helper.php';
            
            $journal_items = [];
            
            if ($type === 'customer') {
                // Debit Cash
                $journal_items[] = [
                    'code' => '1001',
                    'debit' => $amount,
                    'credit' => 0.00
                ];
                // Credit Accounts Receivable
                $journal_items[] = [
                    'code' => '1003',
                    'debit' => 0.00,
                    'credit' => $amount
                ];
                $memo = "Customer Cash Receipt - {$party_name} [{$method}]";
            } else {
                // Debit Accounts Payable
                $journal_items[] = [
                    'code' => '2001',
                    'debit' => $amount,
                    'credit' => 0.00
                ];
                // Credit Cash
                $journal_items[] = [
                    'code' => '1001',
                    'debit' => 0.00,
                    'credit' => $amount
                ];
                $memo = "Supplier Payout Payment - {$party_name} [{$method}]";
            }
            
            postJournalEntry($db, $tenant_id, date('Y-m-d'), $memo, "VCH-" . date('YmdHis'), $journal_items);

            $db->commit();
            $success_msg = "💸 Payment of Rs. " . number_format($amount, 2) . " successfully recorded for '{$party_name}'!";
            
            // Reset fields
            $pre_name = '';
            $pre_amount = 0.00;

        } catch (Exception $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            $error_msg = "🚫 Payment transaction failed: " . $e->getMessage();
        }
    }
}
?>

<div style="max-width: 600px; margin: 0 auto; padding-top: 15px;">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 20px;">
        <h1 style="font-size: 22px; font-weight: 800; letter-spacing: -0.5px;">Udhaar Cash Terminal</h1>
        <a href="dashboard.php" class="btn btn-secondary" style="font-size:12px; padding: 8px 14px;">
            <i class="bx bx-arrow-back"></i> Back to Ledger
        </a>
    </div>

    <!-- Alert Blocks -->
    <?php if (!empty($success_msg)): ?>
        <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); color: #10b981; padding: 14px; border-radius: 8px; font-size: 13.5px; font-weight: 600; margin-bottom: 20px;">
            <?php echo $success_msg; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($error_msg)): ?>
        <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.3); color: var(--danger); padding: 14px; border-radius: 8px; font-size: 13.5px; font-weight: 600; margin-bottom: 20px;">
            <?php echo $error_msg; ?>
        </div>
    <?php endif; ?>

    <!-- Payments Entry Form Card -->
    <div class="card">
        <form action="payments.php" method="POST" style="display: flex; flex-direction: column; gap: 16px;">
            <div class="form-group">
                <label for="type" style="margin-bottom: 6px; font-weight:600;">Transaction Category</label>
                <select name="type" id="type" class="form-control" style="background:#0f172a; padding: 10px;" onchange="togglePartyLists()" required>
                    <option value="customer" <?php echo ($pre_type === 'customer') ? 'selected' : ''; ?>>📥 Receive Payment (from Customer Debtors)</option>
                    <option value="supplier" <?php echo ($pre_type === 'supplier') ? 'selected' : ''; ?>>📤 Payout Payment (to Supplier Creditors)</option>
                </select>
            </div>

            <!-- Existing Parties Selector Dropdown -->
            <div class="form-group" id="selector-wrapper">
                <label for="party_name" style="margin-bottom: 6px; font-weight:600;">Select Account Profile</label>
                
                <!-- Customer List Selector -->
                <select name="party_name" id="customer_select" class="form-control party-select-menu" style="background:#0f172a; padding: 10px; display: <?php echo ($pre_type === 'customer') ? 'block' : 'none'; ?>;">
                    <option value="">-- Select customer name --</option>
                    <?php foreach ($customers as $name): ?>
                        <option value="<?php echo htmlspecialchars($name); ?>" <?php echo ($pre_name === $name && $pre_type === 'customer') ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <!-- Supplier List Selector -->
                <select name="party_name" id="supplier_select" class="form-control party-select-menu" style="background:#0f172a; padding: 10px; display: <?php echo ($pre_type === 'supplier') ? 'block' : 'none'; ?>;">
                    <option value="">-- Select supplier name --</option>
                    <?php foreach ($suppliers as $name): ?>
                        <option value="<?php echo htmlspecialchars($name); ?>" <?php echo ($pre_name === $name && $pre_type === 'supplier') ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Manual Name overrides (for new accounts or one-off transactions) -->
            <div class="form-group">
                <label for="custom_name" style="margin-bottom: 6px; font-weight:600;">Or Enter Custom Party Name</label>
                <input type="text" name="custom_name" id="custom_name" class="form-control" placeholder="Type new client or supplier name..." value="<?php echo empty($customers) && empty($suppliers) ? htmlspecialchars($pre_name) : ''; ?>">
            </div>

            <div class="form-group">
                <label for="amount" style="margin-bottom: 6px; font-weight:600;">Payment Amount (Rs.)</label>
                <input type="number" step="0.01" name="amount" id="amount" class="form-control" placeholder="Enter Cash Amount..." value="<?php echo $pre_amount > 0 ? $pre_amount : ''; ?>" min="0.01" required>
            </div>

            <div class="form-group">
                <label for="payment_method" style="margin-bottom: 6px; font-weight:600;">Payment Method</label>
                <select name="payment_method" id="payment_method" class="form-control" style="background:#0f172a; padding: 10px;" required>
                    <option value="Cash">💵 Cash Handover</option>
                    <option value="Bank Transfer">🏦 Bank Account Transfer</option>
                    <option value="Cheque">✍️ Bank Cheque Transaction</option>
                </select>
            </div>

            <div class="form-group">
                <label for="reference" style="margin-bottom: 6px; font-weight:600;">Reference Remarks / Details</label>
                <input type="text" name="reference" id="reference" class="form-control" placeholder="e.g. Receipt No, Cheque No, Notes...">
            </div>

            <button type="submit" class="btn" style="justify-content: center; padding: 12px; margin-top: 10px; background: #3b82f6; border-color: #3b82f6;">
                <i class="bx bx-check-shield"></i> Post Transaction
            </button>
        </form>
    </div>
</div>

<script>
function togglePartyLists() {
    const type = document.getElementById('type').value;
    const customerMenu = document.getElementById('customer_select');
    const supplierMenu = document.getElementById('supplier_select');

    if (type === 'customer') {
        customerMenu.style.display = 'block';
        supplierMenu.style.display = 'none';
        supplierMenu.value = '';
    } else {
        customerMenu.style.display = 'none';
        customerMenu.value = '';
        supplierMenu.style.display = 'block';
    }
}
</script>

<?php
require_once __DIR__ . '/../../includes/footer.php';
?>
