<?php
/**
 * SaaS Isolated Customer & Supplier Ledger Dashboard
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/db.php';

$tenant_id = $_SESSION['tenant_id'];

try {
    $db = SaaSDB::getConnection();

    // 1. Total Customer Receivables (Dues Outstanding)
    $stmt = $db->prepare("SELECT SUM(net_balance) FROM (
        SELECT SUM(debit) - SUM(credit) AS net_balance 
        FROM `ledger` 
        WHERE `tenant_id` = :tenant AND `type` = 'customer' 
        GROUP BY `party_name`
    ) t WHERE net_balance > 0");
    $stmt->execute(['tenant' => $tenant_id]);
    $total_receivables = $stmt->fetchColumn() ?: 0.00;

    // 2. Total Supplier Payables (Liabilities Outstanding)
    $stmt = $db->prepare("SELECT SUM(net_balance) FROM (
        SELECT SUM(credit) - SUM(debit) AS net_balance 
        FROM `ledger` 
        WHERE `tenant_id` = :tenant AND `type` = 'supplier' 
        GROUP BY `party_name`
    ) t WHERE net_balance > 0");
    $stmt->execute(['tenant' => $tenant_id]);
    $total_payables = $stmt->fetchColumn() ?: 0.00;

    // 3. Top Customer Debtors
    $stmt = $db->prepare("SELECT `party_name`, SUM(debit) - SUM(credit) AS net_balance 
        FROM `ledger` 
        WHERE `tenant_id` = :tenant AND `type` = 'customer' 
        GROUP BY `party_name` 
        HAVING net_balance > 0 
        ORDER BY net_balance DESC 
        LIMIT 5");
    $stmt->execute(['tenant' => $tenant_id]);
    $top_debtors = $stmt->fetchAll();

    // 4. Top Supplier Creditors
    $stmt = $db->prepare("SELECT `party_name`, SUM(credit) - SUM(debit) AS net_balance 
        FROM `ledger` 
        WHERE `tenant_id` = :tenant AND `type` = 'supplier' 
        GROUP BY `party_name` 
        HAVING net_balance > 0 
        ORDER BY net_balance DESC 
        LIMIT 5");
    $stmt->execute(['tenant' => $tenant_id]);
    $top_creditors = $stmt->fetchAll();

} catch (PDOException $e) {
    die("Database financial metrics failure: " . $e->getMessage());
}
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Udhaar Ledger Dashboard</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Isolated, real-time financial tracking of accounts receivable and accounts payable.</p>
    </div>
    
    <div style="display: flex; gap: 10px;">
        <a href="customer.php" class="btn btn-secondary" style="font-size: 13px; padding: 10px 16px; border-color: rgba(16, 185, 129, 0.3); color: #10b981;">
            <i class="bx bx-user-voice"></i> Customer Udhaar
        </a>
        <a href="supplier.php" class="btn btn-secondary" style="font-size: 13px; padding: 10px 16px; border-color: rgba(239, 68, 68, 0.3); color: var(--danger);">
            <i class="bx bx-group"></i> Supplier Payables
        </a>
        <a href="payments.php" class="btn" style="font-size: 13px; padding: 10px 16px; background: #3b82f6; border-color: #3b82f6;">
            <i class="bx bx-wallet"></i> Receive/Pay Cash
        </a>
        <a href="statement.php" class="btn btn-secondary" style="font-size: 13px; padding: 10px 16px;">
            <i class="bx bx-file-blank"></i> Statements
        </a>
    </div>
</div>

<!-- ==========================================
     FINANCIAL SUMMARY KPI CARDS
     ========================================== -->
<div class="stats-grid" style="grid-template-columns: 1fr 1fr; gap: 24px;">
    <!-- RECEIVABLES CARD -->
    <div class="stat-card" style="border-left: 5px solid #10b981;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <span style="font-size: 14px; color: var(--text-secondary); font-weight: 600;">Total Customer Udhaar (Receivables)</span>
            <div style="background: rgba(16, 185, 129, 0.15); width: 38px; height: 38px; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #10b981;">
                <i class="bx bx-trending-up" style="font-size: 20px;"></i>
            </div>
        </div>
        <h3 style="font-size: 32px; font-weight: 800; margin: 0; color: #10b981;">Rs. <?php echo number_format($total_receivables, 2); ?></h3>
        <p style="margin: 6px 0 0 0; color: var(--text-secondary); font-size: 12px;">Cumulative outstanding debt from your registered customers.</p>
    </div>

    <!-- PAYABLES CARD -->
    <div class="stat-card" style="border-left: 5px solid var(--danger);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <span style="font-size: 14px; color: var(--text-secondary); font-weight: 600;">Total Supplier Liabilities (Payables)</span>
            <div style="background: rgba(239, 68, 68, 0.15); width: 38px; height: 38px; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: var(--danger);">
                <i class="bx bx-trending-down" style="font-size: 20px;"></i>
            </div>
        </div>
        <h3 style="font-size: 32px; font-weight: 800; margin: 0; color: var(--danger);">Rs. <?php echo number_format($total_payables, 2); ?></h3>
        <p style="margin: 6px 0 0 0; color: var(--text-secondary); font-size: 12px;">Wholesale procurement balances remaining due to your distributors.</p>
    </div>
</div>

<!-- ==========================================
     TOP DEBTORS / TOP CREDITORS GRID LIST
     ========================================== -->
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-top: 24px; align-items: start; flex-wrap: wrap;">
    <!-- TOP DEBTORS -->
    <div class="card" style="border-top: 4px solid #10b981;">
        <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; color: #10b981;">
            <i class="bx bx-face" style="font-size: 20px;"></i> Top Customer Debtors
        </h3>
        
        <?php if (empty($top_debtors)): ?>
            <div style="text-align:center; padding: 30px; color: var(--text-secondary); font-size:13.5px;">
                ✨ Great! No outstanding customer udhaar logs.
            </div>
        <?php else: ?>
            <table style="width: 100%; border-collapse: collapse; font-size: 13px; text-align: left;">
                <thead>
                    <tr style="border-bottom: 1px solid var(--border-color); color: var(--text-secondary);">
                        <th style="padding: 10px 4px;">Customer Name</th>
                        <th style="padding: 10px 4px; text-align: right;">outstanding balance</th>
                        <th style="padding: 10px 4px; text-align: center; width: 100px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($top_debtors as $debtor): ?>
                        <tr style="border-bottom: 1px solid var(--border-color);">
                            <td style="padding: 12px 4px; font-weight: 600; color: var(--text-main);"><?php echo htmlspecialchars($debtor['party_name']); ?></td>
                            <td style="padding: 12px 4px; text-align: right; font-weight: 700; color: #10b981;">Rs. <?php echo number_format($debtor['net_balance'], 2); ?></td>
                            <td style="padding: 12px 4px; text-align: center;">
                                <a href="statement.php?name=<?php echo urlencode($debtor['party_name']); ?>&type=customer" class="btn btn-secondary" style="font-size: 11px; padding: 4px 10px;">
                                    Statement
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <!-- TOP CREDITORS -->
    <div class="card" style="border-top: 4px solid var(--danger);">
        <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; color: var(--danger);">
            <i class="bx bx-store-alt" style="font-size: 20px;"></i> Top Supplier Creditors
        </h3>

        <?php if (empty($top_creditors)): ?>
            <div style="text-align:center; padding: 30px; color: var(--text-secondary); font-size:13.5px;">
                ✨ Zero outstanding payables to suppliers.
            </div>
        <?php else: ?>
            <table style="width: 100%; border-collapse: collapse; font-size: 13px; text-align: left;">
                <thead>
                    <tr style="border-bottom: 1px solid var(--border-color); color: var(--text-secondary);">
                        <th style="padding: 10px 4px;">Supplier Name</th>
                        <th style="padding: 10px 4px; text-align: right;">Outstanding balance</th>
                        <th style="padding: 10px 4px; text-align: center; width: 100px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($top_creditors as $creditor): ?>
                        <tr style="border-bottom: 1px solid var(--border-color);">
                            <td style="padding: 12px 4px; font-weight: 600; color: var(--text-main);"><?php echo htmlspecialchars($creditor['party_name']); ?></td>
                            <td style="padding: 12px 4px; text-align: right; font-weight: 700; color: var(--danger);">Rs. <?php echo number_format($creditor['net_balance'], 2); ?></td>
                            <td style="padding: 12px 4px; text-align: center;">
                                <a href="statement.php?name=<?php echo urlencode($creditor['party_name']); ?>&type=supplier" class="btn btn-secondary" style="font-size: 11px; padding: 4px 10px;">
                                    Statement
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php
require_once __DIR__ . '/../../includes/footer.php';
?>
