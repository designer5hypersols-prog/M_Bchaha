<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/header.php';
?>
<h2>Udhaar Ledger</h2>
<p>Customer and Supplier dual ledger system.</p>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
