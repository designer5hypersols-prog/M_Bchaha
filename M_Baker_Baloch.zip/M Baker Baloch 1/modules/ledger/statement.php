<?php
/**
 * POS Customer/Supplier Account Statement sheet
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 1. Session Protection Gate
if (!isset($_SESSION['user_id']) || !isset($_SESSION['tenant_id'])) {
    header("Location: /login.php");
    exit;
}

require_once __DIR__ . '/../../config/db.php';

$tenant_id = $_SESSION['tenant_id'];
$party_name = trim($_GET['name'] ?? '');
$type = $_GET['type'] ?? 'customer'; // 'customer' or 'supplier'
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';

if (empty($party_name) || !in_array($type, ['customer', 'supplier'])) {
    die("<div style='padding:40px; text-align:center; color:#ef4444; font-family:sans-serif;'>
            <h2>🚫 Invalid Account request</h2>
            <p>Please select a valid customer or supplier account from the ledger sheet list.</p>
         </div>");
}

// Resolve Tenant details
$tenant_name = "M.BAKAR BALOCH Shop";
$tenant_phone = "+92 300 1234567";
$tenant_address = "Main Market Chowk, Quetta, Pakistan";

if ($tenant_id == 2) {
    $tenant_name = "Quetta Dry Fruits";
    $tenant_phone = "+92 321 7654321";
    $tenant_address = "Dry Fruit Market Area, Quetta, Pakistan";
}

$entries = [];
$aggregates = ['debit' => 0.00, 'credit' => 0.00];

try {
    $db = SaaSDB::getConnection();

    // 1. Compute cumulative financial aggregates
    $sum_stmt = $db->prepare("SELECT SUM(`debit`) AS total_debit, SUM(`credit`) AS total_credit 
                              FROM `ledger` 
                              WHERE `tenant_id` = :tenant AND `type` = :type AND `party_name` = :name");
    $sum_stmt->execute(['tenant' => $tenant_id, 'type' => $type, 'name' => $party_name]);
    $aggregates = $sum_stmt->fetch() ?: ['total_debit' => 0.00, 'total_credit' => 0.00];

    // 2. Fetch statement logs chronologically
    $query = "SELECT * FROM `ledger` 
              WHERE `tenant_id` = :tenant AND `type` = :type AND `party_name` = :name";
              
    $params = [
        'tenant' => $tenant_id,
        'type' => $type,
        'name' => $party_name
    ];

    if (!empty($start_date)) {
        $query .= " AND DATE(`created_at`) >= :start";
        $params['start'] = $start_date;
    }
    if (!empty($end_date)) {
        $query .= " AND DATE(`created_at`) <= :end";
        $params['end'] = $end_date;
    }

    $query .= " ORDER BY `id` ASC";

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $entries = $stmt->fetchAll();

} catch (PDOException $e) {
    die("Statement logs fetch error: " . $e->getMessage());
}

// Calculate outstanding balance
$total_debit = (float)($aggregates['total_debit'] ?? 0.00);
$total_credit = (float)($aggregates['total_credit'] ?? 0.00);
$net_balance = ($type === 'customer') ? ($total_debit - $total_credit) : ($total_credit - $total_debit);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ledger Statement - <?php echo htmlspecialchars($party_name); ?></title>
    <!-- Boxicons CDN -->
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <style>
        :root {
            --bg-color: #0f172a;
            --card-color: #1e293b;
            --border-color: #334155;
            --text-main: #f8fafc;
            --text-secondary: #94a3b8;
            --accent: #10b981;
            --danger: #ef4444;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: #090d16;
            color: var(--text-main);
            padding: 40px 20px;
            display: flex;
            justify-content: center;
        }

        .statement-container {
            width: 850px;
            background: var(--card-color);
            padding: 40px;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.25);
        }

        .header-panel {
            display: flex;
            justify-content: space-between;
            align-items: start;
            border-bottom: 2px solid var(--border-color);
            padding-bottom: 24px;
            margin-bottom: 24px;
        }

        .header-panel h1 {
            font-size: 22px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: -0.5px;
            color: var(--accent);
            margin-bottom: 6px;
        }

        .header-panel p {
            font-size: 13px;
            color: var(--text-secondary);
            line-height: 1.5;
        }

        .summary-grid {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }

        .summary-box {
            background: rgba(255,255,255,0.02);
            border: 1px solid var(--border-color);
            padding: 16px;
            border-radius: 8px;
        }

        .summary-box span {
            font-size: 12px;
            color: var(--text-secondary);
            font-weight: 600;
            display: block;
            margin-bottom: 6px;
            text-transform: uppercase;
        }

        .summary-box h3 {
            font-size: 20px;
            font-weight: 800;
        }

        .statement-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
            text-align: left;
            margin-top: 15px;
        }

        .statement-table th {
            padding: 12px 10px;
            background: rgba(255,255,255,0.03);
            border-bottom: 2px solid var(--border-color);
            color: var(--text-secondary);
            font-weight: 700;
            text-transform: uppercase;
            font-size: 11px;
        }

        .statement-table td {
            padding: 14px 10px;
            border-bottom: 1px solid var(--border-color);
        }

        .filter-section {
            background: rgba(255,255,255,0.01);
            border: 1px solid var(--border-color);
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            display: flex;
            gap: 15px;
            align-items: flex-end;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 6px;
            flex: 1;
        }

        .filter-group label {
            font-size: 11.5px;
            color: var(--text-secondary);
            font-weight: 600;
        }

        .filter-input {
            background: #0f172a;
            border: 1px solid var(--border-color);
            padding: 8px 12px;
            border-radius: 6px;
            color: var(--text-main);
            outline: none;
            font-size: 13px;
        }

        .btn {
            background: var(--accent);
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s;
        }

        .btn-secondary {
            background: #475569;
        }

        .btn:hover {
            opacity: 0.9;
        }

        .actions-panel {
            margin-top: 25px;
            display: flex;
            gap: 10px;
            justify-content: flex-end;
        }

        @media print {
            body {
                background: #fff;
                color: #000;
                padding: 0;
            }
            .statement-container {
                width: 100%;
                box-shadow: none;
                border: none;
                padding: 0;
            }
            .filter-section, .actions-panel, .btn {
                display: none !important;
            }
            .statement-table th {
                background: #eee !important;
                color: #000 !important;
                border-bottom: 2px solid #000 !important;
            }
            .statement-table td {
                color: #000 !important;
                border-bottom: 1px solid #ddd !important;
            }
            :root {
                --card-color: #fff;
                --text-main: #000;
            }
            .header-panel h1, .summary-box h3 {
                color: #000 !important;
            }
            .summary-box {
                border: 1px solid #000 !important;
            }
        }
    </style>
</head>
<body>

<div class="statement-container">
    <!-- Corporate Statement Header -->
    <div class="header-panel">
        <div>
            <h1><?php echo htmlspecialchars($tenant_name); ?></h1>
            <p><?php echo htmlspecialchars($tenant_address); ?></p>
            <p>Tel: <?php echo htmlspecialchars($tenant_phone); ?></p>
        </div>
        <div style="text-align: right;">
            <h2 style="font-size: 16px; font-weight: 800; text-transform: uppercase; color: var(--text-secondary); margin-bottom: 6px;">STATEMENT OF ACCOUNT</h2>
            <p><strong>PARTY:</strong> <?php echo htmlspecialchars($party_name); ?></p>
            <p><strong>TYPE:</strong> <?php echo strtoupper($type); ?></p>
            <p><strong>DATE GENERATED:</strong> <?php echo date('d-M-Y h:i A'); ?></p>
        </div>
    </div>

    <!-- Date range search deck -->
    <form action="statement.php" method="GET" class="filter-section">
        <input type="hidden" name="name" value="<?php echo htmlspecialchars($party_name); ?>">
        <input type="hidden" name="type" value="<?php echo htmlspecialchars($type); ?>">
        
        <div class="filter-group">
            <label for="start_date">Start Date</label>
            <input type="date" name="start_date" id="start_date" class="filter-input" value="<?php echo htmlspecialchars($start_date); ?>">
        </div>

        <div class="filter-group">
            <label for="end_date">End Date</label>
            <input type="date" name="end_date" id="end_date" class="filter-input" value="<?php echo htmlspecialchars($end_date); ?>">
        </div>

        <button type="submit" class="btn" style="background:#3b82f6;">Filter Range</button>
        <?php if (!empty($start_date) || !empty($end_date)): ?>
            <a href="statement.php?name=<?php echo urlencode($party_name); ?>&type=<?php echo htmlspecialchars($type); ?>" class="btn btn-secondary">Reset</a>
        <?php endif; ?>
    </form>

    <!-- Financial aggregates deck -->
    <div class="summary-grid">
        <div class="summary-box" style="border-left: 4px solid #3b82f6;">
            <span><?php echo ($type === 'customer') ? 'Total Purchases' : 'Total Procurements'; ?></span>
            <h3 style="color: #3b82f6;">Rs. <?php echo number_format($total_debit, 2); ?></h3>
        </div>

        <div class="summary-box" style="border-left: 4px solid #10b981;">
            <span>Total Payments</span>
            <h3 style="color: #10b981;">Rs. <?php echo number_format($total_credit, 2); ?></h3>
        </div>

        <div class="summary-box" style="border-left: 4px solid <?php echo $net_balance > 0 ? 'var(--danger)' : '#10b981'; ?>;">
            <span>Outstanding Balance</span>
            <h3 style="color: <?php echo $net_balance > 0 ? 'var(--danger)' : '#10b981'; ?>;">Rs. <?php echo number_format($net_balance, 2); ?></h3>
        </div>
    </div>

    <!-- Chronological Table Ledger Grid -->
    <table class="statement-table">
        <thead>
            <tr>
                <th>Date</th>
                <th>Reference/Details</th>
                <th style="text-align: right;">Debit (Rs.)</th>
                <th style="text-align: right;">Credit (Rs.)</th>
                <th style="text-align: right;">Running Balance (Rs.)</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($entries)): ?>
                <tr>
                    <td colspan="5" style="text-align: center; padding: 30px; color: var(--text-secondary);">
                        No ledger entries found matching specified date bounds.
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($entries as $row): ?>
                    <tr>
                        <td><?php echo date('d-M-Y', strtotime($row['created_at'])); ?></td>
                        <td style="font-family: monospace; font-weight: 600; color:#3b82f6;"><?php echo htmlspecialchars($row['reference']); ?></td>
                        <td style="text-align: right; color:#3b82f6; font-weight: 500;">
                            <?php echo $row['debit'] > 0 ? 'Rs. ' . number_format($row['debit'], 2) : '-'; ?>
                        </td>
                        <td style="text-align: right; color:#10b981; font-weight: 500;">
                            <?php echo $row['credit'] > 0 ? 'Rs. ' . number_format($row['credit'], 2) : '-'; ?>
                        </td>
                        <td style="text-align: right; font-weight: 700; color:<?php echo $row['balance'] > 0 ? 'var(--danger)' : 'var(--text-secondary)'; ?>;">
                            Rs. <?php echo number_format($row['balance'], 2); ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Statements Controls -->
    <div class="actions-panel">
        <button onclick="window.print()" class="btn">
            <i class="bx bx-printer"></i> Print Statement
        </button>
        <a href="<?php echo ($type === 'customer') ? 'customer.php' : 'supplier.php'; ?>" class="btn btn-secondary">
            <i class="bx bx-arrow-back"></i> Back
        </a>
    </div>
</div>

</body>
</html>
