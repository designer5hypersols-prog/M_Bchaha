<?php
/**
 * SaaS Isolated Customer Udhaar ledger sheet
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/db.php';

$tenant_id = $_SESSION['tenant_id'];
$customers = [];

try {
    $db = SaaSDB::getConnection();
    
    // Group financial metrics by customer name
    $stmt = $db->prepare("SELECT `party_name`, 
                                 SUM(`debit`) AS total_debit, 
                                 SUM(`credit`) AS total_credit, 
                                 SUM(`debit`) - SUM(`credit`) AS net_balance 
                          FROM `ledger` 
                          WHERE `tenant_id` = :tenant AND `type` = 'customer' 
                          GROUP BY `party_name` 
                          ORDER BY net_balance DESC");
    $stmt->execute(['tenant' => $tenant_id]);
    $customers = $stmt->fetchAll();
    
} catch (PDOException $e) {
    echo "<div style='color:var(--danger); padding:20px;'>Ledger fetch error: " . $e->getMessage() . "</div>";
}
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Customer Udhaar Sheets</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Real-time balance audits and payment registers for retail debtors.</p>
    </div>
    
    <div style="display: flex; gap: 10px;">
        <a href="dashboard.php" class="btn btn-secondary" style="font-size: 13px; padding: 10px 16px;">
            <i class="bx bx-left-arrow-alt"></i> Dashboard Overview
        </a>
        <a href="payments.php" class="btn" style="font-size: 13px; padding: 10px 16px; background: #3b82f6; border-color: #3b82f6;">
            <i class="bx bx-wallet"></i> Receive Customer Cash
        </a>
    </div>
</div>

<!-- ==========================================
     CUSTOMER SUMMARY REGISTERS
     ========================================== -->
<div class="card">
    <div style="margin-bottom: 20px;">
        <input type="text" id="search-ledger" class="form-control" placeholder="🔍 Search customers by name..." onkeyup="filterLedgerSheet()" style="max-width: 360px;">
    </div>

    <?php if (empty($customers)): ?>
        <div style="text-align: center; padding: 40px; color: var(--text-secondary); font-size: 14px;">
            No customer ledger logs recorded yet. Dues will automatically log here from POS checkouts.
        </div>
    <?php else: ?>
        <div style="overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 14px;">
                <thead>
                    <tr style="border-bottom: 1.5px solid var(--border-color); color: var(--text-secondary);">
                        <th style="padding: 12px 8px;">Customer Name</th>
                        <th style="padding: 12px 8px; text-align: right;">Total Purchases (Debit)</th>
                        <th style="padding: 12px 8px; text-align: right;">Total Paid (Credit)</th>
                        <th style="padding: 12px 8px; text-align: right;">Remaining Due</th>
                        <th style="padding: 12px 8px; text-align: center;">Status</th>
                        <th style="padding: 12px 8px; text-align: center; width: 180px;">Actions</th>
                    </tr>
                </thead>
                <tbody id="ledger-table-body">
                    <?php foreach ($customers as $c): 
                        $net_balance = (float)$c['net_balance'];
                        if ($net_balance > 0) {
                            $status_label = 'Udhaar Due';
                            $status_style = 'background: rgba(234, 179, 8, 0.15); border: 1px solid rgba(234, 179, 8, 0.3); color: #eab308;';
                        } else {
                            $status_label = 'Settled';
                            $status_style = 'background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); color: #10b981;';
                        }
                    ?>
                        <tr class="ledger-row" 
                            data-name="<?php echo htmlspecialchars(strtolower($c['party_name'])); ?>"
                            style="border-bottom: 1px solid var(--border-color); color: var(--text-main); transition: background 0.2s;">
                            <td style="padding: 14px 8px; font-weight: 600;"><?php echo htmlspecialchars($c['party_name']); ?></td>
                            <td style="padding: 14px 8px; text-align: right; font-weight: 500;">Rs. <?php echo number_format($c['total_debit'], 2); ?></td>
                            <td style="padding: 14px 8px; text-align: right; color:#10b981; font-weight: 600;">Rs. <?php echo number_format($c['total_credit'], 2); ?></td>
                            <td style="padding: 14px 8px; text-align: right; color:<?php echo $net_balance > 0 ? '#10b981' : 'var(--text-secondary)'; ?>; font-weight: 700;">
                                Rs. <?php echo number_format($net_balance, 2); ?>
                            </td>
                            <td style="padding: 14px 8px; text-align: center;">
                                <span style="padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: 700; text-transform: uppercase; <?php echo $status_style; ?>">
                                    <?php echo $status_label; ?>
                                </span>
                            </td>
                            <td style="padding: 14px 8px; text-align: center; display:flex; justify-content:center; gap:8px;">
                                <a href="statement.php?name=<?php echo urlencode($c['party_name']); ?>&type=customer" class="btn btn-secondary" style="font-size: 11.5px; padding: 6px 12px; border-color: rgba(59, 130, 246, 0.3); color: #3b82f6; display: inline-flex; align-items: center; gap: 4px;">
                                    <i class="bx bx-file"></i> Statement
                                </a>
                                <?php if ($net_balance > 0): ?>
                                    <a href="payments.php?name=<?php echo urlencode($c['party_name']); ?>&type=customer&amount=<?php echo $net_balance; ?>" class="btn" style="font-size: 11.5px; padding: 6px 12px; background: #10b981; border-color: #10b981; display: inline-flex; align-items: center; gap: 4px;">
                                        <i class="bx bx-wallet"></i> Pay
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<script src="/assets/js/ledger.js"></script>

<?php
require_once __DIR__ . '/../../includes/footer.php';
?>
