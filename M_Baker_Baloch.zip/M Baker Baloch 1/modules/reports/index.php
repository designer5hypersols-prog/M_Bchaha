<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/header.php';
?>
<h2>Reports</h2>
<p>Analytics, BI data, and PDF exports.</p>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
