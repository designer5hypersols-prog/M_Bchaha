<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/header.php';
?>
<h2>Stock Management</h2>
<p>Stock adjustments, low stock alerts, and history tracking.</p>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
