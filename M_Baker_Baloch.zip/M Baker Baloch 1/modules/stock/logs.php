<?php
/**
 * SaaS Isolated Stock Movements Logs
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/db.php';

// Enforce administrative permissions check
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'manager') {
    die("<div class='card' style='margin:20px; color:var(--danger);'>Access Denied: Cashiers do not have permission to view stock movement logs.</div>");
}

$tenant_id = $_SESSION['tenant_id'];
$logs = [];
$search = trim($_GET['search'] ?? '');

try {
    $db = SaaSDB::getConnection();
    
    // Construct dynamic prepared query joining products
    $query = "SELECT sl.*, p.name AS product_name 
              FROM `stock_logs` sl
              JOIN `products` p ON sl.product_id = p.id
              WHERE sl.tenant_id = :tenant";
              
    if (!empty($search)) {
        $query .= " AND p.name LIKE :search";
    }
    
    $query .= " ORDER BY sl.id DESC";
    
    $stmt = $db->prepare($query);
    $params = ['tenant' => $tenant_id];
    
    if (!empty($search)) {
        $params['search'] = '%' . $search . '%';
    }
    
    $stmt->execute($params);
    $logs = $stmt->fetchAll();
    
} catch (PDOException $e) {
    echo "<div style='color:var(--danger); padding:20px;'>Movement logs fetch error: " . $e->getMessage() . "</div>";
}
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Stock Movement Ledger</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Comprehensive audit trail of manual updates, sales outtakes, and replenishment entries.</p>
    </div>
    
    <div style="display: flex; gap: 10px;">
        <a href="dashboard.php" class="btn btn-secondary" style="font-size: 13px; padding: 10px 16px;">
            <i class="bx bx-left-arrow-alt"></i> Back to Dashboard
        </a>
        <a href="adjust_stock.php" class="btn" style="font-size: 13px; padding: 10px 16px; background: #eab308; border-color: #eab308;">
            <i class="bx bx-slider"></i> Manual Adjust
        </a>
    </div>
</div>

<!-- ==========================================
     LOGS TIMELINE LEDGER REGISTER TABLE
     ========================================== -->
<div class="card">
    <form action="logs.php" method="GET" style="display: flex; gap: 10px; margin-bottom: 20px;">
        <input type="text" name="search" class="form-control" placeholder="Search logs by product name..." value="<?php echo htmlspecialchars($search); ?>" style="max-width: 320px;">
        <button type="submit" class="btn">Search</button>
        <?php if (!empty($search)): ?>
            <a href="logs.php" class="btn btn-secondary">Clear</a>
        <?php endif; ?>
    </form>

    <?php if (empty($logs)): ?>
        <div style="text-align: center; padding: 40px; color: var(--text-secondary); font-size: 14px;">
            <i class="bx bx-history" style="font-size: 48px; color: var(--text-secondary); opacity: 0.3; display: block; margin-bottom: 12px;"></i>
            No inventory stock movements recorded under this partition.
        </div>
    <?php else: ?>
        <div style="overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 14px;">
                <thead>
                    <tr style="border-bottom: 1.5px solid var(--border-color); color: var(--text-secondary);">
                        <th style="padding: 12px 8px;">Log ID</th>
                        <th style="padding: 12px 8px;">Product Name</th>
                        <th style="padding: 12px 8px; text-align: center;">Movement Type</th>
                        <th style="padding: 12px 8px; text-align: center;">Qty Delta</th>
                        <th style="padding: 12px 8px;">Reference & Context</th>
                        <th style="padding: 12px 8px;">timestamp</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): 
                        // Determine movement indicator colors
                        if ($log['type'] === 'IN') {
                            $type_label = 'Stock Addition';
                            $badge_style = 'background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); color: #10b981;';
                            $qty_prefix = '+';
                            $qty_style = 'color: #10b981;';
                        } elseif ($log['type'] === 'OUT') {
                            $type_label = 'Sale Outtake';
                            $badge_style = 'background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.3); color: var(--danger);';
                            $qty_prefix = '-';
                            $qty_style = 'color: var(--danger);';
                        } else { // ADJUSTMENT
                            $type_label = 'Manual Correction';
                            $badge_style = 'background: rgba(234, 179, 8, 0.15); border: 1px solid rgba(234, 179, 8, 0.3); color: #eab308;';
                            $qty_prefix = 'Δ ';
                            $qty_style = 'color: #eab308;';
                        }
                    ?>
                        <tr style="border-bottom: 1px solid var(--border-color); color: var(--text-main); transition: background 0.2s;">
                            <td style="padding: 14px 8px; font-family: monospace; font-weight: bold;"><?php echo $log['id']; ?></td>
                            <td style="padding: 14px 8px; font-weight: 600;"><?php echo htmlspecialchars($log['product_name']); ?></td>
                            <td style="padding: 14px 8px; text-align: center;">
                                <span style="padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: 700; text-transform: uppercase; <?php echo $badge_style; ?>">
                                    <?php echo $type_label; ?>
                                </span>
                            </td>
                            <td style="padding: 14px 8px; text-align: center; font-weight: 800; font-size: 15px; <?php echo $qty_style; ?>">
                                <?php echo $qty_prefix . $log['quantity']; ?>
                            </td>
                            <td style="padding: 14px 8px; font-weight: 500; font-family: monospace; color:#3b82f6;">
                                <?php echo htmlspecialchars($log['reference']); ?>
                            </td>
                            <td style="padding: 14px 8px; color: var(--text-secondary); font-size:12.5px;">
                                <?php echo date('d-M-Y h:i A', strtotime($log['created_at'])); ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php
require_once __DIR__ . '/../../includes/footer.php';
?>
