<?php
/**
 * Restocking Inventory Stock Sheets
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/db.php';

// Enforce administrative permissions check
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'manager') {
    die("<div class='card' style='margin:20px; color:var(--danger);'>Access Denied: Cashiers do not have permission to manage stock sheets.</div>");
}

$tenant_id = $_SESSION['tenant_id'];
$products = [];

try {
    $db = SaaSDB::getConnection();
    $stmt = $db->prepare("SELECT * FROM `products` WHERE `tenant_id` = :tenant ORDER BY `name` ASC");
    $stmt->execute(['tenant' => $tenant_id]);
    $products = $stmt->fetchAll();
} catch (PDOException $e) {
    echo "<div style='color:var(--danger); padding:20px;'>Products fetch error: " . $e->getMessage() . "</div>";
}
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Inventory Stock Sheets</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Isolated, real-time tracking of item levels, thresholds, and statuses.</p>
    </div>
    
    <div style="display: flex; gap: 10px;">
        <a href="dashboard.php" class="btn btn-secondary" style="font-size: 13px; padding: 10px 16px;">
            <i class="bx bx-left-arrow-alt"></i> Back to Dashboard
        </a>
        <a href="adjust_stock.php" class="btn" style="font-size: 13px; padding: 10px 16px; background: #eab308; border-color: #eab308;">
            <i class="bx bx-slider"></i> Manual Adjustment
        </a>
    </div>
</div>

<!-- ==========================================
     DYNAMIC SEARCH & FILTER TABLE REGISTER
     ========================================== -->
<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; gap: 20px; margin-bottom: 20px; flex-wrap: wrap;">
        <input type="text" id="search-stock" class="form-control" placeholder="🔍 Search stock catalog by product name..." onkeyup="filterStockSheets()" style="max-width: 360px;">
        
        <div style="display: flex; gap: 8px;">
            <button class="btn btn-secondary" onclick="filterStatus('all')" style="font-size: 12px; padding: 6px 12px;">All Items</button>
            <button class="btn btn-secondary" onclick="filterStatus('safe')" style="font-size: 12px; padding: 6px 12px; color: #10b981; border-color: rgba(16, 185, 129, 0.3);">Safe</button>
            <button class="btn btn-secondary" onclick="filterStatus('low')" style="font-size: 12px; padding: 6px 12px; color: #eab308; border-color: rgba(234, 179, 8, 0.3);">Low Stock</button>
            <button class="btn btn-secondary" onclick="filterStatus('out')" style="font-size: 12px; padding: 6px 12px; color: var(--danger); border-color: rgba(239, 68, 68, 0.3);">Out of Stock</button>
        </div>
    </div>

    <?php if (empty($products)): ?>
        <div style="text-align: center; padding: 40px; color: var(--text-secondary); font-size: 14px;">
            No products defined. Add products in the catalog first to start tracking stock.
        </div>
    <?php else: ?>
        <div style="overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 14px;">
                <thead>
                    <tr style="border-bottom: 1.5px solid var(--border-color); color: var(--text-secondary);">
                        <th style="padding: 12px 8px;">Product ID</th>
                        <th style="padding: 12px 8px;">Product Name</th>
                        <th style="padding: 12px 8px; text-align: right;">Retail Price</th>
                        <th style="padding: 12px 8px; text-align: center;">Stock Count</th>
                        <th style="padding: 12px 8px; text-align: center;">Min stock level</th>
                        <th style="padding: 12px 8px; text-align: center;">Alert Status</th>
                        <th style="padding: 12px 8px; text-align: center; width: 150px;">Actions</th>
                    </tr>
                </thead>
                <tbody id="stock-table-body">
                    <?php foreach ($products as $p): 
                        // Determine alert levels and color classes
                        if ($p['stock'] <= 0) {
                            $status = 'out';
                            $status_label = 'Out of Stock';
                            $badge_style = 'background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.3); color: var(--danger);';
                            $row_bg = 'background: rgba(239, 68, 68, 0.03);';
                        } elseif ($p['stock'] <= $p['min_stock_level']) {
                            $status = 'low';
                            $status_label = 'Low Stock';
                            $badge_style = 'background: rgba(234, 179, 8, 0.15); border: 1px solid rgba(234, 179, 8, 0.3); color: #eab308;';
                            $row_bg = 'background: rgba(234, 179, 8, 0.03);';
                        } else {
                            $status = 'safe';
                            $status_label = 'Safe (OK)';
                            $badge_style = 'background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); color: #10b981;';
                            $row_bg = '';
                        }
                    ?>
                        <tr class="stock-row" 
                            data-name="<?php echo htmlspecialchars(strtolower($p['name'])); ?>" 
                            data-status="<?php echo $status; ?>"
                            style="border-bottom: 1px solid var(--border-color); color: var(--text-main); transition: background 0.2s; <?php echo $row_bg; ?>">
                            <td style="padding: 14px 8px; font-family: monospace; font-weight: bold;"><?php echo $p['id']; ?></td>
                            <td style="padding: 14px 8px; font-weight: 600;"><?php echo htmlspecialchars($p['name']); ?></td>
                            <td style="padding: 14px 8px; text-align: right; font-weight: 700;">Rs. <?php echo number_format($p['price'], 2); ?></td>
                            <td style="padding: 14px 8px; text-align: center; font-weight: 800; font-size: 15px;"><?php echo $p['stock']; ?></td>
                            <td style="padding: 14px 8px; text-align: center; color: var(--text-secondary);"><?php echo $p['min_stock_level']; ?></td>
                            <td style="padding: 14px 8px; text-align: center;">
                                <span style="padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: 700; text-transform: uppercase; <?php echo $badge_style; ?>">
                                    <?php echo $status_label; ?>
                                </span>
                            </td>
                            <td style="padding: 14px 8px; text-align: center;">
                                <a href="adjust_stock.php?id=<?php echo $p['id']; ?>" class="btn btn-secondary" style="font-size: 11.5px; padding: 6px 12px; border-color: rgba(234, 179, 8, 0.3); color: #eab308; display: inline-flex; align-items: center; gap: 4px;">
                                    <i class="bx bx-slider"></i> Adjust
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<script src="/assets/js/stock.js"></script>

<?php
require_once __DIR__ . '/../../includes/footer.php';
?>
