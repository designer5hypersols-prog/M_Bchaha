<?php
/**
 * SaaS Isolated Stock Management Dashboard
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/db.php';

// Enforce administrative permissions check
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'manager') {
    die("<div class='card' style='margin:20px; color:var(--danger);'>Access Denied: Cashiers do not have permission to access Stock Control panels.</div>");
}

$tenant_id = $_SESSION['tenant_id'];

try {
    $db = SaaSDB::getConnection();

    // 1. Total Products
    $stmt = $db->prepare("SELECT COUNT(*) FROM `products` WHERE `tenant_id` = :tenant");
    $stmt->execute(['tenant' => $tenant_id]);
    $total_products = $stmt->fetchColumn() ?: 0;

    // 2. Cumulative Stock Units
    $stmt = $db->prepare("SELECT SUM(`stock`) FROM `products` WHERE `tenant_id` = :tenant");
    $stmt->execute(['tenant' => $tenant_id]);
    $total_stock = $stmt->fetchColumn() ?: 0;

    // 3. Low Stock Items Count
    $stmt = $db->prepare("SELECT COUNT(*) FROM `products` WHERE `tenant_id` = :tenant AND `stock` <= `min_stock_level` AND `stock` > 0");
    $stmt->execute(['tenant' => $tenant_id]);
    $low_stock_count = $stmt->fetchColumn() ?: 0;

    // 4. Out of Stock Items Count
    $stmt = $db->prepare("SELECT COUNT(*) FROM `products` WHERE `tenant_id` = :tenant AND `stock` <= 0");
    $stmt->execute(['tenant' => $tenant_id]);
    $out_of_stock_count = $stmt->fetchColumn() ?: 0;

    // 5. Fetch Low Stock Catalog Details
    $stmt = $db->prepare("SELECT * FROM `products` WHERE `tenant_id` = :tenant AND `stock` <= `min_stock_level` AND `stock` > 0 ORDER BY `stock` ASC");
    $stmt->execute(['tenant' => $tenant_id]);
    $low_stock_items = $stmt->fetchAll();

    // 6. Fetch Out of Stock Catalog Details
    $stmt = $db->prepare("SELECT * FROM `products` WHERE `tenant_id` = :tenant AND `stock` <= 0 ORDER BY `name` ASC");
    $stmt->execute(['tenant' => $tenant_id]);
    $out_of_stock_items = $stmt->fetchAll();

} catch (PDOException $e) {
    die("Database stats fetch failed: " . $e->getMessage());
}
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Inventory Control Center</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Real-time stock alerts, catalog summaries, and replenishment options.</p>
    </div>
    
    <div style="display: flex; gap: 10px;">
        <a href="stock.php" class="btn btn-secondary" style="font-size: 13px; padding: 10px 16px;">
            <i class="bx bx-list-ul"></i> Stock Sheets
        </a>
        <a href="adjust_stock.php" class="btn" style="font-size: 13px; padding: 10px 16px; background: #eab308; border-color: #eab308;">
            <i class="bx bx-slider"></i> Manual Adjust
        </a>
        <a href="logs.php" class="btn btn-secondary" style="font-size: 13px; padding: 10px 16px;">
            <i class="bx bx-history"></i> Stock Logs
        </a>
    </div>
</div>

<!-- ==========================================
     INVENTORY KPI STATS CARDS
     ========================================== -->
<div class="stats-grid">
    <div class="stat-card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <span style="font-size: 13.5px; color: var(--text-secondary); font-weight: 600;">Total Products</span>
            <div style="background: rgba(16, 185, 129, 0.15); width: 34px; height: 34px; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: var(--accent);">
                <i class="bx bx-box" style="font-size: 18px;"></i>
            </div>
        </div>
        <h3 style="font-size: 28px; font-weight: 800; margin: 0; color: var(--text-main);"><?php echo $total_products; ?></h3>
    </div>

    <div class="stat-card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <span style="font-size: 13.5px; color: var(--text-secondary); font-weight: 600;">Cumulative Stock</span>
            <div style="background: rgba(59, 130, 246, 0.15); width: 34px; height: 34px; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #3b82f6;">
                <i class="bx bx-layer" style="font-size: 18px;"></i>
            </div>
        </div>
        <h3 style="font-size: 28px; font-weight: 800; margin: 0; color: var(--text-main);"><?php echo number_format($total_stock); ?></h3>
    </div>

    <div class="stat-card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <span style="font-size: 13.5px; color: var(--text-secondary); font-weight: 600;">Low Stock Warnings</span>
            <div style="background: rgba(234, 179, 8, 0.15); width: 34px; height: 34px; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #eab308;">
                <i class="bx bx-bell" style="font-size: 18px;"></i>
            </div>
        </div>
        <h3 style="font-size: 28px; font-weight: 800; margin: 0; color: #eab308;"><?php echo $low_stock_count; ?></h3>
    </div>

    <div class="stat-card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <span style="font-size: 13.5px; color: var(--text-secondary); font-weight: 600;">Out of Stock</span>
            <div style="background: rgba(239, 68, 68, 0.15); width: 34px; height: 34px; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: var(--danger);">
                <i class="bx bx-block" style="font-size: 18px;"></i>
            </div>
        </div>
        <h3 style="font-size: 28px; font-weight: 800; margin: 0; color: var(--danger);"><?php echo $out_of_stock_count; ?></h3>
    </div>
</div>

<!-- ==========================================
     ALERTS DECKS PANEL
     ========================================== -->
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-top: 24px; align-items: start; flex-wrap: wrap;">
    <!-- OUT OF STOCK PANELS -->
    <div class="card" style="border-left: 4px solid var(--danger);">
        <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; color: var(--danger);">
            <i class="bx bx-error-circle" style="font-size: 20px;"></i> Critical Out of Stock Alerts
        </h3>
        
        <?php if (empty($out_of_stock_items)): ?>
            <div style="text-align:center; padding: 30px; color: var(--text-secondary); font-size:13.5px;">
                ✨ Zero out-of-stock items. Excellent inventory levels!
            </div>
        <?php else: ?>
            <table style="width: 100%; border-collapse: collapse; font-size: 13px; text-align: left;">
                <thead>
                    <tr style="border-bottom: 1px solid var(--border-color); color: var(--text-secondary);">
                        <th style="padding: 10px 4px;">Product Name</th>
                        <th style="padding: 10px 4px; text-align: right;">Retail Price</th>
                        <th style="padding: 10px 4px; text-align: center; width: 100px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($out_of_stock_items as $item): ?>
                        <tr style="border-bottom: 1px solid var(--border-color);">
                            <td style="padding: 12px 4px; font-weight: 600; color: var(--text-main);"><?php echo htmlspecialchars($item['name']); ?></td>
                            <td style="padding: 12px 4px; text-align: right; font-weight: 700;">Rs. <?php echo number_format($item['price'], 2); ?></td>
                            <td style="padding: 12px 4px; text-align: center;">
                                <a href="../purchases/purchase.php" class="btn btn-secondary" style="font-size: 11px; padding: 4px 10px; border-color: rgba(16, 185, 129, 0.3); color: var(--accent);">
                                    Restock
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <!-- LOW STOCK PANELS -->
    <div class="card" style="border-left: 4px solid #eab308;">
        <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; color: #eab308;">
            <i class="bx bx-bell" style="font-size: 20px;"></i> Low Stock warnings (Near Threshold)
        </h3>

        <?php if (empty($low_stock_items)): ?>
            <div style="text-align:center; padding: 30px; color: var(--text-secondary); font-size:13.5px;">
                ✨ Zero replenishment warnings detected.
            </div>
        <?php else: ?>
            <table style="width: 100%; border-collapse: collapse; font-size: 13px; text-align: left;">
                <thead>
                    <tr style="border-bottom: 1px solid var(--border-color); color: var(--text-secondary);">
                        <th style="padding: 10px 4px;">Product Name</th>
                        <th style="padding: 10px 4px; text-align: center;">Current Stock</th>
                        <th style="padding: 10px 4px; text-align: center;">Min stock level</th>
                        <th style="padding: 10px 4px; text-align: center; width: 100px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($low_stock_items as $item): ?>
                        <tr style="border-bottom: 1px solid var(--border-color);">
                            <td style="padding: 12px 4px; font-weight: 600; color: var(--text-main);"><?php echo htmlspecialchars($item['name']); ?></td>
                            <td style="padding: 12px 4px; text-align: center; font-weight: 700; color: #eab308;"><?php echo $item['stock']; ?></td>
                            <td style="padding: 12px 4px; text-align: center; color: var(--text-secondary);"><?php echo $item['min_stock_level']; ?></td>
                            <td style="padding: 12px 4px; text-align: center;">
                                <a href="../purchases/purchase.php" class="btn btn-secondary" style="font-size: 11px; padding: 4px 10px; border-color: rgba(16, 185, 129, 0.3); color: var(--accent);">
                                    Restock
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php
require_once __DIR__ . '/../../includes/footer.php';
?>
