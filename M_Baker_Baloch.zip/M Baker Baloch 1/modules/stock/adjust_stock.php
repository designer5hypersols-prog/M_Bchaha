<?php
/**
 * Manual Inventory Stock Adjustments
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/db.php';

// Enforce administrative permissions check
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'manager') {
    die("<div class='card' style='margin:20px; color:var(--danger);'>Access Denied: Cashiers do not have permission to manage manual adjustments.</div>");
}

$tenant_id = $_SESSION['tenant_id'];
$preselected_id = (int)($_GET['id'] ?? 0);
$success_msg = '';
$error_msg = '';

try {
    $db = SaaSDB::getConnection();
    
    // Fetch all products under this tenant to populate selector
    $p_stmt = $db->prepare("SELECT * FROM `products` WHERE `tenant_id` = :tenant ORDER BY `name` ASC");
    $p_stmt->execute(['tenant' => $tenant_id]);
    $products = $p_stmt->fetchAll();
    
} catch (PDOException $e) {
    die("Database product sync failed: " . $e->getMessage());
}

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = (int)($_POST['product_id'] ?? 0);
    $adj_type = $_POST['adj_type'] ?? ''; // 'IN' or 'OUT'
    $quantity = (int)($_POST['quantity'] ?? 0);
    $reason = trim($_POST['reason'] ?? 'Count Correction');

    if ($product_id <= 0 || !in_array($adj_type, ['IN', 'OUT']) || $quantity <= 0) {
        $error_msg = "🚫 Please provide valid inputs for all fields.";
    } else {
        try {
            // Begin Transaction Lock
            $db->beginTransaction();

            // Fetch active stock particulars FOR UPDATE
            $stmt = $db->prepare("SELECT * FROM `products` WHERE `id` = :id AND `tenant_id` = :tenant FOR UPDATE");
            $stmt->execute(['id' => $product_id, 'tenant' => $tenant_id]);
            $product = $stmt->fetch();

            if (!$product) {
                $db->rollBack();
                $error_msg = "🚫 The selected product does not exist in your tenant partition.";
            } else {
                // Perform stock validation
                if ($adj_type === 'OUT' && $product['stock'] < $quantity) {
                    $db->rollBack();
                    $error_msg = "🚫 Adjustment Rejected: Current stock level ({$product['stock']}) is too low to deduct {$quantity} units.";
                } else {
                    // Update Stock Count
                    if ($adj_type === 'IN') {
                        $new_stock_query = "UPDATE `products` SET `stock` = `stock` + :qty WHERE `id` = :id AND `tenant_id` = :tenant";
                    } else {
                        $new_stock_query = "UPDATE `products` SET `stock` = `stock` - :qty WHERE `id` = :id AND `tenant_id` = :tenant";
                    }

                    $stock_stmt = $db->prepare($new_stock_query);
                    $stock_stmt->execute([
                        'qty' => $quantity,
                        'id' => $product_id,
                        'tenant' => $tenant_id
                    ]);

                    // Log this movement to stock_logs
                    $reference = "Manual Adjustment (" . htmlspecialchars($reason) . ")";
                    $log_stmt = $db->prepare("INSERT INTO `stock_logs` (`product_id`, `type`, `quantity`, `reference`, `tenant_id`) 
                                             VALUES (:prod, :type, :qty, :ref, :tenant)");
                    
                    // If OUT, represent quantity as positive in the database count, since the ENUM type registers direction
                    $log_stmt->execute([
                        'prod' => $product_id,
                        'type' => $adj_type === 'IN' ? 'IN' : 'ADJUSTMENT', // Mark OUT adjustments or simple corrections
                        'qty' => $quantity,
                        'ref' => $reference,
                        'tenant' => $tenant_id
                    ]);

                    // Commit changes
                    $db->commit();
                    $success_msg = "📦 Stock level for '{$product['name']}' adjusted successfully!";
                    
                    // Refresh products lists to display new quantities in the dropdown
                    $p_stmt->execute(['tenant' => $tenant_id]);
                    $products = $p_stmt->fetchAll();
                }
            }
        } catch (Exception $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            $error_msg = "🚫 Adjustment transaction failed: " . $e->getMessage();
        }
    }
}
?>

<div style="max-width: 600px; margin: 0 auto; padding-top: 15px;">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 20px;">
        <h1 style="font-size: 22px; font-weight: 800; letter-spacing: -0.5px;">Manual Stock Correction</h1>
        <a href="stock.php" class="btn btn-secondary" style="font-size:12px; padding: 8px 14px;">
            <i class="bx bx-arrow-back"></i> Back to Sheets
        </a>
    </div>

    <!-- Alert Blocks -->
    <?php if (!empty($success_msg)): ?>
        <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); color: #10b981; padding: 14px; border-radius: 8px; font-size: 13.5px; font-weight: 600; margin-bottom: 20px;">
            <?php echo $success_msg; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($error_msg)): ?>
        <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.3); color: var(--danger); padding: 14px; border-radius: 8px; font-size: 13.5px; font-weight: 600; margin-bottom: 20px;">
            <?php echo $error_msg; ?>
        </div>
    <?php endif; ?>

    <!-- Adjustment form box -->
    <div class="card">
        <form action="adjust_stock.php" method="POST" style="display: flex; flex-direction: column; gap: 16px;">
            <div class="form-group">
                <label for="product_id" style="margin-bottom: 6px; font-weight:600;">Select Product</label>
                <select name="product_id" id="product_id" class="form-control" style="background:#0f172a; padding: 10px;" required>
                    <option value="">-- Choose inventory item --</option>
                    <?php foreach ($products as $p): ?>
                        <option value="<?php echo $p['id']; ?>" <?php echo ($preselected_id == $p['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($p['name']); ?> (Current Stock: <?php echo $p['stock']; ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="adj_type" style="margin-bottom: 6px; font-weight:600;">Adjustment Direction</label>
                <select name="adj_type" id="adj_type" class="form-control" style="background:#0f172a; padding: 10px;" required>
                    <option value="IN">📥 Add Stock (Restock / Correction / Return)</option>
                    <option value="OUT">📤 Deduct Stock (Damage / Theft / Correction)</option>
                </select>
            </div>

            <div class="form-group">
                <label for="quantity" style="margin-bottom: 6px; font-weight:600;">Quantity Units</label>
                <input type="number" name="quantity" id="quantity" class="form-control" min="1" placeholder="Enter amount of items..." required>
            </div>

            <div class="form-group">
                <label for="reason" style="margin-bottom: 6px; font-weight:600;">Reason/Justification</label>
                <select name="reason" id="reason" class="form-control" style="background:#0f172a; padding: 10px;" required>
                    <option value="Count Correction">Count Correction</option>
                    <option value="Inventory Audit Update">Inventory Audit Update</option>
                    <option value="Product Damage">Product Damage</option>
                    <option value="Customer Return">Customer Return</option>
                    <option value="Supplier Replacement">Supplier Replacement</option>
                    <option value="Expired Stock Removal">Expired Stock Removal</option>
                </select>
            </div>

            <button type="submit" class="btn" style="justify-content: center; padding: 12px; margin-top: 10px;">
                <i class="bx bx-check-shield"></i> Save Adjustment Logs
            </button>
        </form>
    </div>
</div>

<?php
require_once __DIR__ . '/../../includes/footer.php';
?>
