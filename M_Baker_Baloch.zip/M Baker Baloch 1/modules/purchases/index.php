<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/header.php';
?>
<h2>Purchases Module</h2>
<p>Supplier purchases and stock receiving operations will be managed here.</p>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
