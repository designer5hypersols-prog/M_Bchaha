<?php
/**
 * POS Restocking Post Transaction Processor
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 1. Session Protection Gate
if (!isset($_SESSION['user_id']) || !isset($_SESSION['tenant_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access. Log in to initiate transactions.']);
    exit;
}

// Enforce administrative permissions check
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'manager') {
    echo json_encode(['success' => false, 'message' => 'Access Denied: Operators do not have permission to manage procurement stocks.']);
    exit;
}

require_once __DIR__ . '/../../config/db.php';

$tenant_id = $_SESSION['tenant_id'];

// 2. Direct Access Gate (strictly POST queries)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

// Decode JSON Payload
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || empty($input['items'])) {
    echo json_encode(['success' => false, 'message' => 'No restocking items detected.']);
    exit;
}

$supplier_name = trim($input['supplier_name'] ?? 'Wholesale Distributor');
$paid_input = (float)($input['paid'] ?? 0.00);
$items = $input['items'];

try {
    $db = SaaSDB::getConnection();
    
    // 3. Initiate Transaction Lock
    $db->beginTransaction();

    // 4. Generate Unique Purchase Number (Format: MBP-YYYYMMDD-XXXX)
    $today_prefix = 'MBP-' . date('Ymd') . '-';
    $stmt = $db->prepare("SELECT COUNT(*) FROM `purchases` WHERE `purchase_no` LIKE :prefix AND `tenant_id` = :tenant");
    $stmt->execute(['prefix' => $today_prefix . '%', 'tenant' => $tenant_id]);
    $today_count = $stmt->fetchColumn() ?: 0;
    $sequence = str_pad($today_count + 1, 4, '0', STR_PAD_LEFT);
    $purchase_no = $today_prefix . $sequence;

    // 5. Calculate Sums Locally & Verify Catalog Products
    $subtotal = 0.00;
    $processed_items = [];

    foreach ($items as $item) {
        $product_id = (int)$item['product_id'];
        $qty = (int)$item['quantity'];
        $cost_price = (float)$item['cost_price'];

        if ($qty <= 0 || $cost_price < 0) {
            $db->rollBack();
            echo json_encode(['success' => false, 'message' => 'Invalid parameters found for selected items.']);
            exit;
        }

        // Fetch product particulars from active tenant context
        $p_stmt = $db->prepare("SELECT * FROM `products` WHERE `id` = :id AND `tenant_id` = :tenant FOR UPDATE");
        $p_stmt->execute(['id' => $product_id, 'tenant' => $tenant_id]);
        $product = $p_stmt->fetch();

        if (!$product) {
            $db->rollBack();
            echo json_encode(['success' => false, 'message' => "Item ID #$product_id is missing in your catalog partition."]);
            exit;
        }

        $item_subtotal = $cost_price * $qty;
        $subtotal += $item_subtotal;

        $processed_items[] = [
            'product_id' => $product_id,
            'name' => $product['name'],
            'cost_price' => $cost_price,
            'quantity' => $qty,
            'subtotal' => $item_subtotal
        ];
    }

    // Calculations
    $due = max(0.00, $subtotal - $paid_input);

    // 6. Write record into `purchases` table
    $p_stmt = $db->prepare("INSERT INTO `purchases` (`purchase_no`, `supplier_name`, `total`, `paid`, `due`, `tenant_id`) 
                            VALUES (:pno, :supp, :tot, :paid, :due, :tenant)");
    $p_stmt->execute([
        'pno' => $purchase_no,
        'supp' => $supplier_name,
        'tot' => $subtotal,
        'paid' => $paid_input,
        'due' => $due,
        'tenant' => $tenant_id
    ]);
    
    $purchase_id = $db->lastInsertId();

    // 7. Write records into `purchase_items` & increment inventories
    $pi_stmt = $db->prepare("INSERT INTO `purchase_items` (`purchase_id`, `product_id`, `product_name`, `cost_price`, `quantity`, `subtotal`) 
                             VALUES (:purchase, :prod, :name, :cost, :qty, :sub)");
    
    $stock_stmt = $db->prepare("UPDATE `products` SET `stock` = `stock` + :qty WHERE `id` = :id AND `tenant_id` = :tenant");

    $log_stmt = $db->prepare("INSERT INTO `stock_logs` (`product_id`, `type`, `quantity`, `reference`, `tenant_id`) 
                              VALUES (:prod, 'IN', :qty, :ref, :tenant)");

    foreach ($processed_items as $pi) {
        // Insert purchase item details
        $pi_stmt->execute([
            'purchase' => $purchase_id,
            'prod' => $pi['product_id'],
            'name' => $pi['name'],
            'cost' => $pi['cost_price'],
            'qty' => $pi['quantity'],
            'sub' => $pi['subtotal']
        ]);

        // Increment product inventory safely
        $stock_stmt->execute([
            'qty' => $pi['quantity'],
            'id' => $pi['product_id'],
            'tenant' => $tenant_id
        ]);

        // Log this inventory intake inside stock_logs table
        $log_stmt->execute([
            'prod' => $pi['product_id'],
            'qty' => $pi['quantity'],
            'ref' => "Purchase Invoice #{$purchase_no}",
            'tenant' => $tenant_id
        ]);
    }

    // 7.5. Record entry inside supplier ledger
    $bal_stmt = $db->prepare("SELECT SUM(`credit`) - SUM(`debit`) FROM `ledger` 
                              WHERE `tenant_id` = :tenant AND `type` = 'supplier' AND `party_name` = :name");
    $bal_stmt->execute(['tenant' => $tenant_id, 'name' => $supplier_name]);
    $prev_balance = (float)$bal_stmt->fetchColumn() ?: 0.00;
    $new_balance = $prev_balance + ($subtotal - $paid_input);

    $ledger_stmt = $db->prepare("INSERT INTO `ledger` (`tenant_id`, `type`, `party_name`, `party_id`, `debit`, `credit`, `balance`, `reference`) 
                                 VALUES (:tenant, 'supplier', :party, NULL, :debit, :credit, :balance, :ref)");
    $ledger_stmt->execute([
        'tenant' => $tenant_id,
        'party' => $supplier_name,
        'debit' => $paid_input,
        'credit' => $subtotal,
        'balance' => $new_balance,
        'ref' => "Wholesale Purchase - Order #{$purchase_no}"
    ]);

    // 7.7. Auto Post balanced Double-Entry Journal Entry
    require_once __DIR__ . '/../accounting/helper.php';
    
    $journal_items = [];
    
    // Debit Cost of Goods Sold (COGS)
    $journal_items[] = [
        'code' => '5001',
        'debit' => $subtotal,
        'credit' => 0.00
    ];
    
    // Credit Cash (if paid cash to supplier during procurement)
    if ($paid_input > 0) {
        $journal_items[] = [
            'code' => '1001',
            'debit' => 0.00,
            'credit' => $paid_input
        ];
    }
    
    // Credit Accounts Payable (if balance remaining due to vendor)
    $due_amount = $subtotal - $paid_input;
    if ($due_amount > 0) {
        $journal_items[] = [
            'code' => '2001',
            'debit' => 0.00,
            'credit' => $due_amount
        ];
    }
    
    postJournalEntry($db, $tenant_id, date('Y-m-d'), "Wholesale Purchase Restock - Order #{$purchase_no} ({$supplier_name})", $purchase_no, $journal_items);

    // 8. Commit Purchase transaction
    $db->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Purchase logged and stock incremented successfully!',
        'purchase_id' => $purchase_id
    ]);

} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }
    echo json_encode(['success' => false, 'message' => 'Transaction failure: ' . $e->getMessage()]);
}
