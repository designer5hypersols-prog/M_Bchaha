<?php
/**
 * SaaS Isolated Purchase Stock Terminal
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/db.php';

// Enforce administrative permissions check
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'manager') {
    die("<div class='card' style='margin:20px; color:var(--danger);'>Access Denied: Cashiers do not have permission to manage procurement stocks.</div>");
}

$tenant_id = $_SESSION['tenant_id'];

try {
    $db = SaaSDB::getConnection();
    $stmt = $db->prepare("SELECT * FROM `products` WHERE `tenant_id` = :tenant ORDER BY `name` ASC");
    $stmt->execute(['tenant' => $tenant_id]);
    $products = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Database product sync failed: " . $e->getMessage());
}
?>

<style>
    .purchase-wrapper {
        display: grid;
        grid-template-columns: 1.2fr 1fr;
        gap: 24px;
        align-items: start;
        margin-top: 15px;
    }

    .purchase-pane {
        height: calc(100vh - 190px);
        display: flex;
        flex-direction: column;
    }

    .search-bar-container {
        margin-bottom: 16px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 15px;
    }

    .product-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
        gap: 14px;
        overflow-y: auto;
        padding-right: 6px;
        flex-grow: 1;
    }

    .product-tile {
        background: rgba(30, 41, 59, 0.45);
        border: 1px solid var(--border-color);
        border-radius: 10px;
        padding: 16px;
        cursor: pointer;
        transition: all 0.2s ease;
        text-align: left;
    }

    .product-tile:hover {
        border-color: var(--accent);
        background: rgba(16, 185, 129, 0.05);
        transform: translateY(-2px);
    }

    .product-tile h4 {
        font-size: 13.5px;
        font-weight: 700;
        color: var(--text-main);
        margin-bottom: 6px;
        line-height: 1.4;
    }

    .product-tile .price {
        font-size: 14px;
        color: var(--accent);
        font-weight: 700;
    }

    .product-tile .stock {
        font-size: 11px;
        color: var(--text-secondary);
        margin-top: 4px;
    }

    .cart-pane-body {
        flex-grow: 1;
        overflow-y: auto;
        margin-bottom: 20px;
        border-bottom: 1px dashed var(--border-color);
        padding-bottom: 15px;
    }

    .cart-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
    }

    .cart-table th {
        color: var(--text-secondary);
        padding: 8px 4px;
        border-bottom: 1.5px solid var(--border-color);
        text-align: left;
    }

    .cart-table td {
        padding: 12px 4px;
        border-bottom: 1px solid var(--border-color);
        vertical-align: middle;
    }

    .qty-input {
        width: 60px;
        background: rgba(15, 23, 42, 0.7);
        border: 1px solid var(--border-color);
        color: #fff;
        border-radius: 4px;
        text-align: center;
        padding: 4px;
        font-size: 13px;
    }

    .cost-input {
        width: 80px;
        background: rgba(15, 23, 42, 0.7);
        border: 1px solid var(--border-color);
        color: #fff;
        border-radius: 4px;
        text-align: right;
        padding: 4px;
        font-size: 13px;
    }

    .btn-remove {
        background: transparent;
        border: none;
        color: var(--danger);
        cursor: pointer;
        font-size: 16px;
    }

    .summary-row {
        display: flex;
        justify-content: space-between;
        font-size: 14px;
        color: var(--text-secondary);
        margin-bottom: 10px;
    }

    .summary-row.total {
        font-size: 18px;
        font-weight: 800;
        color: var(--text-main);
        border-top: 1px solid var(--border-color);
        padding-top: 12px;
        margin-top: 10px;
    }
</style>

<div class="purchase-wrapper">
    <!-- LEFT PANE: Products Deck -->
    <div class="purchase-pane">
        <div class="search-bar-container">
            <input type="text" id="search-product" class="form-control" placeholder="🔍 Search product catalog for restocking..." onkeyup="filterProducts()" style="max-width: 380px;">
            <a href="history.php" class="btn btn-secondary" style="font-size: 12px; padding: 8px 14px;">
                <i class="bx bx-history"></i> Purchase History
            </a>
        </div>
        
        <div class="product-grid" id="product-list">
            <?php foreach ($products as $p): ?>
                <div class="product-tile" 
                     data-id="<?php echo $p['id']; ?>" 
                     data-name="<?php echo htmlspecialchars($p['name']); ?>" 
                     data-price="<?php echo $p['price']; ?>" 
                     onclick="addToPurchaseCart(this)">
                    <h4><?php echo htmlspecialchars($p['name']); ?></h4>
                    <div class="price">Retail: Rs. <?php echo number_format($p['price'], 2); ?></div>
                    <div class="stock">📦 Available Stock: <?php echo $p['stock']; ?></div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- RIGHT PANE: Cart & Checkout Ledger -->
    <div class="purchase-pane card" style="background: rgba(15, 23, 42, 0.55); margin-bottom: 0;">
        <h3 style="font-size: 16px; font-weight: 700; border-bottom: 1px solid var(--border-color); padding-bottom: 12px; margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
            <i class="bx bx-cart" style="color:var(--accent);"></i> Supplier Restocking Basket
        </h3>

        <!-- Supplier Settings -->
        <div class="form-group" style="margin-bottom: 16px;">
            <label for="supplier_name" style="margin-bottom: 4px;">Supplier/Vendor Name</label>
            <input type="text" id="supplier_name" class="form-control" value="Wholesale Distributor" style="padding: 8px 12px; font-size:13px;" required>
        </div>

        <!-- Basket Table Frame -->
        <div class="cart-pane-body">
            <table class="cart-table">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th style="text-align: right; width: 90px;">Cost Rate</th>
                        <th style="text-align: center; width: 70px;">Qty</th>
                        <th style="text-align: right; width: 95px;">Subtotal</th>
                        <th style="width: 30px;"></th>
                    </tr>
                </thead>
                <tbody id="purchase-cart-items">
                    <!-- Dynamic JavaScript Cart Rows -->
                </tbody>
            </table>
            <div id="cart-empty" style="text-align: center; padding: 40px 0; color: var(--text-secondary); font-size: 13.5px;">
                🛒 Restocking basket is empty. Click on product tiles to add items.
            </div>
        </div>

        <!-- Summary computation box -->
        <div style="background: rgba(9, 13, 22, 0.4); border: 1px solid var(--border-color); padding: 16px; border-radius: 8px; margin-bottom: 16px;">
            <div class="summary-row" style="align-items: center;">
                <span>Amount Paid Cash (Rs.):</span>
                <input type="number" id="paid-input" class="qty-input" value="0" min="0" step="1" oninput="calculatePurchaseTotals()" style="width: 100px; text-align: right; padding: 4px 8px; border-color: var(--accent); color: var(--accent); font-weight: bold;">
            </div>

            <div class="summary-row">
                <span>Outstanding Due Balance:</span>
                <span id="summary-due" style="font-weight: 600;">Rs. 0.00</span>
            </div>

            <div class="summary-row total">
                <span>Net Total Purchase cost:</span>
                <span id="summary-total">Rs. 0.00</span>
            </div>
        </div>

        <!-- Action Submit Buttons -->
        <button type="button" class="btn" style="width: 100%; justify-content: center; font-size: 15px; padding: 14px;" onclick="completeSaaSPurchase()">
            <i class="bx bx-check-double"></i> Complete Purchase & Record Stock
        </button>
    </div>
</div>

<script src="/assets/js/purchase.js"></script>

<?php
require_once __DIR__ . '/../../includes/footer.php';
?>
