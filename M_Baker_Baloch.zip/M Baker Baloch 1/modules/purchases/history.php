<?php
/**
 * Restocking Purchase History Logs
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/db.php';

// Enforce administrative permissions check
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'manager') {
    die("<div class='card' style='margin:20px; color:var(--danger);'>Access Denied: Cashiers do not have permission to view procurement histories.</div>");
}

$tenant_id = $_SESSION['tenant_id'];
$purchases = [];
$search = trim($_GET['search'] ?? '');

try {
    $db = SaaSDB::getConnection();
    
    if (!empty($search)) {
        $stmt = $db->prepare("SELECT * FROM `purchases` WHERE `tenant_id` = :tenant AND `supplier_name` LIKE :search ORDER BY `id` DESC");
        $stmt->execute([
            'tenant' => $tenant_id,
            'search' => '%' . $search . '%'
        ]);
    } else {
        $stmt = $db->prepare("SELECT * FROM `purchases` WHERE `tenant_id` = :tenant ORDER BY `id` DESC");
        $stmt->execute(['tenant' => $tenant_id]);
    }
    
    $purchases = $stmt->fetchAll();
} catch (PDOException $e) {
    echo "<div style='color:var(--danger); padding:20px;'>Procurement fetch error: " . $e->getMessage() . "</div>";
}
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Procurement Stock Logs</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Isolated supplier receipts and outstanding payment records.</p>
    </div>
    
    <a href="purchase.php" class="btn">
        <i class="bx bx-plus"></i> New Purchase Order
    </a>
</div>

<!-- ==========================================
     PROCUREMENT LOGS FILTER & REGISTER TABLE
     ========================================== -->
<div class="card">
    <form action="history.php" method="GET" style="display: flex; gap: 10px; margin-bottom: 20px;">
        <input type="text" name="search" class="form-control" placeholder="Search by supplier name..." value="<?php echo htmlspecialchars($search); ?>" style="max-width: 320px;">
        <button type="submit" class="btn">Search</button>
        <?php if (!empty($search)): ?>
            <a href="history.php" class="btn btn-secondary">Clear</a>
        <?php endif; ?>
    </form>

    <?php if (empty($purchases)): ?>
        <div style="text-align: center; padding: 40px; color: var(--text-secondary); font-size: 14px;">
            <i class="bx bx-receipt" style="font-size: 48px; color: var(--text-secondary); opacity: 0.3; display: block; margin-bottom: 12px;"></i>
            No procurement receipts recorded under this partition.
        </div>
    <?php else: ?>
        <div style="overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 14px;">
                <thead>
                    <tr style="border-bottom: 1.5px solid var(--border-color); color: var(--text-secondary);">
                        <th style="padding: 12px 8px;">Order No</th>
                        <th style="padding: 12px 8px;">Supplier</th>
                        <th style="padding: 12px 8px; text-align: right;">Total Cost</th>
                        <th style="padding: 12px 8px; text-align: right;">Paid Cash</th>
                        <th style="padding: 12px 8px; text-align: right;">Due Balance</th>
                        <th style="padding: 12px 8px; text-align: center;">Status</th>
                        <th style="padding: 12px 8px; text-align: center; width: 120px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($purchases as $p): ?>
                        <tr style="border-bottom: 1px solid var(--border-color); color: var(--text-main); transition: background 0.2s;">
                            <td style="padding: 14px 8px; font-family: monospace; font-weight: 700; color:#3b82f6;">
                                <?php echo htmlspecialchars($p['purchase_no']); ?>
                            </td>
                            <td style="padding: 14px 8px; font-weight: 600;"><?php echo htmlspecialchars($p['supplier_name']); ?></td>
                            <td style="padding: 14px 8px; text-align: right; font-weight: bold;">Rs. <?php echo number_format($p['total'], 2); ?></td>
                            <td style="padding: 14px 8px; text-align: right; color:#10b981; font-weight: 600;">Rs. <?php echo number_format($p['paid'], 2); ?></td>
                            <td style="padding: 14px 8px; text-align: right; color:<?php echo $p['due'] > 0 ? 'var(--danger)' : 'var(--text-secondary)'; ?>; font-weight: 600;">
                                Rs. <?php echo number_format($p['due'], 2); ?>
                            </td>
                            <td style="padding: 14px 8px; text-align: center;">
                                <?php if ($p['due'] <= 0): ?>
                                    <span style="background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); color: #10b981; padding: 4px 8px; border-radius: 12px; font-size: 11px; font-weight: 700; text-transform: uppercase;">Paid</span>
                                <?php else: ?>
                                    <span style="background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.3); color: var(--danger); padding: 4px 8px; border-radius: 12px; font-size: 11px; font-weight: 700; text-transform: uppercase;">Due Liabilities</span>
                                <?php endif; ?>
                            </td>
                            <td style="padding: 14px 8px; text-align: center;">
                                <a href="invoice.php?id=<?php echo $p['id']; ?>" class="btn btn-secondary" style="font-size: 12px; padding: 6px 12px; border-color: rgba(59, 130, 246, 0.3); color:#3b82f6; display:inline-flex; align-items:center; gap:4px;">
                                    <i class="bx bx-printer"></i> Slip
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php
require_once __DIR__ . '/../../includes/footer.php';
?>
