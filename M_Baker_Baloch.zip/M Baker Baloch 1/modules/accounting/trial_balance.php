<?php
/**
 * SaaS Isolated Double Entry Trial Balance compilation sheet
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/db.php';

$tenant_id = $_SESSION['tenant_id'];
$balances = [];

$grand_debit = 0.00;
$grand_credit = 0.00;

try {
    $db = SaaSDB::getConnection();

    // Query debit and credit summaries grouped by account
    $stmt = $db->prepare("SELECT a.id, a.account_name, a.account_code, a.account_type, 
                                 COALESCE(SUM(ji.debit), 0.00) AS total_debit, 
                                 COALESCE(SUM(ji.credit), 0.00) AS total_credit 
                          FROM `accounts` a 
                          LEFT JOIN `journal_items` ji ON a.id = ji.account_id 
                          WHERE a.tenant_id = :tenant 
                          GROUP BY a.id 
                          ORDER BY a.account_code ASC");
    $stmt->execute(['tenant' => $tenant_id]);
    $balances = $stmt->fetchAll();

} catch (PDOException $e) {
    echo "<div style='color:var(--danger); padding:20px;'>Trial Balance compile failure: " . $e->getMessage() . "</div>";
}

// Calculate grand sums
foreach ($balances as $row) {
    $grand_debit += (float)$row['total_debit'];
    $grand_credit += (float)$row['total_credit'];
}

$is_balanced = (abs($grand_debit - $grand_credit) < 0.001);
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Trial Balance Audit</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Corporate double-entry verification compiling debit and credit aggregates across all charts.</p>
    </div>
    
    <div style="display: flex; gap: 10px;">
        <a href="dashboard.php" class="btn btn-secondary" style="font-size: 13px; padding: 10px 16px;">
            <i class="bx bx-left-arrow-alt"></i> Back to Accounting
        </a>
        <button onclick="window.print()" class="btn btn-secondary" style="font-size: 13px; padding: 10px 16px;">
            <i class="bx bx-printer"></i> Print Audit
        </button>
    </div>
</div>

<!-- ==========================================
     LEDGER ALIGNMENT STATUS
     ========================================== -->
<?php if ($is_balanced): ?>
    <div style="padding: 16px 20px; border-radius: 8px; margin-bottom: 24px; font-weight: 700; font-size: 14px; display: flex; align-items: center; gap: 10px; background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); color: #10b981;">
        <i class="bx bx-check-double" style="font-size: 20px;"></i>
        <span>🟢 Trial Balance stands completely balanced! Perfect double-entry ledger alignment.</span>
    </div>
<?php else: ?>
    <div style="padding: 16px 20px; border-radius: 8px; margin-bottom: 24px; font-weight: 700; font-size: 14px; display: flex; align-items: center; gap: 10px; background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.3); color: var(--danger);">
        <i class="bx bx-error" style="font-size: 20px;"></i>
        <span>🔴 Caution: Ledger Mismatch detected! Debits and Credits do not align. Verify manual postings.</span>
    </div>
<?php endif; ?>

<!-- ==========================================
     TRIAL BALANCE REPORT CARD
     ========================================== -->
<div class="card">
    <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 14px;">
        <thead>
            <tr style="border-bottom: 2px solid var(--border-color); color: var(--text-secondary); text-transform: uppercase; font-size: 11px;">
                <th style="padding: 12px 8px; width: 140px;">Account Code</th>
                <th style="padding: 12px 8px;">Account Name</th>
                <th style="padding: 12px 8px; width: 150px;">Account Type</th>
                <th style="padding: 12px 8px; text-align: right; width: 180px;">Debit Balance (Rs.)</th>
                <th style="padding: 12px 8px; text-align: right; width: 180px;">Credit Balance (Rs.)</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($balances as $row): 
                $deb = (float)$row['total_debit'];
                $cred = (float)$row['total_credit'];
                
                // Determine normal balance formatting
                $type = $row['account_type'];
                $row_debit = 0.00;
                $row_credit = 0.00;

                if ($type === 'Asset' || $type === 'Expense') {
                    $net = $deb - $cred;
                    if ($net >= 0) $row_debit = $net;
                    else $row_credit = abs($net);
                } else {
                    $net = $cred - $deb;
                    if ($net >= 0) $row_credit = $net;
                    else $row_debit = abs($net);
                }
            ?>
                <tr style="border-bottom: 1px solid var(--border-color); color: var(--text-main);">
                    <td style="padding: 14px 8px; font-weight: 700; font-family: monospace; color:#3b82f6;">
                        <?php echo htmlspecialchars($row['account_code']); ?>
                    </td>
                    <td style="padding: 14px 8px; font-weight: 600;"><?php echo htmlspecialchars($row['account_name']); ?></td>
                    <td style="padding: 14px 8px; color: var(--text-secondary);"><?php echo htmlspecialchars($row['account_type']); ?></td>
                    <td style="padding: 14px 8px; text-align: right; font-weight: 700; color:#3b82f6;">
                        <?php echo $row_debit > 0 ? 'Rs. ' . number_format($row_debit, 2) : '-'; ?>
                    </td>
                    <td style="padding: 14px 8px; text-align: right; font-weight: 700; color:#10b981;">
                        <?php echo $row_credit > 0 ? 'Rs. ' . number_format($row_credit, 2) : '-'; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr style="font-weight: 800; background: rgba(255,255,255,0.015); border-top: 2.5px solid var(--border-color);">
                <td colspan="3" style="padding: 16px 8px; text-align: right; text-transform: uppercase; font-size:12px; color: var(--text-secondary);">Grand Adjusted Sums:</td>
                <td style="padding: 16px 8px; text-align: right; color:#3b82f6; font-size:15px;">Rs. <?php echo number_format($grand_debit, 2); ?></td>
                <td style="padding: 16px 8px; text-align: right; color:#10b981; font-size:15px;">Rs. <?php echo number_format($grand_credit, 2); ?></td>
            </tr>
        </tfoot>
    </table>
</div>

<?php
require_once __DIR__ . '/../../includes/footer.php';
?>
