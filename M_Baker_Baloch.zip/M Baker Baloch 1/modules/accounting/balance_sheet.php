<?php
/**
 * SaaS Isolated Corporate Balance Sheet compilation sheet
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/db.php';

$tenant_id = $_SESSION['tenant_id'];

// Initial accounts balances
$cash = 0.00;
$bank = 0.00;
$receivables = 0.00;
$inventory = 0.00;
$payables = 0.00;
$capital = 0.00;
$retained_earnings = 0.00;

try {
    $db = SaaSDB::getConnection();

    // Reusable balance resolver helper
    function getBalance($db, $tenant, $code, $is_asset_or_expense = true) {
        $stmt = $db->prepare("SELECT SUM(ji.debit) AS td, SUM(ji.credit) AS tc
                              FROM `journal_items` ji
                              JOIN `accounts` a ON ji.account_id = a.id
                              WHERE a.tenant_id = :tenant AND a.account_code = :code");
        $stmt->execute(['tenant' => $tenant, 'code' => $code]);
        $res = $stmt->fetch();
        $td = (float)($res['td'] ?? 0.00);
        $tc = (float)($res['tc'] ?? 0.00);

        return $is_asset_or_expense ? ($td - $tc) : ($tc - $td);
    }

    $cash = getBalance($db, $tenant_id, '1001', true);
    $bank = getBalance($db, $tenant_id, '1002', true);
    $receivables = getBalance($db, $tenant_id, '1003', true);
    $inventory = getBalance($db, $tenant_id, '1004', true);
    $payables = getBalance($db, $tenant_id, '2001', false);
    $capital = getBalance($db, $tenant_id, '3001', false);

    // Calculate dynamic Retained Earnings (Net Profit = Income - Expenses)
    $rev_stmt = $db->prepare("SELECT SUM(ji.credit - ji.debit) 
                              FROM `journal_items` ji
                              JOIN `accounts` a ON ji.account_id = a.id
                              WHERE a.tenant_id = :tenant AND a.account_type = 'Income'");
    $rev_stmt->execute(['tenant' => $tenant_id]);
    $total_revenue = (float)$rev_stmt->fetchColumn() ?: 0.00;

    $exp_stmt = $db->prepare("SELECT SUM(ji.debit - ji.credit) 
                              FROM `journal_items` ji
                              JOIN `accounts` a ON ji.account_id = a.id
                              WHERE a.tenant_id = :tenant AND a.account_type = 'Expense'");
    $exp_stmt->execute(['tenant' => $tenant_id]);
    $total_expenses = (float)$exp_stmt->fetchColumn() ?: 0.00;

    $retained_earnings = $total_revenue - $total_expenses;

} catch (PDOException $e) {
    echo "<div style='color:var(--danger); padding:20px;'>Balance Sheet compile failure: " . $e->getMessage() . "</div>";
}

$total_assets = $cash + $bank + $receivables + $inventory;
$total_liabilities = $payables;
$total_equity = $capital + $retained_earnings;
$total_liabilities_equity = $total_liabilities + $total_equity;

$is_equation_valid = (abs($total_assets - $total_liabilities_equity) < 0.001);
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Corporate Balance Sheet</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Corporate financial audit validating assets, liabilities, and owner capital ratios.</p>
    </div>
    
    <div style="display: flex; gap: 10px;">
        <a href="dashboard.php" class="btn btn-secondary" style="font-size: 13px; padding: 10px 16px;">
            <i class="bx bx-left-arrow-alt"></i> Back to Accounting
        </a>
        <button onclick="window.print()" class="btn btn-secondary" style="font-size: 13px; padding: 10px 16px;">
            <i class="bx bx-printer"></i> Print Balance Sheet
        </button>
    </div>
</div>

<!-- ==========================================
     ACCOUNTING EQUATION COMPLIANCE BAR
     ========================================== -->
<?php if ($is_equation_valid): ?>
    <div style="padding: 16px 20px; border-radius: 8px; margin-bottom: 24px; font-weight: 700; font-size: 14px; display: flex; align-items: center; gap: 10px; background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); color: #10b981;">
        <i class="bx bx-shield-check" style="font-size: 20px;"></i>
        <span>🟢 Balance Sheet Compliant: Assets (Rs. <?php echo number_format($total_assets, 2); ?>) perfectly balance Liabilities + Equity!</span>
    </div>
<?php else: ?>
    <div style="padding: 16px 20px; border-radius: 8px; margin-bottom: 24px; font-weight: 700; font-size: 14px; display: flex; align-items: center; gap: 10px; background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.3); color: var(--danger);">
        <i class="bx bx-shield-x" style="font-size: 20px;"></i>
        <span>🔴 Equation Mismatch: Assets do not balance Liabilities + Equity. Check trial balances.</span>
    </div>
<?php endif; ?>

<!-- ==========================================
     BALANCE SHEET REPORT PANEL
     ========================================== -->
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; align-items: start; margin-top: 20px; flex-wrap: wrap;">
    <!-- LEFT COLUMN: ASSETS -->
    <div class="card" style="border-top: 4px solid #3b82f6;">
        <h3 style="font-size: 15px; font-weight: 800; text-transform: uppercase; color: #3b82f6; margin-bottom: 20px; border-bottom: 1px solid var(--border-color); padding-bottom: 8px;">
            <i class="bx bx-trending-up"></i> Asset Accounts
        </h3>
        
        <div style="display: flex; flex-direction: column; gap: 15px; font-size: 13.5px;">
            <div style="display:flex; justify-content:space-between; border-bottom:1px dashed var(--border-color); padding-bottom: 6px;">
                <span style="color:var(--text-secondary); font-weight:600;">Cash in Hand</span>
                <span style="font-weight:700; color:var(--text-main);">Rs. <?php echo number_format($cash, 2); ?></span>
            </div>
            
            <div style="display:flex; justify-content:space-between; border-bottom:1px dashed var(--border-color); padding-bottom: 6px;">
                <span style="color:var(--text-secondary); font-weight:600;">Bank Balances</span>
                <span style="font-weight:700; color:var(--text-main);">Rs. <?php echo number_format($bank, 2); ?></span>
            </div>

            <div style="display:flex; justify-content:space-between; border-bottom:1px dashed var(--border-color); padding-bottom: 6px;">
                <span style="color:var(--text-secondary); font-weight:600;">Accounts Receivable (Customer Dues)</span>
                <span style="font-weight:700; color:var(--text-main);">Rs. <?php echo number_format($receivables, 2); ?></span>
            </div>

            <div style="display:flex; justify-content:space-between; border-bottom:1px dashed var(--border-color); padding-bottom: 6px;">
                <span style="color:var(--text-secondary); font-weight:600;">Inventory Asset Value</span>
                <span style="font-weight:700; color:var(--text-main);">Rs. <?php echo number_format($inventory, 2); ?></span>
            </div>

            <div style="display:flex; justify-content:space-between; background: rgba(59, 130, 246, 0.08); padding: 12px 14px; border-radius: 6px; font-weight:800; font-size:14px; margin-top: 15px;">
                <span style="color:#3b82f6;">TOTAL ASSETS</span>
                <span style="color:#3b82f6;">Rs. <?php echo number_format($total_assets, 2); ?></span>
            </div>
        </div>
    </div>

    <!-- RIGHT COLUMN: LIABILITIES & EQUITY -->
    <div style="display: flex; flex-direction: column; gap: 24px;">
        <!-- Liabilities Section -->
        <div class="card" style="border-top: 4px solid var(--danger);">
            <h3 style="font-size: 15px; font-weight: 800; text-transform: uppercase; color: var(--danger); margin-bottom: 20px; border-bottom: 1px solid var(--border-color); padding-bottom: 8px;">
                <i class="bx bx-trending-down"></i> Liability Accounts
            </h3>
            
            <div style="display: flex; flex-direction: column; gap: 15px; font-size: 13.5px;">
                <div style="display:flex; justify-content:space-between; border-bottom:1px dashed var(--border-color); padding-bottom: 6px;">
                    <span style="color:var(--text-secondary); font-weight:600;">Accounts Payable (Supplier Dues)</span>
                    <span style="font-weight:700; color:var(--text-main);">Rs. <?php echo number_format($payables, 2); ?></span>
                </div>

                <div style="display:flex; justify-content:space-between; background: rgba(239, 68, 68, 0.08); padding: 12px 14px; border-radius: 6px; font-weight:800; font-size:14px;">
                    <span style="color:var(--danger);">TOTAL LIABILITIES</span>
                    <span style="color:var(--danger);">Rs. <?php echo number_format($total_liabilities, 2); ?></span>
                </div>
            </div>
        </div>

        <!-- Equity Section -->
        <div class="card" style="border-top: 4px solid #a855f7;">
            <h3 style="font-size: 15px; font-weight: 800; text-transform: uppercase; color: #a855f7; margin-bottom: 20px; border-bottom: 1px solid var(--border-color); padding-bottom: 8px;">
                <i class="bx bx-donate-heart"></i> Owner Equity
            </h3>
            
            <div style="display: flex; flex-direction: column; gap: 15px; font-size: 13.5px;">
                <div style="display:flex; justify-content:space-between; border-bottom:1px dashed var(--border-color); padding-bottom: 6px;">
                    <span style="color:var(--text-secondary); font-weight:600;">Owner Capital Investments</span>
                    <span style="font-weight:700; color:var(--text-main);">Rs. <?php echo number_format($capital, 2); ?></span>
                </div>

                <div style="display:flex; justify-content:space-between; border-bottom:1px dashed var(--border-color); padding-bottom: 6px;">
                    <span style="color:var(--text-secondary); font-weight:600;">Retained Earnings / Net Profits</span>
                    <span style="font-weight:700; color:var(--text-main);">Rs. <?php echo number_format($retained_earnings, 2); ?></span>
                </div>

                <div style="display:flex; justify-content:space-between; background: rgba(168, 85, 247, 0.08); padding: 12px 14px; border-radius: 6px; font-weight:800; font-size:14px;">
                    <span style="color:#a855f7;">TOTAL EQUITY</span>
                    <span style="color:#a855f7;">Rs. <?php echo number_format($total_equity, 2); ?></span>
                </div>
            </div>
        </div>

        <!-- Grand Total liabilities & Equity -->
        <div class="card" style="background: rgba(16, 185, 129, 0.08); border: 2.5px solid rgba(16, 185, 129, 0.2); border-radius: 8px; padding: 16px 20px;">
            <div style="display:flex; justify-content:space-between; font-weight:900; font-size:15px; color:#10b981;">
                <span>TOTAL LIABILITIES & EQUITY</span>
                <span>Rs. <?php echo number_format($total_liabilities_equity, 2); ?></span>
            </div>
        </div>
    </div>
</div>

<?php
require_once __DIR__ . '/../../includes/footer.php';
?>
