<?php
/**
 * Chart of Accounts sheets
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/db.php';

$tenant_id = $_SESSION['tenant_id'];
$accounts = [];

try {
    $db = SaaSDB::getConnection();
    
    // Fetch chart of accounts
    $stmt = $db->prepare("SELECT * FROM `accounts` WHERE `tenant_id` = :tenant ORDER BY `account_code` ASC");
    $stmt->execute(['tenant' => $tenant_id]);
    $accounts = $stmt->fetchAll();
    
} catch (PDOException $e) {
    echo "<div style='color:var(--danger); padding:20px;'>Accounts fetch error: " . $e->getMessage() . "</div>";
}
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Chart of Accounts</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Isolated list of account profiles driving double entry postings.</p>
    </div>
    
    <div style="display: flex; gap: 10px;">
        <a href="dashboard.php" class="btn btn-secondary" style="font-size: 13px; padding: 10px 16px;">
            <i class="bx bx-left-arrow-alt"></i> Back to Accounting
        </a>
    </div>
</div>

<!-- ==========================================
     CHART OF ACCOUNTS TABLE
     ========================================== -->
<div class="card">
    <div style="margin-bottom: 20px;">
        <input type="text" id="search-accounts" class="form-control" placeholder="🔍 Search accounts by name or code..." onkeyup="filterAccountsTable()" style="max-width: 360px;">
    </div>

    <?php if (empty($accounts)): ?>
        <div style="text-align: center; padding: 40px; color: var(--text-secondary); font-size: 14px;">
            No accounts configured in your Chart of Accounts.
        </div>
    <?php else: ?>
        <div style="overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 14px;">
                <thead>
                    <tr style="border-bottom: 1.5px solid var(--border-color); color: var(--text-secondary);">
                        <th style="padding: 12px 8px; width: 150px;">Account Code</th>
                        <th style="padding: 12px 8px;">Account Name</th>
                        <th style="padding: 12px 8px; width: 200px;">Account Type</th>
                        <th style="padding: 12px 8px; text-align: center; width: 120px;">Status</th>
                    </tr>
                </thead>
                <tbody id="accounts-table-body">
                    <?php foreach ($accounts as $acc): 
                        $type_style = 'background: rgba(255, 255, 255, 0.05); border: 1px solid var(--border-color); color: var(--text-secondary);';
                        switch ($acc['account_type']) {
                            case 'Asset':
                                $type_style = 'background: rgba(59, 130, 246, 0.12); border: 1px solid rgba(59, 130, 246, 0.2); color: #3b82f6;';
                                break;
                            case 'Liability':
                                $type_style = 'background: rgba(239, 68, 68, 0.12); border: 1px solid rgba(239, 68, 68, 0.2); color: var(--danger);';
                                break;
                            case 'Equity':
                                $type_style = 'background: rgba(168, 85, 247, 0.12); border: 1px solid rgba(168, 85, 247, 0.2); color: #a855f7;';
                                break;
                            case 'Income':
                                $type_style = 'background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.2); color: #10b981;';
                                break;
                            case 'Expense':
                                $type_style = 'background: rgba(234, 179, 8, 0.12); border: 1px solid rgba(234, 179, 8, 0.2); color: #eab308;';
                                break;
                        }
                    ?>
                        <tr class="account-row" 
                            data-code="<?php echo htmlspecialchars(strtolower($acc['account_code'])); ?>"
                            data-name="<?php echo htmlspecialchars(strtolower($acc['account_name'])); ?>"
                            style="border-bottom: 1px solid var(--border-color); color: var(--text-main);">
                            <td style="padding: 14px 8px; font-weight: 700; font-family: monospace; font-size: 14px; color: #3b82f6;">
                                <?php echo htmlspecialchars($acc['account_code']); ?>
                            </td>
                            <td style="padding: 14px 8px; font-weight: 600;"><?php echo htmlspecialchars($acc['account_name']); ?></td>
                            <td style="padding: 14px 8px;">
                                <span style="padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: 700; text-transform: uppercase; <?php echo $type_style; ?>">
                                    <?php echo htmlspecialchars($acc['account_type']); ?>
                                </span>
                            </td>
                            <td style="padding: 14px 8px; text-align: center;">
                                <span style="padding: 2px 8px; border-radius: 6px; font-size: 11px; background: rgba(16, 185, 129, 0.15); color: #10b981; font-weight: 600;">Active</span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<script>
function filterAccountsTable() {
    const query = document.getElementById('search-accounts').value.toLowerCase().trim();
    const rows = document.querySelectorAll('.account-row');

    rows.forEach(row => {
        const code = row.getAttribute('data-code');
        const name = row.getAttribute('data-name');
        if (code.includes(query) || name.includes(query)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}
</script>

<?php
require_once __DIR__ . '/../../includes/footer.php';
?>
