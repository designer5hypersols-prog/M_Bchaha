<?php
/**
 * SaaS Isolated Double Entry Accounting Dashboard
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/db.php';

$tenant_id = $_SESSION['tenant_id'];

$total_revenue = 0.00;
$total_expenses = 0.00;
$cash_balance = 0.00;

try {
    $db = SaaSDB::getConnection();

    // 1. Calculate Total Revenue (Income Accounts: Credit - Debit)
    $stmt = $db->prepare("SELECT SUM(ji.credit - ji.debit) 
                          FROM `journal_items` ji
                          JOIN `accounts` a ON ji.account_id = a.id
                          WHERE a.tenant_id = :tenant AND a.account_type = 'Income'");
    $stmt->execute(['tenant' => $tenant_id]);
    $total_revenue = (float)$stmt->fetchColumn() ?: 0.00;

    // 2. Calculate Total Expenses (Expense Accounts: Debit - Credit)
    $stmt = $db->prepare("SELECT SUM(ji.debit - ji.credit) 
                          FROM `journal_items` ji
                          JOIN `accounts` a ON ji.account_id = a.id
                          WHERE a.tenant_id = :tenant AND a.account_type = 'Expense'");
    $stmt->execute(['tenant' => $tenant_id]);
    $total_expenses = (float)$stmt->fetchColumn() ?: 0.00;

    // 3. Calculate Cash Balance (Cash Account '1001': Debit - Credit)
    $stmt = $db->prepare("SELECT SUM(ji.debit - ji.credit) 
                          FROM `journal_items` ji
                          JOIN `accounts` a ON ji.account_id = a.id
                          WHERE a.tenant_id = :tenant AND a.account_code = '1001'");
    $stmt->execute(['tenant' => $tenant_id]);
    $cash_balance = (float)$stmt->fetchColumn() ?: 0.00;

} catch (PDOException $e) {
    echo "<div style='color:var(--danger); padding:20px;'>Financial engine fetch failure: " . $e->getMessage() . "</div>";
}

$net_profit = $total_revenue - $total_expenses;

// Financial health determination
if ($net_profit > 0) {
    $health_status = "🟢 Excellent: Business is highly profitable";
    $health_style = "background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); color: #10b981;";
} elseif ($net_profit == 0) {
    $health_status = "🟡 Break-even: Revenues and expenses are balanced";
    $health_style = "background: rgba(234, 179, 8, 0.15); border: 1px solid rgba(234, 179, 8, 0.3); color: #eab308;";
} else {
    $health_status = "🔴 Caution: Losses detected. Audit expenses closely";
    $health_style = "background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.3); color: var(--danger);";
}
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Double Entry Accounting Dashboard</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">General ledger, Trial balances, Profit & Loss reports, and corporate accounting controls.</p>
    </div>
    
    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
        <a href="chart_of_accounts.php" class="btn btn-secondary" style="font-size: 12.5px; padding: 10px 14px;">
            <i class="bx bx-list-ul"></i> Chart of Accounts
        </a>
        <a href="journal.php" class="btn" style="font-size: 12.5px; padding: 10px 14px; background: #3b82f6; border-color: #3b82f6;">
            <i class="bx bx-edit-alt"></i> Journal Entries
        </a>
        <a href="ledger.php" class="btn btn-secondary" style="font-size: 12.5px; padding: 10px 14px;">
            <i class="bx bx-book"></i> General Ledger
        </a>
        <a href="trial_balance.php" class="btn btn-secondary" style="font-size: 12.5px; padding: 10px 14px;">
            <i class="bx bx-equalizer"></i> Trial Balance
        </a>
        <a href="profit_loss.php" class="btn btn-secondary" style="font-size: 12.5px; padding: 10px 14px; border-color: rgba(16, 185, 129, 0.3); color: #10b981;">
            <i class="bx bx-trending-up"></i> Profit & Loss
        </a>
        <a href="balance_sheet.php" class="btn btn-secondary" style="font-size: 12.5px; padding: 10px 14px; border-color: rgba(239, 68, 68, 0.3); color: var(--danger);">
            <i class="bx bx-briefcase"></i> Balance Sheet
        </a>
    </div>
</div>

<!-- Financial Health Indicator Banner -->
<div style="padding: 16px 20px; border-radius: 8px; margin-bottom: 24px; font-weight: 700; font-size: 14px; display: flex; align-items: center; gap: 10px; <?php echo $health_style; ?>">
    <i class="bx bx-info-circle" style="font-size: 20px;"></i>
    <span><?php echo $health_status; ?></span>
</div>

<!-- ==========================================
     FINANCIAL SUMMARY KPI DECK
     ========================================== -->
<div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px;">
    <!-- Sales Revenue -->
    <div class="stat-card" style="border-left: 4px solid #10b981;">
        <span style="font-size: 12px; color: var(--text-secondary); font-weight: 600; text-transform: uppercase;">Total Sales Revenue</span>
        <h3 style="font-size: 24px; font-weight: 800; margin: 8px 0 4px 0; color: #10b981;">Rs. <?php echo number_format($total_revenue, 2); ?></h3>
        <p style="margin: 0; color: var(--text-secondary); font-size: 11.5px;">Sales income logs isolated to your company.</p>
    </div>

    <!-- Operating Expenses -->
    <div class="stat-card" style="border-left: 4px solid var(--danger);">
        <span style="font-size: 12px; color: var(--text-secondary); font-weight: 600; text-transform: uppercase;">Operating Expenses</span>
        <h3 style="font-size: 24px; font-weight: 800; margin: 8px 0 4px 0; color: var(--danger);">Rs. <?php echo number_format($total_expenses, 2); ?></h3>
        <p style="margin: 0; color: var(--text-secondary); font-size: 11.5px;">Procurements and administration costs.</p>
    </div>

    <!-- Net Profit -->
    <div class="stat-card" style="border-left: 4px solid #3b82f6;">
        <span style="font-size: 12px; color: var(--text-secondary); font-weight: 600; text-transform: uppercase;">Net profit</span>
        <h3 style="font-size: 24px; font-weight: 800; margin: 8px 0 4px 0; color: #3b82f6;">Rs. <?php echo number_format($net_profit, 2); ?></h3>
        <p style="margin: 0; color: var(--text-secondary); font-size: 11.5px;">Calculated revenue minus total costs.</p>
    </div>

    <!-- Cash Balance -->
    <div class="stat-card" style="border-left: 4px solid #eab308;">
        <span style="font-size: 12px; color: var(--text-secondary); font-weight: 600; text-transform: uppercase;">Liquid Cash Balance</span>
        <h3 style="font-size: 24px; font-weight: 800; margin: 8px 0 4px 0; color: #eab308;">Rs. <?php echo number_format($cash_balance, 2); ?></h3>
        <p style="margin: 0; color: var(--text-secondary); font-size: 11.5px;">Active liquid capital in hand.</p>
    </div>
</div>

<div class="card" style="margin-top: 24px;">
    <h3 style="font-size:16px; font-weight:700; margin-bottom:15px;"><i class="bx bx-shield-quarter"></i> Double Entry System Overview</h3>
    <p style="font-size: 13.5px; color: var(--text-secondary); line-height: 1.6; margin-bottom: 12px;">
        Your "M.BAKAR BALOCH" SaaS Accounting system automates corporate ledger controls. When sales are checked out in POS or wholesale restocks are performed in procurement terminals, the system records compliant double-entry journal items inside your secure workspace partition, keeping your financial statements accurate in real time.
    </p>
    <div style="display:flex; gap: 15px; margin-top: 15px;">
        <a href="profit_loss.php" class="btn" style="background:#10b981; border-color:#10b981; font-size:12.5px;">Generate Income Statement</a>
        <a href="balance_sheet.php" class="btn" style="background:#3b82f6; border-color:#3b82f6; font-size:12.5px;">Compile Balance Sheet</a>
    </div>
</div>

<?php
require_once __DIR__ . '/../../includes/footer.php';
?>
