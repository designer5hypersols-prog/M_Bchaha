<?php
/**
 * SaaS Isolated General Ledger Account Sheet
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/db.php';

$tenant_id = $_SESSION['tenant_id'];
$accounts = [];
$selected_account_id = isset($_GET['account_id']) ? (int)$_GET['account_id'] : 0;
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';

$account_details = null;
$ledger_items = [];
$total_debit = 0.00;
$total_credit = 0.00;

try {
    $db = SaaSDB::getConnection();

    // 1. Fetch Chart of Accounts for dropdown menu
    $stmt = $db->prepare("SELECT * FROM `accounts` WHERE `tenant_id` = :tenant ORDER BY `account_code` ASC");
    $stmt->execute(['tenant' => $tenant_id]);
    $accounts = $stmt->fetchAll();

    if ($selected_account_id > 0) {
        // Resolve selected account type
        $stmt = $db->prepare("SELECT * FROM `accounts` WHERE `id` = :id AND `tenant_id` = :tenant");
        $stmt->execute(['id' => $selected_account_id, 'tenant' => $tenant_id]);
        $account_details = $stmt->fetch();

        if ($account_details) {
            // 2. Fetch splits chronologically matching selected account ID & date range
            $query = "SELECT ji.*, je.entry_date, je.description, je.reference_no 
                      FROM `journal_items` ji
                      JOIN `journal_entries` je ON ji.journal_id = je.id
                      WHERE ji.account_id = :account";
            
            $params = ['account' => $selected_account_id];

            if (!empty($start_date)) {
                $query .= " AND je.entry_date >= :start";
                $params['start'] = $start_date;
            }
            if (!empty($end_date)) {
                $query .= " AND je.entry_date <= :end";
                $params['end'] = $end_date;
            }

            $query .= " ORDER BY je.entry_date ASC, je.id ASC";

            $stmt = $db->prepare($query);
            $stmt->execute($params);
            $ledger_items = $stmt->fetchAll();
        }
    }

} catch (PDOException $e) {
    echo "<div style='color:var(--danger); padding:20px;'>Ledger fetch error: " . $e->getMessage() . "</div>";
}
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">General Ledger Accounts</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Chronological transaction audits and running balance statements for individual accounts.</p>
    </div>
    
    <div style="display: flex; gap: 10px;">
        <a href="dashboard.php" class="btn btn-secondary" style="font-size: 13px; padding: 10px 16px;">
            <i class="bx bx-left-arrow-alt"></i> Back to Dashboard
        </a>
    </div>
</div>

<!-- ==========================================
     ACCOUNT SELECTOR DECK
     ========================================== -->
<div class="card" style="margin-bottom: 24px;">
    <form action="ledger.php" method="GET" style="display: flex; gap: 15px; align-items: flex-end; flex-wrap: wrap;">
        <div class="form-group" style="flex: 2; min-width: 250px;">
            <label for="account_id" style="margin-bottom: 6px; font-size: 12px; font-weight: 600;">Select Account Profile</label>
            <select name="account_id" id="account_id" class="form-control" style="background:#0f172a;" required>
                <option value="">-- Choose Account --</option>
                <?php foreach ($accounts as $acc): ?>
                    <option value="<?php echo $acc['id']; ?>" <?php echo ($selected_account_id === (int)$acc['id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($acc['account_code']); ?> - <?php echo htmlspecialchars($acc['account_name']); ?> (<?php echo htmlspecialchars($acc['account_type']); ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group" style="flex: 1; min-width: 140px;">
            <label for="start_date" style="margin-bottom: 6px; font-size: 12px; font-weight: 600;">Start Date</label>
            <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo htmlspecialchars($start_date); ?>">
        </div>

        <div class="form-group" style="flex: 1; min-width: 140px;">
            <label for="end_date" style="margin-bottom: 6px; font-size: 12px; font-weight: 600;">End Date</label>
            <input type="date" name="end_date" id="end_date" class="form-control" value="<?php echo htmlspecialchars($end_date); ?>">
        </div>

        <button type="submit" class="btn" style="background: #3b82f6; border-color: #3b82f6; padding: 10px 20px;">
            <i class="bx bx-search-alt"></i> Load Statement
        </button>
    </form>
</div>

<!-- ==========================================
     LEDGER STATEMENT GRID
     ========================================== -->
<?php if ($account_details): ?>
    <div class="card">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 15px; flex-wrap:wrap; gap: 10px; border-bottom: 1px solid var(--border-color); padding-bottom: 15px;">
            <div>
                <h3 style="font-size: 16px; font-weight: 800; display:flex; align-items:center; gap:8px;">
                    <i class="bx bx-folder-open" style="color: #3b82f6;"></i>
                    Account: <span style="color:#3b82f6;"><?php echo htmlspecialchars($account_details['account_code']); ?> - <?php echo htmlspecialchars($account_details['account_name']); ?></span>
                </h3>
                <span style="font-size:11.5px; padding: 2px 8px; border-radius:12px; background: rgba(59, 130, 246, 0.12); color:#3b82f6; font-weight:700; text-transform:uppercase; margin-top: 4px; display:inline-block;">
                    Type: <?php echo htmlspecialchars($account_details['account_type']); ?>
                </span>
            </div>
            
            <button onclick="window.print()" class="btn btn-secondary" style="font-size:11.5px; padding: 6px 12px;">
                <i class="bx bx-printer"></i> Print Statement
            </button>
        </div>

        <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 13px;">
            <thead>
                <tr style="border-bottom: 2px solid var(--border-color); color: var(--text-secondary); text-transform: uppercase; font-size: 11px;">
                    <th style="padding: 10px 4px; width: 110px;">Date</th>
                    <th style="padding: 10px 4px; width: 80px; text-align:center;">Voucher #</th>
                    <th style="padding: 10px 4px;">Memo / Description</th>
                    <th style="padding: 10px 4px; width: 120px; font-family: monospace;">Reference</th>
                    <th style="padding: 10px 4px; text-align: right; width: 130px;">Debit (Rs.)</th>
                    <th style="padding: 10px 4px; text-align: right; width: 130px;">Credit (Rs.)</th>
                    <th style="padding: 10px 4px; text-align: right; width: 150px;">Running Balance (Rs.)</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($ledger_items)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 30px; color: var(--text-secondary);">
                            No chronological ledger logs registered for selected date ranges.
                        </td>
                    </tr>
                <?php else: 
                    $running_balance = 0.00;
                    $account_type = $account_details['account_type'];
                    
                    foreach ($ledger_items as $item): 
                        $deb = (float)$item['debit'];
                        $cred = (float)$item['credit'];
                        
                        $total_debit += $deb;
                        $total_credit += $cred;

                        // Balance Sheet/Income Statement normal balance conventions
                        if ($account_type === 'Asset' || $account_type === 'Expense') {
                            $running_balance += ($deb - $cred);
                        } else {
                            $running_balance += ($cred - $deb);
                        }
                    ?>
                        <tr style="border-bottom: 1px solid var(--border-color); color: var(--text-main);">
                            <td style="padding: 12px 4px; font-weight: 500;"><?php echo date('d-M-Y', strtotime($item['entry_date'])); ?></td>
                            <td style="padding: 12px 4px; text-align:center; font-weight: 700; color:#3b82f6;">#<?php echo $item['journal_id']; ?></td>
                            <td style="padding: 12px 4px; font-weight: 600;"><?php echo htmlspecialchars($item['description']); ?></td>
                            <td style="padding: 12px 4px; font-family: monospace; font-weight: 600; color:#10b981;"><?php echo htmlspecialchars($item['reference_no'] ?: '-'); ?></td>
                            <td style="padding: 12px 4px; text-align: right; font-weight: 600; color:#3b82f6;">
                                <?php echo $deb > 0 ? 'Rs. ' . number_format($deb, 2) : '-'; ?>
                            </td>
                            <td style="padding: 12px 4px; text-align: right; font-weight: 600; color:#10b981;">
                                <?php echo $cred > 0 ? 'Rs. ' . number_format($cred, 2) : '-'; ?>
                            </td>
                            <td style="padding: 12px 4px; text-align: right; font-weight: 700; color:<?php echo $running_balance >= 0 ? '#10b981' : 'var(--danger)'; ?>;">
                                Rs. <?php echo number_format($running_balance, 2); ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr style="font-weight: 800; background: rgba(255,255,255,0.01); border-top: 2px solid var(--border-color);">
                    <td colspan="4" style="padding: 14px 4px; text-align: right;">Total Aggregated Summaries:</td>
                    <td style="padding: 14px 4px; text-align: right; color:#3b82f6;">Rs. <?php echo number_format($total_debit, 2); ?></td>
                    <td style="padding: 14px 4px; text-align: right; color:#10b981;">Rs. <?php echo number_format($total_credit, 2); ?></td>
                    <td style="padding: 14px 4px; text-align: right; color:#3b82f6;">
                        Rs. <?php echo number_format(abs($total_debit - $total_credit), 2); ?> (Diff)
                    </td>
                </tr>
            </tfoot>
        </table>
    </div>
<?php else: ?>
    <div class="card" style="text-align: center; padding: 40px; color: var(--text-secondary); font-size: 14px;">
        🔍 Please select an active account profile from the form selector menu above to load statements.
    </div>
<?php endif; ?>

<?php
require_once __DIR__ . '/../../includes/footer.php';
?>
