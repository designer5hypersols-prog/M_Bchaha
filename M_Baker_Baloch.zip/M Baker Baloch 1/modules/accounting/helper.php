<?php
/**
 * SaaS Isolated Double Entry Accounting Engine Helper
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

if (!function_exists('postJournalEntry')) {
    /**
     * Post a balanced double-entry journal voucher safely inside a transaction loop
     * 
     * @param PDO $db Connection
     * @param int $tenant_id Active tenant ID
     * @param string $date Transaction Date (YYYY-MM-DD)
     * @param string $description Entry Memo
     * @param string $ref_no Invoice/Order reference
     * @param array $items List of journal items: [['code' => '1001', 'debit' => 100.00, 'credit' => 0.00], ...]
     * @throws Exception If unbalanced or invalid account codes detected
     */
    function postJournalEntry($db, $tenant_id, $date, $description, $ref_no, $items) {
        if (empty($items)) {
            throw new Exception("Journal items list cannot be empty.");
        }

        $total_debit = 0.00;
        $total_credit = 0.00;
        $resolved_items = [];

        // 1. Audit debits and credits balance
        foreach ($items as $item) {
            $code = trim($item['code']);
            $debit = (float)($item['debit'] ?? 0.00);
            $credit = (float)($item['credit'] ?? 0.00);

            if ($debit < 0 || $credit < 0) {
                throw new Exception("Debit or Credit amounts cannot be negative.");
            }

            $total_debit += $debit;
            $total_credit += $credit;

            // Resolve dynamic account ID by code
            $stmt = $db->prepare("SELECT `id` FROM `accounts` WHERE `tenant_id` = :tenant AND `account_code` = :code");
            $stmt->execute(['tenant' => $tenant_id, 'code' => $code]);
            $account_id = $stmt->fetchColumn();

            if (!$account_id) {
                throw new Exception("Account code '{$code}' is missing in your tenant's Chart of Accounts configuration.");
            }

            $resolved_items[] = [
                'account_id' => $account_id,
                'debit' => $debit,
                'credit' => $credit
            ];
        }

        // Check double-entry equality (with minor float tolerance check)
        if (abs($total_debit - $total_credit) > 0.001) {
            throw new Exception("Double Entry Error: Debits (Rs. " . number_format($total_debit, 2) . ") and Credits (Rs. " . number_format($total_credit, 2) . ") must balance.");
        }

        // 2. Insert into `journal_entries` header
        $h_stmt = $db->prepare("INSERT INTO `journal_entries` (`tenant_id`, `entry_date`, `description`, `reference_no`) 
                                VALUES (:tenant, :edate, :descr, :ref)");
        $h_stmt->execute([
            'tenant' => $tenant_id,
            'edate' => $date,
            'descr' => $description,
            'ref' => $ref_no
        ]);

        $journal_id = $db->lastInsertId();

        // 3. Insert into `journal_items` ledger breakdown
        $i_stmt = $db->prepare("INSERT INTO `journal_items` (`journal_id`, `account_id`, `debit`, `credit`) 
                                VALUES (:journal, :account, :debit, :credit)");
        
        foreach ($resolved_items as $ri) {
            $i_stmt->execute([
                'journal' => $journal_id,
                'account' => $ri['account_id'],
                'debit' => $ri['debit'],
                'credit' => $ri['credit']
            ]);
        }
    }
}
