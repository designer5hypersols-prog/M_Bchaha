<?php
/**
 * SaaS Isolated Double Entry Journal posting register
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/helper.php';

$tenant_id = $_SESSION['tenant_id'];

$success_msg = '';
$error_msg = '';
$accounts = [];
$journals = [];

try {
    $db = SaaSDB::getConnection();

    // 1. Fetch Chart of Accounts for manual voucher selections
    $stmt = $db->prepare("SELECT * FROM `accounts` WHERE `tenant_id` = :tenant ORDER BY `account_code` ASC");
    $stmt->execute(['tenant' => $tenant_id]);
    $accounts = $stmt->fetchAll();

    // Handle manual entry POST request
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $entry_date = $_POST['entry_date'] ?? date('Y-m-d');
        $description = trim($_POST['description'] ?? '');
        $ref_no = trim($_POST['reference_no'] ?? '');
        
        $item_codes = $_POST['item_code'] ?? [];
        $item_debits = $_POST['item_debit'] ?? [];
        $item_credits = $_POST['item_credit'] ?? [];

        $post_items = [];

        for ($i = 0; $i < count($item_codes); $i++) {
            $code = trim($item_codes[$i]);
            $deb = (float)($item_debits[$i] ?? 0.00);
            $cred = (float)($item_credits[$i] ?? 0.00);

            if (!empty($code) && ($deb > 0 || $cred > 0)) {
                $post_items[] = [
                    'code' => $code,
                    'debit' => $deb,
                    'credit' => $cred
                ];
            }
        }

        if (empty($description) || empty($post_items)) {
            $error_msg = "🚫 Please provide an entry description and balanced debit/credit rows.";
        } else {
            try {
                $db->beginTransaction();
                
                // Invoke double-entry engine
                postJournalEntry($db, $tenant_id, $entry_date, $description, $ref_no, $post_items);
                
                $db->commit();
                $success_msg = "🎉 Balanced journal entry posted successfully!";
            } catch (Exception $e) {
                if ($db->inTransaction()) {
                    $db->rollBack();
                }
                $error_msg = "🚫 Posting Failure: " . $e->getMessage();
            }
        }
    }

    // 2. Fetch all historical journal entries along with nested splits
    $stmt = $db->prepare("SELECT je.*, 
                                 SUM(ji.debit) AS entry_total
                          FROM `journal_entries` je
                          JOIN `journal_items` ji ON je.id = ji.journal_id
                          WHERE je.tenant_id = :tenant 
                          GROUP BY je.id
                          ORDER BY je.id DESC");
    $stmt->execute(['tenant' => $tenant_id]);
    $journals = $stmt->fetchAll();

} catch (PDOException $e) {
    $error_msg = "Database access error: " . $e->getMessage();
}
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Journal Entry Registry</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Review ledger transactions and post manual balanced journal vouchers.</p>
    </div>
    
    <div style="display: flex; gap: 10px;">
        <a href="dashboard.php" class="btn btn-secondary" style="font-size: 13px; padding: 10px 16px;">
            <i class="bx bx-left-arrow-alt"></i> Back to Dashboard
        </a>
        <button onclick="toggleVoucherPanel()" class="btn" style="font-size: 13px; padding: 10px 16px; background:#3b82f6; border-color:#3b82f6;">
            <i class="bx bx-plus-circle"></i> Post Manual Voucher
        </button>
    </div>
</div>

<!-- Alert Blocks -->
<?php if (!empty($success_msg)): ?>
    <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); color: #10b981; padding: 14px; border-radius: 8px; font-size: 13.5px; font-weight: 600; margin-bottom: 20px;">
        <?php echo $success_msg; ?>
    </div>
<?php endif; ?>

<?php if (!empty($error_msg)): ?>
    <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.3); color: var(--danger); padding: 14px; border-radius: 8px; font-size: 13.5px; font-weight: 600; margin-bottom: 20px;">
        <?php echo $error_msg; ?>
    </div>
<?php endif; ?>

<!-- ==========================================
     MANUAL JOURNAL VOUCHER SLIP (COLLAPSIBLE)
     ========================================== -->
<div class="card" id="manual-voucher-panel" style="display: none; margin-bottom: 24px; border-top: 4px solid #3b82f6;">
    <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; color: #3b82f6;">
        <i class="bx bx-add-to-queue"></i> Manual Journal Voucher Posting Slip
    </h3>
    
    <form action="journal.php" method="POST" onsubmit="return validateManualJournal()">
        <div style="display: grid; grid-template-columns: 1fr 2fr 1fr; gap: 15px; margin-bottom: 15px; flex-wrap: wrap;">
            <div class="form-group">
                <label for="entry_date" style="margin-bottom: 6px; font-size: 12px; font-weight: 600;">Voucher Date</label>
                <input type="date" name="entry_date" id="entry_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
            </div>
            <div class="form-group">
                <label for="description" style="margin-bottom: 6px; font-size: 12px; font-weight: 600;">Voucher Memo / Description</label>
                <input type="text" name="description" id="description" class="form-control" placeholder="Memo details describing transaction..." required>
            </div>
            <div class="form-group">
                <label for="reference_no" style="margin-bottom: 6px; font-size: 12px; font-weight: 600;">Reference / Slip #</label>
                <input type="text" name="reference_no" id="reference_no" class="form-control" placeholder="Slip Ref ID...">
            </div>
        </div>

        <table style="width: 100%; border-collapse: collapse; margin-top: 15px; font-size:13px;">
            <thead>
                <tr style="border-bottom: 1.5px solid var(--border-color); color: var(--text-secondary);">
                    <th style="padding: 10px 4px;">Account Selection</th>
                    <th style="padding: 10px 4px; text-align: right; width: 180px;">Debit Amount (Rs.)</th>
                    <th style="padding: 10px 4px; text-align: right; width: 180px;">Credit Amount (Rs.)</th>
                </tr>
            </thead>
            <tbody id="voucher-lines-body">
                <!-- Voucher splits rows (3 default placeholders) -->
                <?php for ($i = 0; $i < 3; $i++): ?>
                    <tr style="border-bottom: 1px solid var(--border-color);">
                        <td style="padding: 10px 4px;">
                            <select name="item_code[]" class="form-control item-select" style="background:#0f172a;" onchange="calculateRunningTotals()">
                                <option value="">-- Choose account profile --</option>
                                <?php foreach ($accounts as $acc): ?>
                                    <option value="<?php echo htmlspecialchars($acc['account_code']); ?>">
                                        <?php echo htmlspecialchars($acc['account_code']); ?> - <?php echo htmlspecialchars($acc['account_name']); ?> (<?php echo htmlspecialchars($acc['account_type']); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td style="padding: 10px 4px;">
                            <input type="number" step="0.01" name="item_debit[]" class="form-control text-right debit-input" placeholder="0.00" value="0.00" onchange="calculateRunningTotals()" onkeyup="calculateRunningTotals()">
                        </td>
                        <td style="padding: 10px 4px;">
                            <input type="number" step="0.01" name="item_credit[]" class="form-control text-right credit-input" placeholder="0.00" value="0.00" onchange="calculateRunningTotals()" onkeyup="calculateRunningTotals()">
                        </td>
                    </tr>
                <?php endfor; ?>
            </tbody>
            <tfoot>
                <tr style="font-weight: 700; background: rgba(255,255,255,0.01);">
                    <td style="padding: 14px 4px; text-align: right;">Total running sum:</td>
                    <td style="padding: 14px 4px; text-align: right; color: #3b82f6;" id="debit-total-display">Rs. 0.00</td>
                    <td style="padding: 14px 4px; text-align: right; color: #10b981;" id="credit-total-display">Rs. 0.00</td>
                </tr>
                <tr>
                    <td colspan="3" style="padding: 10px 4px; text-align: left;">
                        <button type="button" onclick="addNewVoucherRow()" class="btn btn-secondary" style="font-size: 11px; padding: 4px 10px;">
                            <i class="bx bx-plus"></i> Add Split Row
                        </button>
                    </td>
                </tr>
            </tfoot>
        </table>

        <!-- Voucher Validation status bar -->
        <div id="validation-bar" style="padding: 10px 14px; border-radius: 6px; font-size:12.5px; font-weight:600; margin-top: 15px; background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.3); color: var(--danger); text-align:center;">
            🚫 Voucher state: unbalanced. Debits and Credits must be non-zero and equal.
        </div>

        <div style="margin-top: 20px; display:flex; gap:10px; justify-content:flex-end;">
            <button type="button" onclick="toggleVoucherPanel()" class="btn btn-secondary">Cancel</button>
            <button type="submit" class="btn" style="background:#10b981; border-color:#10b981;">Post General Journal</button>
        </div>
    </form>
</div>

<!-- ==========================================
     JOURNAL TRANSACTIONS REGISTRY
     ========================================== -->
<div class="card">
    <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 15px;"><i class="bx bx-time-five"></i> Transaction History Logs</h3>

    <?php if (empty($journals)): ?>
        <div style="text-align: center; padding: 40px; color: var(--text-secondary); font-size: 14px;">
            No journal entries recorded in your partition. Complete checkouts or restocks to build registry logs.
        </div>
    <?php else: ?>
        <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 13.5px;">
            <thead>
                <tr style="border-bottom: 1.5px solid var(--border-color); color: var(--text-secondary);">
                    <th style="padding: 12px 8px; width: 60px; text-align: center;">Entry ID</th>
                    <th style="padding: 12px 8px; width: 110px;">Posting Date</th>
                    <th style="padding: 12px 8px;">Description / Memo</th>
                    <th style="padding: 12px 8px; width: 140px; font-family: monospace;">Ref No</th>
                    <th style="padding: 12px 8px; text-align: right; width: 140px;">Voucher Total</th>
                    <th style="padding: 12px 8px; text-align: center; width: 120px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($journals as $j): ?>
                    <tr style="border-bottom: 1px solid var(--border-color); color: var(--text-main);">
                        <td style="padding: 14px 8px; text-align: center; font-weight: 700; color:#3b82f6;">#<?php echo $j['id']; ?></td>
                        <td style="padding: 14px 8px; font-weight: 500;"><?php echo date('d-M-Y', strtotime($j['entry_date'])); ?></td>
                        <td style="padding: 14px 8px; font-weight: 600;"><?php echo htmlspecialchars($j['description']); ?></td>
                        <td style="padding: 14px 8px; font-family: monospace; font-weight: 700; color: #10b981;">
                            <?php echo htmlspecialchars($j['reference_no'] ?: '-'); ?>
                        </td>
                        <td style="padding: 14px 8px; text-align: right; font-weight: 700;">Rs. <?php echo number_format($j['entry_total'], 2); ?></td>
                        <td style="padding: 14px 8px; text-align: center;">
                            <button onclick="toggleDetailsRow(<?php echo $j['id']; ?>)" class="btn btn-secondary" style="font-size: 11px; padding: 4px 10px;">
                                <i class="bx bx-expand"></i> View Splits
                            </button>
                        </td>
                    </tr>
                    
                    <!-- Nested entry items row (initially hidden) -->
                    <tr id="details-row-<?php echo $j['id']; ?>" style="display: none; background: rgba(255,255,255,0.015);">
                        <td colspan="6" style="padding: 15px 30px; border-bottom: 1.5px solid var(--border-color);">
                            <div style="font-size: 12px; font-weight: 700; color: var(--text-secondary); text-transform: uppercase; margin-bottom: 8px;">
                                <i class="bx bx-git-branch"></i> Double Entry Accounting Splits
                            </div>
                            
                            <?php
                            // Fetch splits for this journal entry
                            $s_stmt = $db->prepare("SELECT ji.*, a.account_name, a.account_code, a.account_type 
                                                    FROM `journal_items` ji
                                                    JOIN `accounts` a ON ji.account_id = a.id
                                                    WHERE ji.journal_id = :jid");
                            $s_stmt->execute(['jid' => $j['id']]);
                            $splits = $s_stmt->fetchAll();
                            ?>
                            <table style="width: 100%; border-collapse: collapse; text-align: left; font-size:12px;">
                                <thead>
                                    <tr style="border-bottom: 1px solid var(--border-color); color: var(--text-secondary); font-weight: 600;">
                                        <th style="padding: 6px 4px; width: 120px;">Code</th>
                                        <th style="padding: 6px 4px;">Account Name</th>
                                        <th style="padding: 6px 4px; width: 100px;">Type</th>
                                        <th style="padding: 6px 4px; text-align: right; width: 150px;">Debit (Rs.)</th>
                                        <th style="padding: 6px 4px; text-align: right; width: 150px;">Credit (Rs.)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($splits as $split): ?>
                                        <tr style="border-bottom: 1px dashed var(--border-color);">
                                            <td style="padding: 8px 4px; font-family: monospace; font-weight: 700; color:#3b82f6;">
                                                <?php echo htmlspecialchars($split['account_code']); ?>
                                            </td>
                                            <td style="padding: 8px 4px; font-weight: 600;"><?php echo htmlspecialchars($split['account_name']); ?></td>
                                            <td style="padding: 8px 4px; color: var(--text-secondary);"><?php echo htmlspecialchars($split['account_type']); ?></td>
                                            <td style="padding: 8px 4px; text-align: right; font-weight: 700; color: #3b82f6;">
                                                <?php echo $split['debit'] > 0 ? 'Rs. ' . number_format($split['debit'], 2) : '-'; ?>
                                            </td>
                                            <td style="padding: 8px 4px; text-align: right; font-weight: 700; color: #10b981;">
                                                <?php echo $split['credit'] > 0 ? 'Rs. ' . number_format($split['credit'], 2) : '-'; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<script>
function toggleVoucherPanel() {
    const panel = document.getElementById('manual-voucher-panel');
    if (panel.style.display === 'none') {
        panel.style.display = 'block';
    } else {
        panel.style.display = 'none';
    }
}

function toggleDetailsRow(id) {
    const row = document.getElementById('details-row-' + id);
    if (row.style.display === 'none') {
        row.style.display = '';
    } else {
        row.style.display = 'none';
    }
}

function addNewVoucherRow() {
    const body = document.getElementById('voucher-lines-body');
    const template = body.querySelector('tr').cloneNode(true);
    
    // Clear select and input fields
    template.querySelector('select').value = '';
    const inputs = template.querySelectorAll('input');
    inputs[0].value = '0.00';
    inputs[1].value = '0.00';
    
    body.appendChild(template);
    calculateRunningTotals();
}

function calculateRunningTotals() {
    const debitInputs = document.querySelectorAll('.debit-input');
    const creditInputs = document.querySelectorAll('.credit-input');

    let totalDebit = 0.00;
    let totalCredit = 0.00;

    debitInputs.forEach(input => {
        totalDebit += parseFloat(input.value) || 0.00;
    });

    creditInputs.forEach(input => {
        totalCredit += parseFloat(input.value) || 0.00;
    });

    document.getElementById('debit-total-display').innerText = 'Rs. ' + totalDebit.toFixed(2);
    document.getElementById('credit-total-display').innerText = 'Rs. ' + totalCredit.toFixed(2);

    const validationBar = document.getElementById('validation-bar');

    if (totalDebit > 0 && Math.abs(totalDebit - totalCredit) < 0.001) {
        validationBar.style.background = 'rgba(16, 185, 129, 0.15)';
        validationBar.style.borderColor = 'rgba(16, 185, 129, 0.3)';
        validationBar.style.color = '#10b981';
        validationBar.innerText = '🟢 Balanced state: Voucher is ready to post.';
    } else {
        validationBar.style.background = 'rgba(239, 68, 68, 0.15)';
        validationBar.style.borderColor = 'rgba(239, 68, 68, 0.3)';
        validationBar.style.color = 'var(--danger)';
        validationBar.innerText = '🚫 Voucher state: unbalanced. Debits and Credits must be non-zero and equal.';
    }
}

function validateManualJournal() {
    const debitInputs = document.querySelectorAll('.debit-input');
    const creditInputs = document.querySelectorAll('.credit-input');

    let totalDebit = 0.00;
    let totalCredit = 0.00;

    debitInputs.forEach(input => {
        totalDebit += parseFloat(input.value) || 0.00;
    });

    creditInputs.forEach(input => {
        totalCredit += parseFloat(input.value) || 0.00;
    });

    if (totalDebit <= 0 || Math.abs(totalDebit - totalCredit) > 0.001) {
        alert("🚫 Double Entry Validation Failure: Your voucher debits and credits do not balance.");
        return false;
    }

    return true;
}
</script>

<?php
require_once __DIR__ . '/../../includes/footer.php';
?>
