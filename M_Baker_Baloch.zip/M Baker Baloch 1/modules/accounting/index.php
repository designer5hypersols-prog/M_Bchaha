<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/header.php';
?>
<h2>General Accounting</h2>
<p>Chart of Accounts, Journal Entries, Balance Sheets.</p>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
