<?php
/**
 * SaaS Isolated Corporate Profit & Loss statement
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/db.php';

$tenant_id = $_SESSION['tenant_id'];

$sales_revenue = 0.00;
$cogs = 0.00;
$operating_expenses = 0.00;

try {
    $db = SaaSDB::getConnection();

    // 1. Sales Revenue (Income accounts total)
    $stmt = $db->prepare("SELECT SUM(ji.credit - ji.debit) 
                          FROM `journal_items` ji
                          JOIN `accounts` a ON ji.account_id = a.id
                          WHERE a.tenant_id = :tenant AND a.account_type = 'Income'");
    $stmt->execute(['tenant' => $tenant_id]);
    $sales_revenue = (float)$stmt->fetchColumn() ?: 0.00;

    // 2. Cost of Goods Sold (COGS - account code '5001')
    $stmt = $db->prepare("SELECT SUM(ji.debit - ji.credit) 
                          FROM `journal_items` ji
                          JOIN `accounts` a ON ji.account_id = a.id
                          WHERE a.tenant_id = :tenant AND a.account_code = '5001'");
    $stmt->execute(['tenant' => $tenant_id]);
    $cogs = (float)$stmt->fetchColumn() ?: 0.00;

    // 3. Operating Expenses (Expense code '5002')
    $stmt = $db->prepare("SELECT SUM(ji.debit - ji.credit) 
                          FROM `journal_items` ji
                          JOIN `accounts` a ON ji.account_id = a.id
                          WHERE a.tenant_id = :tenant AND a.account_code = '5002'");
    $stmt->execute(['tenant' => $tenant_id]);
    $operating_expenses = (float)$stmt->fetchColumn() ?: 0.00;

} catch (PDOException $e) {
    echo "<div style='color:var(--danger); padding:20px;'>P&L compile failure: " . $e->getMessage() . "</div>";
}

$gross_profit = $sales_revenue - $cogs;
$net_profit = $gross_profit - $operating_expenses;
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Income Statement (Profit & Loss)</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Corporate P&L statement auditing revenues, cost of goods sold, and operating profit margins.</p>
    </div>
    
    <div style="display: flex; gap: 10px;">
        <a href="dashboard.php" class="btn btn-secondary" style="font-size: 13px; padding: 10px 16px;">
            <i class="bx bx-left-arrow-alt"></i> Back to Accounting
        </a>
        <button onclick="window.print()" class="btn btn-secondary" style="font-size: 13px; padding: 10px 16px;">
            <i class="bx bx-printer"></i> Print Statement
        </button>
    </div>
</div>

<!-- ==========================================
     PROFIT & LOSS STATEMENT CARD
     ========================================== -->
<div class="card" style="max-width: 720px; margin: 0 auto;">
    <div style="text-align: center; margin-bottom: 30px; border-bottom: 1.5px solid var(--border-color); padding-bottom: 20px;">
        <h2 style="font-size: 20px; font-weight: 800; color: #10b981; text-transform: uppercase;">PROFIT & LOSS STATEMENT</h2>
        <p style="margin: 6px 0 0 0; color: var(--text-secondary); font-size: 12.5px;">For the accounting period ending today</p>
    </div>

    <div style="display: flex; flex-direction: column; gap: 18px; font-size: 14px;">
        
        <!-- SALES REVENUE -->
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px dashed var(--border-color); padding-bottom: 8px;">
            <span style="font-weight: 700; color: var(--text-main);"><i class="bx bx-right-arrow-alt"></i> Sales Revenue (Income)</span>
            <span style="font-weight: 700; color: #10b981;">Rs. <?php echo number_format($sales_revenue, 2); ?></span>
        </div>

        <!-- COGS -->
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px dashed var(--border-color); padding-bottom: 8px; padding-left: 20px;">
            <span style="color: var(--text-secondary); font-weight: 600;"><i class="bx bx-minus"></i> Less: Cost of Goods Sold (COGS)</span>
            <span style="font-weight: 600; color: var(--danger);">Rs. <?php echo number_format($cogs, 2); ?></span>
        </div>

        <!-- GROSS PROFIT -->
        <div style="display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.01); border-bottom: 1.5px solid var(--border-color); padding: 8px 10px; border-radius:4px;">
            <span style="font-weight: 800; text-transform: uppercase; color: var(--text-main); font-size: 13px;">Gross Profit Margin</span>
            <span style="font-weight: 800; color: #10b981; font-size: 15px;">Rs. <?php echo number_format($gross_profit, 2); ?></span>
        </div>

        <!-- OPERATING EXPENSES -->
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px dashed var(--border-color); padding-bottom: 8px; padding-left: 20px;">
            <span style="color: var(--text-secondary); font-weight: 600;"><i class="bx bx-minus"></i> Less: Operating Expenses</span>
            <span style="font-weight: 600; color: var(--danger);">Rs. <?php echo number_format($operating_expenses, 2); ?></span>
        </div>

        <!-- NET PROFIT -->
        <div style="display: flex; justify-content: space-between; align-items: center; background: rgba(16, 185, 129, 0.08); border: 1.5px solid rgba(16, 185, 129, 0.2); padding: 14px 16px; border-radius: 8px; margin-top: 10px;">
            <span style="font-weight: 900; text-transform: uppercase; color: #10b981; font-size: 14px;">Net Operating profit</span>
            <span style="font-weight: 900; color: #10b981; font-size: 18px;">Rs. <?php echo number_format($net_profit, 2); ?></span>
        </div>

    </div>
</div>

<?php
require_once __DIR__ . '/../../includes/footer.php';
?>
