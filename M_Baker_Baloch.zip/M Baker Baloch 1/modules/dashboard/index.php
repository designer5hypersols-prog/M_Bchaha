<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/database.php';

$db = Database::getInstance();
$tenant_id = Auth::tenantId();

// Stats
$productsCount = $db->prepare("SELECT COUNT(*) FROM products WHERE tenant_id = ?");
$productsCount->execute([$tenant_id]);
$total_products = $productsCount->fetchColumn();

$salesSum = $db->prepare("SELECT SUM(grand_total) FROM sales WHERE tenant_id = ?");
$salesSum->execute([$tenant_id]);
$total_sales = $salesSum->fetchColumn() ?: 0;
?>
<h2 class="mb-4">Overview</h2>
<div class="row">
    <div class="col-md-3">
        <div class="card shadow-sm text-center p-4 border-0 border-start border-4 border-primary">
            <h5 class="text-secondary">Total Products</h5>
            <h3><?= $total_products ?></h3>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card shadow-sm text-center p-4 border-0 border-start border-4 border-success">
            <h5 class="text-secondary">Total Sales</h5>
            <h3>Rs. <?= number_format($total_sales, 2) ?></h3>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
