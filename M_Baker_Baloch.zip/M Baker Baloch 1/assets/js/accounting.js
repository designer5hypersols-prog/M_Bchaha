/**
 * SaaS Isolated Double Entry Accounting JavaScript helpers
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

/**
 * Validates that manual journal voucher debits equal credits before posting
 */
function validateAccountingVoucher() {
    const debits = document.querySelectorAll('.debit-input');
    const credits = document.querySelectorAll('.credit-input');

    let totalDebit = 0.00;
    let totalCredit = 0.00;

    debits.forEach(i => {
        totalDebit += parseFloat(i.value) || 0.00;
    });

    credits.forEach(i => {
        totalCredit += parseFloat(i.value) || 0.00;
    });

    if (totalDebit <= 0 || Math.abs(totalDebit - totalCredit) > 0.001) {
        alert("🚫 Accounting Error: Debits and Credits do not balance.");
        return false;
    }
    return true;
}
