/**
 * SaaS Stock Sheets Filtering Helper
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

/**
 * Filter stock rows dynamically matching input text
 */
function filterStockSheets() {
    const query = document.getElementById('search-stock').value.toLowerCase().trim();
    const rows = document.querySelectorAll('.stock-row');

    rows.forEach(row => {
        const name = row.getAttribute('data-name');
        if (name.includes(query)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

/**
 * Filter stock rows matching alert status tags
 */
function filterStatus(status) {
    const rows = document.querySelectorAll('.stock-row');
    
    // Clear search box
    document.getElementById('search-stock').value = '';

    rows.forEach(row => {
        const rowStatus = row.getAttribute('data-status');
        
        if (status === 'all') {
            row.style.display = '';
        } else if (rowStatus === status) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}
