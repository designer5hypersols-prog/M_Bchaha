/**
 * SaaS Udhaar Ledger Sheets Filtering Helper
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

/**
 * Filter ledger rows dynamically matching input text
 */
function filterLedgerSheet() {
    const query = document.getElementById('search-ledger').value.toLowerCase().trim();
    const rows = document.querySelectorAll('.ledger-row');

    rows.forEach(row => {
        const name = row.getAttribute('data-name');
        if (name.includes(query)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}
