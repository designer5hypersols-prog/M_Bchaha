/**
 * auth.js
 * Client-side validation and interactive feedback for login system.
 */

document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const submitBtn = document.getElementById('submitBtn');
    const btnText = submitBtn.querySelector('.btn-text');
    const spinner = document.getElementById('submitSpinner');

    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            // Prevent double submission
            if (submitBtn.disabled) {
                e.preventDefault();
                return;
            }

            // Visual loading state
            submitBtn.disabled = true;
            submitBtn.classList.add('btn-loading');
            btnText.textContent = 'Verifying credentials...';
            spinner.classList.remove('d-none');
            
            // Allow form to submit naturally
        });
    }
});
