/**
 * SaaS POS Purchase Stock Basket Engine
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

let purchaseCart = [];

/**
 * Filter product tiles dynamically by input query
 */
function filterProducts() {
    const query = document.getElementById('search-product').value.toLowerCase().trim();
    const tiles = document.querySelectorAll('.product-tile');

    tiles.forEach(tile => {
        const name = tile.getAttribute('data-name').toLowerCase();
        if (name.includes(query)) {
            tile.style.display = 'block';
        } else {
            tile.style.display = 'none';
        }
    });
}

/**
 * Add an item from a product tile to the replenishment basket
 */
function addToPurchaseCart(tile) {
    const id = parseInt(tile.getAttribute('data-id'));
    const name = tile.getAttribute('data-name');
    const price = parseFloat(tile.getAttribute('data-price'));
    
    // Default cost price: 70% of retail price
    const defaultCost = price * 0.70;

    // Check if product is already in the basket
    const existing = purchaseCart.find(item => item.id === id);

    if (existing) {
        existing.quantity++;
    } else {
        purchaseCart.push({
            id: id,
            name: name,
            cost: parseFloat(defaultCost.toFixed(2)),
            quantity: 1
        });
    }

    renderPurchaseCart();
}

/**
 * Update the quantity for a basket item
 */
function updatePurchaseQuantity(id, qty) {
    const item = purchaseCart.find(i => i.id === id);
    if (!item) return;

    qty = parseInt(qty);
    if (isNaN(qty) || qty < 1) {
        qty = 1;
    }

    item.quantity = qty;
    renderPurchaseCart();
}

/**
 * Update the cost price for a basket item
 */
function updatePurchaseCost(id, cost) {
    const item = purchaseCart.find(i => i.id === id);
    if (!item) return;

    cost = parseFloat(cost);
    if (isNaN(cost) || cost < 0) {
        cost = 0.00;
    }

    item.cost = cost;
    renderPurchaseCart();
}

/**
 * Drop an item from the basket
 */
function removeFromPurchaseCart(id) {
    purchaseCart = purchaseCart.filter(item => item.id !== id);
    renderPurchaseCart();
}

/**
 * Calculate totals and update the UI panel
 */
function calculatePurchaseTotals() {
    let totalCost = 0;
    purchaseCart.forEach(item => {
        totalCost += item.cost * item.quantity;
    });

    const paid = parseFloat(document.getElementById('paid-input').value) || 0;
    const due = Math.max(0, totalCost - paid);

    document.getElementById('summary-total').innerText = `Rs. ${totalCost.toFixed(2)}`;
    document.getElementById('summary-due').innerText = `Rs. ${due.toFixed(2)}`;
}

/**
 * Render basket table rows based on active array state
 */
function renderPurchaseCart() {
    const container = document.getElementById('purchase-cart-items');
    const emptyNotice = document.getElementById('cart-empty');
    
    container.innerHTML = '';

    if (purchaseCart.length === 0) {
        emptyNotice.style.display = 'block';
        calculatePurchaseTotals();
        return;
    }

    emptyNotice.style.display = 'none';

    purchaseCart.forEach(item => {
        const subtotal = item.cost * item.quantity;
        const tr = document.createElement('tr');
        
        tr.innerHTML = `
            <td style="padding: 10px 4px; font-weight:600; color: #fff;">${item.name}</td>
            <td style="padding: 10px 4px; text-align: right;">
                <input type="number" class="cost-input" value="${item.cost.toFixed(2)}" min="0" step="0.01" onchange="updatePurchaseCost(${item.id}, this.value)">
            </td>
            <td style="padding: 10px 4px; text-align: center;">
                <input type="number" class="qty-input" value="${item.quantity}" min="1" onchange="updatePurchaseQuantity(${item.id}, this.value)">
            </td>
            <td style="padding: 10px 4px; text-align: right; font-weight:bold;">Rs. ${subtotal.toFixed(2)}</td>
            <td style="padding: 10px 4px; text-align: center;">
                <button class="btn-remove" onclick="removeFromPurchaseCart(${item.id})">
                    <i class="bx bx-trash"></i>
                </button>
            </td>
        `;
        container.appendChild(tr);
    });

    calculatePurchaseTotals();
}

/**
 * Submit the transaction to the backend save_purchase.php controller
 */
function completeSaaSPurchase() {
    if (purchaseCart.length === 0) {
        alert("🛒 Cannot complete transaction: Basket is empty.");
        return;
    }

    const supplierName = document.getElementById('supplier_name').value.trim();
    const paid = parseFloat(document.getElementById('paid-input').value) || 0;

    if (supplierName === '') {
        alert("👤 Please specify a valid supplier/vendor name.");
        return;
    }

    const payload = {
        supplier_name: supplierName,
        paid: paid,
        items: purchaseCart.map(i => ({
            product_id: i.id,
            cost_price: i.cost,
            quantity: i.quantity
        }))
    };

    // Trigger secure AJAX transaction
    fetch('save_purchase.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Redirect to printing invoice layout
            window.location.href = `invoice.php?id=${data.purchase_id}`;
        } else {
            alert(`🚫 Transaction Rejected: ${data.message}`);
        }
    })
    .catch(error => {
        console.error('POS Procurement transaction error:', error);
        alert("🚫 Communication error with purchase services.");
    });
}
