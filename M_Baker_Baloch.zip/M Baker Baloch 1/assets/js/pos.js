/**
 * SaaS POS Basket Engine
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

let cart = [];

/**
 * Filter product tiles dynamically by input query
 */
function filterProducts() {
    const query = document.getElementById('search-product').value.toLowerCase().trim();
    const tiles = document.querySelectorAll('.product-tile');

    tiles.forEach(tile => {
        const name = tile.getAttribute('data-name').toLowerCase();
        if (name.includes(query)) {
            tile.style.display = 'block';
        } else {
            tile.style.display = 'none';
        }
    });
}

/**
 * Add an item from a product tile to the checkout basket
 */
function addToCart(tile) {
    const id = parseInt(tile.getAttribute('data-id'));
    const name = tile.getAttribute('data-name');
    const price = parseFloat(tile.getAttribute('data-price'));
    const stock = parseInt(tile.getAttribute('data-stock'));

    if (stock <= 0) {
        alert("🚫 Cannot add: Out of stock catalog level.");
        return;
    }

    // Check if product is already in the basket
    const existing = cart.find(item => item.id === id);

    if (existing) {
        if (existing.quantity >= stock) {
            alert(`🚫 Cannot add: Limit reached. Only ${stock} units are in stock.`);
            return;
        }
        existing.quantity++;
    } else {
        cart.push({
            id: id,
            name: name,
            price: price,
            stock: stock,
            quantity: 1
        });
    }

    renderCart();
}

/**
 * Update the quantity for a basket item
 */
function updateQuantity(id, qty) {
    const item = cart.find(i => i.id === id);
    if (!item) return;

    qty = parseInt(qty);
    if (isNaN(qty) || qty < 1) {
        qty = 1;
    }

    if (qty > item.stock) {
        alert(`🚫 Cannot set: Only ${item.stock} units are in stock.`);
        qty = item.stock;
    }

    item.quantity = qty;
    renderCart();
}

/**
 * Drop an item from the basket
 */
function removeFromCart(id) {
    cart = cart.filter(item => item.id !== id);
    renderCart();
}

/**
 * Calculate totals and update the UI panel
 */
function calculateCartTotals() {
    let subtotal = 0;
    cart.forEach(item => {
        subtotal += item.price * item.quantity;
    });

    const discount = parseFloat(document.getElementById('discount-input').value) || 0;
    const paid = parseFloat(document.getElementById('paid-input').value) || 0;

    const grandTotal = Math.max(0, subtotal - discount);
    const due = Math.max(0, grandTotal - paid);

    document.getElementById('summary-subtotal').innerText = `Rs. ${subtotal.toFixed(2)}`;
    document.getElementById('summary-grand-total').innerText = `Rs. ${grandTotal.toFixed(2)}`;
    document.getElementById('summary-due').innerText = `Rs. ${due.toFixed(2)}`;
}

/**
 * Render basket table rows based on active array state
 */
function renderCart() {
    const container = document.getElementById('cart-items');
    const emptyNotice = document.getElementById('cart-empty');
    
    container.innerHTML = '';

    if (cart.length === 0) {
        emptyNotice.style.display = 'block';
        calculateCartTotals();
        return;
    }

    emptyNotice.style.display = 'none';

    cart.forEach(item => {
        const subtotal = item.price * item.quantity;
        const tr = document.createElement('tr');
        
        tr.innerHTML = `
            <td style="padding: 10px 4px; font-weight:600; color: #fff;">${item.name}</td>
            <td style="padding: 10px 4px; text-align: right;">Rs. ${item.price.toFixed(2)}</td>
            <td style="padding: 10px 4px; text-align: center;">
                <input type="number" class="qty-input" value="${item.quantity}" min="1" max="${item.stock}" onchange="updateQuantity(${item.id}, this.value)">
            </td>
            <td style="padding: 10px 4px; text-align: right; font-weight:bold;">Rs. ${subtotal.toFixed(2)}</td>
            <td style="padding: 10px 4px; text-align: center;">
                <button class="btn-remove" onclick="removeFromCart(${item.id})">
                    <i class="bx bx-trash"></i>
                </button>
            </td>
        `;
        container.appendChild(tr);
    });

    calculateCartTotals();
}

/**
 * Submit the transaction to the backend save_sale.php controller
 */
function completeSaaSSale() {
    if (cart.length === 0) {
        alert("🛒 Cannot complete transaction: Basket is empty.");
        return;
    }

    const customerName = document.getElementById('customer_name').value.trim();
    const discount = parseFloat(document.getElementById('discount-input').value) || 0;
    const paid = parseFloat(document.getElementById('paid-input').value) || 0;

    if (customerName === '') {
        alert("👤 Please specify a valid customer profile.");
        return;
    }

    const payload = {
        customer_name: customerName,
        discount: discount,
        paid: paid,
        items: cart.map(i => ({
            product_id: i.id,
            price: i.price,
            quantity: i.quantity
        }))
    };

    // Trigger secure AJAX transaction
    fetch('save_sale.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Redirect to printing invoice layout
            window.location.href = `invoice.php?id=${data.sale_id}`;
        } else {
            alert(`🚫 Transaction Rejected: ${data.message}`);
        }
    })
    .catch(error => {
        console.error('POS Complete transaction error:', error);
        alert("🚫 Communication error with billing services.");
    });
}
