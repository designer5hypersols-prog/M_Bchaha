document.addEventListener('DOMContentLoaded', function () {
    const wrapper = document.getElementById("wrapper");
    const toggleButton = document.getElementById("menu-toggle");
    const sidebar = document.getElementById("sidebar-wrapper");

    if (!wrapper || !toggleButton) return;

    // Toggle sidebar
    toggleButton.addEventListener('click', function () {
        wrapper.classList.toggle("toggled");
    });

    // Mobile: close sidebar when clicking overlay
    wrapper.addEventListener('click', function (e) {
        const isMobile = window.innerWidth < 768;
        if (isMobile && wrapper.classList.contains('toggled')) {
            // If clicked outside sidebar
            if (!sidebar.contains(e.target) && e.target !== toggleButton) {
                wrapper.classList.remove('toggled');
            }
        }
    });

    // Highlight active menu link
    const currentPath = window.location.pathname;
    document.querySelectorAll('#sidebar-wrapper .list-group-item').forEach(link => {
        if (link.getAttribute('href') && currentPath.includes(link.getAttribute('href').replace('../', ''))) {
            link.classList.add('active-link');
        }
    });
});
