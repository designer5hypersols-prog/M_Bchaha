<?php
/**
 * Product Subsystem - Add Product Processor
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = (new Database())->connect();

    $sku = sanitize($_POST['sku'] ?? '');
    $barcode = sanitize($_POST['barcode'] ?? '');
    $name = sanitize($_POST['name'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0);
    $brand = sanitize($_POST['brand'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    
    $purchase_price = (float)($_POST['purchase_price'] ?? 0);
    $sell_price = (float)($_POST['sell_price'] ?? 0);
    $stock_qty = (int)($_POST['stock_qty'] ?? 0);
    $min_stock_qty = (int)($_POST['min_stock_qty'] ?? 5);
    $unit = sanitize($_POST['unit'] ?? 'pcs');
    $supplier_name = sanitize($_POST['supplier_name'] ?? '');

    // 1. Validations
    if (empty($sku) || empty($name) || $category_id <= 0 || $purchase_price <= 0 || $sell_price <= 0) {
        header("Location: products.php?error=" . urlencode("Please fill in SKU, Name, Category, and positive Prices."));
        exit;
    }

    try {
        // Check if SKU already exists
        $chk = $db->prepare("SELECT COUNT(*) FROM products WHERE sku = :sku");
        $chk->execute(['sku' => $sku]);
        if ($chk->fetchColumn() > 0) {
            header("Location: products.php?error=" . urlencode("A product with SKU '$sku' already exists."));
            exit;
        }

        // 2. Handle File Upload (Image)
        $image_path = null;
        if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            $file_extension = strtolower(pathinfo($_FILES['product_image']['name'], PATHINFO_EXTENSION));
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'webp'];

            if (in_array($file_extension, $allowed_extensions)) {
                $new_filename = uniqid('prod_', true) . '.' . $file_extension;
                $target_file = $upload_dir . $new_filename;

                if (move_uploaded_file($_FILES['product_image']['tmp_name'], $target_file)) {
                    $image_path = $target_file;
                }
            }
        }

        $branch_id = (int)($_SESSION['branch_id'] ?? 1);

        // 3. Database prepared statement insert
        $ins = $db->prepare("INSERT INTO products (branch_id, sku, barcode, name, category_id, brand, purchase_price, sell_price, stock_qty, min_stock_qty, unit, description, image_path, supplier_name, status) VALUES (:branch_id, :sku, :barcode, :name, :category_id, :brand, :purchase, :sell, :stock, :min_stock, :unit, :desc, :image_path, :supplier_name, 'ACTIVE')");
        
        $ins->execute([
            'branch_id' => $branch_id,
            'sku' => $sku,
            'barcode' => $barcode,
            'name' => $name,
            'category_id' => $category_id,
            'brand' => $brand,
            'purchase' => $purchase_price,
            'sell' => $sell_price,
            'stock' => $stock_qty,
            'min_stock' => $min_stock_qty,
            'unit' => $unit,
            'desc' => $description,
            'image_path' => $image_path,
            'supplier_name' => $supplier_name
        ]);

        header("Location: products.php?success=" . urlencode("Product '$name' added successfully."));
        exit;

    } catch (PDOException $e) {
        header("Location: products.php?error=" . urlencode("Database insert failure: " . $e->getMessage()));
        exit;
    }
} else {
    header("Location: products.php");
    exit;
}
