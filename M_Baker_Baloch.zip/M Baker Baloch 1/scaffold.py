import os

# Project Root Directory
ROOT = r"C:\Users\Designer Hypersols\Desktop\M Baker Baloch 1"

directories = [
    "public",
    "config",
    "core",
    "modules/dashboard",
    "modules/products",
    "modules/sales",
    "modules/purchases",
    "modules/stock",
    "modules/ledger",
    "modules/accounting",
    "modules/reports",
    "modules/ai",
    "modules/settings",
    "assets/css",
    "assets/js",
    "assets/images",
    "includes",
    "storage/cache",
    "storage/backups",
    "logs",
    "uploads/products"
]

files = {}

files["public/.htaccess"] = """Options -Indexes
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php?route=$1 [L,QSA]
"""

files["public/index.php"] = """<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../core/Auth.php';

$route = $_GET['route'] ?? 'dashboard';

// Check Authentication
if (!Auth::check() && $route !== 'login') {
    header('Location: login.php');
    exit;
}

if ($route === 'dashboard') {
    header('Location: ../modules/dashboard/index.php');
    exit;
}
"""

files["public/login.php"] = """<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../core/Session.php';

if (Auth::check()) {
    header('Location: ../modules/dashboard/index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (Auth::attempt($email, $password)) {
        header('Location: ../modules/dashboard/index.php');
        exit;
    } else {
        $error = "Invalid credentials!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - SaaS ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light d-flex align-items-center" style="height: 100vh;">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card shadow border-0 rounded-4 p-4">
                <h3 class="text-center mb-4">ERP SaaS Login</h3>
                <?php if($error): ?>
                    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                <?php endif; ?>
                <form method="POST">
                    <div class="mb-3">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-4">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <button class="btn btn-primary w-100 py-2">Sign In</button>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>
"""

files["public/logout.php"] = """<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../core/Auth.php';

Auth::logout();
header('Location: login.php');
exit;
"""

files["config/config.php"] = """<?php
define('APP_NAME', 'M.BAKAR BALOCH ERP SaaS');
define('APP_URL', 'http://localhost');
define('DB_HOST', 'localhost');
define('DB_NAME', 'mbakar_baloch_erp');
define('DB_USER', 'root');
define('DB_PASS', '');
"""

files["config/database.php"] = """<?php
require_once __DIR__ . '/config.php';

class Database {
    private static $instance = null;
    private $conn;

    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            $this->conn = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die("Database Connection Error: " . $e->getMessage());
        }
    }

    public static function getInstance() {
        if (!self::$instance) {
            self::$instance = new Database();
        }
        return self::$instance->conn;
    }
}
"""

files["core/Auth.php"] = """<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../config/database.php';

class Auth {
    public static function attempt($email, $password) {
        $db = Database::getInstance();
        $stmt = $db->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['tenant_id'] = $user['tenant_id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['name'];
            return true;
        }
        return false;
    }

    public static function check() {
        return isset($_SESSION['user_id']);
    }

    public static function logout() {
        session_destroy();
    }
    
    public static function tenantId() {
        return $_SESSION['tenant_id'] ?? null;
    }
}
"""

files["core/Helper.php"] = """<?php
class Helper {
    public static function sanitize($input) {
        return htmlspecialchars(strip_tags(trim($input)));
    }

    public static function formatCurrency($amount) {
        return "Rs. " . number_format($amount, 2);
    }
}
"""

files["core/Session.php"] = """<?php
class Session {
    public static function setFlash($key, $message) {
        $_SESSION['flash'][$key] = $message;
    }

    public static function getFlash($key) {
        if (isset($_SESSION['flash'][$key])) {
            $msg = $_SESSION['flash'][$key];
            unset($_SESSION['flash'][$key]);
            return $msg;
        }
        return null;
    }
}
"""

files["includes/header.php"] = """<?php
require_once __DIR__ . '/../core/Auth.php';
if (!Auth::check()) { header('Location: /public/login.php'); exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= APP_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
<div class="d-flex" id="wrapper">
    <!-- Sidebar -->
    <?php include 'sidebar.php'; ?>
    
    <!-- Page Content -->
    <div id="page-content-wrapper" class="w-100 bg-light">
        <?php include 'navbar.php'; ?>
        <div class="container-fluid p-4">
"""

files["includes/footer.php"] = """        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="../../assets/js/app.js"></script>
</body>
</html>
"""

files["includes/sidebar.php"] = """<div class="bg-dark border-right text-white p-3" id="sidebar-wrapper" style="width: 250px; min-height: 100vh;">
    <div class="sidebar-heading fw-bold fs-5 mb-4 text-center">MB ERP SaaS</div>
    <div class="list-group list-group-flush">
        <a href="../dashboard/index.php" class="list-group-item list-group-item-action bg-dark text-white"><i class='bx bx-grid-alt'></i> Dashboard</a>
        <a href="../products/index.php" class="list-group-item list-group-item-action bg-dark text-white"><i class='bx bx-box'></i> Products</a>
        <a href="../sales/pos.php" class="list-group-item list-group-item-action bg-dark text-white"><i class='bx bx-receipt'></i> POS Sales</a>
        <a href="../purchases/index.php" class="list-group-item list-group-item-action bg-dark text-white"><i class='bx bx-cart'></i> Purchases</a>
        <a href="../stock/index.php" class="list-group-item list-group-item-action bg-dark text-white"><i class='bx bx-bar-chart-alt-2'></i> Stock</a>
        <a href="../ledger/index.php" class="list-group-item list-group-item-action bg-dark text-white"><i class='bx bx-book-content'></i> Ledger</a>
        <a href="../accounting/index.php" class="list-group-item list-group-item-action bg-dark text-white"><i class='bx bx-calculator'></i> Accounting</a>
        <a href="../reports/index.php" class="list-group-item list-group-item-action bg-dark text-white"><i class='bx bx-line-chart'></i> Reports</a>
    </div>
</div>
"""

files["includes/navbar.php"] = """<nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom shadow-sm px-4 py-3">
    <div class="container-fluid">
        <button class="btn btn-outline-secondary" id="menu-toggle"><i class='bx bx-menu'></i></button>
        <div class="ms-auto d-flex align-items-center">
            <span class="me-3 fw-bold text-secondary">Tenant #<?= Auth::tenantId() ?></span>
            <div class="dropdown">
                <a class="nav-link dropdown-toggle fw-bold" href="#" role="button" data-bs-toggle="dropdown">
                    <?= htmlspecialchars($_SESSION['name']) ?>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="../../public/logout.php"><i class='bx bx-log-out'></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>
"""

files["modules/dashboard/index.php"] = """<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/database.php';

$db = Database::getInstance();
$tenant_id = Auth::tenantId();

// Stats
$productsCount = $db->prepare("SELECT COUNT(*) FROM products WHERE tenant_id = ?");
$productsCount->execute([$tenant_id]);
$total_products = $productsCount->fetchColumn();

$salesSum = $db->prepare("SELECT SUM(grand_total) FROM sales WHERE tenant_id = ?");
$salesSum->execute([$tenant_id]);
$total_sales = $salesSum->fetchColumn() ?: 0;
?>
<h2 class="mb-4">Overview</h2>
<div class="row">
    <div class="col-md-3">
        <div class="card shadow-sm text-center p-4 border-0 border-start border-4 border-primary">
            <h5 class="text-secondary">Total Products</h5>
            <h3><?= $total_products ?></h3>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card shadow-sm text-center p-4 border-0 border-start border-4 border-success">
            <h5 class="text-secondary">Total Sales</h5>
            <h3>Rs. <?= number_format($total_sales, 2) ?></h3>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
"""

files["modules/products/index.php"] = """<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../core/Session.php';

$db = Database::getInstance();
$tenant_id = Auth::tenantId();

if (isset($_GET['delete'])) {
    $stmt = $db->prepare("DELETE FROM products WHERE id = ? AND tenant_id = ?");
    $stmt->execute([$_GET['delete'], $tenant_id]);
    Session::setFlash('success', 'Product deleted.');
    header('Location: index.php');
    exit;
}

$stmt = $db->prepare("SELECT * FROM products WHERE tenant_id = ? ORDER BY id DESC");
$stmt->execute([$tenant_id]);
$products = $stmt->fetchAll();
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Products</h2>
    <a href="add.php" class="btn btn-primary"><i class='bx bx-plus'></i> Add Product</a>
</div>
<?php if($msg = Session::getFlash('success')): ?>
    <div class="alert alert-success"><?= $msg ?></div>
<?php endif; ?>
<div class="card shadow-sm border-0">
    <div class="card-body">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th><th>Name</th><th>Price</th><th>Stock</th><th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($products as $p): ?>
                <tr>
                    <td><?= $p['id'] ?></td>
                    <td><?= htmlspecialchars($p['name']) ?></td>
                    <td>Rs. <?= number_format($p['price'], 2) ?></td>
                    <td><?= $p['stock'] ?></td>
                    <td>
                        <a href="?delete=<?= $p['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?');"><i class='bx bx-trash'></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
"""

files["modules/products/add.php"] = """<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../core/Session.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = Database::getInstance();
    $stmt = $db->prepare("INSERT INTO products (tenant_id, name, price, stock, min_stock_level) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([
        Auth::tenantId(),
        $_POST['name'],
        $_POST['price'],
        $_POST['stock'],
        $_POST['min_stock']
    ]);
    Session::setFlash('success', 'Product added successfully.');
    header('Location: index.php');
    exit;
}
?>
<h2>Add Product</h2>
<div class="card shadow-sm border-0 p-4 mt-3" style="max-width: 600px;">
    <form method="POST">
        <div class="mb-3">
            <label>Product Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Price</label>
            <input type="number" step="0.01" name="price" class="form-control" required>
        </div>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label>Initial Stock</label>
                <input type="number" name="stock" class="form-control" required>
            </div>
            <div class="col-md-6 mb-3">
                <label>Min Stock Level</label>
                <input type="number" name="min_stock" class="form-control" value="5" required>
            </div>
        </div>
        <button class="btn btn-primary"><i class='bx bx-save'></i> Save Product</button>
    </form>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
"""

files["modules/sales/pos.php"] = """<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/database.php';

$db = Database::getInstance();
$tenant_id = Auth::tenantId();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'checkout') {
    // AJAX Checkout Logic
    $cart = json_decode($_POST['cart'], true);
    $total = 0;
    foreach($cart as $item) { $total += $item['price'] * $item['qty']; }
    
    $stmt = $db->prepare("INSERT INTO sales (tenant_id, invoice_no, customer_name, total, grand_total, paid) VALUES (?, ?, ?, ?, ?, ?)");
    $invoice_no = 'INV-' . time();
    $stmt->execute([$tenant_id, $invoice_no, 'Walk-in', $total, $total, $total]);
    $sale_id = $db->lastInsertId();

    $itemStmt = $db->prepare("INSERT INTO sale_items (sale_id, product_id, product_name, price, quantity, subtotal) VALUES (?, ?, ?, ?, ?, ?)");
    $stockStmt = $db->prepare("UPDATE products SET stock = stock - ? WHERE id = ? AND tenant_id = ?");

    foreach($cart as $item) {
        $sub = $item['price'] * $item['qty'];
        $itemStmt->execute([$sale_id, $item['id'], $item['name'], $item['price'], $item['qty'], $sub]);
        $stockStmt->execute([$item['qty'], $item['id'], $tenant_id]);
    }
    
    echo json_encode(['success' => true, 'invoice' => $invoice_no]);
    exit;
}

$stmt = $db->prepare("SELECT * FROM products WHERE tenant_id = ? AND stock > 0");
$stmt->execute([$tenant_id]);
$products = $stmt->fetchAll();
?>
<div class="row">
    <div class="col-md-8">
        <h4>Products</h4>
        <div class="row">
            <?php foreach($products as $p): ?>
            <div class="col-md-3 mb-3">
                <div class="card p-3 shadow-sm border-0 cursor-pointer" onclick="addToCart(<?= $p['id'] ?>, '<?= addslashes($p['name']) ?>', <?= $p['price'] ?>)">
                    <h6 class="mb-1"><?= htmlspecialchars($p['name']) ?></h6>
                    <div class="text-success fw-bold">Rs. <?= $p['price'] ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm border-0 p-3 bg-white h-100">
            <h4>Cart</h4>
            <div id="cart-items" class="flex-grow-1" style="min-height:300px; overflow-y:auto;"></div>
            <div class="border-top pt-3 mt-3">
                <div class="d-flex justify-content-between fs-5 fw-bold">
                    <span>Total:</span>
                    <span id="cart-total">Rs. 0.00</span>
                </div>
                <button class="btn btn-success w-100 mt-3" onclick="checkout()">Complete Sale</button>
            </div>
        </div>
    </div>
</div>
<script>
let cart = [];
function addToCart(id, name, price) {
    let item = cart.find(i => i.id === id);
    if(item) { item.qty++; } else { cart.push({id, name, price, qty:1}); }
    renderCart();
}
function renderCart() {
    let html = ''; let total = 0;
    cart.forEach((i, idx) => {
        let sub = i.price * i.qty; total += sub;
        html += `<div class="d-flex justify-content-between mb-2 pb-2 border-bottom">
            <div>${i.name} <br><small class="text-muted">${i.qty} x Rs. ${i.price}</small></div>
            <div class="fw-bold">Rs. ${sub.toFixed(2)}</div>
        </div>`;
    });
    document.getElementById('cart-items').innerHTML = html;
    document.getElementById('cart-total').innerText = 'Rs. ' + total.toFixed(2);
}
function checkout() {
    if(cart.length === 0) return alert('Cart is empty!');
    let formData = new FormData();
    formData.append('action', 'checkout');
    formData.append('cart', JSON.stringify(cart));
    fetch('pos.php', { method: 'POST', body: formData })
    .then(r => r.json())
    .then(data => {
        if(data.success) {
            alert('Sale Completed! Invoice: ' + data.invoice);
            cart = []; renderCart(); location.reload();
        }
    });
}
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
"""

files["assets/css/style.css"] = """
body { font-family: 'Inter', 'Segoe UI', sans-serif; background-color: #f8fafc; }
#wrapper { overflow-x: hidden; }
#sidebar-wrapper { transition: margin .25s ease-out; background: #0f172a !important; }
.list-group-item { background: transparent !important; border: none; padding: 12px 20px; font-weight: 500; transition: 0.2s; color: #cbd5e1 !important;}
.list-group-item:hover { background: rgba(255,255,255,0.05) !important; color: #fff !important; padding-left: 25px;}
.cursor-pointer { cursor: pointer; }
.cursor-pointer:hover { transform: translateY(-2px); transition: 0.2s; box-shadow: 0 4px 12px rgba(0,0,0,0.1) !important;}
"""

files["database/schema.sql"] = """
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','manager','cashier') DEFAULT 'admin',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO `users` (`id`, `tenant_id`, `name`, `email`, `password`, `role`) VALUES
(1, 1, 'Super Admin', 'admin@erp.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'); 
-- password is 'password'

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `min_stock_level` int(11) DEFAULT 5,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `invoice_no` varchar(50) NOT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `total` decimal(10,2) NOT NULL,
  `grand_total` decimal(10,2) NOT NULL,
  `paid` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `sale_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
"""

files["modules/purchases/index.php"] = """<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/header.php';
?>
<h2>Purchases Module</h2>
<p>Supplier purchases and stock receiving operations will be managed here.</p>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
"""

files["modules/stock/index.php"] = """<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/header.php';
?>
<h2>Stock Management</h2>
<p>Stock adjustments, low stock alerts, and history tracking.</p>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
"""

files["modules/ledger/index.php"] = """<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/header.php';
?>
<h2>Udhaar Ledger</h2>
<p>Customer and Supplier dual ledger system.</p>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
"""

files["modules/accounting/index.php"] = """<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/header.php';
?>
<h2>General Accounting</h2>
<p>Chart of Accounts, Journal Entries, Balance Sheets.</p>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
"""

files["modules/reports/index.php"] = """<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/header.php';
?>
<h2>Reports</h2>
<p>Analytics, BI data, and PDF exports.</p>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
"""

# Script Logic
for d in directories:
    path = os.path.join(ROOT, d)
    os.makedirs(path, exist_ok=True)

for filepath, content in files.items():
    full_path = os.path.join(ROOT, filepath.replace('/', os.sep))
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, "w", encoding="utf-8") as f:
        f.write(content)

print("Scaffolding complete!")
