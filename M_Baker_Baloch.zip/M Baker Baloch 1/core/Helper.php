<?php
class Helper {
    public static function sanitize($input) {
        return htmlspecialchars(strip_tags(trim($input)));
    }

    public static function formatCurrency($amount) {
        return "Rs. " . number_format($amount, 2);
    }
}
