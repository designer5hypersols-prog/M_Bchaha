<?php
/**
 * Core Authentication Engine
 * Handles secure user sessions, CSRF, and multi-tenant isolation.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

class Auth {
    
    /**
     * Attempt to log in a user securely.
     */
    public static function attempt($email, $password) {
        $db = Database::getInstance();
        
        $stmt = $db->prepare("SELECT * FROM users WHERE email = :email AND status = 'active' LIMIT 1");
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            // Protect against session fixation
            session_regenerate_id(true);
            
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['tenant_id'] = $user['tenant_id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['email'] = $user['email'];
            
            // Update last login timestamp
            $update = $db->prepare("UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = :id");
            $update->execute(['id' => $user['id']]);
            
            return true;
        }
        
        return false;
    }

    /**
     * Check if a user is currently authenticated.
     */
    public static function check() {
        return isset($_SESSION['user_id']) && !empty($_SESSION['tenant_id']);
    }

    /**
     * Safely destroy the user session.
     */
    public static function logout() {
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
    }
    
    /**
     * Get the active tenant ID for data isolation.
     */
    public static function tenantId() {
        return $_SESSION['tenant_id'] ?? null;
    }

    /**
     * Generate CSRF Token for forms.
     */
    public static function csrfToken() {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    /**
     * Verify submitted CSRF Token.
     */
    public static function verifyCsrf($token) {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
}
