<?php
/**
 * Mobile Barcode Scanner - REST API Stock Synchronizer (Module 5)
 * Shop Name: M.BAKAR BALOCH
 */

require_once '../sync_engine.php';

$engine = new SyncEngine();
$user = $engine->authorizeApiRequest();
$db = $engine->getDb();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $engine->respondError("Invalid request method. Only POST is allowed.", 405);
}

// Parse input parameters
$raw_input = file_get_contents('php://input');
$data = json_decode($raw_input, true);

$product_id = (int)($data['product_id'] ?? 0);
$qty_change = (int)($data['qty_change'] ?? 0);
$sync_type = sanitize($data['type'] ?? 'ADJUST'); // IN, OUT, ADJUST

if ($product_id <= 0 || $qty_change == 0) {
    $engine->respondError("Please supply valid product_id and non-zero qty_change parameters.");
}

try {
    $db->beginTransaction();

    // Verify product exists and get name
    $stmt = $db->prepare("SELECT name, stock_qty FROM products WHERE id = :id LIMIT 1");
    $stmt->execute(['id' => $product_id]);
    $prod = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$prod) {
        $engine->respondError("Product not found with ID: $product_id", 404);
    }

    // Safety checks for negative stock
    $new_qty = $prod['stock_qty'] + $qty_change;
    if ($new_qty < 0) {
        $engine->respondError("Inventory bounds error: Stock cannot drop below zero. Current stock: " . $prod['stock_qty']);
    }

    // Update Product Stock Qty
    $upd = $db->prepare("UPDATE products SET stock_qty = :new_qty WHERE id = :id");
    $upd->execute(['new_qty' => $new_qty, 'id' => $product_id]);

    // Record Stock History Log
    $log = $db->prepare("INSERT INTO stock_history (product_id, qty_change, type, description, user_id) 
                         VALUES (:p_id, :change, :type, :desc, :u_id)");
    $log->execute([
        'p_id' => $product_id,
        'change' => $qty_change,
        'type' => $sync_type,
        'desc' => "Mobile Barcode Scanner sync update",
        'u_id' => $user['id']
    ]);

    $db->commit();
    $engine->respondSuccess([
        'product_id' => $product_id,
        'product_name' => $prod['name'],
        'previous_qty' => (int)$prod['stock_qty'],
        'updated_qty' => $new_qty
    ], "Inventory stock parameters synced successfully over Mobile API.");

} catch (PDOException $e) {
    if ($db->inTransaction()) $db->rollBack();
    $engine->respondError("Stock synchronization failed: " . $e->getMessage(), 500);
}
