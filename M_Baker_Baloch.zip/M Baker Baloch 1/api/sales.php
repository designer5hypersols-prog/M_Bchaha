<?php
/**
 * Cloud-Based Multi-Device Sync Subsystem - REST API Sales Endpoint (Module 3)
 * Shop Name: M.BAKAR BALOCH
 */

require_once '../sync_engine.php';

$engine = new SyncEngine();
$user = $engine->authorizeApiRequest();
$db = $engine->getDb();

$method = $_SERVER['REQUEST_METHOD'];

// ==========================================
// ROUTE A: GET - SALES HISTORICAL LOGS
// ==========================================
if ($method === 'GET') {
    try {
        $stmt = $db->query("SELECT s.*, c.name as customer_name 
                            FROM sales s 
                            LEFT JOIN customers c ON s.customer_id = c.id 
                            ORDER BY s.id DESC LIMIT 50");
        $sales = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $engine->respondSuccess($sales, "Sales invoices history fetched successfully.");
    } catch (PDOException $e) {
        $engine->respondError("Sales fetch failed: " . $e->getMessage(), 500);
    }
}

// ==========================================
// ROUTE B: POST - CART INVOICE CHECKOUT (WRITE)
// ==========================================
if ($method === 'POST') {
    $raw_input = file_get_contents('php://input');
    $data = json_decode($raw_input, true);

    $customer_id = (int)($data['customer_id'] ?? 0); // 0 means walk-in customer
    $items = $data['items'] ?? []; // Array of: product_id, qty, sell_price, purchase_price, discount
    $total = (float)($data['total_amount'] ?? 0.00);
    $discount = (float)($data['discount'] ?? 0.00);
    $tax = (float)($data['tax_amount'] ?? 0.00);
    $payable = (float)($data['payable_amount'] ?? 0.00);
    $paid = (float)($data['paid_amount'] ?? 0.00);
    $pay_method = sanitize($data['payment_method'] ?? 'CASH');

    if (empty($items)) {
        $engine->respondError("Checkout cart is empty. Please add items.");
    }

    try {
        $db->beginTransaction();

        // 1. AUTO GENERATE UNIQUE INVOICE NUMBER SECURELY
        $invoice_no = "INV-" . strtoupper(bin2hex(random_bytes(3))) . "-" . date('His');

        // Verify duplicate invoice number to avoid conflicts
        $dup_chk = $db->prepare("SELECT COUNT(*) FROM sales WHERE invoice_no = :inv");
        $dup_chk->execute(['inv' => $invoice_no]);
        if ($dup_chk->fetchColumn() > 0) {
            $invoice_no = "INV-" . strtoupper(bin2hex(random_bytes(3))) . "-" . (date('His') + 1);
        }

        // Calculate credit balance
        $credit_due = $payable - $paid;
        $pay_status = 'PAID';
        if ($credit_due > 0) {
            $pay_status = ($paid > 0) ? 'PARTIAL' : 'UNPAID';
        }

        $branch_id = (int)($_SESSION['branch_id'] ?? 1);

        // 2. INSERT SALES INVOICE ROW
        $ins_sale = $db->prepare("INSERT INTO sales (branch_id, invoice_no, customer_id, sale_date, total_amount, discount_amount, tax_amount, payable_amount, paid_amount, payment_method, payment_status, user_id) 
                                  VALUES (:branch_id, :inv, :c_id, CURRENT_DATE(), :tot, :disc, :tax, :pay, :paid, :method, :status, :u_id)");
        $ins_sale->execute([
            'branch_id' => $branch_id,
            'inv' => $invoice_no,
            'c_id' => ($customer_id > 0) ? $customer_id : null,
            'tot' => $total,
            'disc' => $discount,
            'tax' => $tax,
            'pay' => $payable,
            'paid' => $paid,
            'method' => $pay_method,
            'status' => $pay_status,
            'u_id' => $user['id']
        ]);
        $sale_id = $db->lastInsertId();

        // 3. PROCESS ITEMS LOOP
        $ins_item = $db->prepare("INSERT INTO sale_items (sale_id, product_id, qty, purchase_price, sell_price, discount_amount, total_price) 
                                  VALUES (:s_id, :p_id, :qty, :buy, :sell, :disc, :tot)");
        $dec_stock = $db->prepare("UPDATE products SET stock_qty = stock_qty - :qty WHERE id = :id");
        
        // Log Stock History
        $log_stock = $db->prepare("INSERT INTO stock_history (product_id, qty_change, type, description, user_id) 
                                   VALUES (:p_id, :qty, 'OUT', :desc, :u_id)");

        $total_cogs = 0.00;
        foreach ($items as $item) {
            $pid = (int)$item['product_id'];
            $qty = (int)$item['qty'];
            $sell = (float)$item['sell_price'];
            $buy = (float)$item['purchase_price'];
            $item_disc = (float)($item['discount'] ?? 0.00);
            $item_total = ($sell * $qty) - $item_disc;

            // Accumulate COGS
            $total_cogs += ($buy * $qty);

            // Save item
            $ins_item->execute([
                's_id' => $sale_id,
                'p_id' => $pid,
                'qty' => $qty,
                'buy' => $buy,
                'sell' => $sell,
                'disc' => $item_disc,
                'tot' => $item_total
            ]);

            // Decrement Stock safely
            $dec_stock->execute(['qty' => $qty, 'id' => $pid]);

            // Log Warehouse movement
            $log_stock->execute([
                'p_id' => $pid,
                'qty' => -$qty,
                'desc' => "POS Sales Invoice #$invoice_no over REST API",
                'u_id' => $user['id']
            ]);
        }

        // 4. UPDATE CLIENT DEBT BALANCE IF CREDIT Checked out
        if ($customer_id > 0 && $credit_due > 0) {
            $upd_c = $db->prepare("UPDATE customers SET balance = balance + :due WHERE id = :id");
            $upd_c->execute(['due' => $credit_due, 'id' => $customer_id]);

            // Save ledger statement transaction
            $c_ledg = $db->prepare("INSERT INTO customer_payments (customer_id, payment_date, amount, payment_method, type, notes) 
                                    VALUES (:c_id, CURRENT_DATE(), :due, 'CREDIT_DUE', 'DEBIT', :notes)");
            $c_ledg->execute([
                'c_id' => $customer_id,
                'due' => $credit_due,
                'notes' => "Unpaid balance for Invoice #$invoice_no over REST API"
            ]);
        }

        $db->commit();

        // 4b. AUTO POST DOUBLE ENTRY ACCOUNTING JOURNAL
        try {
            require_once '../accounting_engine.php';
            $acct = new AccountingEngine($db);
            $acct->postSalesInvoiceEntry($invoice_no, $payable, $total_cogs, $paid);
        } catch (Exception $e) {}

        // 5. TRIGGER AUTOMATED NOTIFICATION SERVICE IF APPLICABLE
        $phone = '';
        $customer_name = 'Walk-in Customer';
        if ($customer_id > 0) {
            try {
                $stmt_c = $db->prepare("SELECT name, phone FROM customers WHERE id = :id LIMIT 1");
                $stmt_c->execute(['id' => $customer_id]);
                $c_info = $stmt_c->fetch(PDO::FETCH_ASSOC);
                if ($c_info) {
                    $customer_name = $c_info['name'];
                    $phone = $c_info['phone'];
                }
            } catch (PDOException $ex) {}
        }

        if (!empty($phone)) {
            try {
                require_once '../whatsapp_service.php';
                $whatsapp = new WhatsAppService($db);

                // Fetch SALE_INVOICE message template
                $t_stmt = $db->prepare("SELECT message_body FROM templates WHERE template_key = 'SALE_INVOICE' LIMIT 1");
                $t_stmt->execute();
                $template = $t_stmt->fetchColumn();
                if (!$template) {
                    $template = "Dear {{customer_name}}, thank you for shopping at M.BAKAR BALOCH! Your Invoice #{{invoice_no}} total is Rs. {{payable_amount}}.";
                }

                $body = str_replace(
                    ['{{customer_name}}', '{{invoice_no}}', '{{payable_amount}}'],
                    [$customer_name, $invoice_no, number_format($payable, 2)],
                    $template
                );

                $whatsapp->sendWhatsAppMessage($customer_id, $phone, $body);
            } catch (Exception $ex) {}
        }

        $engine->respondSuccess([
            'invoice_no' => $invoice_no,
            'sale_id' => $sale_id
        ], "Sales invoice #$invoice_no checked out and synced successfully across all devices.");

    } catch (PDOException $e) {
        if ($db->inTransaction()) $db->rollBack();
        $engine->respondError("POS Checkout transaction failed: " . $e->getMessage(), 500);
    }
}
