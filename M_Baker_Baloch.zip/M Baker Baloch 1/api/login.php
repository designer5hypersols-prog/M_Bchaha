<?php
/**
 * Cloud-Based Multi-Device Sync Subsystem - REST API Login Endpoint (Module 1)
 * Shop Name: M.BAKAR BALOCH
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../auth_token_system.php';

$db = (new Database())->connect();
$auth = new AuthTokenSystem($db);

// Parse JSON input
$raw_input = file_get_contents('php://input');
$input_data = json_decode($raw_input, true);

$username = sanitize($input_data['username'] ?? $_POST['username'] ?? '');
$password = $input_data['password'] ?? $_POST['password'] ?? '';
$device_name = sanitize($input_data['device_name'] ?? $_POST['device_name'] ?? 'Web Device');

if (empty($username) || empty($password)) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'Please enter username and password fields.'
    ]);
    exit;
}

try {
    // Validate credentials safely
    $stmt = $db->prepare("SELECT * FROM users WHERE username = :user LIMIT 1");
    $stmt->execute(['user' => $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || !password_verify($password, $user['password'])) {
        http_response_code(401);
        echo json_encode([
            'status' => 'error',
            'message' => 'Invalid username or password credentials.'
        ]);
        exit;
    }

    if ($user['status'] !== 'ACTIVE') {
        http_response_code(403);
        echo json_encode([
            'status' => 'error',
            'message' => 'Your cashier profile account has been suspended.'
        ]);
        exit;
    }

    // Issue Token
    $token = $auth->issueToken($user['id']);

    if (!$token) {
        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => 'Token compilation failed.'
        ]);
        exit;
    }

    // Track/Register Device Session
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'RESTClient';
    
    // Revoke previous ACTIVE session tokens to maintain single session if desired (or allow concurrent device syncs)
    $reg = $db->prepare("INSERT INTO device_sessions (user_id, device_name, ip_address, user_agent, session_token, status) 
                         VALUES (:u_id, :device, :ip, :ua, :token, 'ACTIVE')
                         ON DUPLICATE KEY UPDATE last_active = NOW(), status='ACTIVE'");
    $reg->execute([
        'u_id' => $user['id'],
        'device' => $device_name,
        'ip' => $ip,
        'ua' => $ua,
        'token' => $token
    ]);

    // Success response
    http_response_code(200);
    echo json_encode([
        'status' => 'success',
        'message' => 'Multi-device synced login successful.',
        'data' => [
            'api_token' => $token,
            'user' => [
                'id' => (int)$user['id'],
                'username' => $user['username'],
                'fullname' => $user['name'],
                'role' => $user['role']
            ]
        ]
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Database aggregate error: ' . $e->getMessage()
    ]);
}
