<?php
/**
 * Mobile Barcode Scanner - REST API Barcode Lookup (Module 2)
 * Shop Name: M.BAKAR BALOCH
 */

require_once '../sync_engine.php';

$engine = new SyncEngine();
$user = $engine->authorizeApiRequest();
$db = $engine->getDb();

// 1. SELF-HEALING DATABASE MIGRATION CHECK FOR TABLES
try {
    $db->query("SELECT 1 FROM scan_logs LIMIT 1");
} catch (PDOException $e) {
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS `scan_logs` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT NOT NULL,
            `barcode` VARCHAR(100) NOT NULL,
            `product_id` INT DEFAULT NULL,
            `scanned_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
            FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch(PDOException $ex) {}
}

$barcode = sanitize($_GET['barcode'] ?? '');

if (empty($barcode)) {
    $engine->respondError("Please supply barcode query parameter.");
}

try {
    // 2. QUERY PRODUCTS TABLE
    $stmt = $db->prepare("SELECT p.*, c.name as category_name 
                          FROM products p 
                          LEFT JOIN categories c ON p.category_id = c.id 
                          WHERE p.barcode = :barcode AND p.status = 'ACTIVE' 
                          LIMIT 1");
    $stmt->execute(['barcode' => $barcode]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        // Log unmatched scan attempt
        $log = $db->prepare("INSERT INTO scan_logs (user_id, barcode, product_id) VALUES (:u_id, :barcode, NULL)");
        $log->execute(['u_id' => $user['id'], 'barcode' => $barcode]);
        
        $engine->respondError("Product not found with scanned barcode: $barcode", 404);
    }

    // 3. LOG SUCCESSFUL SCAN AUDIT
    $log = $db->prepare("INSERT INTO scan_logs (user_id, barcode, product_id) VALUES (:u_id, :barcode, :p_id)");
    $log->execute([
        'u_id' => $user['id'],
        'barcode' => $barcode,
        'p_id' => $product['id']
    ]);

    // Success response
    $engine->respondSuccess($product, "Barcode '$barcode' fetched successfully.");

} catch (PDOException $e) {
    $engine->respondError("Barcode lookup failed: " . $e->getMessage(), 500);
}
