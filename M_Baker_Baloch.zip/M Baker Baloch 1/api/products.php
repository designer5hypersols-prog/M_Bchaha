<?php
/**
 * Cloud-Based Multi-Device Sync Subsystem - REST API Products Endpoint (Module 2)
 * Shop Name: M.BAKAR BALOCH
 */

require_once '../sync_engine.php';

$engine = new SyncEngine();
$user = $engine->authorizeApiRequest();
$db = $engine->getDb();

$method = $_SERVER['REQUEST_METHOD'];

// ==========================================
// ROUTE A: GET - FETCH ALL PRODUCTS (READ)
// ==========================================
if ($method === 'GET') {
    $search = sanitize($_GET['search'] ?? '');
    $category_id = (int)($_GET['category_id'] ?? 0);

    try {
        $query = "SELECT p.*, c.name as category_name 
                  FROM products p 
                  LEFT JOIN categories c ON p.category_id = c.id 
                  WHERE 1=1";
        $params = [];

        if (!empty($search)) {
            $query .= " AND (p.name LIKE :search OR p.sku LIKE :search OR p.barcode LIKE :search)";
            $params['search'] = "%$search%";
        }

        if ($category_id > 0) {
            $query .= " AND p.category_id = :cat_id";
            $params['cat_id'] = $category_id;
        }

        $query .= " ORDER BY p.name ASC";

        $stmt = $db->prepare($query);
        $stmt->execute($params);
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $engine->respondSuccess($products, "Warehouse products fetched successfully.");

    } catch (PDOException $e) {
        $engine->respondError("Products fetch failed: " . $e->getMessage(), 500);
    }
}

// ==========================================
// ROUTE B: POST - REGISTER OR UPDATE PRODUCT (WRITE)
// ==========================================
if ($method === 'POST') {
    // Only Managers and Admins can write
    if ($user['role'] !== 'ADMIN' && $user['role'] !== 'MANAGER') {
        $engine->respondError("Access Denied: Managers or Administrators privilege required.", 403);
    }

    $raw_input = file_get_contents('php://input');
    $data = json_decode($raw_input, true);

    $id = (int)($data['id'] ?? 0);
    $name = sanitize($data['name'] ?? '');
    $sku = sanitize($data['sku'] ?? '');
    $barcode = sanitize($data['barcode'] ?? '');
    $cat_id = (int)($data['category_id'] ?? 0);
    $brand = sanitize($data['brand'] ?? '');
    $buy_price = (float)($data['purchase_price'] ?? 0.00);
    $sell_price = (float)($data['sell_price'] ?? 0.00);
    $stock_qty = (int)($data['stock_qty'] ?? 0);
    $min_stock = (int)($data['min_stock_qty'] ?? 5);
    $unit = sanitize($data['unit'] ?? 'pcs');
    $desc = sanitize($data['description'] ?? '');

    if (empty($name) || empty($sku) || $buy_price <= 0 || $sell_price <= 0) {
        $engine->respondError("Please input the product name, SKU SKU, buying price, and selling price.");
    }

    try {
        if ($id > 0) {
            // Action A: Edit product
            $stmt = $db->prepare("UPDATE products SET 
                name = :name, sku = :sku, barcode = :barcode, category_id = :cat, brand = :brand, 
                purchase_price = :buy, sell_price = :sell, min_stock_qty = :min, unit = :unit, description = :desc 
                WHERE id = :id");
            $stmt->execute([
                'name' => $name, 'sku' => $sku, 'barcode' => $barcode, 'cat' => $cat_id, 'brand' => $brand,
                'buy' => $buy_price, 'sell' => $sell_price, 'min' => $min_stock, 'unit' => $unit, 'desc' => $desc, 'id' => $id
            ]);
            
            // Log stock movement adjustment if any override
            $log = $db->prepare("INSERT INTO stock_history (product_id, qty_change, type, description, user_id) 
                                 VALUES (:p_id, 0, 'ADJUST', 'Product parameters synced over API', :user_id)");
            $log->execute(['p_id' => $id, 'user_id' => $user['id']]);

            $engine->respondSuccess(['product_id' => $id], "Product '$name' updated successfully over API.");
        } else {
            // Action B: Add product
            $db->beginTransaction();

            $stmt = $db->prepare("INSERT INTO products (name, sku, barcode, category_id, brand, purchase_price, sell_price, stock_qty, min_stock_qty, unit, description, status) 
                                 VALUES (:name, :sku, :barcode, :cat, :brand, :buy, :sell, :qty, :min, :unit, :desc, 'ACTIVE')");
            $stmt->execute([
                'name' => $name, 'sku' => $sku, 'barcode' => $barcode, 'cat' => $cat_id, 'brand' => $brand,
                'buy' => $buy_price, 'sell' => $sell_price, 'qty' => $stock_qty, 'min' => $min_stock, 'unit' => $unit, 'desc' => $desc
            ]);
            $new_id = $db->lastInsertId();

            // Log stock movement
            $log = $db->prepare("INSERT INTO stock_history (product_id, qty_change, type, description, user_id) 
                                 VALUES (:p_id, :qty, 'IN', 'Initial stock entry over API', :user_id)");
            $log->execute(['p_id' => $new_id, 'qty' => $stock_qty, 'user_id' => $user['id']]);

            $db->commit();
            $engine->respondSuccess(['product_id' => $new_id], "Product '$name' registered successfully over API.");
        }
    } catch (PDOException $e) {
        if ($db->inTransaction()) $db->rollBack();
        $engine->respondError("Product sync failed: " . $e->getMessage(), 500);
    }
}
