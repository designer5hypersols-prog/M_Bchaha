/**
 * Cloud-Based Multi-Device Sync Subsystem - Client Real-Time Poller (Module 4)
 * Shop Name: M.BAKAR BALOCH
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. INJECT FLOATING ONLINE/SYNC STATUS BADGE INTO NAVBAR
    injectSyncStatusIndicator();

    // Start background sync pollers (runs every 10 seconds)
    setInterval(pollRealTimeSyncUpdates, 10000);
});

/**
 * Injects a glowing SaaS network status badge inside top navbar
 */
function injectSyncStatusIndicator() {
    const navbarRight = document.querySelector('.header-right');
    if (!navbarRight) return;

    const indicator = document.createElement('div');
    indicator.id = 'syncStatusIndicator';
    indicator.style.display = 'inline-flex';
    indicator.style.alignItems = 'center';
    indicator.style.gap = '6px';
    indicator.style.padding = '4px 10px';
    indicator.style.background = 'var(--input-bg)';
    indicator.style.border = '1px solid var(--border-color)';
    indicator.style.borderRadius = 'var(--radius-full)';
    indicator.style.fontSize = '11.5px';
    indicator.style.fontWeight = '700';
    indicator.style.transition = 'all 0.3s ease';

    indicator.innerHTML = `
        <span style="display:inline-block; width:8px; height:8px; background:#10b981; border-radius:50%; box-shadow:0 0 8px #10b981; animation:syncGlow 1.5s infinite;"></span>
        <span style="color:var(--text-secondary);" id="syncStatusText">Cloud Synced</span>
    `;

    // Inject custom animation styling
    const style = document.createElement('style');
    style.innerHTML = `
        @keyframes syncGlow {
            0%, 100% { opacity: 0.6; }
            50% { opacity: 1; }
        }
    `;
    document.head.appendChild(style);

    navbarRight.insertBefore(indicator, navbarRight.firstChild);
}

/**
 * Set Network Indicator Status parameters
 */
function updateSyncStatus(isOnline, message = "Cloud Synced") {
    const dot = document.querySelector('#syncStatusIndicator span:first-child');
    const txt = document.getElementById('syncStatusText');
    const container = document.getElementById('syncStatusIndicator');

    if (!dot || !txt || !container) return;

    if (isOnline) {
        dot.style.background = '#10b981';
        dot.style.boxShadow = '0 0 8px #10b981';
        txt.textContent = message;
        container.style.borderColor = 'var(--border-color)';
    } else {
        dot.style.background = '#f43f5e';
        dot.style.boxShadow = '0 0 8px #f43f5e';
        txt.textContent = message;
        container.style.borderColor = 'rgba(244, 63, 94, 0.3)';
    }
}

/**
 * Dynamic Long-Polling Asynchronous updates processor
 */
function pollRealTimeSyncUpdates() {
    // Only poll if tab is active to preserve resources
    if (document.hidden) return;

    // Call API endpoints. (Using relative URLs since frontend is on same host!)
    // In production, endpoints are authorized by the session token!
    fetch('api/sales.php', { method: 'GET' })
        .then(res => {
            if (!res.ok) throw new Error("Sync Interrupted");
            return res.json();
        })
        .then(data => {
            updateSyncStatus(true, "Cloud Synced");
            
            if (data.status === 'success' && data.data) {
                // Dynamically update dashboard parameters if user is loading dashboard
                updateDashboardSalesDOM(data.data);
            }
        })
        .catch(err => {
            updateSyncStatus(false, "Sync Offline");
        });
}

/**
 * Dynamically updates stats metrics inside dashboard DOM without page reloads
 */
function updateDashboardSalesDOM(salesList) {
    if (!salesList || salesList.length === 0) return;

    // Calculate dynamic today's sales turnover from live sync list
    const today = new Date().toISOString().split('T')[0];
    let todaysSalesSum = 0;

    salesList.forEach(sale => {
        if (sale.sale_date === today) {
            todaysSalesSum += parseFloat(sale.payable_amount);
        }
    });

    // Locate metric cards
    const metricCards = document.querySelectorAll('.metric-card');
    metricCards.forEach(card => {
        const title = card.querySelector('.metric-title');
        if (title && title.textContent.includes("Today's Sales")) {
            const val = card.querySelector('.metric-value');
            if (val) {
                // Formatting currency nicely
                const formatted = "Rs. " + todaysSalesSum.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                if (val.textContent !== formatted) {
                    val.textContent = formatted;
                    // Trigger dynamic pulse glow highlight effect on visual update
                    val.style.transition = 'color 0.3s ease';
                    val.style.color = 'var(--accent)';
                    setTimeout(() => { val.style.color = 'var(--text-main)'; }, 1000);
                }
            }
        }
    });
}
