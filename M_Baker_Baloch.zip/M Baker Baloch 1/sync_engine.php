<?php
/**
 * Cloud-Based Multi-Device Sync Subsystem - REST API Routing Engine (Module 2)
 * Shop Name: M.BAKAR BALOCH
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Handle CORS Preflight OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'auth_token_system.php';

class SyncEngine {
    private $db;
    private $auth;

    public function __construct() {
        $this->db = (new Database())->connect();
        $this->auth = new AuthTokenSystem($this->db);
    }

    /**
     * Enforce token-based access security on API endpoints
     */
    public function authorizeApiRequest() {
        $user = $this->auth->validateRequestToken();
        if (!$user) {
            http_response_code(401);
            echo json_encode([
                'status' => 'error',
                'message' => 'Unauthorized Access. Invalid or expired bearer token.'
            ]);
            exit;
        }
        return $user;
    }

    /**
     * Helper: Terminate REST request cleanly with success message
     */
    public function respondSuccess($data = [], $message = "Request processed successfully.") {
        http_response_code(200);
        echo json_encode([
            'status' => 'success',
            'message' => $message,
            'data' => $data
        ]);
        exit;
    }

    /**
     * Helper: Terminate REST request with custom error message
     */
    public function respondError($message = "Request failed.", $code = 400) {
        http_response_code($code);
        echo json_encode([
            'status' => 'error',
            'message' => $message
        ]);
        exit;
    }

    /**
     * Helper: Get MySQL Database connection instance
     */
    public function getDb() {
        return $this->db;
    }
}
