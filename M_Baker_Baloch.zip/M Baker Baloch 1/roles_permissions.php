<?php
/**
 * Settings & Admin Control Subsystem - Roles & Permissions Editor (Module 3)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = "";

// Enforce Admin Rights
if ($_SESSION['user_role'] !== 'ADMIN') {
    die("Access Denied: You must be an Administrator to access modular permissions.");
}

// 1. FILTER ACTIVE ROLE TO EDIT
$selected_role = sanitize($_GET['role'] ?? 'MANAGER');

// List of all core modules
$modules = ['Dashboard', 'Products', 'Sales', 'Purchases', 'Customers', 'Suppliers', 'Reports', 'Settings'];

// 2. PROCESS POST SAVE PERMISSIONS
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = sanitize($_POST['role'] ?? 'MANAGER');
    
    try {
        $db->beginTransaction();
        
        // Loop and save each module permission state
        $upd = $db->prepare("INSERT INTO permissions (role, module_name, can_read, can_write, can_delete) 
                             VALUES (:role, :module, :read, :write, :delete) 
                             ON DUPLICATE KEY UPDATE can_read = :read, can_write = :write, can_delete = :delete");
                             
        foreach ($modules as $mod) {
            // Read checkboxes
            $can_read = isset($_POST["read_$mod"]) ? 1 : 0;
            $can_write = isset($_POST["write_$mod"]) ? 1 : 0;
            $can_delete = isset($_POST["delete_$mod"]) ? 1 : 0;
            
            // Hardforce admin permissions
            if ($role === 'ADMIN') {
                $can_read = $can_write = $can_delete = 1;
            }
            
            $upd->execute([
                'role' => $role,
                'module' => $mod,
                'read' => $can_read,
                'write' => $can_write,
                'delete' => $can_delete
            ]);
        }
        
        // Log administrative activity
        $log = $db->prepare("INSERT INTO activity_logs (user_id, action, target) VALUES (:user_id, 'UPDATE_PERMISSIONS', :target)");
        $log->execute(['user_id' => $_SESSION['user_id'], 'target' => "Role: $role"]);
        
        $db->commit();
        $success_message = "Permissions matrix for Role '$role' saved successfully.";
    } catch (PDOException $e) {
        $db->rollBack();
        $error_message = "Save failed: " . $e->getMessage();
    }
}

// 3. LOAD EXISTING PERMISSIONS FOR SELECTED ROLE
$role_perms = [];
try {
    $stmt = $db->prepare("SELECT * FROM permissions WHERE role = :role");
    $stmt->execute(['role' => $selected_role]);
    $raw_perms = $stmt->fetchAll();
    
    foreach ($raw_perms as $rp) {
        $role_perms[$rp['module_name']] = [
            'read' => (int)$rp['can_read'],
            'write' => (int)$rp['can_write'],
            'delete' => (int)$rp['can_delete']
        ];
    }
} catch (PDOException $e) {}
unset($stmt);

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<!-- Action Notifications -->
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo $error_message; ?></span>
    </div>
<?php endif; ?>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success">
        <i class="bx bx-check-circle"></i>
        <span><?php echo $success_message; ?></span>
    </div>
<?php endif; ?>

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <a href="settings.php#subsystems_link" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
            <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Settings Hub
        </a>
    </div>
</div>

<!-- ==========================================
     ROLE SELECTOR GRID PANEL
     ========================================== -->
<div class="card" style="margin-bottom: 25px; padding: 20px;">
    <div style="display: flex; gap: 15px; align-items: center; flex-wrap: wrap;">
        <span style="font-weight: 700; color: var(--text-main); font-size: 14.5px;">Select Target Security Role to Configure:</span>
        <div style="display: flex; gap: 8px;">
            <a href="roles_permissions.php?role=MANAGER" class="btn btn-sm <?php echo $selected_role === 'MANAGER' ? '' : 'btn-secondary'; ?>" style="width: auto; height:38px;">Shop Manager Rights</a>
            <a href="roles_permissions.php?role=CASHIER" class="btn btn-sm <?php echo $selected_role === 'CASHIER' ? '' : 'btn-secondary'; ?>" style="width: auto; height:38px;">Cashier Operator Rights</a>
            <a href="roles_permissions.php?role=ADMIN" class="btn btn-sm <?php echo $selected_role === 'ADMIN' ? '' : 'btn-secondary'; ?>" style="width: auto; height:38px; pointer-events:none; opacity: 0.7;">Administrator Rights (Full Access)</a>
        </div>
    </div>
</div>

<!-- ==========================================
     MODULAR RIGHTS ASSIGNMENT GRID TABLE
     ========================================== -->
<div class="card">
    <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
        <div class="card-title">
            <i class="bx bx-shield-quarter"></i>
            <span>Module-wise Access Matrix Matrix [Role: <?php echo $selected_role; ?>]</span>
        </div>
    </div>

    <form method="POST" action="roles_permissions.php?role=<?php echo $selected_role; ?>">
        <input type="hidden" name="role" value="<?php echo $selected_role; ?>">

        <div class="table-responsive">
            <table class="permission-matrix-table">
                <thead>
                    <tr>
                        <th style="text-align: left;">System Sub-Module</th>
                        <th>Can Access / Read</th>
                        <th>Can Modify / Write</th>
                        <th>Can Delete / Purge</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($modules as $mod): 
                        $read_state = $role_perms[$mod]['read'] ?? 0;
                        $write_state = $role_perms[$mod]['write'] ?? 0;
                        $delete_state = $role_perms[$mod]['delete'] ?? 0;
                        
                        // Admins are locked to fully enabled checkboxes
                        $is_admin_disabled = ($selected_role === 'ADMIN') ? 'disabled checked' : '';
                    ?>
                        <tr class="animate-fade">
                            <td>
                                <strong><?php echo htmlspecialchars($mod); ?> Module</strong>
                            </td>
                            <td>
                                <label class="switch-control">
                                    <input type="checkbox" name="read_<?php echo $mod; ?>" value="1" <?php echo ($read_state || $selected_role === 'ADMIN') ? 'checked' : ''; ?> <?php echo $is_admin_disabled; ?>>
                                    <span class="switch-slider"></span>
                                </label>
                            </td>
                            <td>
                                <label class="switch-control">
                                    <input type="checkbox" name="write_<?php echo $mod; ?>" value="1" <?php echo ($write_state || $selected_role === 'ADMIN') ? 'checked' : ''; ?> <?php echo $is_admin_disabled; ?>>
                                    <span class="switch-slider"></span>
                                </label>
                            </td>
                            <td>
                                <label class="switch-control">
                                    <input type="checkbox" name="delete_<?php echo $mod; ?>" value="1" <?php echo ($delete_state || $selected_role === 'ADMIN') ? 'checked' : ''; ?> <?php echo $is_admin_disabled; ?>>
                                    <span class="switch-slider"></span>
                                </label>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($selected_role !== 'ADMIN'): ?>
            <div style="margin-top: 30px; border-top: 1.5px dashed var(--border-color); padding-top: 20px; display: flex; justify-content: flex-end;">
                <button type="submit" class="btn" style="width: auto; padding: 0 35px; height: 46px; font-weight:700;">Save Modular Permissions Matrix</button>
            </div>
        <?php endif; ?>
    </form>
</div>

<!-- Subsystem JS -->
<script src="settings.js"></script>

<?php require_once 'includes/header.php'; ?>
