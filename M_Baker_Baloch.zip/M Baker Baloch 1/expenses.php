<?php
/**
 * Expense Management Module (Module 8)
 * Shop Management System: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = "";

// 1. Process Logging New Expense
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = sanitize($_POST['action'] ?? '');
    
    // Add Expense
    if ($action === 'add') {
        $title = sanitize($_POST['title'] ?? '');
        $category = sanitize($_POST['category'] ?? 'Misc');
        $amount = (float)($_POST['amount'] ?? 0);
        $expense_date = sanitize($_POST['expense_date'] ?? date('Y-m-d'));
        $description = sanitize($_POST['description'] ?? '');

        if (empty($title) || $amount <= 0 || empty($expense_date)) {
            $error_message = "Please enter Title, Date, and a positive Amount.";
        } else {
            try {
                $stmt = $db->prepare("INSERT INTO expenses (title, category, amount, expense_date, description) VALUES (:title, :category, :amount, :expense_date, :description)");
                $stmt->execute([
                    'title' => $title,
                    'category' => $category,
                    'amount' => $amount,
                    'expense_date' => $expense_date,
                    'description' => $description
                ]);

                // Auto Post Double Entry Accounting Journal
                try {
                    require_once 'accounting_engine.php';
                    $acct = new AccountingEngine($db);
                    $acct->postOperatingExpenseEntry($title, $amount);
                } catch (Exception $e) {}

                $success_message = "Expense '$title' recorded successfully!";
            } catch (PDOException $e) {
                $error_message = "Error recording expense: " . $e->getMessage();
            }
        }
    }
    
    // Delete Expense
    elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            try {
                $stmt = $db->prepare("DELETE FROM expenses WHERE id = :id");
                $stmt->execute(['id' => $id]);
                $success_message = "Expense record deleted successfully!";
            } catch (PDOException $e) {
                $error_message = "Error deleting expense: " . $e->getMessage();
            }
        }
    }
}

// 2. Fetch and Calculate Expense Summaries for Current Month
$total_expense_month = 0;
$rent_total = 0;
$utility_total = 0;
$misc_total = 0;

try {
    // Total expenses current month
    $sum_stmt = $db->query("SELECT SUM(amount) FROM expenses WHERE MONTH(expense_date) = MONTH(CURRENT_DATE()) AND YEAR(expense_date) = YEAR(CURRENT_DATE())");
    $total_expense_month = $sum_stmt->fetchColumn() ?: 0.00;

    // Categorized breakdown for current month
    $rent_stmt = $db->query("SELECT SUM(amount) FROM expenses WHERE category = 'Rent' AND MONTH(expense_date) = MONTH(CURRENT_DATE()) AND YEAR(expense_date) = YEAR(CURRENT_DATE())");
    $rent_total = $rent_stmt->fetchColumn() ?: 0.00;

    $util_stmt = $db->query("SELECT SUM(amount) FROM expenses WHERE category = 'Utilities' AND MONTH(expense_date) = MONTH(CURRENT_DATE()) AND YEAR(expense_date) = YEAR(CURRENT_DATE())");
    $utility_total = $util_stmt->fetchColumn() ?: 0.00;

} catch (PDOException $e) {
    //
}

// 3. Search and Load Expense Listings
$search = sanitize($_GET['search'] ?? '');
$filter_cat = sanitize($_GET['category'] ?? 'ALL');

$query = "SELECT * FROM expenses WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (title LIKE :search OR description LIKE :search)";
    $params['search'] = "%$search%";
}

if ($filter_cat !== 'ALL') {
    $query .= " AND category = :cat";
    $params['cat'] = $filter_cat;
}

$query .= " ORDER BY expense_date DESC, id DESC";

try {
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $expense_list = $stmt->fetchAll();
} catch (PDOException $e) {
    $expense_list = [];
}

require_once 'includes/header.php';
?>

<!-- Action Notifications -->
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo $error_message; ?></span>
    </div>
<?php endif; ?>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success">
        <i class="bx bx-check-circle"></i>
        <span><?php echo $success_message; ?></span>
    </div>
<?php endif; ?>

<!-- ==========================================
     EXPENSE STATISTICS CARDS
     ========================================== -->
<div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); margin-bottom: 24px;">
    <!-- Monthly Total -->
    <div class="stat-card danger">
        <div class="stat-info">
            <span>Overall Monthly Expenses</span>
            <h2><?php echo format_currency($total_expense_month); ?></h2>
        </div>
        <div class="stat-icon">
            <i class="bx bx-wallet"></i>
        </div>
    </div>
    
    <!-- Utilities -->
    <div class="stat-card warning">
        <div class="stat-info">
            <span>Electric & Utility Costs</span>
            <h2><?php echo format_currency($utility_total); ?></h2>
        </div>
        <div class="stat-icon">
            <i class="bx bx-bulb"></i>
        </div>
    </div>
    
    <!-- Rent -->
    <div class="stat-card primary">
        <div class="stat-info">
            <span>Shop Building Rent</span>
            <h2><?php echo format_currency($rent_total); ?></h2>
        </div>
        <div class="stat-icon">
            <i class="bx bx-home-alt"></i>
        </div>
    </div>
</div>

<!-- Search bar & Add trigger -->
<div class="search-filter-section">
    <form method="GET" action="expenses.php" style="display: flex; flex-grow: 1; flex-wrap: wrap; gap: 15px; width: 100%;">
        
        <div class="search-input-group">
            <i class="bx bx-search"></i>
            <input type="text" name="search" class="search-control" placeholder="Search by description, name..." value="<?php echo htmlspecialchars($search); ?>">
        </div>
        
        <div class="filter-actions" style="flex-grow: 1; display: flex; justify-content: space-between;">
            <div style="display: flex; gap: 10px;">
                <select name="category" class="select-control" onchange="this.form.submit()">
                    <option value="ALL" <?php echo $filter_cat === 'ALL' ? 'selected' : ''; ?>>All Categories</option>
                    <option value="Rent" <?php echo $filter_cat === 'Rent' ? 'selected' : ''; ?>>Rent Payments</option>
                    <option value="Utilities" <?php echo $filter_cat === 'Utilities' ? 'selected' : ''; ?>>Utilities (Bills)</option>
                    <option value="Salaries" <?php echo $filter_cat === 'Salaries' ? 'selected' : ''; ?>>Staff Salaries</option>
                    <option value="Transport" <?php echo $filter_cat === 'Transport' ? 'selected' : ''; ?>>Transport / Logistics</option>
                    <option value="Packaging" <?php echo $filter_cat === 'Packaging' ? 'selected' : ''; ?>>Packaging Outlays</option>
                    <option value="SUPPLIER PAYMENT" <?php echo $filter_cat === 'SUPPLIER PAYMENT' ? 'selected' : ''; ?>>Supplier Payments</option>
                    <option value="Misc" <?php echo $filter_cat === 'Misc' ? 'selected' : ''; ?>>Miscellaneous (Misc)</option>
                </select>
                <button type="submit" class="btn btn-sm btn-secondary">Filter</button>
            </div>
            
            <button type="button" class="btn btn-sm" style="width: auto;" onclick="openModal('addExpenseModal')">
                <i class="bx bx-plus-circle"></i> Log Shop Expense
            </button>
        </div>
    </form>
</div>

<!-- ==========================================
     EXPENSE LEDGER DATA TABLE
     ========================================== -->
<div class="card">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Expense Title</th>
                    <th>Category</th>
                    <th>Amount Value</th>
                    <th>Description / Memo</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($expense_list)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; color: var(--text-muted); padding: 40px;">No expense transactions matched search keys.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach($expense_list as $exp): ?>
                        <tr class="animate-fade">
                            <td><?php echo format_date($exp['expense_date']); ?></td>
                            <td><strong><?php echo htmlspecialchars($exp['title']); ?></strong></td>
                            <td>
                                <span style="font-size:12px; font-weight:600; padding:4px 10px; background:var(--input-bg); border-radius:var(--radius-sm);">
                                    <?php echo htmlspecialchars($exp['category']); ?>
                                </span>
                            </td>
                            <td style="font-weight: 700; color: var(--error);"><?php echo format_currency($exp['amount']); ?></td>
                            <td style="font-style: italic; font-size:13px; color: var(--text-secondary);"><?php echo htmlspecialchars($exp['description'] ?: '-'); ?></td>
                            <td>
                                <form method="POST" action="expenses.php" onsubmit="return confirm('Are you sure you want to remove this expense record?')" style="display: inline;">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?php echo $exp['id']; ?>">
                                    <button type="submit" class="btn-action btn-action-delete" title="Delete Expense">
                                        <i class="bx bx-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ==========================================
     ADD EXPENSE DIALOG MODAL
     ========================================== -->
<div id="addExpenseModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Record Operational Shop Expense</h3>
            <i class="bx bx-x modal-close" onclick="closeModal('addExpenseModal')"></i>
        </div>
        
        <form method="POST" action="expenses.php">
            <input type="hidden" name="action" value="add">
            
            <div class="form-group">
                <label class="form-label">Expense Title / Name *</label>
                <input type="text" name="title" class="form-control" style="padding-left: 15px;" required placeholder="e.g. Electric bill April 2026">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div class="form-group">
                    <label class="form-label">Select Category *</label>
                    <select name="category" class="select-control" style="width: 100%; height: 50px;" required>
                        <option value="Utilities">Utilities (Electricity, Water, Gas)</option>
                        <option value="Rent">Shop Rent Payment</option>
                        <option value="Salaries">Staff Salary Payment</option>
                        <option value="Transport">Transport / Delivery Logistics</option>
                        <option value="Packaging">Packaging Material Outlays</option>
                        <option value="Misc">Miscellaneous (Misc)</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Date *</label>
                    <input type="date" name="expense_date" class="form-control" style="padding-left: 15px; height: 50px;" value="<?php echo date('Y-m-d'); ?>" required>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Expense Amount Value (PKR) *</label>
                <input type="number" step="0.01" name="amount" class="form-control" style="padding-left: 15px;" required placeholder="0.00">
            </div>

            <div class="form-group">
                <label class="form-label">Detailed Memo Description</label>
                <textarea name="description" class="form-control" style="padding: 15px; height: 80px; resize: none;" placeholder="Provide additional details or check numbers..."></textarea>
            </div>

            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                <button type="button" class="btn btn-sm btn-secondary" onclick="closeModal('addExpenseModal')">Cancel</button>
                <button type="submit" class="btn btn-sm" style="width: auto;">Save Expense</button>
            </div>
        </form>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
