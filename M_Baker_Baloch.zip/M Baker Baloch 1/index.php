<?php
/**
 * Core Dynamic Router Entry Point
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Enforce session check
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
} else {
    header("Location: modules/dashboard/index.php");
    exit;
}
