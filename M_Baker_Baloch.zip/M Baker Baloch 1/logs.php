<?php
/**
 * Settings & Admin Control Subsystem - Activity Audit Logs (Module 7)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = "";

// Enforce Admin Rights
if ($_SESSION['user_role'] !== 'ADMIN') {
    die("Access Denied: You must be an Administrator to access activity logs.");
}

// 1. FILTER PARAMETERS
$search = sanitize($_GET['search'] ?? '');

$limit = 15; // Logs per page
$page = (int)($_GET['page'] ?? 1);
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

$query_base = "SELECT al.*, u.name as user_name, u.username as user_uname, u.role as user_role 
              FROM activity_logs al 
              LEFT JOIN users u ON al.user_id = u.id 
              WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query_base .= " AND (al.action LIKE :search OR al.target LIKE :search OR u.name LIKE :search OR u.username LIKE :search)";
    $params['search'] = "%$search%";
}

// Calculate pagination parameters
try {
    $count_query = "SELECT COUNT(*) FROM (" . $query_base . ") as sub";
    $count_stmt = $db->prepare($count_query);
    $count_stmt->execute($params);
    $total_records = (int)$count_stmt->fetchColumn();
} catch (PDOException $e) {
    $total_records = 0;
}

$total_pages = ceil($total_records / $limit);
if ($total_pages < 1) $total_pages = 1;
if ($page > $total_pages) $page = $total_pages;
$offset = ($page - 1) * $limit;

// Load records
try {
    $load_query = $query_base . " ORDER BY al.id DESC LIMIT $limit OFFSET $offset";
    $load_stmt = $db->prepare($load_query);
    $load_stmt->execute($params);
    $logs = $load_stmt->fetchAll();
} catch (PDOException $e) {
    $logs = [];
}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <a href="settings.php#subsystems_link" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
            <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Settings Hub
        </a>
    </div>
    
    <div style="display: flex; gap: 10px;">
        <button type="button" class="btn btn-sm btn-secondary" style="width: auto;" onclick="exportReportTableToCSV('activityLogsTable', 'mbakar_baloch_activity_audit_logs')">
            <i class="bx bx-download"></i> Export Logs CSV
        </button>
    </div>
</div>

<!-- ==========================================
     ADVANCED LOG SEARCH FILTER
     ========================================== -->
<div class="search-filter-section" style="margin-bottom: 24px;">
    <form method="GET" action="logs.php" style="display: flex; flex-grow: 1; flex-wrap: wrap; gap: 15px; width: 100%;">
        <div class="search-input-group" style="max-width: 100%;">
            <i class="bx bx-search"></i>
            <input type="text" name="search" class="search-control" placeholder="Search log actions, target configurations, admin username..." value="<?php echo htmlspecialchars($search); ?>">
        </div>
    </form>
</div>

<!-- ==========================================
     ACTIVITY LOGS TABLE
     ========================================== -->
<div class="card">
    <div class="table-responsive">
        <table class="table" id="activityLogsTable">
            <thead>
                <tr>
                    <th>Timestamp</th>
                    <th>User Identity</th>
                    <th>Security Role</th>
                    <th>Action Tag</th>
                    <th>Target Module / Parameter</th>
                    <th>IP Address</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($logs)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; color: var(--text-muted); padding: 45px;">No activity logs compiled yet.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach($logs as $l): ?>
                        <tr class="animate-fade">
                            <td><?php echo format_date($l['created_at']) . ' ' . date('H:i:s', strtotime($l['created_at'])); ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($l['user_name'] ?: 'System'); ?></strong>
                                <span style="font-size:11px; display:block; color:var(--text-muted);">@<?php echo htmlspecialchars($l['user_uname'] ?: 'sys'); ?></span>
                            </td>
                            <td><span class="status-pill info"><?php echo htmlspecialchars($l['user_role'] ?: 'SYSTEM'); ?></span></td>
                            <td style="font-weight: 600; color: var(--accent);"><?php echo htmlspecialchars($l['action']); ?></td>
                            <td><span style="font-size: 13px; color:var(--text-secondary);"><?php echo htmlspecialchars($l['target'] ?: '-'); ?></span></td>
                            <td><code style="font-size: 12px; font-weight:600;"><?php echo htmlspecialchars($l['ip_address'] ?: '127.0.0.1'); ?></code></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ==========================================
     PAGINATION CONTROL ROW FOOTER
     ========================================== -->
<div class="pagination" style="margin-top: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <span style="font-size: 13.5px; color: var(--text-secondary);">Showing <strong><?php echo count($logs); ?></strong> of <strong><?php echo $total_records; ?></strong> logged sessions.</span>
    
    <div style="display: flex; gap: 5px;">
        <a href="logs.php?page=<?php echo ($page - 1); ?>&search=<?php echo urlencode($search); ?>" 
           class="btn btn-sm btn-secondary <?php echo ($page <= 1) ? 'disabled' : ''; ?>" 
           style="width: auto; padding: 6px 12px; pointer-events: <?php echo ($page <= 1) ? 'none' : 'auto'; ?>;">
           &larr; Prev
        </a>

        <?php for($k = 1; $k <= $total_pages; $k++): ?>
            <a href="logs.php?page=<?php echo $k; ?>&search=<?php echo urlencode($search); ?>" 
               class="btn btn-sm <?php echo ($page === $k) ? '' : 'btn-secondary'; ?>" 
               style="width: 32px; padding: 6px 0; text-align: center;">
               <?php echo $k; ?>
            </a>
        <?php endfor; ?>

        <a href="logs.php?page=<?php echo ($page + 1); ?>&search=<?php echo urlencode($search); ?>" 
           class="btn btn-sm btn-secondary <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>" 
           style="width: auto; padding: 6px 12px; pointer-events: <?php echo ($page >= $total_pages) ? 'none' : 'auto'; ?>;">
           Next &rarr;
        </a>
    </div>
</div>

<!-- Subsystem JS -->
<script src="reports.js"></script>

<?php require_once 'includes/footer.php'; ?>
