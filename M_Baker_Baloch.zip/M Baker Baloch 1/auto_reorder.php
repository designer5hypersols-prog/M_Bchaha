<?php
/**
  * Auto Reorder System - Replenishment Terminal & Procurement PO Suggestions
  * Shop Name: M.BAKAR BALOCH
  */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';
require_once 'audit_logger.php';

// Enforce manager/admin permissions
if ($_SESSION['role'] !== 'SUPERADMIN' && $_SESSION['role'] !== 'ADMIN' && $_SESSION['role'] !== 'MANAGER') {
    die("Access Denied: You do not have permissions to access the Auto Reorder System.");
}

$db = (new Database())->connect();
$message = '';
$error = '';

// Handle Auto Procurement Restocking (Simulate PO Generation)
if (isset($_POST['action']) && $_POST['action'] === 'generate_po') {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        $error = "CSRF Token Validation Failed.";
    } else {
        $product_id = (int)$_POST['product_id'];
        $supplier_id = (int)$_POST['supplier_id'];
        $suggested_qty = (int)$_POST['qty'];
        $purchase_price = (float)$_POST['purchase_price'];
        $branch_id = isset($_SESSION['branch_id']) && $_SESSION['branch_id'] > 0 ? (int)$_SESSION['branch_id'] : 1;

        if ($product_id <= 0 || $supplier_id <= 0 || $suggested_qty <= 0 || $purchase_price <= 0) {
            $error = "All reorder details (product, supplier, quantity, and purchase price) are required.";
        } else {
            try {
                $db->beginTransaction();

                // 1. Create Purchase record
                $stmt = $db->prepare("INSERT INTO purchases (supplier_id, branch_id, total_amount, paid_amount, due_amount, status) 
                                      VALUES (:sid, :bid, :total, :paid, :due, 'PAID')");
                $total_cost = $suggested_qty * $purchase_price;
                $stmt->execute([
                    'sid' => $supplier_id,
                    'bid' => $branch_id,
                    'total' => $total_cost,
                    'paid' => $total_cost,
                    'due' => 0.00
                ]);
                $purchase_id = $db->lastInsertId();

                // 2. Create Purchase Item record
                $stmt_item = $db->prepare("INSERT INTO purchase_items (purchase_id, product_id, qty, cost_price) 
                                           VALUES (:pid, :prod_id, :qty, :cost)");
                $stmt_item->execute([
                    'pid' => $purchase_id,
                    'prod_id' => $product_id,
                    'qty' => $suggested_qty,
                    'cost' => $purchase_price
                ]);

                // 3. Increment stock quantity in products
                $stmt_stock = $db->prepare("UPDATE products SET stock = stock + :qty WHERE id = :id");
                $stmt_stock->execute(['qty' => $suggested_qty, 'id' => $product_id]);

                $db->commit();
                
                AuditLogger::logActivity("CREATE", "Auto Reorder System generated Purchase PO Voucher ID: " . $purchase_id . " for product ID: " . $product_id . " restocking " . $suggested_qty . " units.");
                $message = "Procurement Restock Voucher generated successfully! Stocks incremented.";
            } catch (PDOException $e) {
                $db->rollBack();
                $error = "Failed to process auto procurement restock: " . $e->getMessage();
            }
        }
    }
}

// Fetch low stock items and auto-map to their last purchased supplier
$low_stock_items = [];
try {
    // Select products where stock <= alert_quantity
    // And auto-resolve the last supplier they were purchased from
    $stmt = $db->query("SELECT p.id, p.name as product_name, p.sku as product_sku, p.stock as current_stock, p.alert_quantity, p.unit,
                               COALESCE(
                                   (SELECT s.id 
                                    FROM purchase_items pi 
                                    JOIN purchases s ON pi.purchase_id = s.id 
                                    WHERE pi.product_id = p.id 
                                    ORDER BY s.created_at DESC LIMIT 1), 
                                   (SELECT id FROM suppliers LIMIT 1)
                               ) as mapped_supplier_id,
                               COALESCE(
                                   (SELECT s.name 
                                    FROM purchase_items pi 
                                    JOIN purchases s ON pi.purchase_id = s.id 
                                    JOIN suppliers s ON s.id = s.supplier_id
                                    WHERE pi.product_id = p.id 
                                    ORDER BY s.created_at DESC LIMIT 1), 
                                   (SELECT name FROM suppliers LIMIT 1)
                               ) as mapped_supplier_name,
                               COALESCE(
                                   (SELECT pi.cost_price 
                                    FROM purchase_items pi 
                                    WHERE pi.product_id = p.id 
                                    ORDER BY pi.id DESC LIMIT 1),
                                   100.00
                               ) as last_cost_price
                        FROM products p
                        WHERE p.stock <= p.alert_quantity
                        ORDER BY p.stock ASC");
    $low_stock_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Custom CSS -->
<link rel="stylesheet" href="settings.css">

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="margin: 0; font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Auto Reorder System</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Automated procurement triggers mapping depleted inventory to verified suppliers.</p>
    </div>
</div>

<!-- Alerts -->
<?php if ($message): ?>
    <div class="alert alert-success animate-fade" style="margin-bottom: 20px;"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-danger animate-fade" style="margin-bottom: 20px;"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<!-- ==========================================
     LOW STOCK AUTO TRIGGERS MATRIX
     ========================================== -->
<div class="card">
    <div class="card-header" style="margin-bottom: 15px; padding-bottom: 8px; border-bottom: 1.5px dashed var(--border-color);">
        <div class="card-title">
            <i class="bx bx-recode" style="color:var(--accent);"></i>
            <span>Active Depletion Auto-Triggers</span>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Product details</th>
                    <th style="text-align: center;">Current Stock</th>
                    <th style="text-align: center;">Alert quantity</th>
                    <th>Auto-Mapped Supplier</th>
                    <th style="text-align: right;">Last restock Cost</th>
                    <th style="text-align: center;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($low_stock_items)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px; color: var(--text-muted);">
                            <i class="bx bx-check-shield" style="font-size: 48px; color: var(--success); margin-bottom: 12px; display: block;"></i>
                            All catalog stock levels are healthy! No replenishment suggestions needed.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($low_stock_items as $item): 
                        // Suggest reorder quantity (e.g. alert_qty * 3 - current stock, minimum 50 units)
                        $suggested_reorder = max(50, ($item['alert_quantity'] * 3) - $item['current_stock']);
                    ?>
                        <tr class="animate-fade">
                            <td>
                                <strong><?php echo htmlspecialchars($item['product_name']); ?></strong>
                                <span style="display:block; font-size:11px; color:var(--text-muted);">SKU: <?php echo htmlspecialchars($item['product_sku']); ?></span>
                            </td>
                            <td style="text-align: center;"><strong style="color:var(--danger); font-size:14px;"><?php echo $item['current_stock']; ?> <?php echo htmlspecialchars($item['unit']); ?></strong></td>
                            <td style="text-align: center;"><code><?php echo $item['alert_quantity']; ?> <?php echo htmlspecialchars($item['unit']); ?></code></td>
                            <td>
                                <strong style="color: var(--text-main);"><?php echo htmlspecialchars($item['mapped_supplier_name'] ?: 'Local Open Market'); ?></strong>
                                <span style="display:block; font-size:10px; color:var(--text-muted);">Auto Resolved</span>
                            </td>
                            <td style="text-align: right; font-weight: 700; color: var(--text-main);">Rs. <?php echo number_format($item['last_cost_price'], 2); ?></td>
                            <td style="text-align: center;">
                                <form method="POST" action="auto_reorder.php" style="display: inline-block;">
                                    <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                                    <input type="hidden" name="action" value="generate_po">
                                    <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                    <input type="hidden" name="supplier_id" value="<?php echo $item['mapped_supplier_id']; ?>">
                                    <input type="hidden" name="qty" value="<?php echo $suggested_reorder; ?>">
                                    <input type="hidden" name="purchase_price" value="<?php echo $item['last_cost_price']; ?>">
                                    
                                    <button type="submit" class="btn btn-sm" style="width: auto; background: var(--success); border-color: var(--success); color: #fff; font-size: 11.5px; height: 30px; padding: 0 10px;">
                                        <i class="bx bx-cart-add"></i> Auto-Procure (<?php echo $suggested_reorder; ?> <?php echo htmlspecialchars($item['unit']); ?>)
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
