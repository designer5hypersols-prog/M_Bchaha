/**
 * Ultra Premium ERP Dashboard Scripts
 * Shop Management System: M.BAKAR BALOCH
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Loader dismissal handler
    hideLoader();

    // 2. Collapse/Expand Sidebar Navigation
    initCollapsibleSidebar();

    // 3. Theme custom toggler (Dark & Light)
    initDashboardTheme();

    // 4. Draw interactive charts
    renderDashboardCharts();
});

/**
 * Page loading dismiss screen
 */
function hideLoader() {
    const loader = document.getElementById('pageLoader');
    if (loader) {
        window.addEventListener('load', () => {
            loader.style.opacity = '0';
            setTimeout(() => {
                loader.style.visibility = 'hidden';
            }, 500);
        });
        
        // Safety timeout
        setTimeout(() => {
            loader.style.opacity = '0';
            setTimeout(() => {
                loader.style.visibility = 'hidden';
            }, 500);
        }, 1500);
    }
}

/**
 * Collapsible sidebar animations
 */
function initCollapsibleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const trigger = document.getElementById('sidebarTrigger');
    
    if (sidebar && trigger) {
        // Read previous state from localstorage
        const isCollapsed = localStorage.getItem('sidebar-collapsed') === 'true';
        if (isCollapsed) {
            sidebar.classList.add('collapsed');
        }

        trigger.addEventListener('click', (e) => {
            e.stopPropagation();
            sidebar.classList.toggle('collapsed');
            
            // Sync to localstorage
            const collapsedState = sidebar.classList.contains('collapsed');
            localStorage.setItem('sidebar-collapsed', collapsedState);
            
            // Trigger layout redraw for active ChartJS instances
            setTimeout(() => {
                window.dispatchEvent(new Event('resize'));
            }, 400);
        });
    }
}

/**
 * System Theme Controller
 */
function initDashboardTheme() {
    const themeBtn = document.getElementById('dashboardThemeToggle');
    const savedTheme = localStorage.getItem('theme') || 'light';
    
    document.documentElement.setAttribute('data-theme', savedTheme);
    updateThemeToggleIcon(savedTheme);

    if (themeBtn) {
        themeBtn.addEventListener('click', () => {
            const currentTheme = document.documentElement.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            
            document.documentElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            updateThemeToggleIcon(newTheme);
            
            // Re-render charts with correct color paletts
            renderDashboardCharts();
        });
    }
}

function updateThemeToggleIcon(theme) {
    const icon = document.querySelector('#dashboardThemeToggle i');
    if (icon) {
        if (theme === 'dark') {
            icon.className = 'bx bx-sun';
        } else {
            icon.className = 'bx bx-moon';
        }
    }
}

/**
 * Dynamic Render of Chart.js elements
 */
let revenueChartInstance = null;
let categoryChartInstance = null;

function renderDashboardCharts() {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    const gridColor = isDark ? 'rgba(255, 255, 255, 0.05)' : 'rgba(15, 23, 42, 0.05)';
    const textColor = isDark ? '#8292a6' : '#64748b';

    // Destroy previous instances to prevent rendering overlaps during theme swaps
    if (revenueChartInstance) revenueChartInstance.destroy();
    if (categoryChartInstance) categoryChartInstance.destroy();

    // 1. Line Chart: Monthly Revenue
    const ctxRevenue = document.getElementById('monthlyRevenueChart');
    if (ctxRevenue) {
        // Read raw data from HTML attributes on canvas
        const months = JSON.parse(ctxRevenue.getAttribute('data-months') || '[]');
        const revenues = JSON.parse(ctxRevenue.getAttribute('data-revenues') || '[]');

        revenueChartInstance = new Chart(ctxRevenue.getContext('2d'), {
            type: 'line',
            data: {
                labels: months,
                datasets: [{
                    label: 'Revenue (PKR)',
                    data: revenues,
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.08)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.35,
                    pointBackgroundColor: '#10b981',
                    pointHoverRadius: 6,
                    pointHoverBorderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    x: {
                        grid: { color: gridColor },
                        ticks: { color: textColor }
                    },
                    y: {
                        grid: { color: gridColor },
                        ticks: { color: textColor }
                    }
                }
            }
        });
    }

    // 2. Doughnut Chart: Category Sales Analytics
    const ctxCat = document.getElementById('categoryAnalyticsChart');
    if (ctxCat) {
        const categories = JSON.parse(ctxCat.getAttribute('data-categories') || '[]');
        const counts = JSON.parse(ctxCat.getAttribute('data-counts') || '[]');

        categoryChartInstance = new Chart(ctxCat.getContext('2d'), {
            type: 'doughnut',
            data: {
                labels: categories,
                datasets: [{
                    data: counts,
                    backgroundColor: [
                        '#10b981', // Emerald
                        '#0ea5e9', // Sky Blue
                        '#f59e0b', // Amber
                        '#a855f7', // Purple
                        '#f43f5e', // Rose
                        '#64748b'  // Slate
                    ],
                    borderWidth: 2,
                    borderColor: isDark ? '#0c1220' : '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { color: textColor, padding: 15, font: { family: 'Plus Jakarta Sans' } }
                    }
                },
                cutout: '70%'
            }
        });
    }
}
