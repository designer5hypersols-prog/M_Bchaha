<?php
/**
 * Cloud-Based Multi-Device Sync Subsystem - Device Session Control (Module 9)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = "";

// Enforce Admin Rights
if ($_SESSION['user_role'] !== 'ADMIN') {
    die("Access Denied: You must be an Administrator to manage connected device sessions.");
}

// ==========================================
// PROCESS POST SESSION REVOCATION
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = sanitize($_POST['action'] ?? '');
    $session_id = (int)($_POST['session_id'] ?? 0);

    if ($action === 'revoke' && $session_id > 0) {
        try {
            $db->beginTransaction();

            // 1. Fetch token linked to device session to invalidate it in user_tokens
            $fetch_token = $db->prepare("SELECT session_token FROM device_sessions WHERE id = :id LIMIT 1");
            $fetch_token->execute(['id' => $session_id]);
            $token = $fetch_token->fetchColumn();

            if ($token) {
                // Delete / Revoke User token
                $del_t = $db->prepare("DELETE FROM user_tokens WHERE token = :token");
                $del_t->execute(['token' => $token]);
            }

            // 2. Set device status to REVOKED
            $upd_d = $db->prepare("UPDATE device_sessions SET status = 'REVOKED' WHERE id = :id");
            $upd_d->execute(['id' => $session_id]);

            // Log administrative activity
            $log = $db->prepare("INSERT INTO activity_logs (user_id, action, target) VALUES (:u_id, 'REVOKE_DEVICE_SESSION', :target)");
            $log->execute(['u_id' => $_SESSION['user_id'], 'target' => "Device Session ID: $session_id"]);

            $db->commit();
            $success_message = "Selected device session revoked successfully. This device has been forced to sign out.";
        } catch (PDOException $e) {
            if ($db->inTransaction()) $db->rollBack();
            $error_message = "Revocation failed: " . $e->getMessage();
        }
    }
}

// ==========================================
// LOAD ALL CONNECTED DEVICES SESSIONS
// ==========================================
$sessions = [];
try {
    $stmt = $db->query("SELECT ds.*, u.name as user_fullname, u.username as user_uname 
                        FROM device_sessions ds 
                        JOIN users u ON ds.user_id = u.id 
                        ORDER BY ds.last_active DESC");
    $sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<!-- Action Notifications -->
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo $error_message; ?></span>
    </div>
<?php endif; ?>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success">
        <i class="bx bx-check-circle"></i>
        <span><?php echo $success_message; ?></span>
    </div>
<?php endif; ?>

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <a href="settings.php#subsystems_link" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
            <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Settings Hub
        </a>
    </div>
</div>

<!-- ==========================================
     CONNECTED DEVICES TABLE LIST
     ========================================== -->
<div class="card">
    <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
        <div class="card-title">
            <i class="bx bx-mobile-alt" style="color:var(--accent);"></i>
            <span>Connected Devices & Sync Sessions Console</span>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Device / Platform</th>
                    <th>User Identity</th>
                    <th>IP Address</th>
                    <th>Last Active</th>
                    <th>Connection Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($sessions as $sess): ?>
                    <tr class="animate-fade">
                        <td>
                            <div style="display:flex; align-items:center; gap:10px;">
                                <i class="bx <?php echo (stripos($sess['device_name'], 'Mobile') !== false) ? 'bx-mobile' : 'bx-laptop'; ?>" style="font-size:24px; color:var(--accent);"></i>
                                <div>
                                    <strong><?php echo htmlspecialchars($sess['device_name']); ?></strong>
                                    <span style="display:block; font-size:11px; color:var(--text-muted); max-width:240px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="<?php echo htmlspecialchars($sess['user_agent']); ?>">
                                        <?php echo htmlspecialchars($sess['user_agent']); ?>
                                    </span>
                                </div>
                            </div>
                        </td>
                        <td>
                            <strong><?php echo htmlspecialchars($sess['user_fullname']); ?></strong>
                            <span style="display:block; font-size:11px; color:var(--text-muted);">@<?php echo htmlspecialchars($sess['user_uname']); ?></span>
                        </td>
                        <td><code style="font-size:12px; font-weight:700;"><?php echo htmlspecialchars($sess['ip_address']); ?></code></td>
                        <td><?php echo format_date($sess['last_active']) . ' ' . date('H:i:s', strtotime($sess['last_active'])); ?></td>
                        <td>
                            <?php if ($sess['status'] === 'ACTIVE'): ?>
                                <span style="font-size: 10px; font-weight:700; padding:2px 8px; background:var(--accent-glow); color:var(--accent); border-radius:4px;">ACTIVE</span>
                            <?php else: ?>
                                <span style="font-size: 10px; font-weight:700; padding:2px 8px; background:var(--danger-glow); color:var(--danger); border-radius:4px;">REVOKED</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($sess['status'] === 'ACTIVE'): ?>
                                <form method="POST" action="device_manager.php" onsubmit="return confirm('CAUTION! Revoking this session will instantly sign out this device. Proceed?');">
                                    <input type="hidden" name="action" value="revoke">
                                    <input type="hidden" name="session_id" value="<?php echo $sess['id']; ?>">
                                    <button type="submit" class="btn btn-sm" style="background:var(--error); border-color:var(--error); height:32px; width:auto; font-size:11.5px; padding:0 12px;">
                                        <i class="bx bx-log-out" style="margin-right:4px;"></i> Force Logout
                                    </button>
                                </form>
                            <?php else: ?>
                                <span style="font-size: 12px; color: var(--text-muted);">Disconnected</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
