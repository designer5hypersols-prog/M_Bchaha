<?php
/**
  * Executive Business Intelligence (BI) Analytics Engine
  * Shop Name: M.BAKAR BALOCH
  */

require_once __DIR__ . '/config/database.php';

class AnalyticsEngine {
    private $db;
    private $cache_duration = 3600; // Cache metrics for 1 hour (3600 seconds)

    public function __construct($db) {
        $this->db = $db;
        $this->initializeCacheTable();
    }

    /**
     * Programmatically guarantee that analytics cache tables exist
     */
    private function initializeCacheTable() {
        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS `analytics_cache` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `metric_key` VARCHAR(100) NOT NULL UNIQUE,
                `metric_value` TEXT NOT NULL,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        } catch (PDOException $e) {
            // Silently continue or log error
        }
    }

    /**
     * Get aggregate metric, checking cache first
     */
    public function getMetric($key, $callback, $force_refresh = false) {
        if (!$force_refresh) {
            try {
                $stmt = $this->db->prepare("SELECT metric_value, updated_at FROM analytics_cache WHERE metric_key = :k LIMIT 1");
                $stmt->execute(['k' => $key]);
                $cached = $stmt->fetch();
                
                if ($cached) {
                    $age = time() - strtotime($cached['updated_at']);
                    if ($age < $this->cache_duration) {
                        return json_decode($cached['metric_value'], true);
                    }
                }
            } catch (PDOException $e) {}
        }

        // Cache miss or force refresh: execute heavy aggregations
        $value = call_user_func($callback, $this->db);

        // Store back to cache
        try {
            $save = $this->db->prepare("INSERT INTO analytics_cache (metric_key, metric_value) 
                                        VALUES (:k, :v) 
                                        ON DUPLICATE KEY UPDATE metric_value = :v, updated_at = CURRENT_TIMESTAMP");
            $save->execute([
                'k' => $key,
                'v' => json_encode($value)
            ]);
        } catch (PDOException $e) {}

        return $value;
    }

    /**
     * Clear all cached aggregations
     */
    public function clearCache() {
        try {
            $this->db->exec("TRUNCATE TABLE analytics_cache");
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
}
