<?php
/**
 * Purchase restock intake Management Module (Module 5)
 * Shop Management System: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = "";

// 1. Process Restock Purchases Form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'restock') {
    $supplier_id = (int)($_POST['supplier_id'] ?? 0);
    $product_id = (int)($_POST['product_id'] ?? 0);
    $price = (float)($_POST['purchase_price'] ?? 0);
    $qty = (int)($_POST['qty'] ?? 0);
    $paid_amount = (float)($_POST['paid_amount'] ?? 0);
    $payment_method = sanitize($_POST['payment_method'] ?? 'CASH');
    $notes = sanitize($_POST['notes'] ?? 'Restock batch entry');

    if ($supplier_id <= 0 || $product_id <= 0 || $qty <= 0 || $price <= 0) {
        $error_message = "Please fill in all details with positive prices and quantities.";
    } else {
        try {
            $db->beginTransaction();

            // Calculate total price
            $total_amount = $price * $qty;
            $payable_amount = $total_amount; // No initial cart discount standard

            // Determine status
            $status = 'UNPAID';
            if ($paid_amount >= $payable_amount) {
                $status = 'PAID';
            } elseif ($paid_amount > 0) {
                $status = 'PARTIAL';
            }

            // Create unique purchase reference code
            $purchase_no = 'PUR-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(2)));

            // 1. Insert Purchase Header
            $ins_stmt = $db->prepare("INSERT INTO purchases (purchase_no, supplier_id, purchase_date, total_amount, payable_amount, paid_amount, payment_status, payment_method, notes) VALUES (:p_no, :sup_id, CURRENT_DATE(), :total, :payable, :paid, :status, :method, :notes)");
            $ins_stmt->execute([
                'p_no' => $purchase_no,
                'sup_id' => $supplier_id,
                'total' => $total_amount,
                'payable' => $payable_amount,
                'paid' => $paid_amount,
                'status' => $status,
                'method' => $payment_method,
                'notes' => $notes
            ]);
            $purchase_id = $db->lastInsertId();

            // 2. Insert Purchase Child Item
            $item_stmt = $db->prepare("INSERT INTO purchase_items (purchase_id, product_id, price, qty, total) VALUES (:p_id, :prod_id, :price, :qty, :total)");
            $item_stmt->execute([
                'p_id' => $purchase_id,
                'prod_id' => $product_id,
                'price' => $price,
                'qty' => $qty,
                'total' => $total_amount
            ]);

            // 3. Increment Product Stock levels in warehouse
            $stock_stmt = $db->prepare("UPDATE products SET stock_qty = stock_qty + :qty, purchase_price = :new_p_price WHERE id = :id");
            $stock_stmt->execute([
                'qty' => $qty,
                'new_p_price' => $price, // Dynamically adjust reference buying price to matches latest restock price!
                'id' => $product_id
            ]);

            // 4. Log audit stock transaction history
            $audit_stmt = $db->prepare("INSERT INTO stock_history (product_id, type, qty, reference_id, remarks) VALUES (:prod_id, 'IN', :qty, :ref_id, :remarks)");
            $audit_stmt->execute([
                'prod_id' => $product_id,
                'qty' => $qty,
                'ref_id' => $purchase_id,
                'remarks' => "Stock intake under: $purchase_no"
            ]);

            // 5. Update supplier balance due if we didn't pay in full
            $remaining_debt = $payable_amount - $paid_amount;
            if ($remaining_debt > 0) {
                $sup_stmt = $db->prepare("UPDATE suppliers SET balance = balance + :debt WHERE id = :id");
                $sup_stmt->execute(['debt' => $remaining_debt, 'id' => $supplier_id]);
            }

            $db->commit();
            $success_message = "Restock intake $purchase_no registered successfully! Product counts incremented.";

        } catch (PDOException $e) {
            $db->rollBack();
            $error_message = "Restock intake failed: " . $e->getMessage();
        }
    }
}

// 2. Load Suppliers and Products lists for restocks form
$suppliers = [];
$products = [];
try {
    $sup_list = $db->query("SELECT id, name, balance FROM suppliers ORDER BY name ASC");
    $suppliers = $sup_list->fetchAll();

    $prod_list = $db->query("SELECT id, name, sku, purchase_price, unit FROM products WHERE status = 'ACTIVE' ORDER BY name ASC");
    $products = $prod_list->fetchAll();
} catch (PDOException $e) {
    //
}

// 3. Fetch purchase history log
$purchase_history = [];
try {
    $hist_stmt = $db->query("SELECT p.*, s.name as supplier_name FROM purchases p LEFT JOIN suppliers s ON p.supplier_id = s.id ORDER BY p.id DESC LIMIT 40");
    $purchase_history = $hist_stmt->fetchAll();
} catch (PDOException $e) {
    //
}

require_once 'includes/header.php';
?>

<!-- Action Notifications -->
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo $error_message; ?></span>
    </div>
<?php endif; ?>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success">
        <i class="bx bx-check-circle"></i>
        <span><?php echo $success_message; ?></span>
    </div>
<?php endif; ?>

<!-- Tab Navigation buttons -->
<div style="display: flex; gap: 15px; border-bottom: 2px solid var(--border-color); margin-bottom: 24px; padding-bottom: 10px;">
    <button type="button" id="tabBtnRestock" class="btn btn-sm" style="width: auto; background: var(--accent); color: white;" onclick="switchPurchaseTab('restock')">
        <i class="bx bx-cart-add"></i> Create Restock Purchase
    </button>
    <button type="button" id="tabBtnPurchases" class="btn btn-sm btn-secondary" style="width: auto;" onclick="switchPurchaseTab('history')">
        <i class="bx bx-history"></i> Purchase Intake History
    </button>
</div>

<!-- ==========================================
     TAB 1: CREATE NEW RESTOCK TRANSACTION
     ========================================== -->
<div id="tabContentRestock">
    <div class="card" style="max-width: 700px; margin: 0 auto;">
        <div class="card-header" style="margin-bottom: 20px; padding-bottom: 12px;">
            <div class="card-title">
                <i class="bx bx-cart-add"></i>
                <span>Log Inventory Intake / Purchase Restock Order</span>
            </div>
        </div>

        <form method="POST" action="purchases.php" id="purchaseIntakeForm">
            <input type="hidden" name="action" value="restock">

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <!-- Supplier Selector -->
                <div class="form-group">
                    <label class="form-label">Select Vendor Supplier *</label>
                    <select name="supplier_id" class="select-control" style="width: 100%; height: 48px;" required>
                        <option value="">Choose Supplier...</option>
                        <?php foreach($suppliers as $s): ?>
                            <option value="<?php echo $s['id']; ?>">
                                <?php echo htmlspecialchars($s['name']); ?> 
                                <?php echo ($s['balance'] > 0) ? ' [Pending Debt: ' . format_currency($s['balance']) . ']' : ''; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Product Selector -->
                <div class="form-group">
                    <label class="form-label">Select Product to Restock *</label>
                    <select id="purchase_product_id" name="product_id" class="select-control" style="width: 100%; height: 48px;" required onchange="autofillPurchasePrice(this)">
                        <option value="">Choose Product...</option>
                        <?php foreach($products as $p): ?>
                            <option value="<?php echo $p['id']; ?>" data-price="<?php echo $p['purchase_price']; ?>">
                                <?php echo htmlspecialchars($p['name']); ?> (<?php echo htmlspecialchars($p['sku']); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <!-- Purchase Price per Unit -->
                <div class="form-group">
                    <label class="form-label">Buying Cost (per unit / set) *</label>
                    <input type="number" step="0.01" id="purchaseCostInput" name="purchase_price" class="form-control" style="padding-left: 15px; height: 48px;" required placeholder="0.00" onkeyup="recalcPurchasePayable()">
                </div>

                <!-- Quantity -->
                <div class="form-group">
                    <label class="form-label">Intake Quantity *</label>
                    <input type="number" id="purchaseQtyInput" name="qty" class="form-control" style="padding-left: 15px; height: 48px;" required placeholder="Qty" onkeyup="recalcPurchasePayable()">
                </div>
            </div>

            <div style="border-top: 1.5px dashed var(--border-color); padding-top: 15px; margin-top: 10px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
                <span style="font-size: 15px; color: var(--text-secondary); font-weight: 500;">Gross Invoice cost:</span>
                <strong id="purchaseTotalPayableLabel" style="font-size: 20px; color: var(--accent);">PKR 0.00</strong>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <!-- Payment Paid Amount -->
                <div class="form-group">
                    <label class="form-label">Paid to Supplier (PKR) *</label>
                    <input type="number" step="0.01" id="purchasePaidInput" name="paid_amount" class="form-control" style="padding-left: 15px; height: 48px;" required placeholder="0.00" onkeyup="recalcPurchasePayable()">
                </div>

                <!-- Payment Method -->
                <div class="form-group">
                    <label class="form-label">Payment Mode *</label>
                    <select name="payment_method" class="select-control" style="width: 100%; height: 48px;">
                        <option value="CASH">Cash Drawer</option>
                        <option value="BANK">Bank Account / Check</option>
                        <option value="CREDIT">Add Outstanding Debt Ledger</option>
                    </select>
                </div>
            </div>

            <div class="pos-totals-row" style="margin-bottom: 22px;">
                <span>Supplier Ledger Dues Balance:</span>
                <strong id="purchaseDebtLabel">PKR 0.00</strong>
            </div>

            <div class="form-group">
                <label class="form-label">Procurement Notes / Reference Details</label>
                <input type="text" name="notes" class="form-control" style="padding-left: 15px;" placeholder="e.g. Restock batch from Karachi vendor, check no: 43">
            </div>

            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                <button type="submit" class="btn" style="width: auto; padding: 14px 40px;">
                    <i class="bx bx-check-double"></i> Save Restock Procurement
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ==========================================
     TAB 2: RESTOCKS INTAKE HISTORICAL LOGS
     ========================================== -->
<div id="tabContentHistory" style="display: none;">
    <div class="card">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Purchase No</th>
                        <th>Supplier</th>
                        <th>Purchase Date</th>
                        <th>Total Cost</th>
                        <th>Paid</th>
                        <th>Ledger Debt</th>
                        <th>Status</th>
                        <th>Notes / Memo</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($purchase_history)): ?>
                        <tr>
                            <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 40px;">No historical purchases registered in standard database logs.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($purchase_history as $pur): 
                            $status_badge = get_payment_status($pur['payment_status']);
                            $debt = $pur['payable_amount'] - $pur['paid_amount'];
                        ?>
                            <tr>
                                <td style="font-weight: 600; color: var(--accent);"><?php echo htmlspecialchars($pur['purchase_no']); ?></td>
                                <td><strong><?php echo htmlspecialchars($pur['supplier_name'] ?: 'Unknown Vendor'); ?></strong></td>
                                <td><?php echo format_date($pur['purchase_date']); ?></td>
                                <td><?php echo format_currency($pur['payable_amount']); ?></td>
                                <td><?php echo format_currency($pur['paid_amount']); ?></td>
                                <td style="color: var(--error); font-weight: 600;"><?php echo format_currency(max(0, $debt)); ?></td>
                                <td>
                                    <span class="status-pill <?php echo $status_badge['class']; ?>"><?php echo $status_badge['label']; ?></span>
                                </td>
                                <td style="font-style: italic; font-size: 13px; color: var(--text-secondary);"><?php echo htmlspecialchars($pur['notes']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
/**
 * Tab Toggles
 */
function switchPurchaseTab(tab) {
    const btnRestock = document.getElementById('tabBtnRestock');
    const btnPurch = document.getElementById('tabBtnPurchases');
    const contRestock = document.getElementById('tabContentRestock');
    const contHist = document.getElementById('tabContentHistory');

    if (tab === 'restock') {
        btnRestock.style.background = 'var(--accent)';
        btnRestock.style.color = 'white';
        btnPurch.style.background = 'var(--input-bg)';
        btnPurch.style.color = 'var(--text-primary)';
        contRestock.style.display = 'block';
        contHist.style.display = 'none';
    } else {
        btnPurch.style.background = 'var(--accent)';
        btnPurch.style.color = 'white';
        btnRestock.style.background = 'var(--input-bg)';
        btnRestock.style.color = 'var(--text-primary)';
        contHist.style.display = 'block';
        contRestock.style.display = 'none';
    }
}

/**
 * Autofill base price based on item options selection
 */
function autofillPurchasePrice(select) {
    const option = select.options[select.selectedIndex];
    if (option) {
        const basePrice = option.getAttribute('data-price');
        if (basePrice) {
            document.getElementById('purchaseCostInput').value = parseFloat(basePrice).toFixed(2);
            recalcPurchasePayable();
        }
    }
}

/**
 * Live calculations inside Intake panel
 */
function recalcPurchasePayable() {
    const cost = parseFloat(document.getElementById('purchaseCostInput').value) || 0;
    const qty = parseInt(document.getElementById('purchaseQtyInput').value) || 0;
    const total = cost * qty;

    const paid = parseFloat(document.getElementById('purchasePaidInput').value) || 0;
    const debt = total - paid;

    document.getElementById('purchaseTotalPayableLabel').innerText = 'PKR ' + total.toFixed(2);

    const debtLabel = document.getElementById('purchaseDebtLabel');
    if (debt > 0) {
        debtLabel.innerText = 'To Pay Supplier: PKR ' + debt.toFixed(2);
        debtLabel.style.color = 'var(--error)';
    } else {
        debtLabel.innerText = 'Fully Paid (Change: PKR ' + Math.abs(debt).toFixed(2) + ')';
        debtLabel.style.color = 'var(--accent)';
    }
}
</script>

<?php require_once 'includes/footer.php'; ?>
