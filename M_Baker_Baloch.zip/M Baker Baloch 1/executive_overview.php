<?php
/**
  * Executive Business Intelligence (BI) - YoY Branch & Product Drill-Downs
  * Shop Name: M.BAKAR BALOCH
  */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';
require_once 'analytics_engine.php';
require_once 'kpi_calculator.php';
require_once 'trend_analysis.php';
require_once 'insights_generator.php';

// Enforce executive roles
if ($_SESSION['user_role'] !== 'SUPERADMIN' && $_SESSION['user_role'] !== 'ADMIN') {
    die("Access Denied: You do not have permissions to access corporate drill-down panels.");
}

$db = (new Database())->connect();
$engine = new AnalyticsEngine($db);

// Filter by Branch
$selected_branch_id = isset($_GET['branch_id']) ? (int)$_GET['branch_id'] : 0;

$branches = [];
try {
    $branches = $db->query("SELECT id, name FROM branches WHERE status = 'ACTIVE'")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

// Gather aggregations
$kpis = $engine->getMetric('overview_kpis', ['KPICalculator', 'calculateOverview']);
$branch_rankings = $engine->getMetric('branch_kpis', ['KPICalculator', 'calculateBranchMetrics']);
$insights = $engine->getMetric('forecast_insights', ['InsightsGenerator', 'compileInsights']);

// Fetch filtered transaction stats if branch is selected
$filtered_sales = 0.00;
$filtered_orders = 0;
$filtered_cogs = 0.00;

try {
    if ($selected_branch_id > 0) {
        $stmt_s = $db->prepare("SELECT COALESCE(SUM(payable_amount), 0.00), COUNT(*) FROM sales WHERE branch_id = :bid");
        $stmt_s->execute(['bid' => $selected_branch_id]);
        $s_row = $stmt_s->fetch(PDO::FETCH_NUM);
        $filtered_sales = (float)$s_row[0];
        $filtered_orders = (int)$s_row[1];

        $stmt_c = $db->prepare("SELECT COALESCE(SUM(si.purchase_price * si.qty), 0.00) 
                                 FROM sale_items si 
                                 JOIN sales s ON si.sale_id = s.id 
                                 WHERE s.branch_id = :bid");
        $stmt_c->execute(['bid' => $selected_branch_id]);
        $filtered_cogs = (float)$stmt_c->fetchColumn();
    } else {
        $filtered_sales = $kpis['total_revenue'];
        $filtered_orders = array_sum(array_column($branch_rankings['list'], 'orders'));
        $filtered_cogs = $kpis['total_cost_goods'];
    }
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <a href="bi_dashboard.php" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
            <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to BI Cockpit
        </a>
        <h1 style="margin: 6px 0 0 0; font-size: 22px; font-weight: 800; letter-spacing: -0.5px;">Corporate Branch Drill-Down</h1>
    </div>
    
    <!-- Filter dropdown -->
    <div style="display: flex; align-items: center; gap: 10px;">
        <span style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Selected Branch:</span>
        <select onchange="window.location.href='executive_overview.php?branch_id=' + this.value" 
                style="height: 38px; padding: 0 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; font-weight: 600; outline: none; cursor: pointer;">
            <option value="0" <?php echo $selected_branch_id === 0 ? 'selected' : ''; ?>>All Company Outlets Combined</option>
            <?php foreach ($branches as $b): ?>
                <option value="<?php echo $b['id']; ?>" <?php echo $selected_branch_id === $b['id'] ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($b['name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
</div>

<!-- ==========================================
     I. FILTERED METRICS SUB-KPI CARDS
     ========================================== -->
<div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); margin-bottom: 24px;">
    <!-- Sales -->
    <div class="stat-card success">
        <div class="stat-info">
            <span>Branch Consolidated Sales</span>
            <h2>Rs. <?php echo number_format($filtered_sales, 2); ?></h2>
        </div>
        <div class="stat-icon">
            <i class="bx bx-bar-chart"></i>
        </div>
    </div>

    <!-- Orders -->
    <div class="stat-card primary">
        <div class="stat-info">
            <span>Branch Operational Volume</span>
            <h2><?php echo $filtered_orders; ?> Invoices issued</h2>
        </div>
        <div class="stat-icon">
            <i class="bx bx-receipt"></i>
        </div>
    </div>

    <!-- Profits -->
    <div class="stat-card warning">
        <div class="stat-info">
            <span>Estimated Gross Profits</span>
            <h2>Rs. <?php echo number_format($filtered_sales - $filtered_cogs, 2); ?></h2>
        </div>
        <div class="stat-icon">
            <i class="bx bx-dollar"></i>
        </div>
    </div>
</div>

<div style="display: grid; grid-template-columns: 1.5fr 1fr; gap: 24px; align-items: start;">

    <!-- Left: Branch Rankings & Performance comparison table -->
    <div class="card">
        <div class="card-header" style="margin-bottom: 15px; padding-bottom: 8px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-buildings" style="color:var(--accent);"></i>
                <span>Outlets Performance Matrix</span>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Branch / Outlet</th>
                        <th style="text-align:right;">Orders Total</th>
                        <th style="text-align:right;">Sales Revenue (Rs.)</th>
                        <th style="text-align:center;">Options</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($branch_rankings['list'] as $item): ?>
                        <tr class="animate-fade">
                            <td><strong><?php echo htmlspecialchars($item['name']); ?></strong></td>
                            <td style="text-align:right; font-weight:700;"><?php echo $item['orders']; ?> checkouts</td>
                            <td style="text-align:right; font-weight:800; color:var(--accent);">
                                Rs. <?php echo number_format($item['sales'], 2); ?>
                            </td>
                            <td style="text-align:center;">
                                <a href="executive_overview.php?branch_id=<?php echo $item['id']; ?>" class="btn btn-sm" style="height:26px; width:auto; font-size:11px; padding:0 10px; background:var(--bg-primary); border-color:var(--border-color); color:var(--text-main); text-decoration:none;">
                                    Drill Down
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Right: Customer Spend Analytics -->
    <div class="card">
        <div class="card-header" style="margin-bottom: 15px; padding-bottom: 8px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-user-check" style="color:var(--accent);"></i>
                <span>VIP Customer Ledgers Spendings</span>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Client Details</th>
                        <th style="text-align:right;">Consolidated Spend (Rs.)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($insights['customer_spending'])): ?>
                        <tr>
                            <td colspan="2" style="text-align:center; color:var(--text-muted);">No customer spends registered yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($insights['customer_spending'] as $c): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($c['name']); ?></strong>
                                    <span style="display:block; font-size:10.5px; color:var(--text-muted);"><?php echo htmlspecialchars($c['phone']); ?></span>
                                </td>
                                <td style="text-align:right; font-weight:800; color:var(--accent);">Rs. <?php echo number_format($c['total_spend'], 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once 'includes/footer.php'; ?>
