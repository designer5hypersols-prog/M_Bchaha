<?php
/**
 * Cloud-Based Multi-Device Sync Subsystem - Database Schemas & Migrations (Module 6)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

$db = (new Database())->connect();
$migration_log = "";

try {
    // 1. API Authentication Tokens Table
    $db->exec("CREATE TABLE IF NOT EXISTS `user_tokens` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `user_id` INT NOT NULL,
        `token` VARCHAR(255) NOT NULL UNIQUE,
        `expires_at` TIMESTAMP NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $migration_log .= "API user_tokens table successfully checked/created.\n";

    // 2. Connected Devices & Live Sessions Table
    $db->exec("CREATE TABLE IF NOT EXISTS `device_sessions` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `user_id` INT NOT NULL,
        `device_name` VARCHAR(100) DEFAULT 'Unknown Device',
        `ip_address` VARCHAR(45) NOT NULL,
        `user_agent` TEXT DEFAULT NULL,
        `last_active` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        `session_token` VARCHAR(255) NOT NULL UNIQUE,
        `status` ENUM('ACTIVE', 'REVOKED') NOT NULL DEFAULT 'ACTIVE',
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $migration_log .= "Connected device_sessions table successfully checked/created.\n";

    // Seed dynamic sample devices if empty
    $chk = $db->query("SELECT COUNT(*) FROM device_sessions")->fetchColumn();
    if ($chk == 0) {
        // Fetch a user id
        $uid = $db->query("SELECT id FROM users LIMIT 1")->fetchColumn();
        if ($uid) {
            $db->exec("INSERT INTO device_sessions (user_id, device_name, ip_address, user_agent, session_token, status) VALUES 
                ($uid, 'Main PC (Chrome)', '192.168.1.15', 'Mozilla/5.0 (Windows NT 10.0)', 'sess_mock_token_1', 'ACTIVE'),
                ($uid, 'Cashier Terminal (Firefox)', '192.168.1.20', 'Mozilla/5.0 (Windows NT 10.0)', 'sess_mock_token_2', 'ACTIVE'),
                ($uid, 'Manager Mobile App', '192.168.1.45', 'Dart/3.0 (mobile)', 'sess_mock_token_3', 'ACTIVE')");
            $migration_log .= "Sample sync devices successfully seeded.\n";
        }
    }

} catch (PDOException $e) {
    $migration_log .= "Migration failure: " . $e->getMessage() . "\n";
}

// Log migration completion if loaded manually in browser
if (basename($_SERVER['PHP_SELF']) === 'database_sync.php') {
    header('Content-Type: text/plain');
    echo "==========================================================\n";
    echo "M.BAKAR BALOCH ERP - DB SYNC SYSTEM MIGRATION TOOL\n";
    echo "==========================================================\n";
    echo $migration_log;
}
