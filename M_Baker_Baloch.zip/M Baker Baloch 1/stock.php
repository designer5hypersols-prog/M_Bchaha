<?php
/**
 * Stock Management Module (Module 3)
 * Shop Management System: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = "";

// 1. Process Manual Stock Adjustments
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'adjust') {
    $product_id = (int)($_POST['product_id'] ?? 0);
    $adjust_type = sanitize($_POST['adjust_type'] ?? 'IN'); // IN, OUT, ADJUST (Override)
    $qty = (int)($_POST['qty'] ?? 0);
    $remarks = sanitize($_POST['remarks'] ?? 'Manual stock adjustment');

    if ($product_id <= 0 || $qty <= 0) {
        $error_message = "Please select a product and enter a positive quantity.";
    } else {
        try {
            // Start Transaction for safety
            $db->beginTransaction();

            // Fetch current stock
            $stmt = $db->prepare("SELECT stock_qty, name FROM products WHERE id = :id FOR UPDATE");
            $stmt->execute(['id' => $product_id]);
            $product = $stmt->fetch();

            if (!$product) {
                $error_message = "Selected product does not exist.";
                $db->rollBack();
            } else {
                $current_stock = (int)$product['stock_qty'];
                $new_stock = $current_stock;
                
                if ($adjust_type === 'IN') {
                    $new_stock += $qty;
                } elseif ($adjust_type === 'OUT') {
                    if ($current_stock < $qty) {
                        $error_message = "Cannot subtract more items than are currently in stock. Current: $current_stock";
                        $db->rollBack();
                        $product = null; // Prevent execution below
                    } else {
                        $new_stock -= $qty;
                    }
                } elseif ($adjust_type === 'ADJUST') {
                    // Override quantity
                    $new_stock = $qty;
                }

                if ($product) {
                    // Update Product Stock
                    $update = $db->prepare("UPDATE products SET stock_qty = :new_stock WHERE id = :id");
                    $update->execute(['new_stock' => $new_stock, 'id' => $product_id]);

                    // Add History Log
                    $audit = $db->prepare("INSERT INTO stock_history (product_id, type, qty, remarks) VALUES (:prod_id, :type, :qty, :remarks)");
                    $audit->execute([
                        'prod_id' => $product_id,
                        'type' => $adjust_type,
                        'qty' => $qty,
                        'remarks' => $remarks
                    ]);

                    $db->commit();
                    $success_message = "Stock level for '" . $product['name'] . "' updated successfully. Current: $new_stock";
                }
            }
        } catch (PDOException $e) {
            $db->rollBack();
            $error_message = "Database error during adjustment: " . $e->getMessage();
        }
    }
}

// 2. Fetch products details for selections and listings
$search = sanitize($_GET['search'] ?? '');
$filter_status = sanitize($_GET['stock_status'] ?? 'ALL');

// Build Product query
$query = "SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id WHERE p.status = 'ACTIVE'";
$params = [];

if (!empty($search)) {
    $query .= " AND (p.name LIKE :search OR p.sku LIKE :search)";
    $params['search'] = "%$search%";
}

if ($filter_status === 'OUT') {
    $query .= " AND p.stock_qty = 0";
} elseif ($filter_status === 'LOW') {
    $query .= " AND p.stock_qty <= p.min_stock_qty AND p.stock_qty > 0";
} elseif ($filter_status === 'GOOD') {
    $query .= " AND p.stock_qty > p.min_stock_qty";
}

$query .= " ORDER BY p.stock_qty ASC";

try {
    $prod_stmt = $db->prepare($query);
    $prod_stmt->execute($params);
    $products = $prod_stmt->fetchAll();
} catch (PDOException $e) {
    $products = [];
}

// 3. Fetch Stock History logs
try {
    $log_stmt = $db->query("SELECT sh.*, p.name as product_name, p.sku as product_sku, p.unit FROM stock_history sh JOIN products p ON sh.product_id = p.id ORDER BY sh.id DESC LIMIT 100");
    $stock_logs = $log_stmt->fetchAll();
} catch (PDOException $e) {
    $stock_logs = [];
}

require_once 'includes/header.php';
?>

<!-- Action Notifications -->
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo $error_message; ?></span>
    </div>
<?php endif; ?>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success">
        <i class="bx bx-check-circle"></i>
        <span><?php echo $success_message; ?></span>
    </div>
<?php endif; ?>

<!-- Tabbed Panel Selector Navigation -->
<div style="display: flex; gap: 15px; border-bottom: 2px solid var(--border-color); margin-bottom: 24px; padding-bottom: 10px;">
    <button type="button" id="tabBtnStock" class="btn btn-sm" style="width: auto; background: var(--accent); color: white;" onclick="switchTab('stock')">
        <i class="bx bx-cabinet"></i> Current Stock Levels
    </button>
    <button type="button" id="tabBtnLogs" class="btn btn-sm btn-secondary" style="width: auto;" onclick="switchTab('logs')">
        <i class="bx bx-history"></i> Adjustment History Logs
    </button>
</div>

<!-- ==========================================
     TAB A: CURRENT STOCK LEVELS PANELS
     ========================================== -->
<div id="tabContentStock">
    <!-- Filter bars -->
    <div class="search-filter-section">
        <form method="GET" action="stock.php" style="display: flex; flex-grow: 1; flex-wrap: wrap; gap: 15px; width: 100%;">
            
            <div class="search-input-group">
                <i class="bx bx-search"></i>
                <input type="text" name="search" class="search-control" placeholder="Search product name or code..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
            
            <div class="filter-actions" style="flex-grow: 1; display: flex; justify-content: space-between;">
                <div style="display: flex; gap: 10px;">
                    <select name="stock_status" class="select-control" onchange="this.form.submit()">
                        <option value="ALL" <?php echo $filter_status === 'ALL' ? 'selected' : ''; ?>>All Stock Levels</option>
                        <option value="GOOD" <?php echo $filter_status === 'GOOD' ? 'selected' : ''; ?>>Healthy Stock</option>
                        <option value="LOW" <?php echo $filter_status === 'LOW' ? 'selected' : ''; ?>>Low Stock Warn</option>
                        <option value="OUT" <?php echo $filter_status === 'OUT' ? 'selected' : ''; ?>>Out of Stock</option>
                    </select>
                    <button type="submit" class="btn btn-sm btn-secondary">Filter</button>
                </div>
                
                <button type="button" class="btn btn-sm" style="width: auto;" onclick="openModal('adjustStockModal')">
                    <i class="bx bx-git-compare"></i> Adjust Stock Manually
                </button>
            </div>
        </form>
    </div>

    <!-- Inventory table list -->
    <div class="card">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>SKU</th>
                        <th>Product Name</th>
                        <th>Category</th>
                        <th>Min Level</th>
                        <th>Current Count</th>
                        <th>Status Indicator</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($products)): ?>
                        <tr>
                            <td colspan="7" style="text-align: center; color: var(--text-muted); padding: 40px;">No inventory levels match filter parameters.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($products as $prod): 
                            $status_badge = get_stock_status($prod['stock_qty'], $prod['min_stock_qty']);
                        ?>
                            <tr class="animate-fade">
                                <td style="font-weight: 600; color: var(--accent);"><?php echo htmlspecialchars($prod['sku']); ?></td>
                                <td><strong><?php echo htmlspecialchars($prod['name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($prod['category_name']); ?></td>
                                <td><?php echo $prod['min_stock_qty']; ?> <?php echo htmlspecialchars($prod['unit']); ?></td>
                                <td style="font-weight: 700;"><?php echo $prod['stock_qty']; ?> <?php echo htmlspecialchars($prod['unit']); ?></td>
                                <td>
                                    <span class="status-pill <?php echo $status_badge['class']; ?>"><?php echo $status_badge['label']; ?></span>
                                </td>
                                <td>
                                    <button type="button" class="btn-action" title="Quick Adjust" onclick="triggerQuickAdjust(<?php echo $prod['id']; ?>, '<?php echo addslashes($prod['name']); ?>')">
                                        <i class="bx bx-git-compare"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ==========================================
     TAB B: ADJUSTMENT HISTORY LOGS PANELS
     ========================================== -->
<div id="tabContentLogs" style="display: none;">
    <div class="card">
        <div class="card-header">
            <div class="card-title">
                <i class="bx bx-history"></i>
                <span>Audit Logs History (Last 100 Entries)</span>
            </div>
            <span style="font-size: 12px; color: var(--text-muted);">Stock transactions log</span>
        </div>
        
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Date & Time</th>
                        <th>SKU</th>
                        <th>Product Name</th>
                        <th>Type</th>
                        <th>Change Qty</th>
                        <th>Remarks / Reason</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($stock_logs)): ?>
                        <tr>
                            <td colspan="6" style="text-align: center; color: var(--text-muted); padding: 40px;">No adjustment history found.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($stock_logs as $log): ?>
                            <tr>
                                <td><?php echo date('d M Y, h:i A', strtotime($log['created_at'])); ?></td>
                                <td style="font-weight: 600; color: var(--accent);"><?php echo htmlspecialchars($log['product_sku']); ?></td>
                                <td><strong><?php echo htmlspecialchars($log['product_name']); ?></strong></td>
                                <td>
                                    <?php if ($log['type'] === 'IN'): ?>
                                        <span class="status-pill status-success"><i class="bx bx-trending-up" style="margin-right: 4px;"></i> STOCK IN</span>
                                    <?php elseif ($log['type'] === 'OUT'): ?>
                                        <span class="status-pill status-danger"><i class="bx bx-trending-down" style="margin-right: 4px;"></i> STOCK OUT</span>
                                    <?php else: ?>
                                        <span class="status-pill status-warning"><i class="bx bx-git-compare" style="margin-right: 4px;"></i> OVERRIDE</span>
                                    <?php endif; ?>
                                </td>
                                <td style="font-weight: 700;"><?php echo $log['qty']; ?> <?php echo htmlspecialchars($log['unit']); ?></td>
                                <td style="font-style: italic; color: var(--text-secondary);"><?php echo htmlspecialchars($log['remarks']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ==========================================
     MANUAL ADJUSTMENT DIALOG MODAL
     ========================================== -->
<div id="adjustStockModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Manual Stock Audit Adjustment</h3>
            <i class="bx bx-x modal-close" onclick="closeModal('adjustStockModal')"></i>
        </div>
        
        <form method="POST" action="stock.php">
            <input type="hidden" name="action" value="adjust">
            
            <div class="form-group">
                <label class="form-label">Select Inventory Product *</label>
                <select id="adjust_product_id" name="product_id" class="select-control" style="width: 100%; height: 50px;" required>
                    <option value="">Choose product...</option>
                    <?php 
                    // Load active products list again for selections
                    try {
                        $p_list = $db->query("SELECT id, name, sku, stock_qty, unit FROM products WHERE status = 'ACTIVE' ORDER BY name ASC");
                        while($p = $p_list->fetch()) {
                            echo '<option value="' . $p['id'] . '">' . htmlspecialchars($p['name']) . ' (' . htmlspecialchars($p['sku']) . ') - Current: ' . $p['stock_qty'] . ' ' . htmlspecialchars($p['unit']) . '</option>';
                        }
                    } catch(PDOException $e) {}
                    ?>
                </select>
            </div>

            <div style="display: grid; grid-template-columns: 1.2fr 1fr; gap: 15px;">
                <div class="form-group">
                    <label class="form-label">Adjustment Action *</label>
                    <select name="adjust_type" class="select-control" style="width: 100%; height: 50px;" required>
                        <option value="IN">ADD Stock (IN - restock/returned items)</option>
                        <option value="OUT">SUBTRACT Stock (OUT - damage/theft/missing)</option>
                        <option value="ADJUST">OVERRIDE Count (ADJUST - force exact inventory)</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Adjustment Quantity *</label>
                    <input type="number" name="qty" class="form-control" style="padding-left: 15px;" required min="1" placeholder="e.g. 10">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Audit Remarks / Explanation *</label>
                <input type="text" name="remarks" class="form-control" style="padding-left: 15px;" required placeholder="e.g. Found 2 items during yearly count audit">
            </div>

            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                <button type="button" class="btn btn-sm btn-secondary" onclick="closeModal('adjustStockModal')">Cancel</button>
                <button type="submit" class="btn btn-sm" style="width: auto;">Submit Audit Adjust</button>
            </div>
        </form>
    </div>
</div>

<script>
/**
 * Tab switcher client controls
 */
function switchTab(tab) {
    const btnStock = document.getElementById('tabBtnStock');
    const btnLogs = document.getElementById('tabBtnLogs');
    const contStock = document.getElementById('tabContentStock');
    const contLogs = document.getElementById('tabContentLogs');
    
    if (tab === 'stock') {
        btnStock.style.background = 'var(--accent)';
        btnStock.style.color = 'white';
        btnLogs.style.background = 'var(--input-bg)';
        btnLogs.style.color = 'var(--text-primary)';
        
        contStock.style.display = 'block';
        contLogs.style.display = 'none';
    } else {
        btnLogs.style.background = 'var(--accent)';
        btnLogs.style.color = 'white';
        btnStock.style.background = 'var(--input-bg)';
        btnStock.style.color = 'var(--text-primary)';
        
        contLogs.style.display = 'block';
        contStock.style.display = 'none';
    }
}

/**
 * Trigger manual adjustments for exact items from listings
 */
function triggerQuickAdjust(productId, productName) {
    document.getElementById('adjust_product_id').value = productId;
    openModal('adjustStockModal');
}
</script>

<?php require_once 'includes/footer.php'; ?>
