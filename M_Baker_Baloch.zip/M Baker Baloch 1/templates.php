<?php
/**
 * Automated Notifications Subsystem - Message Templates Editor (Module 4)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();
$success_msg = "";
$error_msg = "";

// Enforce Manager or Admin rights
if ($_SESSION['user_role'] !== 'ADMIN' && $_SESSION['user_role'] !== 'MANAGER') {
    die("Access Denied: You do not have permissions to manage automated message templates.");
}

// ==========================================
// PROCESS POST TEMPLATE UPDATES
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $template_id = (int)($_POST['template_id'] ?? 0);
    $message_body = sanitize($_POST['message_body'] ?? '');

    if ($template_id > 0 && !empty($message_body)) {
        try {
            $upd = $db->prepare("UPDATE templates SET message_body = :body WHERE id = :id");
            $upd->execute(['body' => $message_body, 'id' => $template_id]);
            
            $success_msg = "Message template updated successfully. Automated notifications will now reflect these changes.";
        } catch (PDOException $e) {
            $error_msg = "Template update failed: " . $e->getMessage();
        }
    } else {
        $error_msg = "Please input a valid template body.";
    }
}

// ==========================================
// LOAD ALL TEMPLATES
// ==========================================
$templates = [];
try {
    $templates = $db->query("SELECT * FROM templates ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Action Alerts -->
<?php if (!empty($success_msg)): ?>
    <div class="alert alert-success">
        <i class="bx bx-check-circle"></i>
        <span><?php echo $success_msg; ?></span>
    </div>
<?php endif; ?>

<?php if (!empty($error_msg)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo $error_msg; ?></span>
    </div>
<?php endif; ?>

<div style="margin-bottom: 24px;">
    <a href="settings.php#subsystems_link" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
        <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Settings Hub
    </a>
</div>

<!-- ==========================================
     TEMPLATES LIST & EDITING MODALS
     ========================================== -->
<div class="card">
    <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
        <div class="card-title">
            <i class="bx bx-message-square-edit" style="color:var(--accent);"></i>
            <span>Automated Customer Notifications Templates</span>
        </div>
    </div>

    <div style="background:var(--input-bg); border:1px solid var(--border-color); padding:16px; border-radius:var(--radius-sm); margin-bottom:24px; font-size:13px; line-height:1.5;">
        <strong style="color:var(--accent); display:block; margin-bottom:6px;"><i class="bx bx-info-circle"></i> Supported Variable Merge Codes:</strong>
        Use these parameters inside templates. The ERP automatically merges dynamic customer and sales data before dispatching:
        <ul style="margin-left: 20px; margin-top: 6px; display: grid; grid-template-columns: 1fr 1fr; gap: 4px;">
            <li><code>{{customer_name}}</code> - Recipient Full Name</li>
            <li><code>{{invoice_no}}</code> - Unique POS Invoice Code</li>
            <li><code>{{payable_amount}}</code> - Payable Amount Dues</li>
            <li><code>{{amount}}</code> - Installment Cash Value paid</li>
            <li><code>{{balance}}</code> - Outstanding Receivables</li>
            <li><code>{{shop_name}}</code> - Shop Brand Name (M.BAKAR BALOCH)</li>
        </ul>
    </div>

    <div style="display:flex; flex-direction:column; gap:20px;">
        <?php foreach ($templates as $t): ?>
            <div style="background:var(--bg-base); border:1px solid var(--border-color); padding:20px; border-radius:var(--radius-md); transition:var(--transition); position:relative;">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:12px;">
                    <div>
                        <strong style="font-size:15px; color:var(--text-main);"><?php echo htmlspecialchars($t['template_name']); ?></strong>
                        <span style="font-size:11px; margin-left:8px; padding:2px 8px; background:var(--accent-glow); color:var(--accent); border-radius:4px; font-weight:700;"><?php echo $t['language']; ?></span>
                    </div>
                    <code style="font-size:11.5px; background:var(--input-bg); padding:4px 8px; border-radius:4px; font-weight:700;">Key: <?php echo $t['template_key']; ?></code>
                </div>

                <form method="POST" action="templates.php">
                    <input type="hidden" name="template_id" value="<?php echo $t['id']; ?>">
                    <div style="margin-bottom:12px;">
                        <textarea name="message_body" style="width:100%; height:80px; padding:12px; background:var(--bg-surface); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px; font-family:inherit; resize:vertical; line-height:1.4;" required><?php echo htmlspecialchars($t['message_body']); ?></textarea>
                    </div>
                    <div style="display:flex; justify-content:flex-end;">
                        <button type="submit" class="btn btn-sm" style="background:var(--accent); border-color:var(--accent); height:34px; width:auto; font-size:12px; padding:0 16px;">
                            <i class="bx bx-save" style="margin-right:4px;"></i> Update Template
                        </button>
                    </div>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
