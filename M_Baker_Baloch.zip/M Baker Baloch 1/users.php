<?php
/**
 * Settings & Admin Control Subsystem - User Directories (Module 2)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = "";

// Enforce Admin Rights
if ($_SESSION['user_role'] !== 'ADMIN') {
    die("Access Denied: You must be an Administrator to access the User directory.");
}

// 1. PROCESS POST MUTATIONS
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = sanitize($_POST['action'] ?? '');

    // Action A: Add User
    if ($action === 'add') {
        $name = sanitize($_POST['name'] ?? '');
        $username = sanitize($_POST['username'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $phone = sanitize($_POST['phone'] ?? '');
        $role = sanitize($_POST['role'] ?? 'CASHIER');
        $pass = $_POST['password'] ?? '';

        if (empty($name) || empty($username) || empty($pass)) {
            $error_message = "Please input the full name, username, and password fields.";
        } else {
            try {
                // Verify duplicate username
                $chk = $db->prepare("SELECT COUNT(*) FROM users WHERE username = :user");
                $chk->execute(['user' => $username]);
                if ($chk->fetchColumn() > 0) {
                    $error_message = "The username '$username' is already taken. Please choose another username.";
                } else {
                    $hash = password_hash($pass, PASSWORD_BCRYPT);
                    $ins = $db->prepare("INSERT INTO users (username, password, role, name, status, email, phone) VALUES (:username, :password, :role, :name, 'ACTIVE', :email, :phone)");
                    $ins->execute([
                        'username' => $username,
                        'password' => $hash,
                        'role' => $role,
                        'name' => $name,
                        'email' => $email,
                        'phone' => $phone
                    ]);
                    $success_message = "User profile '$name' registered successfully in directory.";
                }
            } catch (PDOException $e) {
                $error_message = "Registration failed: " . $e->getMessage();
            }
        }
    }

    // Action B: Edit User
    if ($action === 'edit') {
        $id = (int)($_POST['id'] ?? 0);
        $name = sanitize($_POST['name'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $phone = sanitize($_POST['phone'] ?? '');
        $role = sanitize($_POST['role'] ?? 'CASHIER');
        $status = sanitize($_POST['status'] ?? 'ACTIVE');

        if ($id <= 0 || empty($name)) {
            $error_message = "Invalid parameters submitted.";
        } else {
            try {
                // Prevent editing self to inactive or cashier!
                if ($id === $_SESSION['user_id'] && ($role !== 'ADMIN' || $status !== 'ACTIVE')) {
                    $error_message = "Access Shield: You cannot alter your own admin role or set your account to Inactive.";
                } else {
                    $upd = $db->prepare("UPDATE users SET name = :name, email = :email, phone = :phone, role = :role, status = :status WHERE id = :id");
                    $upd->execute([
                        'name' => $name,
                        'email' => $email,
                        'phone' => $phone,
                        'role' => $role,
                        'status' => $status,
                        'id' => $id
                    ]);
                    $success_message = "User parameters updated successfully.";
                }
            } catch (PDOException $e) {
                $error_message = "Update failed: " . $e->getMessage();
            }
        }
    }

    // Action C: Delete User
    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id === $_SESSION['user_id']) {
            $error_message = "Access Shield: You cannot delete your own admin account while logged in.";
        } else {
            try {
                $del = $db->prepare("DELETE FROM users WHERE id = :id");
                $del->execute(['id' => $id]);
                $success_message = "User deleted successfully from databases.";
            } catch (PDOException $e) {
                $error_message = "Deletion failed: " . $e->getMessage();
            }
        }
    }
}

// 2. LOAD USER RECORDS
$users = [];
try {
    $users = $db->query("SELECT * FROM users ORDER BY name ASC")->fetchAll();
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<!-- Action Notifications -->
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo $error_message; ?></span>
    </div>
<?php endif; ?>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success">
        <i class="bx bx-check-circle"></i>
        <span><?php echo $success_message; ?></span>
    </div>
<?php endif; ?>

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <a href="settings.php#subsystems_link" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
            <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Settings Hub
        </a>
    </div>
    
    <div>
        <button type="button" class="btn btn-sm" style="width: auto; height: 44px;" onclick="openModal('addUserModal')">
            <i class="bx bx-plus-circle"></i> Register New User
        </button>
    </div>
</div>

<!-- ==========================================
     USER DIRECTORY GRID
     ========================================== -->
<div class="card">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Full Name</th>
                    <th>Username</th>
                    <th>User Role</th>
                    <th>Phone</th>
                    <th>Email Address</th>
                    <th>Status Badge</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($users as $u): ?>
                    <tr class="animate-fade">
                        <td><strong><?php echo htmlspecialchars($u['name']); ?></strong></td>
                        <td style="font-weight: 600; color:var(--accent);"><?php echo htmlspecialchars($u['username']); ?></td>
                        <td><span class="status-pill info"><?php echo htmlspecialchars($u['role']); ?></span></td>
                        <td><?php echo htmlspecialchars($u['phone'] ?: '-'); ?></td>
                        <td><?php echo htmlspecialchars($u['email'] ?: '-'); ?></td>
                        <td>
                            <?php if ($u['status'] === 'ACTIVE'): ?>
                                <span style="font-size: 10px; font-weight:700; padding:2px 8px; background:var(--accent-glow); color:var(--accent); border-radius:4px;">ACTIVE</span>
                            <?php else: ?>
                                <span style="font-size: 10px; font-weight:700; padding:2px 8px; background:var(--danger-glow); color:var(--danger); border-radius:4px;">INACTIVE</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="action-btns">
                                <button type="button" class="btn-action" title="Edit details" 
                                        onclick="triggerUserEditModal(<?php echo $u['id']; ?>, '<?php echo addslashes($u['name']); ?>', '<?php echo $u['phone']; ?>', '<?php echo $u['email']; ?>', '<?php echo $u['role']; ?>', '<?php echo $u['status']; ?>')">
                                    <i class="bx bx-edit"></i>
                                </button>
                                
                                <?php if ($u['id'] !== $_SESSION['user_id']): ?>
                                    <form method="POST" action="users.php" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this user profile?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $u['id']; ?>">
                                        <button type="submit" class="btn-action" title="Delete Profile" style="color:var(--error); border-color:var(--error-glow);">
                                            <i class="bx bx-trash"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ==========================================
     ADD USER REGISTER MODAL OVERLAY
     ========================================== -->
<div id="addUserModal" class="modal-overlay">
    <div class="modal-content" style="max-width: 520px;">
        <div class="modal-header">
            <h3>Register New Manager / Cashier</h3>
            <i class="bx bx-x modal-close" onclick="closeModal('addUserModal')"></i>
        </div>

        <form method="POST" action="users.php">
            <input type="hidden" name="action" value="add">

            <div class="form-group">
                <label class="form-label">Full Name *</label>
                <input type="text" name="name" class="form-control" style="padding-left:12px; height:44px;" required placeholder="e.g. Asif Khan">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div class="form-group">
                    <label class="form-label">Username *</label>
                    <input type="text" name="username" class="form-control" style="padding-left:12px; height:44px;" required placeholder="Unique Login ID">
                </div>
                <div class="form-group">
                    <label class="form-label">User Role</label>
                    <select name="role" class="select-control" style="width:100%; height:44px;">
                        <option value="CASHIER">Shop Cashier</option>
                        <option value="MANAGER">Shop Manager</option>
                        <option value="ADMIN">Shop Administrator</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Login Password *</label>
                <input type="password" name="password" class="form-control" style="padding-left:12px; height:44px;" required placeholder="Minimum 6 characters">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div class="form-group">
                    <label class="form-label">Phone Number</label>
                    <input type="text" name="phone" class="form-control" style="padding-left:12px; height:44px;" placeholder="03XXXXXXXXX">
                </div>
                <div class="form-group">
                    <label class="form-label">Email Address</label>
                    <input type="email" name="email" class="form-control" style="padding-left:12px; height:44px;" placeholder="asif@mbakar.com">
                </div>
            </div>

            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px; border-top:1.5px dashed var(--border-color); padding-top:15px;">
                <button type="button" class="btn btn-sm btn-secondary" onclick="closeModal('addUserModal')">Cancel</button>
                <button type="submit" class="btn btn-sm" style="width: auto;">Save User</button>
            </div>
        </form>
    </div>
</div>

<!-- ==========================================
     EDIT USER MODAL OVERLAY
     ========================================== -->
<div id="editUserModal" class="modal-overlay">
    <div class="modal-content" style="max-width: 520px;">
        <div class="modal-header">
            <h3>Update User Parameters</h3>
            <i class="bx bx-x modal-close" onclick="closeModal('editUserModal')"></i>
        </div>

        <form method="POST" action="users.php">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" id="edit_user_id" name="id">

            <div class="form-group">
                <label class="form-label">Full Name *</label>
                <input type="text" id="edit_name" name="name" class="form-control" style="padding-left:12px; height:44px;" required>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div class="form-group">
                    <label class="form-label">User Role</label>
                    <select id="edit_role" name="role" class="select-control" style="width:100%; height:44px;">
                        <option value="CASHIER">Shop Cashier</option>
                        <option value="MANAGER">Shop Manager</option>
                        <option value="ADMIN">Shop Administrator</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Account Status</label>
                    <select id="edit_status" name="status" class="select-control" style="width:100%; height:44px;">
                        <option value="ACTIVE">ACTIVE Account</option>
                        <option value="INACTIVE">INACTIVE Suspended</option>
                    </select>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div class="form-group">
                    <label class="form-label">Phone Number</label>
                    <input type="text" id="edit_phone" name="phone" class="form-control" style="padding-left:12px; height:44px;">
                </div>
                <div class="form-group">
                    <label class="form-label">Email Address</label>
                    <input type="email" id="edit_email" name="email" class="form-control" style="padding-left:12px; height:44px;">
                </div>
            </div>

            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px; border-top:1.5px dashed var(--border-color); padding-top:15px;">
                <button type="button" class="btn btn-sm btn-secondary" onclick="closeModal('editUserModal')">Cancel</button>
                <button type="submit" class="btn btn-sm" style="width: auto;">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
/**
 * Dynamic Modal Prefiller
 */
function triggerUserEditModal(id, name, phone, email, role, status) {
    document.getElementById('edit_user_id').value = id;
    document.getElementById('edit_name').value = name;
    document.getElementById('edit_phone').value = phone;
    document.getElementById('edit_email').value = email;
    document.getElementById('edit_role').value = role;
    document.getElementById('edit_status').value = status;
    openModal('editUserModal');
}
</script>

<!-- Subsystem JS -->
<script src="settings.js"></script>

<?php require_once 'includes/header.php'; ?>
