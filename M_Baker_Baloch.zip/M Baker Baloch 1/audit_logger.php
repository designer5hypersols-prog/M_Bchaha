<?php
/**
  * Advanced Security & Audit Trail System - Audit Logger
  * Shop Name: M.BAKAR BALOCH
  */

class AuditLogger {
    private static $db = null;

    /**
     * Set the database connection dependency
     */
    private static function initDB() {
        if (self::$db === null) {
            require_once __DIR__ . '/config/database.php';
            self::$db = (new Database())->connect();
            self::checkAndCreateTables();
        }
    }

    /**
     * Programmatically guarantee that the required security tables exist
     */
    private static function checkAndCreateTables() {
        try {
            // 1. activity_logs table
            self::$db->exec("CREATE TABLE IF NOT EXISTS `activity_logs` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT DEFAULT NULL,
                `action_type` VARCHAR(100) NOT NULL,
                `description` TEXT NOT NULL,
                `ip_address` VARCHAR(45) NOT NULL,
                `device_info` TEXT NOT NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            // 2. audit_trails table (JSON changes snapshot logs)
            self::$db->exec("CREATE TABLE IF NOT EXISTS `audit_trails` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT DEFAULT NULL,
                `table_name` VARCHAR(100) NOT NULL,
                `record_id` INT NOT NULL,
                `action_type` VARCHAR(50) NOT NULL,
                `before_snapshot` JSON DEFAULT NULL,
                `after_snapshot` JSON DEFAULT NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        } catch (PDOException $e) {
            // Fail silently or handle error gracefully
        }
    }

    /**
     * Get Client IP Address securely
     */
    public static function getIP() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        }
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1';
    }

    /**
     * Get User Agent details
     */
    public static function getDeviceInfo() {
        return isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Unknown Device';
    }

    /**
     * Log a general system or user action
     */
    public static function logActivity($action_type, $description) {
        self::initDB();
        
        $user_id = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
        $ip = self::getIP();
        $device = self::getDeviceInfo();

        try {
            $stmt = self::$db->prepare("INSERT INTO activity_logs (user_id, action_type, description, ip_address, device_info) 
                                        VALUES (:uid, :act, :descr, :ip, :dev)");
            $stmt->execute([
                'uid' => $user_id,
                'act' => $action_type,
                'descr' => $description,
                'ip' => $ip,
                'dev' => $device
            ]);
        } catch (PDOException $e) {}
    }

    /**
     * Log data changes with before-and-after snapshots (JSON format)
     */
    public static function logChange($table_name, $record_id, $action_type, $before_snapshot = null, $after_snapshot = null) {
        self::initDB();
        
        $user_id = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;

        try {
            $stmt = self::$db->prepare("INSERT INTO audit_trails (user_id, table_name, record_id, action_type, before_snapshot, after_snapshot) 
                                        VALUES (:uid, :tbl, :rec, :act, :before, :after)");
            $stmt->execute([
                'uid' => $user_id,
                'tbl' => $table_name,
                'rec' => (int)$record_id,
                'act' => $action_type,
                'before' => $before_snapshot ? json_encode($before_snapshot) : null,
                'after' => $after_snapshot ? json_encode($after_snapshot) : null
            ]);
        } catch (PDOException $e) {}
    }
}
