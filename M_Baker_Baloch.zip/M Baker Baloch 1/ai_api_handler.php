<?php
/**
 * AI Smart Assistant - Backend API Handler (Module 3)
 * Shop Name: M.BAKAR BALOCH
 */

header('Content-Type: application/json');

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();

// 1. VERIFY SYSTEM RIGHTS
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized access.']);
    exit;
}

// 2. SELF-HEALING DATABASE MIGRATION CHECK FOR AI TABLES
try {
    $db->query("SELECT 1 FROM ai_chat_history LIMIT 1");
} catch (PDOException $e) {
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS `ai_chat_history` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT NOT NULL,
            `sender` ENUM('USER', 'ASSISTANT') NOT NULL,
            `message` TEXT NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        
        $db->exec("CREATE TABLE IF NOT EXISTS `ai_logs` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT DEFAULT NULL,
            `query_string` TEXT NOT NULL,
            `detected_action` VARCHAR(100) DEFAULT NULL,
            `ip_address` VARCHAR(45) DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch(PDOException $ex) {}
}

// 3. READ USER QUERY INPUT
$raw_input = file_get_contents('php://input');
$input_data = json_decode($raw_input, true);
$query = sanitize($input_data['message'] ?? '');

if (empty($query)) {
    echo json_encode(['reply' => 'Aapne koi sawal nahi pucha. Please ask me a question about M.BAKAR BALOCH.']);
    exit;
}

$reply = "";
$action_code = "UNKNOWN";

// Normalize query to lowercase for regex keyword checking
$q_lower = strtolower($query);

// 4. PARSE QUESTIONS DYNAMICALLY AND RUN SAFE READ-ONLY QUERIES
try {
    
    // CASE A: Sales queries ("sales", "aaj ki sales", "today sales", "kitni hui")
    if (preg_match('/\b(sale|sales|aaj|today|turnover|turn-over|bikri)\b/', $q_lower)) {
        $action_code = "CHECK_SALES";
        
        $todays_sales = $db->query("SELECT SUM(payable_amount) FROM sales WHERE sale_date = CURRENT_DATE()")->fetchColumn() ?: 0.00;
        $monthly_sales = $db->query("SELECT SUM(payable_amount) FROM sales WHERE MONTH(sale_date) = MONTH(CURRENT_DATE()) AND YEAR(sale_date) = YEAR(CURRENT_DATE())")->fetchColumn() ?: 0.00;
        
        $reply = "Aapki **M.BAKAR BALOCH** shop par aaj ki total sales **Rs. " . number_format($todays_sales, 2) . "** hui hai.\nAur is current month ki total turnover sales **Rs. " . number_format($monthly_sales, 2) . "** hai.";
    }
    
    // CASE B: Low Stock Warning ("stock", "qty", "quantity", "kam", "low stock", "kaun se")
    elseif (preg_match('/\b(stock|low|kam|quantities|quantity|brooms|wipers|brushes|utensils)\b/', $q_lower)) {
        $action_code = "CHECK_STOCK";
        
        $low_items = $db->query("SELECT name, stock_qty, min_stock_qty, unit FROM products WHERE stock_qty <= min_stock_qty AND status = 'ACTIVE' ORDER BY stock_qty ASC LIMIT 5")->fetchAll();
        
        if (empty($low_items)) {
            $reply = "MashaAllah! Warehouse inventory registers full normal state. Koi product low stock warning state mein nahi hai.";
        } else {
            $reply = "Ye hain top low stock warning inventory items:\n\n";
            foreach ($low_items as $item) {
                $reply .= "- **" . $item['name'] . "**: " . $item['stock_qty'] . " " . $item['unit'] . " left (Alert threshold: " . $item['min_stock_qty'] . ")\n";
            }
            $reply .= "\nRestock items add karne ke liye purchases tab select karein.";
        }
    }
    
    // CASE C: Net Profit overview ("profit", "faida", "loss", "net profit", "monetary")
    elseif (preg_match('/\b(profit|faida|loss|net profit|yield|kamai|margin)\b/', $q_lower)) {
        $action_code = "CHECK_PROFIT";
        
        $m_sales = $db->query("SELECT SUM(payable_amount) FROM sales WHERE MONTH(sale_date) = MONTH(CURRENT_DATE()) AND YEAR(sale_date) = YEAR(CURRENT_DATE())")->fetchColumn() ?: 0.00;
        $m_purchases = $db->query("SELECT SUM(payable_amount) FROM purchases WHERE MONTH(purchase_date) = MONTH(CURRENT_DATE()) AND YEAR(purchase_date) = YEAR(CURRENT_DATE())")->fetchColumn() ?: 0.00;
        $m_expenses = $db->query("SELECT SUM(amount) FROM expenses WHERE MONTH(expense_date) = MONTH(CURRENT_DATE()) AND YEAR(expense_date) = YEAR(CURRENT_DATE())")->fetchColumn() ?: 0.00;
        
        $net_profit = $m_sales - $m_purchases - $m_expenses;
        
        $reply = "Is active month ka dynamic margin overview:\n\n" .
                 "- **Total Turnover Sales**: Rs. " . number_format($m_sales, 2) . "\n" .
                 "- **Total Purchases Cost**: Rs. " . number_format($m_purchases, 2) . "\n" .
                 "- **Total Expenses Overhead**: Rs. " . number_format($m_expenses, 2) . "\n\n" .
                 "💵 **Estimated Net Yield (Profit)**: **Rs. " . number_format($net_profit, 2) . "**.";
    }
    
    // CASE D: Customer Credit Dues ledger ("customer", "ledger", "udhar", "outstanding", "due")
    elseif (preg_match('/\b(customer|ledger|udhar|borrow|due|outstanding|payment)\b/', $q_lower)) {
        $action_code = "CHECK_LEDGER";
        
        $top_debtors = $db->query("SELECT name, phone, balance FROM customers WHERE balance > 0 ORDER BY balance DESC LIMIT 4")->fetchAll();
        
        if (empty($top_debtors)) {
            $reply = "Aapke customers directory mein koi udhar dues receivables pending nahi hai. Sab paid statuses active hain!";
        } else {
            $reply = "Ye hain top outstanding receivables balances wale customers:\n\n";
            foreach ($top_debtors as $c) {
                $reply .= "- **" . $c['name'] . "** (" . ($c['phone'] ?: 'No Phone') . "): **Rs. " . number_format($c['balance'], 2) . "** udhar outstanding.\n";
            }
            $reply .= "\nLedger updates or settle entries process karne ke liye Customers panel select karein.";
        }
    }
    
    // CASE E: DEFAULT BOT EXPLANATION HANDLER
    else {
        $reply = "Hello! Main aapka **M.BAKAR BALOCH AI Smart Assistant** helper bot hoon. 🙋‍♂️\nAap mujhse real-time sales values, low warehouse stock quantities, operational margins profit, ya customer balances ledgers reports ke baare mein sawal puch sakte hain!\n\n**Jaise sawal puchen:**\n- *'aaj ki total sales kitni hui?'*\n- *'low stock products show karo'*\n- *'is month profit kitna hua?'*\n- *'outstanding udhar customers list'*";
    }

    // 5. REGISTER LOG & PERSIST CHAT MESSAGES HISTORIES IN MYSQL
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    
    // Save AI Log
    $log = $db->prepare("INSERT INTO ai_logs (user_id, query_string, detected_action, ip_address) VALUES (:u_id, :query, :action, :ip)");
    $log->execute(['u_id' => $_SESSION['user_id'], 'query' => $query, 'action' => $action_code, 'ip' => $ip]);
    
    // Save User Query in chat history
    $h_user = $db->prepare("INSERT INTO ai_chat_history (user_id, sender, message) VALUES (:u_id, 'USER', :msg)");
    $h_user->execute(['u_id' => $_SESSION['user_id'], 'msg' => $query]);
    
    // Save AI Reply in chat history
    $h_ai = $db->prepare("INSERT INTO ai_chat_history (user_id, sender, message) VALUES (:u_id, 'ASSISTANT', :msg)");
    $h_ai->execute(['u_id' => $_SESSION['user_id'], 'msg' => $reply]);

    // Send JSON Response
    echo json_encode(['reply' => $reply]);

} catch (PDOException $e) {
    echo json_encode(['reply' => 'Database aggregate error: ' . $e->getMessage()]);
}
