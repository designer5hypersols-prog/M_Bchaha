<?php
/**
 * Logout Session Controller
 * Shop Management System: M.BAKAR BALOCH
 */

require_once 'config/config.php';

require_once 'security_engine.php';
require_once 'audit_logger.php';

// Log successful sign out and flush token from DB
if (isset($_SESSION['session_token'])) {
    AuditLogger::logActivity("LOGOUT", "Operator successfully signed out.");
    SecurityEngine::removeSessionFromDB($_SESSION['session_token']);
}

// Unset all session variables
$_SESSION = [];

// Destroy session cookie if present
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Clear Remember Me auto-login cookies
if (isset($_COOKIE['remember_me'])) {
    setcookie('remember_me', '', time() - 3600, "/");
}

// Destroy active PHP session
session_destroy();

// Redirect back to login page
header("Location: login.php");
exit;
