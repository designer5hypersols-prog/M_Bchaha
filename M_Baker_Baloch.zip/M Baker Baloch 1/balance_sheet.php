<?php
/**
 * Double Entry Accounting Subsystem - Balance Sheet (Module 7)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();

// Enforce Access
if ($_SESSION['user_role'] !== 'ADMIN' && $_SESSION['user_role'] !== 'MANAGER') {
    die("Access Denied: You must be an Administrator or Manager to compile financial statements.");
}

$as_of_date = sanitize($_GET['as_of_date'] ?? date('Y-m-d'));

$assets = [];
$liabilities = [];
$equity = [];

$total_assets = 0.00;
$total_liabilities = 0.00;
$total_equity = 0.00;

try {
    // 1. PULL ALL ACTIVE ACCOUNTS WITH BALANCES
    $stmt = $db->prepare("SELECT a.*, 
                                 COALESCE(SUM(ji.debit), 0.00) as total_debit, 
                                 COALESCE(SUM(ji.credit), 0.00) as total_credit 
                          FROM accounts a 
                          LEFT JOIN journal_items ji ON a.id = ji.account_id 
                          LEFT JOIN journal_entries je ON ji.journal_entry_id = je.id
                          WHERE je.entry_date <= :as_of OR je.entry_date IS NULL
                          GROUP BY a.id");
    $stmt->execute(['as_of' => $as_of_date]);
    $raw_accounts = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculate balances according to account types
    foreach ($raw_accounts as $acc) {
        $db_val = (float)$acc['total_debit'];
        $cr_val = (float)$acc['total_credit'];
        
        $balance = 0.00;
        $is_debit_nature = in_array($acc['type'], ['ASSET', 'EXPENSE']);
        
        if ($is_debit_nature) {
            $balance = $db_val - $cr_val;
        } else {
            $balance = $cr_val - $db_val;
        }

        if ($acc['type'] === 'ASSET') {
            $assets[] = ['code' => $acc['code'], 'name' => $acc['name'], 'balance' => $balance];
            $total_assets += $balance;
        } elseif ($acc['type'] === 'LIABILITY') {
            $liabilities[] = ['code' => $acc['code'], 'name' => $acc['name'], 'balance' => $balance];
            $total_liabilities += $balance;
        } elseif ($acc['type'] === 'EQUITY') {
            $equity[] = ['code' => $acc['code'], 'name' => $acc['name'], 'balance' => $balance];
            $total_equity += $balance;
        }
    }

    // 2. DYNAMICALLY PULL CURRENT PERIOD NET PROFIT TO ALIGN BALANCES (RETAINED EARNINGS INTEGRITY)
    // Income
    $stmt_i = $db->prepare("SELECT COALESCE(SUM(ji.credit) - SUM(ji.debit), 0.00) 
                            FROM journal_items ji JOIN accounts a ON ji.account_id = a.id
                            LEFT JOIN journal_entries je ON ji.journal_entry_id = je.id
                            WHERE a.type = 'INCOME' AND je.entry_date <= :as_of");
    $stmt_i->execute(['as_of' => $as_of_date]);
    $period_inc = (float)$stmt_i->fetchColumn();

    // Expenses
    $stmt_e = $db->prepare("SELECT COALESCE(SUM(ji.debit) - SUM(ji.credit), 0.00) 
                            FROM journal_items ji JOIN accounts a ON ji.account_id = a.id
                            LEFT JOIN journal_entries je ON ji.journal_entry_id = je.id
                            WHERE a.type = 'EXPENSE' AND je.entry_date <= :as_of");
    $stmt_e->execute(['as_of' => $as_of_date]);
    $period_exp = (float)$stmt_e->fetchColumn();

    $net_period_profit = $period_inc - $period_exp;

    // Append to total equity to reflect current operations (GAAP standards)
    $total_equity += $net_period_profit;

} catch(PDOException $e) {}

$total_liabilities_equity = $total_liabilities + $total_equity;
$is_aligned = abs($total_assets - $total_liabilities_equity) < 0.05;

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<!-- ==========================================
     A. DATE FILTER
     ========================================== -->
<div class="card" style="margin-bottom:24px; padding:16px;">
    <form method="GET" action="balance_sheet.php" style="display:flex; gap:16px; align-items:flex-end; flex-wrap:wrap;">
        <div style="flex-grow:1; min-width:200px;">
            <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">As of Date</label>
            <input type="date" name="as_of_date" value="<?php echo $as_of_date; ?>" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;">
        </div>

        <div>
            <button type="submit" class="btn" style="background:var(--accent); border-color:var(--accent); height:40px; width:auto; font-size:13.5px; padding:0 24px;">
                <i class="bx bx-filter" style="margin-right:4px;"></i> Fetch Statement
            </button>
        </div>
    </form>
</div>

<!-- ==========================================
     B. BALANCE SHEET REPORT CARD
     ========================================== -->
<div class="card" style="max-width: 850px; margin: 0 auto;">
    <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color); display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
        <div class="card-title">
            <i class="bx bx-receipt" style="color:var(--accent);"></i>
            <span>Corporate Balance Sheet (Statement of Financial Position)</span>
        </div>
        <button type="button" class="btn btn-sm" onclick="window.print()" style="background:var(--bg-secondary); border-color:var(--border-color); height:30px; width:auto; font-size:11px; padding:0 12px; color:var(--text-main);">
            <i class="bx bx-printer" style="margin-right:4px;"></i> Print
        </button>
    </div>

    <!-- Alignment Double check info -->
    <?php if ($is_aligned): ?>
        <div style="background:var(--accent-glow); color:var(--accent); padding:10px 14px; font-size:12px; border-radius:4px; font-weight:700; margin-bottom:20px; display:inline-flex; align-items:center; gap:6px;">
            <i class="bx bx-check-shield"></i> Balance Sheet is perfectly aligned: Assets = Liabilities + Equity
        </div>
    <?php else: ?>
        <div style="background:var(--danger-glow); color:var(--danger); padding:10px 14px; font-size:12px; border-radius:4px; font-weight:700; margin-bottom:20px; display:inline-flex; align-items:center; gap:6px;">
            <i class="bx bx-error"></i> Balance sheet out of alignment. Difference: Rs. <?php echo number_format(abs($total_assets - $total_liabilities_equity), 2); ?>
        </div>
    <?php endif; ?>

    <div style="display:grid; grid-template-columns:1fr 1fr; gap:30px;">
        
        <!-- COLUMN LEFT: ASSETS -->
        <div>
            <div style="font-weight:800; font-size:15px; color:var(--text-main); border-bottom:2px solid var(--border-color); padding-bottom:4px; margin-bottom:12px; text-transform:uppercase;">ASSETS</div>
            <div style="display:flex; flex-direction:column; gap:10px;">
                <?php foreach($assets as $ass): ?>
                    <div style="display:flex; justify-content:space-between; font-size:13.5px;">
                        <span><?php echo htmlspecialchars($ass['name']); ?> (<?php echo $ass['code']; ?>)</span>
                        <strong>Rs. <?php echo number_format($ass['balance'], 2); ?></strong>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div style="display:flex; justify-content:space-between; margin-top:30px; border-top:1.5px solid var(--border-color); padding-top:10px; font-weight:900; font-size:15px; color:var(--accent);">
                <span>TOTAL ASSETS</span>
                <span>Rs. <?php echo number_format($total_assets, 2); ?></span>
            </div>
        </div>

        <!-- COLUMN RIGHT: LIABILITIES & EQUITY -->
        <div>
            <div style="font-weight:800; font-size:15px; color:var(--text-main); border-bottom:2px solid var(--border-color); padding-bottom:4px; margin-bottom:12px; text-transform:uppercase;">LIABILITIES</div>
            <div style="display:flex; flex-direction:column; gap:10px; margin-bottom:24px;">
                <?php foreach($liabilities as $lia): ?>
                    <div style="display:flex; justify-content:space-between; font-size:13.5px;">
                        <span><?php echo htmlspecialchars($lia['name']); ?> (<?php echo $lia['code']; ?>)</span>
                        <strong>Rs. <?php echo number_format($lia['balance'], 2); ?></strong>
                    </div>
                <?php endforeach; ?>
                <div style="display:flex; justify-content:space-between; border-top:1px solid var(--border-color); padding-top:8px; font-size:12.5px; font-weight:700;">
                    <span>Liabilities Total</span>
                    <span>Rs. <?php echo number_format($total_liabilities, 2); ?></span>
                </div>
            </div>

            <div style="font-weight:800; font-size:15px; color:var(--text-main); border-bottom:2px solid var(--border-color); padding-bottom:4px; margin-bottom:12px; text-transform:uppercase;">OWNER EQUITY</div>
            <div style="display:flex; flex-direction:column; gap:10px;">
                <?php foreach($equity as $eq): ?>
                    <div style="display:flex; justify-content:space-between; font-size:13.5px;">
                        <span><?php echo htmlspecialchars($eq['name']); ?> (<?php echo $eq['code']; ?>)</span>
                        <strong>Rs. <?php echo number_format($eq['balance'], 2); ?></strong>
                    </div>
                <?php endforeach; ?>

                <!-- Current Net profit row -->
                <div style="display:flex; justify-content:space-between; font-size:13.5px;">
                    <span>Current period Net Profit / (Loss)</span>
                    <strong>Rs. <?php echo number_format($net_period_profit, 2); ?></strong>
                </div>
            </div>
            
            <div style="display:flex; justify-content:space-between; margin-top:19px; border-top:1.5px solid var(--border-color); padding-top:10px; font-weight:900; font-size:15px; color:var(--text-main);">
                <span>TOTAL LIABILITIES & EQUITY</span>
                <span style="color:var(--accent);">Rs. <?php echo number_format($total_liabilities_equity, 2); ?></span>
            </div>
        </div>

    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
