<?php
/**
 * POS Billing Terminal - Thermal Receipt Print Page
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

$db = (new Database())->connect();
$id = (int)($_GET['id'] ?? 0);

try {
    // 1. Fetch Sales Invoice Header Details
    $stmt = $db->prepare("SELECT s.*, c.name as customer_name, c.phone as customer_phone, c.address as customer_address FROM sales s LEFT JOIN customers c ON s.customer_id = c.id WHERE s.id = :id LIMIT 1");
    $stmt->execute(['id' => $id]);
    $sale = $stmt->fetch();

    if (!$sale) {
        die("Sales Invoice transaction ID '$id' was not found in database.");
    }

    // 2. Fetch Sales Invoice Line Items
    $items_stmt = $db->prepare("SELECT si.*, p.name as product_name, p.sku as product_sku FROM sale_items si JOIN products p ON si.product_id = p.id WHERE si.sale_id = :id");
    $items_stmt->execute(['id' => $id]);
    $items = $items_stmt->fetchAll();

    // 3. Fetch Shop General Settings
    $shop_name = $db->query("SELECT key_value FROM settings WHERE key_name = 'shop_name' LIMIT 1")->fetchColumn() ?: BRAND_NAME;
    $shop_phone = $db->query("SELECT key_value FROM settings WHERE key_name = 'shop_phone' LIMIT 1")->fetchColumn() ?: '+92 300 1234567';
    $shop_email = $db->query("SELECT key_value FROM settings WHERE key_name = 'shop_email' LIMIT 1")->fetchColumn() ?: 'info@mbakarbaloch.com';
    $shop_address = $db->query("SELECT key_value FROM settings WHERE key_name = 'shop_address' LIMIT 1")->fetchColumn() ?: 'Main Bazar Road, Plastic Market, Balochistan, Pakistan';
    $tax_rate = (float)($db->query("SELECT key_value FROM settings WHERE key_name = 'tax_rate' LIMIT 1")->fetchColumn() ?: 0);

} catch (PDOException $e) {
    die("Database query failure: " . $e->getMessage());
}

// Calculate financial tallies
$subtotal = 0;
foreach($items as $i) {
    $subtotal += $i['price'] * $i['qty'];
}
$tax_amount = $subtotal * ($tax_rate / 100);
$grand_total = $sale['payable_amount'];
$change = (float)$sale['paid_amount'] - $grand_total;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt - <?php echo htmlspecialchars($sale['invoice_no']); ?></title>
    <!-- Include Subsystem Styles -->
    <link rel="stylesheet" href="invoice.css">
    <style>
        body {
            background: #f1f5f9;
            margin: 0;
            padding: 20px;
            font-family: 'Courier New', Courier, monospace;
        }

        .receipt-card {
            background: #ffffff;
            max-width: 320px; /* Standard 80mm printer size */
            margin: 0 auto;
            padding: 20px;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            border: 1px solid #e2e8f0;
        }

        .receipt-header {
            text-align: center;
            margin-bottom: 18px;
        }

        .receipt-header h2 {
            margin: 0 0 5px 0;
            font-size: 19px;
            font-weight: 800;
            color: #0f172a;
        }

        .receipt-header p {
            margin: 2px 0;
            font-size: 11px;
            color: #64748b;
        }

        .divider {
            border-top: 1px dashed #cbd5e1;
            margin: 12px 0;
        }

        .meta-row {
            display: flex;
            justify-content: space-between;
            font-size: 11.5px;
            margin-bottom: 5px;
            color: #1e293b;
        }

        .items-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 11.5px;
            margin-top: 10px;
        }

        .items-table th {
            text-align: left;
            border-bottom: 1.5px solid #0f172a;
            padding-bottom: 6px;
            font-weight: 700;
        }

        .items-table td {
            padding: 6px 0;
            vertical-align: top;
        }

        .totals-table {
            width: 100%;
            font-size: 11.5px;
            margin-top: 12px;
        }

        .totals-table td {
            padding: 3px 0;
        }

        .totals-table tr.grand-total td {
            font-size: 13.5px;
            font-weight: 800;
            color: #0f172a;
            border-top: 1.5px solid #0f172a;
            padding-top: 6px;
        }

        .receipt-footer {
            text-align: center;
            margin-top: 24px;
            font-size: 11px;
            color: #64748b;
        }

        /* Print Override buttons styles */
        .btn-print-action {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 8px 16px;
            background: #0f172a;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-family: inherit;
            font-size: 12px;
            font-weight: 600;
            margin-top: 15px;
            width: 100%;
            text-decoration: none;
        }

        .btn-print-action.secondary {
            background: #f1f5f9;
            color: #334155;
            border: 1px solid #cbd5e1;
            margin-top: 8px;
        }

        @media print {
            body {
                background: white !important;
                padding: 0 !important;
            }
            .receipt-card {
                box-shadow: none !important;
                border: none !important;
                max-width: 100% !important;
                padding: 0 !important;
            }
            .no-print {
                display: none !important;
            }
        }
    </style>
</head>
<body onload="window.print()">

    <div class="receipt-card">
        
        <!-- Shop Logo & Details -->
        <div class="receipt-header">
            <h2><?php echo htmlspecialchars($shop_name); ?></h2>
            <p>Plastic & Household Goods</p>
            <p style="font-size: 10px;"><?php echo htmlspecialchars($shop_address); ?></p>
            <p style="font-size: 10px;">Phone: <?php echo htmlspecialchars($shop_phone); ?></p>
        </div>

        <div class="divider"></div>

        <!-- Receipt Metadata -->
        <div class="meta-row">
            <span>Invoice No:</span>
            <strong><?php echo htmlspecialchars($sale['invoice_no']); ?></strong>
        </div>
        <div class="meta-row">
            <span>Sale Date:</span>
            <strong><?php echo format_date($sale['sale_date']); ?></strong>
        </div>
        <div class="meta-row">
            <span>Customer:</span>
            <strong><?php echo htmlspecialchars($sale['customer_name'] ?: 'Walk-in Customer'); ?></strong>
        </div>
        <?php if (!empty($sale['customer_phone'])): ?>
            <div class="meta-row">
                <span>Phone:</span>
                <strong><?php echo htmlspecialchars($sale['customer_phone']); ?></strong>
            </div>
        <?php endif; ?>
        <div class="meta-row">
            <span>Cashier:</span>
            <strong>Admin Operator</strong>
        </div>

        <div class="divider"></div>

        <!-- Line items table -->
        <table class="items-table">
            <thead>
                <tr>
                    <th>Item Description</th>
                    <th style="text-align: center;">Qty</th>
                    <th style="text-align: right;">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($items as $item): 
                    $total_item_val = $item['price'] * $item['qty'];
                ?>
                    <tr>
                        <td>
                            <?php echo htmlspecialchars($item['product_name']); ?>
                            <span style="display:block; font-size:9.5px; color:#64748b;">SKU: <?php echo htmlspecialchars($item['product_sku']); ?></span>
                        </td>
                        <td style="text-align: center;"><?php echo $item['qty']; ?></td>
                        <td style="text-align: right;"><?php echo format_currency($total_item_val); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="divider"></div>

        <!-- Calculations table totals -->
        <table class="totals-table">
            <tr>
                <td>Subtotal Gross:</td>
                <td style="text-align: right;"><?php echo format_currency($subtotal); ?></td>
            </tr>
            <tr>
                <td>Estimated Tax (<?php echo $tax_rate; ?>%):</td>
                <td style="text-align: right;"><?php echo format_currency($tax_amount); ?></td>
            </tr>
            <?php if ($sale['discount'] > 0): ?>
                <tr style="color: #b91c1c;">
                    <td>Discounts (-) :</td>
                    <td style="text-align: right;">- <?php echo format_currency($sale['discount']); ?></td>
                </tr>
            <?php endif; ?>
            
            <tr class="grand-total">
                <td>Net Total:</td>
                <td style="text-align: right;"><?php echo format_currency($grand_total); ?></td>
            </tr>
            
            <tr>
                <td style="padding-top: 8px;">Cash Received:</td>
                <td style="text-align: right; padding-top: 8px; font-weight: 700;"><?php echo format_currency($sale['paid_amount']); ?></td>
            </tr>

            <?php if ($change >= 0): ?>
                <tr>
                    <td>Return Change:</td>
                    <td style="text-align: right; font-weight: 700; color: #15803d;"><?php echo format_currency($change); ?></td>
                </tr>
            <?php else: ?>
                <tr style="color: #b91c1c;">
                    <td>Remaining Balance Owed:</td>
                    <td style="text-align: right; font-weight: 700;"><?php echo format_currency(abs($change)); ?></td>
                </tr>
            <?php endif; ?>
            
            <tr>
                <td>Payment Method:</td>
                <td style="text-align: right; text-transform: uppercase;"><strong><?php echo htmlspecialchars($sale['payment_method']); ?></strong></td>
            </tr>
        </table>

        <div class="divider"></div>

        <!-- Footer -->
        <div class="receipt-footer">
            <p>Thank you for shopping at M.BAKAR BALOCH!</p>
            <p>Please keep this receipt for warranty returns.</p>
            <p style="font-size: 8px; margin-top:10px;">ERP software developed dynamically.</p>
        </div>

        <!-- Actions visible only on A4 screen layout -->
        <div class="no-print" style="margin-top: 20px; border-top: 1px dashed #cbd5e1; padding-top: 15px;">
            <button type="button" class="btn-print-action" onclick="window.print()"><i class="bx bx-printer"></i> Reprint Receipt</button>
            <a href="create_invoice.php" class="btn-print-action secondary"><i class="bx bx-plus-circle"></i> Back to POS Terminal</a>
            <a href="sales.php" class="btn-print-action secondary"><i class="bx bx-left-arrow-alt"></i> Back to Sales Hub</a>
        </div>

    </div>

</body>
</html>
