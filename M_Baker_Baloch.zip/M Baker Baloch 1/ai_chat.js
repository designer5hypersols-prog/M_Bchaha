/**
 * AI Smart Assistant Client Controller - Interactive chat drawers triggers (Module 2)
 * Shop Name: M.BAKAR BALOCH
 */

document.addEventListener('DOMContentLoaded', () => {
    const trigger = document.getElementById('aiChatTrigger');
    const panel = document.getElementById('aiChatPanel');
    const closeBtn = document.getElementById('aiChatClose');
    const sendBtn = document.getElementById('aiSendBtn');
    const chatInput = document.getElementById('aiChatInput');
    const messagesContainer = document.getElementById('aiChatMessages');

    if (!trigger || !panel) return;

    // 1. Toggle Panel open/close
    trigger.addEventListener('click', () => {
        panel.classList.toggle('active');
        // Scroll to bottom when opening
        setTimeout(scrollToBottom, 200);
    });

    closeBtn.addEventListener('click', () => {
        panel.classList.remove('active');
    });

    // 2. Click send button or press enter
    sendBtn.addEventListener('click', submitUserMessage);
    chatInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            submitUserMessage();
        }
    });

    /**
     * Submit user query to backend handler
     */
    function submitUserMessage() {
        const query = chatInput.value.trim();
        if (query === "") return;

        // Clear input field
        chatInput.value = "";

        // Append User bubble
        appendMessage('USER', query);
        scrollToBottom();

        // Show typing indicator dot bubble
        showTypingIndicator();
        scrollToBottom();

        // Send HTTP Fetch Query
        fetch('ai_api_handler.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: query })
        })
        .then(response => response.json())
        .then(data => {
            removeTypingIndicator();
            if (data.reply) {
                appendMessage('ASSISTANT', data.reply);
            } else {
                appendMessage('ASSISTANT', 'Error: System could not formulate response.');
            }
            scrollToBottom();
        })
        .catch(err => {
            removeTypingIndicator();
            appendMessage('ASSISTANT', 'Database connection error. Please try again.');
            scrollToBottom();
        });
    }

    /**
     * Append bubble message inside the scrolling container
     */
    function appendMessage(sender, text) {
        const msgDiv = document.createElement('div');
        msgDiv.className = `ai-message ${sender.toLowerCase()} animate-fade`;
        
        // Convert double asterisks to strong markup and newlines to breaks
        let formatted = text
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\n/g, '<br>');

        msgDiv.innerHTML = formatted;

        // Append time tag
        const timeSpan = document.createElement('span');
        timeSpan.className = 'ai-time';
        const now = new Date();
        timeSpan.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        msgDiv.appendChild(timeSpan);

        messagesContainer.appendChild(msgDiv);
    }

    /**
     * Show Typing indicators dots
     */
    function showTypingIndicator() {
        const bubble = document.createElement('div');
        bubble.id = 'aiTypingBubble';
        bubble.className = 'ai-typing-bubble assistant animate-fade';
        bubble.innerHTML = `
            <div class="ai-typing-dot"></div>
            <div class="ai-typing-dot"></div>
            <div class="ai-typing-dot"></div>
        `;
        messagesContainer.appendChild(bubble);
    }

    /**
     * Delete Typing indicators dots
     */
    function removeTypingIndicator() {
        const bubble = document.getElementById('aiTypingBubble');
        if (bubble) {
            bubble.remove();
        }
    }

    /**
     * Auto scroll to latest bubble entry
     */
    function scrollToBottom() {
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
});

/**
 * Handle quick chip clicks
 */
function submitAiQuickQuery(queryString) {
    const chatInput = document.getElementById('aiChatInput');
    if (chatInput) {
        chatInput.value = queryString;
        document.getElementById('aiSendBtn').click();
    }
}
