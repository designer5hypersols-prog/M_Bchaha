<?php
/**
 * Double Entry Accounting Subsystem - Automation Engine (Module 8)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

class AccountingEngine {
    private $db;

    public function __construct($dbConnection = null) {
        $this->db = $dbConnection ?: (new Database())->connect();
        $this->selfHealAndSeed();
    }

    /**
     * Verifies tables exist and seeds standard accounts
     */
    private function selfHealAndSeed() {
        try {
            $this->db->query("SELECT 1 FROM accounts LIMIT 1");
        } catch (PDOException $e) {
            try {
                // Create Accounts Table
                $this->db->exec("CREATE TABLE IF NOT EXISTS `accounts` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `code` VARCHAR(20) NOT NULL UNIQUE,
                    `name` VARCHAR(100) NOT NULL,
                    `type` ENUM('ASSET', 'LIABILITY', 'EQUITY', 'INCOME', 'EXPENSE') NOT NULL,
                    `description` TEXT DEFAULT NULL,
                    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

                $this->db->exec("CREATE TABLE IF NOT EXISTS `journal_entries` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `entry_date` DATE NOT NULL,
                    `reference_no` VARCHAR(100) DEFAULT NULL,
                    `description` TEXT DEFAULT NULL,
                    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

                $this->db->exec("CREATE TABLE IF NOT EXISTS `journal_items` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `journal_entry_id` INT NOT NULL,
                    `account_id` INT NOT NULL,
                    `debit` DECIMAL(15, 2) NOT NULL DEFAULT 0.00,
                    `credit` DECIMAL(15, 2) NOT NULL DEFAULT 0.00,
                    FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE CASCADE,
                    FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE RESTRICT
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

                // Seed Default Standard Accounts
                $this->db->exec("INSERT IGNORE INTO accounts (code, name, type, description) VALUES 
                    ('1010', 'Cash Account', 'ASSET', 'Physical store register cash reserves'),
                    ('1020', 'Bank Balance', 'ASSET', 'Online bank deposits and payment gateway assets'),
                    ('1200', 'Accounts Receivable (Udhar)', 'ASSET', 'Outstanding customer receivables ledger'),
                    ('1300', 'Inventory Assets', 'ASSET', 'Valuation of plastic products and warehouse stock'),
                    ('2100', 'Accounts Payable', 'LIABILITY', 'Outstanding vendor and supplier payables'),
                    ('3000', 'Owner Capital', 'EQUITY', 'Initial shop investment capital'),
                    ('3100', 'Retained Earnings', 'EQUITY', 'Undistributed cumulative store net margins'),
                    ('4100', 'Sales Revenue', 'INCOME', 'Turnover earned from POS checkouts'),
                    ('5100', 'Cost of Goods Sold (COGS)', 'EXPENSE', 'Direct procurement cost of products sold'),
                    ('5200', 'Operating Expenses', 'EXPENSE', 'Store bills, wages, packaging, and general losses')");
            } catch(PDOException $ex) {}
        }
    }

    /**
     * Posts a manual or automated Double Entry Journal Entry
     * Every entry items must be array of: ['code' => '1010', 'debit' => 500, 'credit' => 0]
     */
    public function postJournalEntry($date, $ref, $desc, $items) {
        $total_debit = 0.00;
        $total_credit = 0.00;

        foreach ($items as $item) {
            $total_debit += (float)($item['debit'] ?? 0.00);
            $total_credit += (float)($item['credit'] ?? 0.00);
        }

        // 1. ENFORCE DOUBLE ENTRY EQUALITY RULE
        if (abs($total_debit - $total_credit) > 0.01) {
            throw new Exception("Accounting Balance Rule Violated: Sum of Debits (Rs. $total_debit) must exactly equal Sum of Credits (Rs. $total_credit). Difference: " . abs($total_debit - $total_credit));
        }

        try {
            $this->db->beginTransaction();

            // Insert Header
            $ins_head = $this->db->prepare("INSERT INTO journal_entries (entry_date, reference_no, description) VALUES (:date, :ref, :desc)");
            $ins_head->execute([
                'date' => $date,
                'ref' => $ref,
                'desc' => $desc
            ]);
            $entry_id = $this->db->lastInsertId();

            // Insert Items
            $ins_item = $this->db->prepare("INSERT INTO journal_items (journal_entry_id, account_id, debit, credit) 
                                            VALUES (:entry_id, (SELECT id FROM accounts WHERE code = :code LIMIT 1), :debit, :credit)");

            foreach ($items as $item) {
                $ins_item->execute([
                    'entry_id' => $entry_id,
                    'code' => $item['code'],
                    'debit' => (float)$item['debit'],
                    'credit' => (float)$item['credit']
                ]);
            }

            $this->db->commit();
            return $entry_id;
        } catch (PDOException $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            throw $e;
        }
    }

    /**
     * Auto Post Sales Invoices
     */
    public function postSalesInvoiceEntry($invoiceNo, $payableTotal, $cogsVal, $paidAmount) {
        $dueAmount = $payableTotal - $paidAmount;
        $items = [];

        // Cash / Bank Debit (Received payment)
        if ($paidAmount > 0) {
            $items[] = ['code' => '1010', 'debit' => $paidAmount, 'credit' => 0.00];
        }

        // Accounts Receivable Debit (Credit due)
        if ($dueAmount > 0) {
            $items[] = ['code' => '1200', 'debit' => $dueAmount, 'credit' => 0.00];
        }

        // Sales Revenue Credit (Total Turnover)
        $items[] = ['code' => '4100', 'debit' => 0.00, 'credit' => $payableTotal];

        // COGS Debit & Inventory Credit
        if ($cogsVal > 0) {
            $items[] = ['code' => '5100', 'debit' => $cogsVal, 'credit' => 0.00];
            $items[] = ['code' => '1300', 'debit' => 0.00, 'credit' => $cogsVal];
        }

        $this->postJournalEntry(date('Y-m-d'), $invoiceNo, "Auto-posting checkout from Sales Invoice #$invoiceNo", $items);
    }

    /**
     * Auto Post Stock Purchases restocks
     */
    public function postStockPurchaseEntry($purchaseNo, $totalCost, $paidAmount) {
        $dueAmount = $totalCost - $paidAmount;
        $items = [];

        // Inventory Asset Debit (Total cost value increase)
        $items[] = ['code' => '1300', 'debit' => $totalCost, 'credit' => 0.00];

        // Cash Credit (Payment made)
        if ($paidAmount > 0) {
            $items[] = ['code' => '1010', 'debit' => 0.00, 'credit' => $paidAmount];
        }

        // Accounts Payable Credit (Due to supplier)
        if ($dueAmount > 0) {
            $items[] = ['code' => '2100', 'debit' => 0.00, 'credit' => $dueAmount];
        }

        $this->postJournalEntry(date('Y-m-d'), $purchaseNo, "Auto-posting restocking from Purchase Invoice #$purchaseNo", $items);
    }

    /**
     * Auto Post Operational Expenses
     */
    public function postOperatingExpenseEntry($expenseName, $amount) {
        $items = [
            ['code' => '5200', 'debit' => $amount, 'credit' => 0.00], // Expense Debit
            ['code' => '1010', 'debit' => 0.00, 'credit' => $amount]  // Cash Credit
        ];

        $this->postJournalEntry(date('Y-m-d'), 'EXP-' . date('His'), "Auto-posting Operating Expense: $expenseName", $items);
    }
}
