/**
 * Product Management Subsystem Scripts
 * Shop Management System: M.BAKAR BALOCH
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Initialize view-mode togglers (Grid vs Table List)
    initViewModes();

    // 2. Setup product image upload file previews
    initImageUploadPreview('productImageAdd', 'imgPreviewAdd');
    initImageUploadPreview('productImageEdit', 'imgPreviewEdit');
});

/**
 * Switch view scopes (grid vs list table)
 */
function initViewModes() {
    const btnGrid = document.getElementById('viewModeGrid');
    const btnTable = document.getElementById('viewModeTable');
    const panelGrid = document.getElementById('productsGridContainer');
    const panelTable = document.getElementById('productsTableContainer');

    if (btnGrid && btnTable && panelGrid && panelTable) {
        // Retrieve past preference
        const savedMode = localStorage.getItem('products-view-mode') || 'table';
        setViewMode(savedMode);

        btnGrid.addEventListener('click', () => setViewMode('grid'));
        btnTable.addEventListener('click', () => setViewMode('table'));
    }
}

function setViewMode(mode) {
    const btnGrid = document.getElementById('viewModeGrid');
    const btnTable = document.getElementById('viewModeTable');
    const panelGrid = document.getElementById('productsGridContainer');
    const panelTable = document.getElementById('productsTableContainer');

    if (mode === 'grid') {
        btnGrid.classList.add('active');
        btnTable.classList.remove('active');
        panelGrid.style.display = 'grid';
        panelTable.style.display = 'none';
    } else {
        btnTable.classList.add('active');
        btnGrid.classList.remove('active');
        panelTable.style.display = 'block';
        panelGrid.style.display = 'none';
    }

    localStorage.setItem('products-view-mode', mode);
}

/**
 * Instant local image preview triggers
 */
function initImageUploadPreview(inputId, previewId) {
    const fileInput = document.getElementById(inputId);
    const imgPreview = document.getElementById(previewId);

    if (fileInput && imgPreview) {
        fileInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.addEventListener('load', function() {
                    imgPreview.setAttribute('src', this.result);
                    imgPreview.style.display = 'block';
                });
                reader.readAsDataURL(file);
            } else {
                imgPreview.style.display = 'none';
            }
        });
    }
}

/**
 * Auto-generate secure unique barcode numbers (EAN-13 structure)
 */
function generateRandomBarcode(targetInputId) {
    const targetInput = document.getElementById(targetInputId);
    if (targetInput) {
        // EAN-13 uses 12 random numbers + check digit. For ERP, we can generate a robust unique mock code
        let barcodeStr = "890"; // Pakistan / South Asia regional prefix mock
        for (let i = 0; i < 9; i++) {
            barcodeStr += Math.floor(Math.random() * 10);
        }
        
        targetInput.value = barcodeStr;
        alert("Generated SKU Barcode code: " + barcodeStr);
    }
}

/**
 * Excel spreadsheet exporter tool
 */
function exportProductsToCSV(tableId) {
    const csv = [];
    const rows = document.querySelectorAll("#" + tableId + " tr");
    
    for (let i = 0; i < rows.length; i++) {
        const row = [];
        // Skip last action headers & columns during Excel exports
        const cols = rows[i].querySelectorAll("td:not(:last-child), th:not(:last-child)");
        
        for (let j = 0; j < cols.length; j++) {
            let data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, "").replace(/,/g, ";").trim();
            row.push('"' + data + '"');
        }
        csv.push(row.join(","));
    }

    const csvFile = new Blob([csv.join("\n")], {type: "text/csv"});
    const link = document.createElement("a");
    link.download = "mbakar_baloch_products_registry.csv";
    link.href = window.URL.createObjectURL(csvFile);
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
