<?php
/**
 * Customer & Supplier Ledger Subsystem - Payments installment Processor (Module 11)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = sanitize($_POST['type'] ?? '');
    $person_id = (int)($_POST['person_id'] ?? 0);
    $amount = (float)($_POST['amount'] ?? 0);
    $method = sanitize($_POST['payment_method'] ?? 'CASH');
    $notes = sanitize($_POST['notes'] ?? 'Dues Clearing Installment');

    if ($person_id <= 0 || $amount <= 0) {
        header("Location: dashboard.php");
        exit;
    }

    try {
        // ==========================================
        // ROUTE A: CUSTOMER PAYMENT INSTALLMENT
        // ==========================================
        if ($type === 'customer') {
            $db->beginTransaction();

            // Fetch customer metadata
            $chk = $db->prepare("SELECT name, balance FROM customers WHERE id = :id FOR UPDATE");
            $chk->execute(['id' => $person_id]);
            $cust = $chk->fetch();

            if (!$cust) {
                throw new Exception("Customer profile was not found in directory.");
            }

            // 1. Record the receipt row in customer_payments table
            $ins = $db->prepare("INSERT INTO customer_payments (customer_id, amount, payment_date, payment_method, notes) VALUES (:cust_id, :amt, CURRENT_DATE(), :method, :notes)");
            $ins->execute([
                'cust_id' => $person_id,
                'amt' => $amount,
                'method' => $method,
                'notes' => $notes
            ]);

            // 2. Decrement the outstanding credit balance
            $upd = $db->prepare("UPDATE customers SET balance = balance - :amt WHERE id = :id");
            $upd->execute(['amt' => $amount, 'id' => $person_id]);

            $db->commit();
            header("Location: customers.php?success=" . urlencode("Successfully logged installment of " . format_currency($amount) . " from customer '" . $cust['name'] . "'. Ledger updated."));
            exit;
        }

        // ==========================================
        // ROUTE B: SUPPLIER OUTBOUND PAYOUT SETTLEMENT
        // ==========================================
        if ($type === 'supplier') {
            $db->beginTransaction();

            // Fetch supplier metadata
            $chk = $db->prepare("SELECT name, balance FROM suppliers WHERE id = :id FOR UPDATE");
            $chk->execute(['id' => $person_id]);
            $sup = $chk->fetch();

            if (!$sup) {
                throw new Exception("Supplier vendor was not found in directory.");
            }

            // 1. Record the payout row in supplier_payments table
            $ins = $db->prepare("INSERT INTO supplier_payments (supplier_id, amount, payment_date, payment_method, notes) VALUES (:sup_id, :amt, CURRENT_DATE(), :method, :notes)");
            $ins->execute([
                'sup_id' => $person_id,
                'amt' => $amount,
                'method' => $method,
                'notes' => $notes
            ]);

            // 2. Decrement outstanding dues liabilities
            $upd = $db->prepare("UPDATE suppliers SET balance = balance - :amt WHERE id = :id");
            $upd->execute(['amt' => $amount, 'id' => $person_id]);

            // 3. Automatically log payout into expenses table to keep accounting consistent!
            $ins_exp = $db->prepare("INSERT INTO expenses (title, category, amount, expense_date, description) VALUES (:title, 'Supplier Payment', :amount, CURRENT_DATE(), :desc)");
            $ins_exp->execute([
                'title' => "Vendor Ledger Payout: " . $sup['name'],
                'amount' => $amount,
                'desc' => "Dues settlement payout using $method. notes: $notes"
            ]);

            $db->commit();
            header("Location: suppliers.php?success=" . urlencode("Successfully logged payout of " . format_currency($amount) . " to supplier '" . $sup['name'] . "'. Dues adjusted."));
            exit;
        }

    } catch (Exception $e) {
        $db->rollBack();
        die("Installment entry failure: " . $e->getMessage());
    }
} else {
    header("Location: dashboard.php");
    exit;
}
