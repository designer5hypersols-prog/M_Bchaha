<?php
/**
 * Double Entry Accounting Subsystem - General Ledger (Module 3)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();

// Enforce Access
if ($_SESSION['user_role'] !== 'ADMIN' && $_SESSION['user_role'] !== 'MANAGER') {
    die("Access Denied: You must be an Administrator or Manager to view corporate ledger balances.");
}

// ==========================================
// LOAD CHART OF ACCOUNTS FOR FILTER SELECT
// ==========================================
$accounts = [];
try {
    $accounts = $db->query("SELECT * FROM accounts ORDER BY code ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {}

$selected_account_id = (int)($_GET['account_id'] ?? 0);
$start_date = sanitize($_GET['start_date'] ?? date('Y-m-01'));
$end_date = sanitize($_GET['end_date'] ?? date('Y-m-d'));

$ledger_items = [];
$account_details = null;

if ($selected_account_id > 0) {
    try {
        // Fetch selected account specifications
        $acc_stmt = $db->prepare("SELECT * FROM accounts WHERE id = :id LIMIT 1");
        $acc_stmt->execute(['id' => $selected_account_id]);
        $account_details = $acc_stmt->fetch(PDO::FETCH_ASSOC);

        // Fetch journal items under selected dates
        $query = "SELECT ji.*, je.entry_date, je.reference_no, je.description 
                  FROM journal_items ji 
                  JOIN journal_entries je ON ji.journal_entry_id = je.id 
                  WHERE ji.account_id = :account_id 
                    AND je.entry_date BETWEEN :start AND :end 
                  ORDER BY je.entry_date ASC, je.id ASC, ji.id ASC";
        
        $stmt = $db->prepare($query);
        $stmt->execute([
            'account_id' => $selected_account_id,
            'start' => $start_date,
            'end' => $end_date
        ]);
        $ledger_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {}
}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<!-- ==========================================
     A. LEDGER SELECTOR BAR
     ========================================== -->
<div class="card" style="margin-bottom:24px; padding:16px;">
    <form method="GET" action="general_ledger.php" style="display:flex; gap:16px; align-items:flex-end; flex-wrap:wrap;">
        <div style="flex-grow:2; min-width:200px;">
            <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Select Ledger Account</label>
            <select name="account_id" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px; cursor:pointer;" required>
                <option value="">-- Choose Account --</option>
                <?php foreach($accounts as $acc): ?>
                    <option value="<?php echo $acc['id']; ?>" <?php echo ($selected_account_id == $acc['id']) ? 'selected' : ''; ?>>
                        <?php echo $acc['code']; ?> - <?php echo htmlspecialchars($acc['name']); ?> (<?php echo $acc['type']; ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div style="flex-grow:1; min-width:130px;">
            <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Start Date</label>
            <input type="date" name="start_date" value="<?php echo $start_date; ?>" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;">
        </div>

        <div style="flex-grow:1; min-width:130px;">
            <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">End Date</label>
            <input type="date" name="end_date" value="<?php echo $end_date; ?>" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;">
        </div>

        <div>
            <button type="submit" class="btn" style="background:var(--accent); border-color:var(--accent); height:40px; width:auto; font-size:13.5px; padding:0 24px;">
                <i class="bx bx-analyse" style="margin-right:4px;"></i> Fetch Ledger
            </button>
        </div>
    </form>
</div>

<!-- ==========================================
     B. GENERAL LEDGER TRANSACTIONS SHEET
     ========================================== -->
<div class="card">
    <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color); display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
        <div class="card-title">
            <i class="bx bx-list-ol" style="color:var(--accent);"></i>
            <span>General Ledger Transaction History</span>
        </div>
        <?php if ($account_details): ?>
            <span style="font-size: 11px; font-weight:700; padding:2px 8px; background:var(--accent-glow); color:var(--accent); border-radius:4px;">
                CLASSIFICATION: <?php echo $account_details['type']; ?>
            </span>
        <?php endif; ?>
    </div>

    <?php if (!$account_details): ?>
        <div style="text-align: center; color: var(--text-muted); padding: 40px;">Select a ledger account above to load financial audit details.</div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Reference Voucher</th>
                        <th>Description / Note</th>
                        <th style="text-align:right;">Debit (+)</th>
                        <th style="text-align:right;">Credit (-)</th>
                        <th style="text-align:right;">Running Balance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $running_balance = 0.00;
                    $is_asset_or_expense = in_array($account_details['type'], ['ASSET', 'EXPENSE']);
                    
                    if (empty($ledger_items)): ?>
                        <tr>
                            <td colspan="6" style="text-align: center; color: var(--text-muted); padding: 30px;">No postings recorded for the selected account in this date range.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($ledger_items as $item): 
                            $db_val = (float)$item['debit'];
                            $cr_val = (float)$item['credit'];

                            // Calculate Running Balance based on dynamic Account Class rule
                            if ($is_asset_or_expense) {
                                $running_balance += ($db_val - $cr_val);
                            } else {
                                $running_balance += ($cr_val - $db_val);
                            }
                        ?>
                            <tr class="animate-fade">
                                <td><?php echo format_date($item['entry_date']); ?></td>
                                <td><code style="font-size:12px; font-weight:700;"><?php echo htmlspecialchars($item['reference_no'] ?: 'JV-POST'); ?></code></td>
                                <td><?php echo htmlspecialchars($item['description']); ?></td>
                                <td style="text-align:right; font-weight:<?php echo ($db_val > 0) ? '700' : '400'; ?>;">
                                    <?php echo ($db_val > 0) ? 'Rs. ' . number_format($db_val, 2) : '-'; ?>
                                </td>
                                <td style="text-align:right; font-weight:<?php echo ($cr_val > 0) ? '700' : '400'; ?>;">
                                    <?php echo ($cr_val > 0) ? 'Rs. ' . number_format($cr_val, 2) : '-'; ?>
                                </td>
                                <td style="text-align:right; font-weight:800; color:var(--accent);">
                                    Rs. <?php echo number_format($running_balance, 2); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>
