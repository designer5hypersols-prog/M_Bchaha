<?php
/**
 * AI-Powered Sales Prediction & Forecasting - Visual Dashboard (Module 1)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';
require_once 'ai_analysis_engine.php';

$engine = new AIAnalysisEngine();
$data = $engine->generateBusinessForecast();

require_once 'includes/header.php';
?>

<!-- Import settings CSS for consistent grids -->
<link rel="stylesheet" href="settings.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<div style="margin-bottom: 28px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">AI Sales Forecasting & Predictions</h1>
        <p style="font-size: 13.5px; color: var(--text-muted); margin-top: 4px;">Predictive analytics and smart stock suggestions engine for <strong><?php echo BRAND_NAME; ?></strong>.</p>
    </div>
    <div>
        <a href="ai_reports.php" target="_blank" class="btn" style="background:var(--accent); border-color:var(--accent); font-weight:700; display:inline-flex; align-items:center; gap:8px;">
            <i class="bx bx-download" style="font-size:18px;"></i> Export PDF AI Report
        </a>
    </div>
</div>

<!-- ==========================================
     1. PREDICTION KPI METRICS
     ========================================== -->
<div class="metrics-grid" style="margin-bottom: 24px;">
    
    <!-- Daily Forecast -->
    <div class="metric-card primary">
        <div class="metric-top">
            <span class="metric-title">Predicted Daily Sales</span>
            <div class="metric-icon-box"><i class="bx bx-calendar"></i></div>
        </div>
        <div class="metric-bottom">
            <div class="metric-value">Rs. <?php echo number_format($data['forecast']['daily'], 2); ?></div>
            <div class="metric-trend trend-up"><i class="bx bx-bolt-circle"></i> Estimated</div>
        </div>
    </div>

    <!-- Weekly Forecast -->
    <div class="metric-card primary">
        <div class="metric-top">
            <span class="metric-title">Predicted Weekly Sales</span>
            <div class="metric-icon-box"><i class="bx bx-calendar-star"></i></div>
        </div>
        <div class="metric-bottom">
            <div class="metric-value">Rs. <?php echo number_format($data['forecast']['weekly'], 2); ?></div>
            <div class="metric-trend trend-up"><i class="bx bx-check-shield"></i> Calculated</div>
        </div>
    </div>

    <!-- Monthly Forecast -->
    <div class="metric-card success" style="border:1px solid var(--accent);">
        <div class="metric-top">
            <span class="metric-title">Predicted Monthly Sales</span>
            <div class="metric-icon-box"><i class="bx bx-line-chart"></i></div>
        </div>
        <div class="metric-bottom">
            <div class="metric-value">Rs. <?php echo number_format($data['forecast']['monthly'], 2); ?></div>
            <div class="metric-trend trend-up"><i class="bx bx-trending-up"></i> +<?php echo number_format($data['forecast']['growth_rate'], 1); ?>% growth</div>
        </div>
    </div>

    <!-- Monthly Net Margin Profit Forecast -->
    <div class="metric-card <?php echo ($data['forecast']['profit'] >= 0) ? 'success' : 'danger'; ?>" style="border:1.5px solid <?php echo ($data['forecast']['profit'] >= 0) ? 'var(--accent)' : 'var(--danger)'; ?>;">
        <div class="metric-top">
            <span class="metric-title">Predicted Monthly Profit</span>
            <div class="metric-icon-box"><i class="bx bx-wallet"></i></div>
        </div>
        <div class="metric-bottom">
            <div class="metric-value">Rs. <?php echo number_format($data['forecast']['profit'], 2); ?></div>
            <div class="metric-trend <?php echo ($data['forecast']['profit'] >= 0) ? 'trend-up' : 'trend-down'; ?>">
                <i class="bx bx-analyse"></i> Margins
            </div>
        </div>
    </div>

</div>

<!-- ==========================================
     2. ANALYTICAL GRAPH CHARTING
     ========================================== -->
<div class="charts-grid" style="margin-bottom:24px;">
    <!-- Sales curve with forecast extension -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">
                <i class="bx bx-line-chart-down"></i>
                <span>Sales Trend Velocity & AI Next Month Forecast</span>
            </div>
        </div>
        <div class="chart-container">
            <canvas id="forecastTrendChart" 
                    data-months="<?php echo htmlspecialchars(json_encode(array_column($data['historical_sales'], 'month_yr'))); ?>"
                    data-sales="<?php echo htmlspecialchars(json_encode(array_column($data['historical_sales'], 'total'))); ?>"
                    data-forecast="<?php echo $data['forecast']['monthly']; ?>">
            </canvas>
        </div>
    </div>

    <!-- Product velocities bar chart -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">
                <i class="bx bx-bar-chart-alt-2"></i>
                <span>Product Performance Velocity (Qty Sold)</span>
            </div>
        </div>
        <div class="chart-container">
            <canvas id="productVelocityChart"
                    data-names="<?php echo htmlspecialchars(json_encode(array_column($data['high_demand'], 'name'))); ?>"
                    data-sold="<?php echo htmlspecialchars(json_encode(array_column($data['high_demand'], 'total_sold'))); ?>">
            </canvas>
        </div>
    </div>
</div>

<!-- ==========================================
     3. AI SMART INSIGHTS BULLETIN
     ========================================== -->
<div class="card" style="margin-bottom:24px;">
    <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
        <div class="card-title">
            <i class="bx bx-bot" style="color:var(--accent);"></i>
            <span>AI Smart Insights & Inventory Risk Bulletins</span>
        </div>
    </div>

    <div style="display:flex; flex-direction:column; gap:12px;">
        <?php if (empty($data['insights'])): ?>
            <div style="text-align: center; color: var(--text-muted); padding: 40px;">
                <i class="bx bx-check-shield" style="font-size: 40px; color: var(--accent); margin-bottom: 10px; display: block;"></i>
                AI analysis has evaluated all inventory parameters as normal. No stock warnings.
            </div>
        <?php else: ?>
            <?php foreach($data['insights'] as $insight): 
                $badge_class = 'primary';
                $icon = 'bx-info-circle';
                if ($insight['type'] === 'DANGER') { $badge_class = 'danger'; $icon = 'bx-error-circle'; }
                elseif ($insight['type'] === 'SUCCESS') { $badge_class = 'success'; $icon = 'bx-check-circle'; }
                elseif ($insight['type'] === 'WARNING') { $badge_class = 'warning'; $icon = 'bx-help-circle'; }
            ?>
                <div class="alert alert-<?php echo strtolower($insight['type'] === 'DANGER' ? 'danger' : ($insight['type'] === 'SUCCESS' ? 'success' : 'warning')); ?>" style="display:flex; align-items:center; gap:12px; margin:0; padding:16px;">
                    <i class="bx <?php echo $icon; ?>" style="font-size:22px; flex-shrink:0;"></i>
                    <span style="font-size:13.5px; line-height:1.45;">
                        <?php 
                        // Convert double asterisks to bold labels
                        echo preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', htmlspecialchars($insight['message'])); 
                        ?>
                    </span>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Render Script Charts -->
<script src="forecast_charts.js"></script>

<?php require_once 'includes/footer.php'; ?>
