<?php
/**
  * Warehouse & Location-Based Inventory System - Shelf Coordinates CRUD Registry
  * Shop Name: M.BAKAR BALOCH
  */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';
require_once 'location_engine.php';
require_once 'audit_logger.php';

// Enforce admin/manager role
if ($_SESSION['role'] !== 'SUPERADMIN' && $_SESSION['role'] !== 'ADMIN' && $_SESSION['role'] !== 'MANAGER') {
    die("Access Denied: You do not have permissions to manage shelf locations.");
}

$db = (new Database())->connect();
$message = '';
$error = '';

// Handle Add Location
if (isset($_POST['action']) && $_POST['action'] === 'add') {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        $error = "CSRF Token Validation Failed.";
    } else {
        $warehouse_id = (int)$_POST['warehouse_id'];
        $zone = sanitize($_POST['zone']);
        $rack = sanitize($_POST['rack']);
        $shelf = sanitize($_POST['shelf']);
        $description = sanitize($_POST['description']);

        if ($warehouse_id <= 0 || empty($zone) || empty($rack) || empty($shelf)) {
            $error = "Warehouse, Zone, Rack, and Shelf fields are all required.";
        } else {
            try {
                $stmt = $db->prepare("INSERT INTO locations (warehouse_id, zone, rack, shelf, description, status) 
                                      VALUES (:wh, :z, :r, :s, :descr, 'ACTIVE')");
                $stmt->execute([
                    'wh' => $warehouse_id,
                    'z' => $zone,
                    'r' => $rack,
                    's' => $shelf,
                    'descr' => $description
                ]);
                
                AuditLogger::logActivity("CREATE", "Configured shelf location divider coordinate: " . $zone . " &rarr; " . $rack . " &rarr; " . $shelf);
                $message = "Shelf partition coordinate configured successfully!";
            } catch (PDOException $e) {
                $error = "Failed to create shelf coordinate: " . $e->getMessage();
            }
        }
    }
}

// Fetch Warehouses for selection dropdown
$warehouses = [];
try {
    $warehouses = $db->query("SELECT id, name FROM warehouses WHERE status = 'ACTIVE' ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

// Fetch Locations Grid
$locations = [];
try {
    $stmt = $db->query("SELECT l.*, w.name as warehouse_name 
                        FROM locations l
                        JOIN warehouses w ON l.warehouse_id = w.id
                        ORDER BY w.name ASC, l.zone ASC, l.rack ASC, l.shelf ASC");
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Custom CSS -->
<link rel="stylesheet" href="settings.css">

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="margin: 0; font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Shelves Coordinate Registry</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Configure the physical sub-locations (Zones, Racks, and Shelves) inside warehouses.</p>
    </div>
    <div style="display: flex; gap: 10px;">
        <a href="warehouse.php" class="btn btn-secondary btn-sm" style="width: auto;">
            <i class="bx bx-buildings"></i> Warehouses List
        </a>
    </div>
</div>

<!-- Alerts -->
<?php if ($message): ?>
    <div class="alert alert-success animate-fade"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-danger animate-fade"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<!-- ==========================================
     LAYOUT: ADD & CONFIG LIST
     ========================================== -->
<div style="display: grid; grid-template-columns: 1fr 2fr; gap: 24px; align-items: start;">

    <!-- Left: Add Config form -->
    <div class="card">
        <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-plus-circle" style="color:var(--accent);"></i>
                <span>Configure Shelf Partition</span>
            </div>
        </div>

        <form method="POST" action="locations.php" style="display:flex; flex-direction:column; gap:16px;">
            <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
            <input type="hidden" name="action" value="add">

            <div>
                <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">Select Warehouse</label>
                <select name="warehouse_id" required style="width: 100%; height: 38px; padding: 0 10px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none; cursor: pointer;">
                    <option value="">-- Choose Warehouse --</option>
                    <?php foreach ($warehouses as $wh): ?>
                        <option value="<?php echo $wh['id']; ?>"><?php echo htmlspecialchars($wh['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">Zone / Room Section</label>
                <input type="text" name="zone" required placeholder="e.g. Zone A (Cold Rooms)" style="width: 100%; height: 38px; padding: 0 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none;">
            </div>

            <div>
                <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">Rack Row Identifier</label>
                <input type="text" name="rack" required placeholder="e.g. Rack 12" style="width: 100%; height: 38px; padding: 0 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none;">
            </div>

            <div>
                <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">Shelf / Drawer / Bin Coordinate</label>
                <input type="text" name="shelf" required placeholder="e.g. Shelf 3 (Bin B)" style="width: 100%; height: 38px; padding: 0 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none;">
            </div>

            <div>
                <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">Description Note</label>
                <input type="text" name="description" placeholder="Optional coordinate details..." style="width: 100%; height: 38px; padding: 0 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none;">
            </div>

            <button type="submit" class="btn" style="background: var(--accent); border-color: var(--accent); color: #fff;">
                Save Coordinate
            </button>
        </form>
    </div>

    <!-- Right: Datatable -->
    <div class="card">
        <div class="card-header" style="margin-bottom: 15px; padding-bottom: 8px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-list-ul" style="color:var(--accent);"></i>
                <span>Active Physical Coordinates List</span>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Warehouse</th>
                        <th>Zone/Room</th>
                        <th>Rack Row</th>
                        <th>Shelf Bin</th>
                        <th>Description Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($locations)): ?>
                        <tr>
                            <td colspan="5" style="text-align: center; color: var(--text-muted);">No locations configured yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($locations as $loc): ?>
                            <tr class="animate-fade">
                                <td><strong><?php echo htmlspecialchars($loc['warehouse_name']); ?></strong></td>
                                <td><span style="font-weight: 600; color: var(--accent);"><?php echo htmlspecialchars($loc['zone']); ?></span></td>
                                <td><code><?php echo htmlspecialchars($loc['rack']); ?></code></td>
                                <td><code><?php echo htmlspecialchars($loc['shelf']); ?></code></td>
                                <td style="font-size: 12px; color: var(--text-secondary);"><?php echo htmlspecialchars($loc['description'] ?: '-'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once 'includes/footer.php'; ?>
