/**
 * Customer & Supplier Ledger Client Script
 * Shop Name: M.BAKAR BALOCH
 */

document.addEventListener('DOMContentLoaded', () => {
    //
});

/**
 * Auto-Copy customized WhatsApp credit balance payment reminder
 */
function copyPaymentReminder(name, phone, balance) {
    if (balance <= 0) {
        alert("This customer has cleared all outstanding dues. No payment reminder is necessary!");
        return;
    }

    const cleanPhone = phone.replace(/[^0-9]/g, '');
    const message = `Dear ${name}, this is a friendly reminder that an outstanding balance of PKR ${parseFloat(balance).toFixed(2)} is pending in your credit ledger at M.BAKAR BALOCH. Kindly arrange to clear your dues at your earliest convenience. Thank you!`;
    
    // Copy to clipboard
    navigator.clipboard.writeText(message).then(() => {
        alert("WhatsApp payment reminder message successfully copied to clipboard!\n\n\"" + message + "\"");
    }).catch(err => {
        alert("Clipboard copy failed. Draft message: \n" + message);
    });
}

/**
 * Export ledger timelines to CSV sheet
 */
function exportLedgerToCSV(name, ledgerType) {
    const csv = [];
    const cards = document.querySelectorAll(".timeline-card");

    // CSV Headers
    csv.push('"Date","Activity/Type","Description","Amount (PKR)"');

    cards.forEach(card => {
        const date = card.querySelector(".timeline-date").innerText.trim();
        const title = card.querySelector(".timeline-title").innerText.replace(/,/g, ";").trim();
        const desc = card.querySelector(".timeline-body").innerText.replace(/,/g, ";").trim();
        
        // Match numbers inside body or title
        let amt = "0.00";
        const amtMatch = desc.match(/PKR\s?([0-9.]+)/i);
        if (amtMatch) {
            amt = amtMatch[1];
        }

        csv.push(`"${date}","${title}","${desc}","${amt}"`);
    });

    const csvFile = new Blob([csv.join("\n")], {type: "text/csv"});
    const link = document.createElement("a");
    link.download = `${ledgerType.toLowerCase()}_ledger_${name.toLowerCase().replace(/\s+/g, '_')}.csv`;
    link.href = window.URL.createObjectURL(csvFile);
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
