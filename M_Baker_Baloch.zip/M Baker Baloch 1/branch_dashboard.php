<?php
/**
 * Multi-Branch ERP Subsystem - Branch Dashboard Terminal (Module 4)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();

$branch_id = (int)($_SESSION['branch_id'] ?? 1);
$branch_name = "Assigned Branch";

$branch_sales = 0.00;
$branch_txns = 0;
$branch_stocks = 0;
$recent_sales = [];

try {
    // Fetch current branch name
    $b_stmt = $db->prepare("SELECT name FROM branches WHERE id = :id LIMIT 1");
    $b_stmt->execute(['id' => $branch_id]);
    $branch_name = $b_stmt->fetchColumn() ?: "Local Branch";

    // Branch Revenue
    $r_stmt = $db->prepare("SELECT SUM(payable_amount) FROM sales WHERE branch_id = :bid");
    $r_stmt->execute(['bid' => $branch_id]);
    $branch_sales = (float)$r_stmt->fetchColumn();

    // Branch Transactions count
    $t_stmt = $db->prepare("SELECT COUNT(*) FROM sales WHERE branch_id = :bid");
    $t_stmt->execute(['bid' => $branch_id]);
    $branch_txns = (int)$t_stmt->fetchColumn();

    // Branch Stock count
    $s_stmt = $db->prepare("SELECT SUM(stock_qty) FROM products WHERE branch_id = :bid");
    $s_stmt->execute(['bid' => $branch_id]);
    $branch_stocks = (int)$s_stmt->fetchColumn();

    // Fetch recent sales at this branch
    $h_stmt = $db->prepare("SELECT s.*, c.name as customer_name 
                            FROM sales s 
                            LEFT JOIN customers c ON s.customer_id = c.id 
                            WHERE s.branch_id = :bid 
                            ORDER BY s.id DESC LIMIT 10");
    $h_stmt->execute(['bid' => $branch_id]);
    $recent_sales = $h_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<!-- ==========================================
     A. OUTLET HEADER REMINDER
     ========================================== -->
<div style="background:var(--accent-glow); color:var(--accent); padding:16px 20px; border-radius:var(--radius-sm); margin-bottom:24px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
    <div>
        <h2 style="margin:0; font-size:16px; font-weight:800; text-transform:uppercase;">ACTIVE OUTLET PORTAL: <?php echo htmlspecialchars($branch_name); ?></h2>
        <span style="font-size:12.5px; color:var(--text-secondary);">Logged in as branch operator. All operations and records are fully isolated.</span>
    </div>
    <span style="font-size:11px; font-weight:700; background:var(--accent); color:#ffffff; padding:4px 10px; border-radius:4px;">BRANCH ID: #<?php echo $branch_id; ?></span>
</div>

<!-- ==========================================
     B. KPI CARDS
     ========================================== -->
<div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); margin-bottom: 24px;">
    
    <!-- Branch Sales -->
    <div class="stat-card success">
        <div class="stat-info">
            <span>Branch Sales Revenue</span>
            <h2>Rs. <?php echo number_format($branch_sales, 2); ?></h2>
        </div>
        <div class="stat-icon">
            <i class="bx bx-bar-chart-alt-2"></i>
        </div>
    </div>

    <!-- Branch Txns -->
    <div class="stat-card primary">
        <div class="stat-info">
            <span>Sales Checkout invoices</span>
            <h2><?php echo $branch_txns; ?> checkout transactions</h2>
        </div>
        <div class="stat-icon">
            <i class="bx bx-receipt"></i>
        </div>
    </div>

    <!-- Branch Stock -->
    <div class="stat-card warning">
        <div class="stat-info">
            <span>Warehouse stock counts</span>
            <h2><?php echo number_format($branch_stocks); ?> items remaining</h2>
        </div>
        <div class="stat-icon">
            <i class="bx bx-cabinet"></i>
        </div>
    </div>

</div>

<!-- ==========================================
     C. RECENT INVOICES OUTLET DIRECTORY
     ========================================== -->
<div class="card">
    <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
        <div class="card-title">
            <i class="bx bx-receipt" style="color:var(--accent);"></i>
            <span>Recent Local Sales Checkouts</span>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table" style="--table-padding: 10px 12px;">
            <thead>
                <tr>
                    <th>Invoice No</th>
                    <th>Date</th>
                    <th>Customer Name</th>
                    <th style="text-align:right;">Subtotal</th>
                    <th style="text-align:right;">Discount</th>
                    <th style="text-align:right;">Total Paid</th>
                    <th style="text-align:right;">Dues</th>
                    <th>Payment</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($recent_sales)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 30px;">No sales checkouts recorded at this branch yet.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach($recent_sales as $sale): 
                        $status_badge = get_payment_status($sale['payment_status']);
                    ?>
                        <tr class="animate-fade">
                            <td><code><?php echo htmlspecialchars($sale['invoice_no']); ?></code></td>
                            <td><?php echo format_date($sale['sale_date'] ?? date('Y-m-d')); ?></td>
                            <td><strong><?php echo htmlspecialchars($sale['customer_name'] ?: 'Walk-in Customer'); ?></strong></td>
                            <td style="text-align:right;">Rs. <?php echo number_format($sale['total_amount'], 2); ?></td>
                            <td style="text-align:right; color:var(--warning);">Rs. <?php echo number_format($sale['discount_amount'], 2); ?></td>
                            <td style="text-align:right; font-weight:700;">Rs. <?php echo number_format($sale['paid_amount'], 2); ?></td>
                            <td style="text-align:right; color:var(--error); font-weight:700;">
                                Rs. <?php echo number_format($sale['payable_amount'] - $sale['paid_amount'], 2); ?>
                            </td>
                            <td>
                                <span class="badge <?php echo $status_badge['class']; ?>">
                                    <?php echo $status_badge['label']; ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
