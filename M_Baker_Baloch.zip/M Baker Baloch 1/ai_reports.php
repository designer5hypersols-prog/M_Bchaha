<?php
/**
 * AI-Powered Sales Prediction & Forecasting - Printable Report (Module 5)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';
require_once 'ai_analysis_engine.php';

$engine = new AIAnalysisEngine();
$data = $engine->generateBusinessForecast();

// Verify user role
if ($_SESSION['user_role'] !== 'ADMIN' && $_SESSION['user_role'] !== 'MANAGER') {
    die("Access Denied: You do not have permissions to access corporate BI forecasts.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>M.BAKAR BALOCH - AI Business Forecast Report</title>
    <style>
        body {
            font-family: 'Plus Jakarta Sans', Arial, sans-serif;
            background: #ffffff;
            color: #0f172a;
            margin: 0;
            padding: 40px;
            font-size: 14px;
            line-height: 1.5;
        }
        .header {
            border-bottom: 2px solid #10b981;
            padding-bottom: 20px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
        }
        .brand {
            font-size: 24px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #0f172a;
        }
        .title {
            font-size: 16px;
            font-weight: 700;
            color: #64748b;
        }
        .grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        .card {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 16px;
        }
        .card-title {
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            color: #64748b;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
        }
        .card-value {
            font-size: 18px;
            font-weight: 800;
            color: #10b981;
        }
        .section-title {
            font-size: 15px;
            font-weight: 700;
            border-bottom: 1.5px dashed #cbd5e1;
            padding-bottom: 6px;
            margin-top: 30px;
            margin-bottom: 15px;
            color: #0f172a;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        th {
            background: #f1f5f9;
            color: #475569;
            text-align: left;
            padding: 10px 12px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
        }
        td {
            padding: 10px 12px;
            border-bottom: 1px solid #e2e8f0;
        }
        .alert {
            background: #fef2f2;
            border-left: 4px solid #f43f5e;
            padding: 12px 16px;
            border-radius: 4px;
            font-size: 13px;
            margin-bottom: 10px;
        }
        .print-btn-row {
            margin-bottom: 20px;
            text-align: right;
        }
        .btn {
            background: #10b981;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            font-weight: 700;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
        }
        @media print {
            .print-btn-row { display: none; }
            body { padding: 0; }
        }
    </style>
</head>
<body>

    <div class="print-btn-row">
        <button type="button" class="btn" onclick="window.print()">Print / Save PDF</button>
    </div>

    <!-- Header info -->
    <div class="header">
        <div>
            <div class="brand"><?php echo BRAND_NAME; ?></div>
            <div style="font-size:12px; color:#64748b; margin-top:4px;">Business Forecasting & Analytical Predictions Report</div>
        </div>
        <div style="text-align:right;">
            <div class="title">CONFIDENTIAL BI REPORT</div>
            <div style="font-size:11px; color:#64748b;">Generated: <?php echo date('Y-m-d H:i:s'); ?></div>
        </div>
    </div>

    <!-- 1. Predictions Summary Grid -->
    <div class="section-title">Sales & Financial Projections (Next 30 Days)</div>
    <div class="grid">
        <div class="card">
            <div class="card-title">Daily Predicted Sales</div>
            <div class="card-value">Rs. <?php echo number_format($data['forecast']['daily'], 2); ?></div>
        </div>
        <div class="card">
            <div class="card-title">Weekly Predicted Sales</div>
            <div class="card-value">Rs. <?php echo number_format($data['forecast']['weekly'], 2); ?></div>
        </div>
        <div class="card">
            <div class="card-title">Monthly Predicted Sales</div>
            <div class="card-value" style="color:#0ea5e9;">Rs. <?php echo number_format($data['forecast']['monthly'], 2); ?></div>
        </div>
        <div class="card">
            <div class="card-title">Expected Net Profit Margin</div>
            <div class="card-value">Rs. <?php echo number_format($data['forecast']['profit'], 2); ?></div>
        </div>
    </div>

    <!-- 2. High Demand Item Inventory Statuses -->
    <div class="section-title">High Demand Inventory Stock Velocities</div>
    <table>
        <thead>
            <tr>
                <th>Product Description</th>
                <th>Current Stock</th>
                <th>Total Sold (Recent Months)</th>
                <th>AI Inventory Status Indicator</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($data['high_demand'] as $hd): 
                $status = "Normal";
                $color = "#10b981";
                if ($hd['stock_qty'] <= 15) {
                    $status = "CRITICAL REORDER";
                    $color = "#f43f5e";
                }
            ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars($hd['name']); ?></strong></td>
                    <td><?php echo $hd['stock_qty']; ?> pcs</td>
                    <td><?php echo $hd['total_sold']; ?> sold</td>
                    <td><strong style="color:<?php echo $color; ?>;"><?php echo $status; ?></strong></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- 3. Stagnant asset listings -->
    <div class="section-title">Stagnant Stock Capital Alerts (Low Demand)</div>
    <table>
        <thead>
            <tr>
                <th>Product Description</th>
                <th>Current Stock</th>
                <th>AI Capital Stagnation Alert</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($data['low_demand'] as $ld): ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars($ld['name']); ?></strong></td>
                    <td><?php echo $ld['stock_qty']; ?> pcs</td>
                    <td><strong style="color:#f59e0b;">OVERSTOCK RISK - Free up dynamic capital</strong></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- 4. Strategic insights summaries -->
    <div class="section-title">AI Business Growth Strategy Recommendations</div>
    <div style="display:flex; flex-direction:column; gap:8px;">
        <?php foreach($data['insights'] as $insight): ?>
            <div class="alert" style="border-left-color: <?php echo ($insight['type'] === 'DANGER') ? '#f43f5e' : (($insight['type'] === 'SUCCESS') ? '#10b981' : '#f59e0b'); ?>; background: #f8fafc;">
                <strong>Recommendation:</strong> <?php echo htmlspecialchars($insight['message']); ?>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Print trigger -->
    <script>
        window.onload = function() {
            // Automatically prompt print dialog on load
            setTimeout(function() {
                window.print();
            }, 500);
        };
    </script>
</body>
</html>
