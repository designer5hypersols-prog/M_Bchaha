<div class="bg-dark border-right text-white p-3" id="sidebar-wrapper">
    <div class="sidebar-heading fw-bold fs-5 mb-4 text-center" style="letter-spacing:1px;">
        <span style="color:#10b981;">MB</span> ERP SaaS
    </div>
    <div class="list-group list-group-flush">
        <a href="../dashboard/index.php" class="list-group-item list-group-item-action">
            <i class='bx bx-grid-alt me-2'></i> Dashboard
        </a>
        <a href="../products/index.php" class="list-group-item list-group-item-action">
            <i class='bx bx-box me-2'></i> Products
        </a>
        <a href="../sales/pos.php" class="list-group-item list-group-item-action">
            <i class='bx bx-receipt me-2'></i> POS Sales
        </a>
        <a href="../purchases/index.php" class="list-group-item list-group-item-action">
            <i class='bx bx-cart me-2'></i> Purchases
        </a>
        <a href="../stock/index.php" class="list-group-item list-group-item-action">
            <i class='bx bx-bar-chart-alt-2 me-2'></i> Stock
        </a>
        <a href="../ledger/index.php" class="list-group-item list-group-item-action">
            <i class='bx bx-book-content me-2'></i> Ledger
        </a>
        <a href="../accounting/index.php" class="list-group-item list-group-item-action">
            <i class='bx bx-calculator me-2'></i> Accounting
        </a>
        <a href="../reports/index.php" class="list-group-item list-group-item-action">
            <i class='bx bx-line-chart me-2'></i> Reports
        </a>
    </div>
</div>
