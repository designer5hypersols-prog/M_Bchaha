<nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom shadow-sm px-3 py-2">
    <div class="container-fluid">
        <!-- Hamburger Menu Toggle -->
        <button class="btn btn-outline-secondary" id="menu-toggle" aria-label="Toggle Menu">
            <i class='bx bx-menu'></i>
        </button>

        <!-- App Name (visible on mobile) -->
        <span class="ms-2 fw-bold text-dark d-lg-none" style="font-size:0.95rem;">MB ERP</span>

        <div class="ms-auto d-flex align-items-center gap-2">
            <!-- Tenant Badge -->
            <span class="badge bg-secondary d-none d-sm-inline">
                Tenant #<?= Auth::tenantId() ?>
            </span>

            <!-- User Dropdown -->
            <div class="dropdown">
                <a class="nav-link dropdown-toggle fw-bold text-dark" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class='bx bx-user-circle me-1'></i>
                    <span class="d-none d-sm-inline"><?= htmlspecialchars($_SESSION['name']) ?></span>
                </a>
                <ul class="dropdown-menu dropdown-menu-end shadow">
                    <li>
                        <span class="dropdown-item-text text-muted small">
                            <?= htmlspecialchars($_SESSION['email'] ?? '') ?>
                        </span>
                    </li>
                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <a class="dropdown-item text-danger" href="../../public/logout.php">
                            <i class='bx bx-log-out me-1'></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>
