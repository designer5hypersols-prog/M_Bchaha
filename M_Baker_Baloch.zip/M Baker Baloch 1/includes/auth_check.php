<?php
/**
 * Authentication Middleware / Route Protection
 * Shop Management System: M.BAKAR BALOCH
 */

require_once __DIR__ . '/../config/config.php';

// If user session is not set, redirect to login page
if (!isset($_SESSION['user_id'])) {
    // If the request is an AJAX call, return JSON unauthorized status
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        header('HTTP/1.1 401 Unauthorized');
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Session expired. Please log in again.']);
        exit;
    }
    
    // Store current URL in session to redirect back after successful login
    $_SESSION['redirect_to'] = $_SERVER['REQUEST_URI'];
    header("Location: login.php");
    exit;
}

// Enforce Database Session State and Inactivity Timeout checks
require_once __DIR__ . '/../security_engine.php';
SecurityEngine::verifySessionState();

// Update last activity timestamp locally
$_SESSION['last_activity'] = time();
