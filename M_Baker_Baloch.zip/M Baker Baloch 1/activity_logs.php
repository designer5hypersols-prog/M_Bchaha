<?php
/**
  * Advanced Security & Audit Trail System - Visual Activity Timeline
  * Shop Name: M.BAKAR BALOCH
  */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';
require_once 'audit_logger.php';

// Enforce admin/executive role
if ($_SESSION['role'] !== 'SUPERADMIN' && $_SESSION['role'] !== 'ADMIN') {
    die("Access Denied: You do not have permissions to view system activity logs.");
}

$db = (new Database())->connect();

// Filters variables
$filter_user_id = isset($_GET['user_id']) ? $_GET['user_id'] : '';
$filter_action = isset($_GET['action_type']) ? sanitize($_GET['action_type']) : '';
$filter_start_date = isset($_GET['start_date']) ? sanitize($_GET['start_date']) : '';
$filter_end_date = isset($_GET['end_date']) ? sanitize($_GET['end_date']) : '';
$search_query = isset($_GET['search']) ? sanitize($_GET['search']) : '';

// 1. Fetch active users list for dropdown filter
$users = [];
try {
    $users = $db->query("SELECT id, name, username FROM users ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

// 2. Fetch logs with filters
$query = "SELECT al.*, u.name as operator_name, u.username as operator_username 
          FROM activity_logs al 
          LEFT JOIN users u ON al.user_id = u.id 
          WHERE 1=1";
$params = [];

if ($filter_user_id !== '') {
    $query .= " AND al.user_id = :uid";
    $params['uid'] = (int)$filter_user_id;
}
if ($filter_action !== '') {
    $query .= " AND al.action_type = :act";
    $params['act'] = $filter_action;
}
if ($filter_start_date !== '') {
    $query .= " AND DATE(al.created_at) >= :sdate";
    $params['sdate'] = $filter_start_date;
}
if ($filter_end_date !== '') {
    $query .= " AND DATE(al.created_at) <= :edate";
    $params['edate'] = $filter_end_date;
}
if ($search_query !== '') {
    $query .= " AND (al.description LIKE :q OR al.ip_address LIKE :q OR al.device_info LIKE :q)";
    $params['q'] = '%' . $search_query . '%';
}

$query .= " ORDER BY al.created_at DESC LIMIT 100";

$logs = [];
try {
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Custom Styles -->
<link rel="stylesheet" href="settings.css">
<style>
    .timeline-container {
        position: relative;
        margin: 20px 0;
        padding-left: 30px;
        border-left: 2px solid var(--border-color);
    }
    .timeline-item {
        position: relative;
        margin-bottom: 24px;
        background: var(--bg-secondary);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-sm);
        padding: 16px;
        transition: all 0.2s ease;
    }
    .timeline-item:hover {
        border-color: var(--accent);
        box-shadow: 0 4px 12px rgba(0,0,0,0.02);
    }
    .timeline-dot {
        position: absolute;
        left: -41px;
        top: 20px;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: var(--bg-primary);
        border: 3.5px solid var(--accent);
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .badge-action {
        font-size: 10px;
        font-weight: 700;
        text-transform: uppercase;
        padding: 3px 8px;
        border-radius: 4px;
    }
    .badge-action.login { background: var(--success-glow); color: var(--success); }
    .badge-action.logout { background: var(--bg-primary); color: var(--text-muted); }
    .badge-action.edit { background: var(--warning-glow); color: var(--warning); }
    .badge-action.create { background: var(--accent-glow); color: var(--accent); }
    .badge-action.delete { background: var(--danger-glow); color: var(--danger); }
    .badge-action.alert { background: var(--danger-glow); color: var(--danger); border: 1px dashed var(--danger); }
</style>

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="margin: 0; font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Auditing Activity Logs</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Traceability index tracking all corporate events and back-office alterations.</p>
    </div>
    <div style="display: flex; gap: 10px;">
        <a href="security_dashboard.php" class="btn btn-secondary btn-sm" style="width: auto;">
            <i class="bx bx-shield-quarter"></i> Security Dashboard
        </a>
    </div>
</div>

<!-- ==========================================
     TIMELINE FILTERS BAR
     ========================================== -->
<div class="card" style="margin-bottom: 24px;">
    <form method="GET" action="activity_logs.php" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)) 80px; gap: 15px; align-items: end;">
        
        <div>
            <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">Select Operator</label>
            <select name="user_id" style="width: 100%; height: 38px; padding: 0 10px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none; cursor: pointer;">
                <option value="">All Users</option>
                <?php foreach ($users as $u): ?>
                    <option value="<?php echo $u['id']; ?>" <?php echo $filter_user_id == $u['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($u['name']); ?> (<?php echo htmlspecialchars($u['username']); ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div>
            <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">Action Category</label>
            <select name="action_type" style="width: 100%; height: 38px; padding: 0 10px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none; cursor: pointer;">
                <option value="">All Actions</option>
                <option value="LOGIN" <?php echo $filter_action === 'LOGIN' ? 'selected' : ''; ?>>Login</option>
                <option value="LOGOUT" <?php echo $filter_action === 'LOGOUT' ? 'selected' : ''; ?>>Logout</option>
                <option value="CREATE" <?php echo $filter_action === 'CREATE' ? 'selected' : ''; ?>>Create</option>
                <option value="EDIT" <?php echo $filter_action === 'EDIT' ? 'selected' : ''; ?>>Edit</option>
                <option value="DELETE" <?php echo $filter_action === 'DELETE' ? 'selected' : ''; ?>>Delete</option>
                <option value="SECURITY_ALERT" <?php echo $filter_action === 'SECURITY_ALERT' ? 'selected' : ''; ?>>Security Alerts</option>
            </select>
        </div>

        <div>
            <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">Start Date</label>
            <input type="date" name="start_date" value="<?php echo $filter_start_date; ?>" style="width: 100%; height: 38px; padding: 0 10px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none;">
        </div>

        <div>
            <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">End Date</label>
            <input type="date" name="end_date" value="<?php echo $filter_end_date; ?>" style="width: 100%; height: 38px; padding: 0 10px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none;">
        </div>

        <div>
            <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">Search Keyword</label>
            <input type="text" name="search" value="<?php echo $search_query; ?>" placeholder="IP, device description..." style="width: 100%; height: 38px; padding: 0 10px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none;">
        </div>

        <button type="submit" class="btn" style="height: 38px; display: flex; align-items: center; justify-content: center; background: var(--accent); border-color: var(--accent); color: #fff;">
            <i class="bx bx-search" style="font-size: 18px;"></i>
        </button>
    </form>
</div>

<!-- ==========================================
     TIMELINE CHRONOLOGY RENDER
     ========================================== -->
<div class="card">
    <?php if (empty($logs)): ?>
        <div style="text-align: center; padding: 40px 20px; color: var(--text-muted);">
            <i class="bx bx-folder-open" style="font-size: 48px; margin-bottom: 12px; display: block; color: var(--border-color);"></i>
            <span style="font-size: 14px;">No chronological audit trails found matching the filters.</span>
        </div>
    <?php else: ?>
        <div class="timeline-container">
            <?php foreach ($logs as $log): 
                // Determine Badge styling based on action type
                $badge_class = 'edit';
                $dot_color = 'var(--warning)';
                switch (strtoupper($log['action_type'])) {
                    case 'LOGIN':
                        $badge_class = 'login';
                        $dot_color = 'var(--success)';
                        break;
                    case 'LOGOUT':
                        $badge_class = 'logout';
                        $dot_color = 'var(--text-muted)';
                        break;
                    case 'CREATE':
                        $badge_class = 'create';
                        $dot_color = 'var(--accent)';
                        break;
                    case 'DELETE':
                        $badge_class = 'delete';
                        $dot_color = 'var(--danger)';
                        break;
                    case 'SECURITY_ALERT':
                    case 'SECURITY_VIOLATION':
                        $badge_class = 'alert';
                        $dot_color = 'var(--danger)';
                        break;
                }
            ?>
                <div class="timeline-item animate-fade">
                    <div class="timeline-dot" style="border-color: <?php echo $dot_color; ?>;"></div>
                    
                    <div style="display: flex; justify-content: space-between; align-items: start; flex-wrap: wrap; gap: 10px; margin-bottom: 8px;">
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <span class="badge-action <?php echo $badge_class; ?>"><?php echo htmlspecialchars($log['action_type']); ?></span>
                            <strong style="font-size: 14px; color: var(--text-main);">
                                <?php echo htmlspecialchars($log['operator_name'] ?: 'System Process'); ?>
                            </strong>
                            <span style="font-size: 12px; color: var(--text-muted);">
                                @<?php echo htmlspecialchars($log['operator_username'] ?: 'system'); ?>
                            </span>
                        </div>
                        <span style="font-size: 12px; color: var(--text-muted); font-weight: 600;">
                            <?php echo date('d M Y, h:i A', strtotime($log['created_at'])); ?>
                        </span>
                    </div>

                    <p style="margin: 0 0 10px 0; font-size: 13.5px; line-height: 1.5; color: var(--text-main); font-weight: 500;">
                        <?php echo htmlspecialchars($log['description']); ?>
                    </p>

                    <div style="display: flex; gap: 15px; font-size: 11px; color: var(--text-muted);">
                        <span><i class="bx bx-network-chart"></i> IP: <code><?php echo htmlspecialchars($log['ip_address']); ?></code></span>
                        <span><i class="bx bx-laptop"></i> Device: <?php echo htmlspecialchars(substr($log['device_info'], 0, 70)) . (strlen($log['device_info']) > 70 ? '...' : ''); ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>
