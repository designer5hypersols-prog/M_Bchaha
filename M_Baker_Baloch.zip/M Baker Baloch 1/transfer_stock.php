<?php
/**
  * Warehouse & Location-Based Inventory System - Relocation Terminal & History Logs
  * Shop Name: M.BAKAR BALOCH
  */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';
require_once 'location_engine.php';
require_once 'audit_logger.php';

// Enforce manager/admin permissions
if ($_SESSION['role'] !== 'SUPERADMIN' && $_SESSION['role'] !== 'ADMIN' && $_SESSION['role'] !== 'MANAGER') {
    die("Access Denied: You do not have permissions to relocate stock.");
}

$db = (new Database())->connect();
$message = '';
$error = '';

// Handle Relocation Submit
if (isset($_POST['action']) && $_POST['action'] === 'relocate') {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        $error = "CSRF Token Validation Failed.";
    } else {
        $product_id = (int)$_POST['product_id'];
        $from_loc_id = (int)$_POST['from_loc_id']; // This is the ID from product_locations
        $to_loc_id = (int)$_POST['to_loc_id'];     // This is the ID from locations
        $qty = (int)$_POST['qty'];
        $notes = sanitize($_POST['notes']);
        $user_id = $_SESSION['user_id'];

        if ($product_id <= 0 || $from_loc_id <= 0 || $to_loc_id <= 0 || $qty <= 0) {
            $error = "All form fields are required, and transfer quantity must be greater than zero.";
        } else {
            // Relocate using Transactional logistics engine
            $result = LocationEngine::relocateStock($product_id, $from_loc_id, $to_loc_id, $qty, $user_id, $notes);
            if ($result === true) {
                $message = "Stock relocated successfully!";
                AuditLogger::logActivity("EDIT", "Relocated " . $qty . " units of product ID: " . $product_id . " to target shelf coordinate ID: " . $to_loc_id);
            } else {
                $error = $result; // Error message returned from logistics engine
            }
        }
    }
}

// Fetch Products currently in stock by location (for source selector)
$source_options = [];
try {
    $source_options = $db->query("SELECT pl.id, pl.product_id, pl.qty, p.name as product_name, p.sku as product_sku,
                                         w.name as warehouse_name, l.zone, l.rack, l.shelf 
                                  FROM product_locations pl
                                  JOIN products p ON pl.product_id = p.id
                                  JOIN warehouses w ON pl.warehouse_id = w.id
                                  JOIN locations l ON pl.location_id = l.id
                                  WHERE pl.qty > 0
                                  ORDER BY p.name ASC, w.name ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

// Fetch Target Shelves list
$target_shelves = [];
try {
    $target_shelves = $db->query("SELECT l.id, w.name as warehouse_name, l.zone, l.rack, l.shelf 
                                  FROM locations l
                                  JOIN warehouses w ON l.warehouse_id = w.id
                                  WHERE l.status = 'ACTIVE'
                                  ORDER BY w.name ASC, l.zone ASC, l.rack ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

// Fetch Recent Transfers Log
$recent_transfers = [];
try {
    $recent_transfers = $db->query("SELECT sm.*, p.name as product_name, p.sku as product_sku,
                                           fw.name as from_wh_name, fl.zone as from_zone, fl.rack as from_rack, fl.shelf as from_shelf,
                                           tw.name as to_wh_name, tl.zone as to_zone, tl.rack as to_rack, tl.shelf as to_shelf,
                                           u.name as operator_name
                                    FROM stock_movements sm
                                    JOIN products p ON sm.product_id = p.id
                                    LEFT JOIN warehouses fw ON sm.from_warehouse_id = fw.id
                                    LEFT JOIN locations fl ON sm.from_location_id = fl.id
                                    LEFT JOIN warehouses tw ON sm.to_warehouse_id = tw.id
                                    LEFT JOIN locations tl ON sm.to_location_id = tl.id
                                    LEFT JOIN users u ON sm.user_id = u.id
                                    WHERE sm.movement_type = 'TRANSFER'
                                    ORDER BY sm.created_at DESC LIMIT 15")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Custom CSS -->
<link rel="stylesheet" href="settings.css">

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="margin: 0; font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Physical Relocation Terminal</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Relocate stock volumes between storage Zones, Racks, and Shelves safely.</p>
    </div>
    <div style="display: flex; gap: 10px;">
        <a href="stock_by_location.php" class="btn btn-secondary btn-sm" style="width: auto;">
            <i class="bx bx-list-ul"></i> Placement Catalog
        </a>
    </div>
</div>

<!-- Alerts -->
<?php if ($message): ?>
    <div class="alert alert-success animate-fade"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-danger animate-fade"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<!-- ==========================================
     LAYOUT: RELOCATION VOUCHER FORM & LOGS
     ========================================== -->
<div style="display: grid; grid-template-columns: 1fr 2fr; gap: 24px; align-items: start;">

    <!-- Left: relocation form -->
    <div class="card">
        <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-transfer-alt" style="color:var(--accent);"></i>
                <span>Create Relocation Voucher</span>
            </div>
        </div>

        <form method="POST" action="transfer_stock.php" style="display:flex; flex-direction:column; gap:16px;">
            <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
            <input type="hidden" name="action" value="relocate">

            <div>
                <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">1. Select Source Placement</label>
                <select name="from_loc_id" id="from_loc_selector" required onchange="updateProductSelected(this)" style="width: 100%; height: 38px; padding: 0 10px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none; cursor: pointer;">
                    <option value="">-- Choose Source Stock Shelf --</option>
                    <?php foreach ($source_options as $src): ?>
                        <option value="<?php echo $src['id']; ?>" data-pid="<?php echo $src['product_id']; ?>" data-qty="<?php echo $src['qty']; ?>">
                            <?php echo htmlspecialchars($src['product_name']); ?> (SKU: <?php echo htmlspecialchars($src['product_sku']); ?>) &rarr; <?php echo htmlspecialchars($src['warehouse_name']); ?> [<?php echo htmlspecialchars($src['zone']); ?> / <?php echo htmlspecialchars($src['rack']); ?> / <?php echo htmlspecialchars($src['shelf']); ?>] (Avail: <?php echo $src['qty']; ?> pcs)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Hidden field for product_id, auto-populated by JS based on selection -->
            <input type="hidden" name="product_id" id="product_id_field" value="">

            <div>
                <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">2. Select Target Coordinates</label>
                <select name="to_loc_id" required style="width: 100%; height: 38px; padding: 0 10px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none; cursor: pointer;">
                    <option value="">-- Choose Target Shelf coordinate --</option>
                    <?php foreach ($target_shelves as $tgt): ?>
                        <option value="<?php echo $tgt['id']; ?>">
                            <?php echo htmlspecialchars($tgt['warehouse_name']); ?> &rarr; <?php echo htmlspecialchars($tgt['zone']); ?> &bull; <?php echo htmlspecialchars($tgt['rack']); ?> &bull; <?php echo htmlspecialchars($tgt['shelf']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">3. Quantity to Transfer</label>
                <input type="number" name="qty" id="qty_transfer_input" min="1" required style="width: 100%; height: 38px; padding: 0 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none;">
            </div>

            <div>
                <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">4. Verification Notes</label>
                <input type="text" name="notes" placeholder="e.g. Stock relocation for Karachi dispatch" style="width: 100%; height: 38px; padding: 0 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none;">
            </div>

            <button type="submit" class="btn" style="background: var(--accent); border-color: var(--accent); color: #fff;">
                Commit Transfer
            </button>
        </form>
    </div>

    <!-- Right: Relocation logs -->
    <div class="card">
        <div class="card-header" style="margin-bottom: 15px; padding-bottom: 8px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-history" style="color:var(--accent);"></i>
                <span>Recent Relocation Transfers Log</span>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table" style="font-size: 12px;">
                <thead>
                    <tr>
                        <th>Product details</th>
                        <th>Source coordinates</th>
                        <th>Target coordinates</th>
                        <th style="text-align: center;">Qty</th>
                        <th>Operator</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($recent_transfers)): ?>
                        <tr>
                            <td colspan="5" style="text-align: center; color: var(--text-muted);">No stock relocations processed recently.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($recent_transfers as $t): ?>
                            <tr class="animate-fade">
                                <td>
                                    <strong><?php echo htmlspecialchars($t['product_name']); ?></strong>
                                    <span style="display:block; font-size:10px; color:var(--text-muted);">SKU: <?php echo htmlspecialchars($t['product_sku']); ?></span>
                                </td>
                                <td>
                                    <span style="display:block; font-weight:600;"><?php echo htmlspecialchars($t['from_wh_name']); ?></span>
                                    <span style="font-size:10px; color:var(--text-muted);"><?php echo htmlspecialchars($t['from_zone']); ?> &bull; <?php echo htmlspecialchars($t['from_rack']); ?> &bull; <?php echo htmlspecialchars($t['from_shelf']); ?></span>
                                </td>
                                <td>
                                    <span style="display:block; font-weight:600;"><?php echo htmlspecialchars($t['to_wh_name']); ?></span>
                                    <span style="font-size:10px; color:var(--text-muted);"><?php echo htmlspecialchars($t['to_zone']); ?> &bull; <?php echo htmlspecialchars($t['to_rack']); ?> &bull; <?php echo htmlspecialchars($t['to_shelf']); ?></span>
                                </td>
                                <td style="text-align: center;"><strong style="color:var(--accent); font-size:13.5px;"><?php echo $t['qty']; ?></strong></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($t['operator_name'] ?: 'System'); ?></strong>
                                    <span style="display:block; font-size:10px; color:var(--text-muted);"><?php echo date('d M, h:i A', strtotime($t['created_at'])); ?></span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- Helper script to dynamically map selections -->
<script>
function updateProductSelected(select) {
    const selectedOption = select.options[select.selectedIndex];
    if (selectedOption && selectedOption.value !== "") {
        const pid = selectedOption.getAttribute('data-pid');
        const maxQty = selectedOption.getAttribute('data-qty');
        
        document.getElementById('product_id_field').value = pid;
        
        const qtyInput = document.getElementById('qty_transfer_input');
        qtyInput.setAttribute('max', maxQty);
        qtyInput.placeholder = "Max " + maxQty + " pcs";
    } else {
        document.getElementById('product_id_field').value = "";
    }
}
</script>

<?php require_once 'includes/footer.php'; ?>
