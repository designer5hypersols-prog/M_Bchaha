<?php
/**
 * AI-Powered Sales Prediction & Forecasting - Embeddable Insights Dashboard (Module 4)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'ai_analysis_engine.php';

$engine = new AIAnalysisEngine();
$data = $engine->generateBusinessForecast();
?>

<!-- ==========================================
     AI ANALYTICS WIDGET ROW
     ========================================== -->
<div class="card" style="margin-bottom: 24px; border: 1.5px solid var(--accent);">
    
    <!-- Widget Title Header -->
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1px dashed var(--border-color);">
        <div style="display:flex; align-items:center; gap:8px; font-weight:800; font-size:15px; color:var(--text-main);">
            <i class="bx bx-bot" style="color:var(--accent); font-size:22px;"></i>
            <span>M.BAKAR BALOCH - AI Strategic Advisor Widget</span>
        </div>
        <a href="ai_forecast.php" style="font-size:12.5px; color:var(--accent); font-weight:700; text-decoration:none;">View Core Projections &rarr;</a>
    </div>

    <!-- Double Columns Split: Velocity Indicators vs Alerts -->
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
        
        <!-- Left: Product Demand High vs Low -->
        <div style="background:var(--bg-base); padding:16px; border-radius:var(--radius-sm); border:1px solid var(--border-color);">
            <strong style="display:block; font-size:13px; color:var(--text-main); margin-bottom:12px; border-bottom:1px solid var(--border-color); padding-bottom:6px;">
                <i class="bx bx-trending-up"></i> Top Selling (High Demand)
            </strong>
            <div style="display:flex; flex-direction:column; gap:8px; margin-bottom:16px;">
                <?php foreach(array_slice($data['high_demand'], 0, 3) as $hd): ?>
                    <div style="display:flex; justify-content:space-between; align-items:center; font-size:12.5px;">
                        <span><?php echo htmlspecialchars($hd['name']); ?></span>
                        <strong style="color:var(--accent);"><?php echo $hd['total_sold']; ?> sold</strong>
                    </div>
                <?php endforeach; ?>
            </div>

            <strong style="display:block; font-size:13px; color:var(--text-main); margin-bottom:12px; border-bottom:1px solid var(--border-color); padding-bottom:6px;">
                <i class="bx bx-pause-circle"></i> Slow Moving (Overstock Risk)
            </strong>
            <div style="display:flex; flex-direction:column; gap:8px;">
                <?php foreach(array_slice($data['low_demand'], 0, 3) as $ld): ?>
                    <div style="display:flex; justify-content:space-between; align-items:center; font-size:12.5px;">
                        <span><?php echo htmlspecialchars($ld['name']); ?></span>
                        <strong style="color:var(--warning);"><?php echo $ld['stock_qty']; ?> items</strong>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Right: AI Strategy Insights -->
        <div style="display:flex; flex-direction:column; gap:10px; justify-content:center;">
            <?php 
            // Display top two insights dynamically
            $sample_insights = array_slice($data['insights'], 0, 2);
            foreach ($sample_insights as $ins): 
                $bg = 'rgba(16, 185, 129, 0.05)';
                $border = 'var(--accent)';
                if ($ins['type'] === 'DANGER') { $bg = 'rgba(244, 63, 94, 0.05)'; $border = 'var(--danger)'; }
                elseif ($ins['type'] === 'WARNING') { $bg = 'rgba(245, 158, 11, 0.05)'; $border = 'var(--warning)'; }
            ?>
                <div style="background:<?php echo $bg; ?>; border-left:4px solid <?php echo $border; ?>; padding:12px; border-radius:4px; font-size:12.5px; line-height:1.4;">
                    <?php echo preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', htmlspecialchars($ins['message'])); ?>
                </div>
            <?php endforeach; ?>
        </div>

    </div>

</div>
