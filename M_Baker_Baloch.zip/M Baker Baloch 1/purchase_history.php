<?php
/**
 * Purchase & Stock Subsystem - Purchase History Ledger (Module 5)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = sanitize($_GET['success'] ?? '');

// 1. FILTER & SEARCH PARAMETERS
$search = sanitize($_GET['search'] ?? '');
$status_filter = sanitize($_GET['status'] ?? '');
$date_filter = sanitize($_GET['date'] ?? '');

$limit = 10; // Invoices per page
$page = (int)($_GET['page'] ?? 1);
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

$query_base = "SELECT p.*, s.name as supplier_name FROM purchases p LEFT JOIN suppliers s ON p.supplier_id = s.id WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query_base .= " AND (p.purchase_no LIKE :search OR s.name LIKE :search OR p.payment_method LIKE :search)";
    $params['search'] = "%$search%";
}

if (!empty($status_filter)) {
    $query_base .= " AND p.payment_status = :status";
    $params['status'] = $status_filter;
}

if (!empty($date_filter)) {
    if ($date_filter === 'today') {
        $query_base .= " AND p.purchase_date = CURRENT_DATE()";
    } elseif ($date_filter === 'yesterday') {
        $query_base .= " AND p.purchase_date = DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY)";
    } elseif ($date_filter === 'week') {
        $query_base .= " AND p.purchase_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)";
    } elseif ($date_filter === 'month') {
        $query_base .= " AND p.purchase_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)";
    }
}

// Calculate pagination parameters
try {
    $count_query = str_replace("p.*, s.name as supplier_name", "COUNT(*)", $query_base);
    $count_stmt = $db->prepare($count_query);
    $count_stmt->execute($params);
    $total_records = (int)$count_stmt->fetchColumn();
} catch (PDOException $e) {
    $total_records = 0;
}

$total_pages = ceil($total_records / $limit);
if ($total_pages < 1) $total_pages = 1;
if ($page > $total_pages) $page = $total_pages;
$offset = ($page - 1) * $limit;

// Load records
try {
    $load_query = $query_base . " ORDER BY p.id DESC LIMIT $limit OFFSET $offset";
    $load_stmt = $db->prepare($load_query);
    $load_stmt->execute($params);
    $purchases = $load_stmt->fetchAll();
} catch (PDOException $e) {
    $purchases = [];
}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="purchase.css">

<!-- Success notification -->
<?php if (!empty($success_message)): ?>
    <div class="alert alert-success">
        <i class="bx bx-check-circle"></i>
        <span><?php echo htmlspecialchars($success_message); ?></span>
    </div>
<?php endif; ?>

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <a href="purchase.php" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
            <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Purchases Hub
        </a>
    </div>
    
    <div style="display: flex; gap: 10px;">
        <button type="button" class="btn btn-sm btn-secondary" style="width: auto;" onclick="exportPurchasesToCSV('masterPurchasesHistoryTable')">
            <i class="bx bx-download"></i> Export Purchases CSV
        </button>
        <a href="add_purchase.php" class="btn btn-sm" style="width: auto; text-decoration: none; display: inline-flex; align-items: center; justify-content: center;">
            <i class="bx bx-plus-circle" style="font-size:18px; margin-right:6px;"></i> Launch Restocking Terminal
        </a>
    </div>
</div>

<!-- ==========================================
     ADVANCED PROCUREMENT FILTERS
     ========================================== -->
<div class="search-filter-section" style="margin-bottom: 24px;">
    <form method="GET" action="purchase_history.php" style="display: flex; flex-grow: 1; flex-wrap: wrap; gap: 15px; width: 100%;">
        
        <div class="search-input-group">
            <i class="bx bx-search"></i>
            <input type="text" name="search" class="search-control" placeholder="Search Purchase No, supplier name..." value="<?php echo htmlspecialchars($search); ?>">
        </div>

        <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
            <!-- Status dropdown -->
            <select name="status" class="select-control" style="width: auto; height: 44px;" onchange="this.form.submit()">
                <option value="">All Payment Statuses</option>
                <option value="PAID" <?php echo $status_filter === 'PAID' ? 'selected' : ''; ?>>PAID</option>
                <option value="PARTIAL" <?php echo $status_filter === 'PARTIAL' ? 'selected' : ''; ?>>PARTIAL</option>
                <option value="UNPAID" <?php echo $status_filter === 'UNPAID' ? 'selected' : ''; ?>>UNPAID</option>
            </select>

            <!-- Date dropdown -->
            <select name="date" class="select-control" style="width: auto; height: 44px;" onchange="this.form.submit()">
                <option value="">All Dates</option>
                <option value="today" <?php echo $date_filter === 'today' ? 'selected' : ''; ?>>Today</option>
                <option value="yesterday" <?php echo $date_filter === 'yesterday' ? 'selected' : ''; ?>>Yesterday</option>
                <option value="week" <?php echo $date_filter === 'week' ? 'selected' : ''; ?>>Last 7 Days</option>
                <option value="month" <?php echo $date_filter === 'month' ? 'selected' : ''; ?>>Last 30 Days</option>
            </select>

            <button type="submit" class="btn btn-sm btn-secondary" style="height: 44px;">Filter</button>
        </div>
    </form>
</div>

<!-- ==========================================
     PURCHASES HISTORICAL DATA TABLE
     ========================================== -->
<div class="card">
    <div class="table-responsive">
        <table class="table" id="masterPurchasesHistoryTable">
            <thead>
                <tr>
                    <th>Purchase No</th>
                    <th>Supplier Vendor</th>
                    <th>Purchase Date</th>
                    <th>Gross Purchase</th>
                    <th>Discounts</th>
                    <th>Net Payable</th>
                    <th>Paid Amount</th>
                    <th>Method</th>
                    <th>Payment Status</th>
                    <th>Remarks</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($purchases)): ?>
                    <tr>
                        <td colspan="10" style="text-align: center; color: var(--text-muted); padding: 45px;">No historical purchases match current filters.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach($purchases as $pur): 
                        $status_badge = get_payment_status($pur['payment_status']);
                    ?>
                        <tr class="animate-fade">
                            <td style="font-weight: 600; color: var(--accent);"><?php echo htmlspecialchars($pur['purchase_no']); ?></td>
                            <td><strong><?php echo htmlspecialchars($pur['supplier_name'] ?: 'Cash Supplier / Walk-in'); ?></strong></td>
                            <td><?php echo format_date($pur['purchase_date']); ?></td>
                            <td><?php echo format_currency($pur['total_amount']); ?></td>
                            <td style="color:var(--error);">- <?php echo format_currency($pur['discount']); ?></td>
                            <td style="font-weight: 700; color: var(--text-main);"><?php echo format_currency($pur['payable_amount']); ?></td>
                            <td style="font-weight: 600; color: var(--accent);"><?php echo format_currency($pur['paid_amount']); ?></td>
                            <td style="text-transform: uppercase; font-size:12px;"><strong><?php echo htmlspecialchars($pur['payment_method']); ?></strong></td>
                            <td>
                                <span class="status-pill <?php echo $status_badge['class']; ?>"><?php echo $status_badge['label']; ?></span>
                            </td>
                            <td><?php echo htmlspecialchars($pur['notes'] ?: '-'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ==========================================
     PAGINATION CONTROL ROW FOOTER
     ========================================== -->
<div class="pagination" style="margin-top: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <span style="font-size: 13.5px; color: var(--text-secondary);">Showing <strong><?php echo count($purchases); ?></strong> of <strong><?php echo $total_records; ?></strong> orders.</span>
    
    <div style="display: flex; gap: 5px;">
        <!-- Previous -->
        <a href="purchase_history.php?page=<?php echo ($page - 1); ?>&search=<?php echo urlencode($search); ?>&status=<?php echo $status_filter; ?>&date=<?php echo $date_filter; ?>" 
           class="btn btn-sm btn-secondary <?php echo ($page <= 1) ? 'disabled' : ''; ?>" 
           style="width: auto; padding: 6px 12px; pointer-events: <?php echo ($page <= 1) ? 'none' : 'auto'; ?>;">
           &larr; Prev
        </a>

        <!-- Page numbers -->
        <?php for($i = 1; $i <= $total_pages; $i++): ?>
            <a href="purchase_history.php?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo $status_filter; ?>&date=<?php echo $date_filter; ?>" 
               class="btn btn-sm <?php echo ($page === $i) ? '' : 'btn-secondary'; ?>" 
               style="width: 32px; padding: 6px 0; text-align: center;">
               <?php echo $i; ?>
            </a>
        <?php endfor; ?>

        <!-- Next -->
        <a href="purchase_history.php?page=<?php echo ($page + 1); ?>&search=<?php echo urlencode($search); ?>&status=<?php echo $status_filter; ?>&date=<?php echo $date_filter; ?>" 
           class="btn btn-sm btn-secondary <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>" 
           style="width: auto; padding: 6px 12px; pointer-events: <?php echo ($page >= $total_pages) ? 'none' : 'auto'; ?>;">
           Next &rarr;
        </a>
    </div>
</div>

<script>
/**
 * Purchases CSV Exporter
 */
function exportPurchasesToCSV(tableId) {
    const csv = [];
    const rows = document.querySelectorAll("#" + tableId + " tr");
    
    for (let i = 0; i < rows.length; i++) {
        const row = [];
        const cols = rows[i].querySelectorAll("td, th");
        
        for (let j = 0; j < cols.length; j++) {
            let data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, "").replace(/,/g, ";").trim();
            row.push('"' + data + '"');
        }
        csv.push(row.join(","));
    }

    const csvFile = new Blob([csv.join("\n")], {type: "text/csv"});
    const link = document.createElement("a");
    link.download = "mbakar_baloch_purchases_ledger.csv";
    link.href = window.URL.createObjectURL(csvFile);
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
</script>

<?php require_once 'includes/footer.php'; ?>
