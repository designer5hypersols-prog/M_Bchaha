<?php
/**
 * Authentication Engine - Session Initiation
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($email) || empty($password)) {
        $error = "Please fill in all credential fields.";
    } else {
        try {
            $db = SaaSDB::getConnection();
            $stmt = $db->prepare("SELECT * FROM `users` WHERE `email` = :email LIMIT 1");
            $stmt->execute(['email' => $email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                // Set Secure Session Parameters
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['fullname'] = $user['name'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['tenant_id'] = $user['tenant_id'];

                // Redirect to tenant dashboard
                header("Location: ../modules/dashboard/index.php");
                exit;
            } else {
                $error = "Invalid email or password combination.";
            }
        } catch (PDOException $e) {
            $error = "Auth transaction error: " . $e->getMessage();
        }
    }
    
    $_SESSION['login_error'] = $error;
    header("Location: ../login.php");
    exit;
} else {
    header("Location: ../login.php");
    exit;
}
