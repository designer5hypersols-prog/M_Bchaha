<?php
/**
 * Customer & Supplier Ledger Subsystem - Supplier Timeline Ledger (Module 3)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

$db = (new Database())->connect();
$supplier_id = (int)($_GET['id'] ?? 0);

try {
    // 1. Fetch supplier details
    $stmt = $db->prepare("SELECT * FROM suppliers WHERE id = :id LIMIT 1");
    $stmt->execute(['id' => $supplier_id]);
    $supplier = $stmt->fetch();

    if (!$supplier) {
        die("Supplier profile ID '$supplier_id' not found in database.");
    }

    // 2. Fetch all restocking purchases
    $purchases_stmt = $db->prepare("SELECT 'PURCHASE' as trans_type, id, purchase_no as ref_no, purchase_date as trans_date, payable_amount as debit, paid_amount as credit, notes FROM purchases WHERE supplier_id = :id");
    $purchases_stmt->execute(['id' => $supplier_id]);
    $purchases = $purchases_stmt->fetchAll();

    // 3. Fetch all separate installment payment clearings
    $pays_stmt = $db->prepare("SELECT 'PAYMENT' as trans_type, id, CONCAT('PAY-', id) as ref_no, payment_date as trans_date, 0.00 as debit, amount as credit, notes FROM supplier_payments WHERE supplier_id = :id");
    $pays_stmt->execute(['id' => $supplier_id]);
    $payments = $pays_stmt->fetchAll();

    // 4. Combine and Sort chronologically by date
    $timeline = array_merge($purchases, $payments);
    usort($timeline, function($a, $b) {
        return strtotime($a['trans_date']) - strtotime($b['trans_date']);
    });

} catch (PDOException $e) {
    die("Ledger load error: " . $e->getMessage());
}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="ledger.css">

<!-- Navigation -->
<div class="no-print" style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <a href="suppliers.php" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
            <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Suppliers directory
        </a>
    </div>
    
    <div style="display: flex; gap: 10px;">
        <button type="button" class="btn btn-sm btn-secondary" style="width: auto;" onclick="window.print()">
            <i class="bx bx-printer"></i> Print Statement Report
        </button>
        <button type="button" class="btn btn-sm btn-secondary" style="width: auto;" onclick="exportLedgerToCSV('<?php echo addslashes($supplier['name']); ?>', 'Supplier')">
            <i class="bx bx-download"></i> Export Statement CSV
        </button>
    </div>
</div>

<!-- ==========================================
     SUPPLIER BRIEF DETAILS CARD
     ========================================== -->
<div class="card" style="margin-bottom: 25px;">
    <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 20px;">
        <div>
            <h2 style="font-size: 20px; font-weight: 800; color:var(--text-main); margin-bottom: 6px;"><?php echo htmlspecialchars($supplier['name']); ?></h2>
            <p style="margin: 3px 0; font-size: 13.5px; color:var(--text-secondary);"><i class="bx bx-user" style="margin-right: 6px;"></i>Contact Person: <?php echo htmlspecialchars($supplier['contact_person'] ?: 'N/A'); ?></p>
            <p style="margin: 3px 0; font-size: 13.5px; color:var(--text-secondary);"><i class="bx bx-phone" style="margin-right: 6px;"></i>Phone: <?php echo htmlspecialchars($supplier['phone'] ?: 'N/A'); ?></p>
            <p style="margin: 3px 0; font-size: 13.5px; color:var(--text-secondary);"><i class="bx bx-map" style="margin-right: 6px;"></i>Address: <?php echo htmlspecialchars($supplier['address'] ?: 'N/A'); ?></p>
        </div>
        
        <div style="text-align: right;">
            <span style="font-size:12px; color:var(--text-muted); text-transform:uppercase; font-weight:700;">Outstanding Balance Owed (Dues)</span>
            <h1 style="font-size: 28px; font-weight: 900; margin-top: 5px; color: <?php echo ($supplier['balance'] > 0) ? 'var(--error)' : 'var(--accent)'; ?>;">
                <?php echo format_currency($supplier['balance']); ?>
            </h1>
        </div>
    </div>
</div>

<!-- ==========================================
     UNIFIED TRANSACTIONS TIMELINE LEDGER
     ========================================= -->
<div class="card">
    <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom:1.5px dashed var(--border-color);">
        <div class="card-title">
            <i class="bx bx-history"></i>
            <span>Statement Timeline & Procurement-Payout flow logs</span>
        </div>
    </div>

    <?php if (empty($timeline)): ?>
        <div style="text-align: center; color: var(--text-muted); padding: 50px;">
            <i class="bx bx-folder-open" style="font-size: 40px; color: var(--text-muted); margin-bottom: 10px;"></i>
            <p>No purchases or payouts transactions logged for this vendor profile.</p>
        </div>
    <?php else: ?>
        <div class="ledger-timeline">
            
            <!-- Opening Balance Marker -->
            <div class="timeline-item">
                <div class="timeline-marker" style="background:var(--accent);"></div>
                <div class="timeline-card" style="border-left: 3px solid var(--accent); padding: 10px 16px;">
                    <div class="timeline-header">
                        <span class="timeline-title">Account Created</span>
                        <span class="timeline-date">Setup Date</span>
                    </div>
                    <div class="timeline-body">
                        <span>Ledger statement initiated. Initial procurement balance tracked.</span>
                    </div>
                </div>
            </div>

            <?php 
            $running_balance = 0.00;
            foreach ($timeline as $trans): 
                $debit = (float)$trans['debit'];
                $credit = (float)$trans['credit'];
                $net_dues_added = $debit - $credit;
                $running_balance += $net_dues_added;
                
                $item_class = ($trans['trans_type'] === 'PURCHASE') ? 'purchase' : 'payment';
                $border_color = ($trans['trans_type'] === 'PURCHASE') ? 'var(--error)' : 'var(--accent)';
            ?>
                <div class="timeline-item <?php echo $item_class; ?>">
                    <div class="timeline-marker"></div>
                    <div class="timeline-card" style="border-left: 3.5px solid <?php echo $border_color; ?>;">
                        
                        <div class="timeline-header">
                            <span class="timeline-title">
                                <?php if ($trans['trans_type'] === 'PURCHASE'): ?>
                                    <i class="bx bx-receipt" style="margin-right: 6px; color:var(--error);"></i> Inbound Restock Purchase [<?php echo htmlspecialchars($trans['ref_no']); ?>]
                                <?php else: ?>
                                    <i class="bx bx-check-shield" style="margin-right: 6px; color:var(--accent);"></i> Cash Payout installment [<?php echo htmlspecialchars($trans['ref_no']); ?>]
                                <?php endif; ?>
                            </span>
                            <span class="timeline-date"><?php echo format_date($trans['trans_date']); ?></span>
                        </div>

                        <div class="timeline-body">
                            <div style="display: flex; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
                                <div>
                                    <p style="margin: 2px 0;"><?php echo htmlspecialchars($trans['notes'] ?: 'Ledger entries'); ?></p>
                                    
                                    <?php if ($trans['trans_type'] === 'PURCHASE'): ?>
                                        <span style="font-size:11.5px; color:var(--text-muted);">
                                            Procurement: <?php echo format_currency($debit); ?> | Paid on spot: <?php echo format_currency($credit); ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                
                                <div style="text-align: right;">
                                    <span style="font-size:11.5px; display:block; color:var(--text-muted);">Transaction Dues:</span>
                                    <strong style="color: <?php echo ($net_dues_added > 0) ? 'var(--error)' : 'var(--accent)'; ?>;">
                                        <?php echo ($net_dues_added > 0) ? '+' : ''; ?>
                                        <?php echo format_currency($net_dues_added); ?>
                                    </strong>
                                    
                                    <span style="font-size:11.5px; display:block; margin-top:5px; color:var(--text-muted);">Running Balance Owed:</span>
                                    <strong><?php echo format_currency($running_balance); ?></strong>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Subsystem JS -->
<script src="ledger.js"></script>

<?php require_once 'includes/header.php'; ?>
