<?php
/**
 * Multi-Branch ERP Subsystem - Stock Transfer Terminal (Module 5)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';
require_once 'multi_branch_engine.php';

$db = (new Database())->connect();
$engine = new MultiBranchEngine($db);

$error_message = "";
$success_message = "";

// Enforce Manager rights at least
if ($_SESSION['user_role'] !== 'SUPERADMIN' && $_SESSION['user_role'] !== 'ADMIN' && $_SESSION['user_role'] !== 'MANAGER') {
    die("Access Denied: Only managers and admins have permission to execute inter-branch transfers.");
}

// ==========================================
// PROCESS POST STOCK MOVEMENT REQUEST
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = (int)($_POST['product_id'] ?? 0);
    $from_branch = (int)($_POST['from_branch_id'] ?? 0);
    $to_branch = (int)($_POST['to_branch_id'] ?? 0);
    $qty = (int)($_POST['qty'] ?? 0);
    $notes = sanitize($_POST['notes'] ?? '');

    // If logged in as Manager, lock source branch to their assigned branch
    if ($_SESSION['user_role'] === 'MANAGER') {
        $from_branch = (int)$_SESSION['branch_id'];
    }

    if ($product_id > 0 && $from_branch > 0 && $to_branch > 0 && $qty > 0) {
        try {
            $ref_no = $engine->executeStockTransfer($product_id, $from_branch, $to_branch, $qty, $notes, $_SESSION['user_id']);
            $success_message = "Warehouse logistics complete! Product shifted safely. Transfer Ref: **$ref_no**.";
        } catch (Exception $e) {
            $error_message = "Transfer failed: " . $e->getMessage();
        }
    } else {
        $error_message = "Please fill all mandatory logistics fields and specify a positive quantity.";
    }
}

// ==========================================
// LOAD OUTLETS AND SOURCE PRODUCTS
// ==========================================
$branches = [];
$products = [];
try {
    $branches = $db->query("SELECT id, name FROM branches WHERE status = 'ACTIVE'")->fetchAll(PDO::FETCH_ASSOC);
    
    // Load products based on branch limitations
    $p_query = "SELECT p.*, b.name as branch_name 
                FROM products p 
                JOIN branches b ON p.branch_id = b.id 
                WHERE p.status = 'ACTIVE' ";
                
    if ($_SESSION['user_role'] === 'MANAGER') {
        $bid = (int)$_SESSION['branch_id'];
        $p_query .= " AND p.branch_id = $bid ";
    }
    $p_query .= " ORDER BY p.name ASC";
    $products = $db->query($p_query)->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

// ==========================================
// LOAD INTER-BRANCH TRANSFERS LOG HISTORY
// ==========================================
$transfers = [];
try {
    $t_stmt = $db->query("SELECT t.*, p.name as product_name, p.sku, 
                                 b_from.name as from_name, b_to.name as to_name,
                                 u.fullname as user_name 
                          FROM stock_transfers t 
                          JOIN products p ON t.product_id = p.id 
                          JOIN branches b_from ON t.from_branch_id = b_from.id 
                          JOIN branches b_to ON t.to_branch_id = b_to.id 
                          JOIN users u ON t.created_by = u.id 
                          ORDER BY t.id DESC LIMIT 50");
    $transfers = $t_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<!-- Action Notifications -->
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo $error_message; ?></span>
    </div>
<?php endif; ?>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success">
        <i class="bx bx-check-circle"></i>
        <span><?php echo preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $success_message); ?></span>
    </div>
<?php endif; ?>

<div style="margin-bottom: 24px;">
    <a href="settings.php#subsystems_link" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
        <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Settings Hub
    </a>
</div>

<div style="display:grid; grid-template-columns: 1.5fr 1fr; gap: 24px; align-items:start;">

    <!-- ==========================================
         A. LOGISTICS TRANSFER LEDGER HISTORIES
         ========================================== -->
    <div class="card">
        <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-transfer-alt" style="color:var(--accent);"></i>
                <span>Historical Inter-Branch Transfers Ledger</span>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table" style="--table-padding: 8px 10px; font-size: 12.5px;">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Reference Voucher</th>
                        <th>Product Item</th>
                        <th>From Branch</th>
                        <th>To Branch</th>
                        <th style="text-align:center;">Shifted Qty</th>
                        <th>Authorized By</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($transfers)): ?>
                        <tr>
                            <td colspan="7" style="text-align: center; color: var(--text-muted); padding: 30px;">No warehouse transfers logged yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($transfers as $tr): ?>
                            <tr class="animate-fade">
                                <td><?php echo format_date($tr['transfer_date']); ?></td>
                                <td><code><?php echo htmlspecialchars($tr['reference_no']); ?></code></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($tr['product_name']); ?></strong>
                                    <span style="display:block; font-size:10px; color:var(--text-muted);">SKU: <?php echo htmlspecialchars($tr['sku']); ?></span>
                                </td>
                                <td><?php echo htmlspecialchars($tr['from_name']); ?></td>
                                <td><?php echo htmlspecialchars($tr['to_name']); ?></td>
                                <td style="text-align:center; font-weight:800; color:var(--accent);"><?php echo $tr['qty']; ?> pcs</td>
                                <td><?php echo htmlspecialchars($tr['user_name']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ==========================================
         B. INITIATE TRANSFER REQUEST FORM
         ========================================== -->
    <div class="card" style="position:sticky; top:20px;">
        <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-plus-circle" style="color:var(--accent);"></i>
                <span>Initiate Stock Shift</span>
            </div>
        </div>

        <form method="POST" action="stock_transfer.php" style="display:flex; flex-direction:column; gap:16px;">
            
            <?php if ($_SESSION['user_role'] === 'SUPERADMIN' || $_SESSION['user_role'] === 'ADMIN'): ?>
                <!-- Source Branch Selector (Admins only) -->
                <div>
                    <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Source Outflow Branch *</label>
                    <select name="from_branch_id" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;" required>
                        <option value="">-- Choose Source Branch --</option>
                        <?php foreach($branches as $b): ?>
                            <option value="<?php echo $b['id']; ?>"><?php echo htmlspecialchars($b['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            <?php endif; ?>

            <!-- Target Product Selector -->
            <div>
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Select Shift Item *</label>
                <select name="product_id" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;" required>
                    <option value="">-- Choose Product Item --</option>
                    <?php foreach($products as $p): ?>
                        <option value="<?php echo $p['id']; ?>">
                            <?php echo htmlspecialchars($p['name']); ?> (Available: <?php echo $p['stock_qty']; ?> pcs)
                            <?php if ($_SESSION['user_role'] !== 'MANAGER'): ?>
                                [<?php echo htmlspecialchars($p['branch_name']); ?>]
                            <?php endif; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Destination Branch Selector -->
            <div>
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Destination Inflow Branch *</label>
                <select name="to_branch_id" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;" required>
                    <option value="">-- Choose Target Branch --</option>
                    <?php foreach($branches as $b): ?>
                        <!-- Manager cannot transfer to own branch as source, let's filter visually if possible -->
                        <option value="<?php echo $b['id']; ?>"><?php echo htmlspecialchars($b['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Transfer Quantity -->
            <div>
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Transfer Quantity *</label>
                <input type="number" name="qty" min="1" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;" required placeholder="Number of items to transfer">
            </div>

            <!-- Notes -->
            <div>
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Logistics remarks / Memo</label>
                <textarea name="notes" style="width:100%; height:60px; padding:12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px; font-family:inherit; resize:none;" placeholder="Supplier receipt reference numbers..."></textarea>
            </div>

            <button type="submit" class="btn" style="background:var(--accent); border-color:var(--accent); height:40px; font-weight:700; width:100%;">
                <i class="bx bx-check-shield" style="margin-right:4px;"></i> Commit Transfer Order
            </button>
        </form>
    </div>

</div>

<?php require_once 'includes/footer.php'; ?>
