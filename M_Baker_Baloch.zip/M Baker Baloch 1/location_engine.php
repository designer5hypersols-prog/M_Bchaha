<?php
/**
  * Warehouse & Location-Based Inventory System - Logistics Engine
  * Shop Name: M.BAKAR BALOCH
  */

class LocationEngine {
    private static $db = null;

    private static function initDB() {
        if (self::$db === null) {
            require_once __DIR__ . '/config/database.php';
            self::$db = (new Database())->connect();
            self::checkAndCreateTables();
        }
    }

    /**
     * Programmatically guarantee that the required warehousing tables exist
     */
    private static function checkAndCreateTables() {
        try {
            // 1. warehouses table
            self::$db->exec("CREATE TABLE IF NOT EXISTS `warehouses` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `branch_id` INT DEFAULT NULL,
                `name` VARCHAR(150) NOT NULL,
                `address` TEXT DEFAULT NULL,
                `capacity` INT DEFAULT 10000,
                `status` ENUM('ACTIVE', 'INACTIVE') NOT NULL DEFAULT 'ACTIVE',
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            // 2. locations table (Zone / Rack / Shelf partition coordinates)
            self::$db->exec("CREATE TABLE IF NOT EXISTS `locations` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `warehouse_id` INT NOT NULL,
                `zone` VARCHAR(50) NOT NULL,
                `rack` VARCHAR(50) NOT NULL,
                `shelf` VARCHAR(50) NOT NULL,
                `description` VARCHAR(255) DEFAULT NULL,
                `status` ENUM('ACTIVE', 'INACTIVE') NOT NULL DEFAULT 'ACTIVE',
                FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            // 3. product_locations table (Maps items to specific shelf quantities)
            self::$db->exec("CREATE TABLE IF NOT EXISTS `product_locations` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `product_id` INT NOT NULL,
                `warehouse_id` INT NOT NULL,
                `location_id` INT NOT NULL,
                `qty` INT NOT NULL DEFAULT 0,
                UNIQUE KEY `prod_wh_loc` (`product_id`, `warehouse_id`, `location_id`),
                FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
                FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE CASCADE,
                FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            // 4. stock_movements table (Movements & Auditing Logs)
            self::$db->exec("CREATE TABLE IF NOT EXISTS `stock_movements` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT DEFAULT NULL,
                `product_id` INT NOT NULL,
                `from_warehouse_id` INT DEFAULT NULL,
                `from_location_id` INT DEFAULT NULL,
                `to_warehouse_id` INT DEFAULT NULL,
                `to_location_id` INT DEFAULT NULL,
                `qty` INT NOT NULL,
                `movement_type` ENUM('IN', 'OUT', 'TRANSFER', 'ADJUSTMENT') NOT NULL,
                `notes` TEXT DEFAULT NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
                FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
                FOREIGN KEY (`from_warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE SET NULL,
                FOREIGN KEY (`from_location_id`) REFERENCES `locations` (`id`) ON DELETE SET NULL,
                FOREIGN KEY (`to_warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE SET NULL,
                FOREIGN KEY (`to_location_id`) REFERENCES `locations` (`id`) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            
            // Insert a default Warehouse if none exists
            $check_wh = self::$db->query("SELECT COUNT(*) FROM warehouses")->fetchColumn();
            if ($check_wh == 0) {
                self::$db->exec("INSERT INTO warehouses (name, address, capacity, status) 
                                 VALUES ('Main Central Warehouse', 'Main Industrial Area, Quetta', 15000, 'ACTIVE')");
                $wh_id = self::$db->lastInsertId();
                self::$db->exec("INSERT INTO locations (warehouse_id, zone, rack, shelf, description, status) 
                                 VALUES ($wh_id, 'Zone A', 'Rack 1', 'Shelf 3', 'Bulk storage boxes area', 'ACTIVE')");
            }
        } catch (PDOException $e) {}
    }

    /**
     * Relocate a stock quantity between physical shelves or warehouses transactionally
     */
    public static function relocateStock($productId, $fromLocId, $toLocId, $qty, $userId, $notes = '') {
        self::initDB();
        $qty = (int)$qty;
        if ($qty <= 0) return "Transfer quantity must be greater than zero.";

        try {
            self::$db->beginTransaction();

            // 1. Fetch Source Details
            $stmt_src = self::$db->prepare("SELECT * FROM product_locations WHERE id = :id LIMIT 1");
            $stmt_src->execute(['id' => $fromLocId]);
            $src = $stmt_src->fetch();

            if (!$src) {
                self::$db->rollBack();
                return "Source location registry not found.";
            }

            if ($src['qty'] < $qty) {
                self::$db->rollBack();
                return "Insufficient stock at source location. Available: " . $src['qty'] . " pcs.";
            }

            // 2. Fetch Target Details
            $stmt_target = self::$db->prepare("SELECT * FROM locations WHERE id = :id LIMIT 1");
            $stmt_target->execute(['id' => $toLocId]);
            $target = $stmt_target->fetch();

            if (!$target) {
                self::$db->rollBack();
                return "Target location registry not found.";
            }

            // 3. Subtract from source
            $new_src_qty = $src['qty'] - $qty;
            $sub_stmt = self::$db->prepare("UPDATE product_locations SET qty = :q WHERE id = :id");
            $sub_stmt->execute(['q' => $new_src_qty, 'id' => $fromLocId]);

            // 4. Add to target (upsert)
            $add_stmt = self::$db->prepare("INSERT INTO product_locations (product_id, warehouse_id, location_id, qty) 
                                            VALUES (:p, :w, :l, :q) 
                                            ON DUPLICATE KEY UPDATE qty = qty + :q");
            $add_stmt->execute([
                'p' => $productId,
                'w' => $target['warehouse_id'],
                'l' => $toLocId,
                'q' => $qty
            ]);

            // 5. Record stock movement logs
            $log_stmt = self::$db->prepare("INSERT INTO stock_movements (user_id, product_id, from_warehouse_id, from_location_id, to_warehouse_id, to_location_id, qty, movement_type, notes) 
                                            VALUES (:uid, :pid, :fwh, :floc, :twh, :tloc, :qty, 'TRANSFER', :notes)");
            $log_stmt->execute([
                'uid' => $userId,
                'pid' => $productId,
                'fwh' => $src['warehouse_id'],
                'floc' => $src['location_id'],
                'twh' => $target['warehouse_id'],
                'tloc' => $toLocId,
                'qty' => $qty,
                'notes' => $notes ?: 'Physical relocation between shelves'
            ]);

            self::$db->commit();
            return true;
        } catch (PDOException $e) {
            self::$db->rollBack();
            return "Transaction failed: " . $e->getMessage();
        }
    }

    /**
     * Record inventory entry (IN or OUT) for location
     */
    public static function recordMovement($productId, $warehouseId, $locationId, $qty, $type, $userId, $notes = '') {
        self::initDB();
        try {
            self::$db->beginTransaction();

            $qty = (int)$qty;
            if ($type === 'IN') {
                $stmt = self::$db->prepare("INSERT INTO product_locations (product_id, warehouse_id, location_id, qty) 
                                            VALUES (:p, :w, :l, :q) 
                                            ON DUPLICATE KEY UPDATE qty = qty + :q");
                $stmt->execute(['p' => $productId, 'w' => $warehouseId, 'l' => $locationId, 'q' => $qty]);
                
                $log = self::$db->prepare("INSERT INTO stock_movements (user_id, product_id, from_warehouse_id, from_location_id, to_warehouse_id, to_location_id, qty, movement_type, notes) 
                                            VALUES (:uid, :pid, NULL, NULL, :twh, :tloc, :qty, 'IN', :notes)");
                $log->execute(['uid' => $userId, 'pid' => $productId, 'twh' => $warehouseId, 'tloc' => $locationId, 'qty' => $qty, 'notes' => $notes]);

            } elseif ($type === 'OUT') {
                $stmt = self::$db->prepare("SELECT qty FROM product_locations WHERE product_id = :p AND location_id = :l LIMIT 1");
                $stmt->execute(['p' => $productId, 'l' => $locationId]);
                $current = (int)$stmt->fetchColumn();

                if ($current < $qty) {
                    self::$db->rollBack();
                    return "Insufficient stock at the selected location.";
                }

                $sub = self::$db->prepare("UPDATE product_locations SET qty = qty - :q WHERE product_id = :p AND location_id = :l");
                $sub->execute(['q' => $qty, 'p' => $productId, 'l' => $locationId]);

                $log = self::$db->prepare("INSERT INTO stock_movements (user_id, product_id, from_warehouse_id, from_location_id, to_warehouse_id, to_location_id, qty, movement_type, notes) 
                                            VALUES (:uid, :pid, :fwh, :floc, NULL, NULL, :qty, 'OUT', :notes)");
                $log->execute(['uid' => $userId, 'pid' => $productId, 'fwh' => $warehouseId, 'floc' => $locationId, 'qty' => $qty, 'notes' => $notes]);
            }

            self::$db->commit();
            return true;
        } catch (PDOException $e) {
            self::$db->rollBack();
            return "Transaction failed: " . $e->getMessage();
        }
    }
}
