<?php
/**
 * Double Entry Accounting Subsystem - Cash Flow Statement (Module 9)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();

// Enforce Access
if ($_SESSION['user_role'] !== 'ADMIN' && $_SESSION['user_role'] !== 'MANAGER') {
    die("Access Denied: You must be an Administrator or Manager to compile financial statements.");
}

$start_date = sanitize($_GET['start_date'] ?? date('Y-m-01'));
$end_date = sanitize($_GET['end_date'] ?? date('Y-m-d'));

$inflows = [];
$outflows = [];

$total_inflow = 0.00;
$total_outflow = 0.00;

try {
    // 1. GATHER CASH INFLOWS (DEBITS TO 1010 AND 1020)
    $stmt_in = $db->prepare("SELECT je.reference_no, je.description, je.entry_date, COALESCE(SUM(ji.debit), 0.00) as amount 
                             FROM journal_items ji 
                             JOIN journal_entries je ON ji.journal_entry_id = je.id 
                             JOIN accounts a ON ji.account_id = a.id 
                             WHERE a.code IN ('1010', '1020') AND ji.debit > 0 
                               AND je.entry_date BETWEEN :start AND :end 
                             GROUP BY je.id ORDER BY je.entry_date ASC");
    $stmt_in->execute(['start' => $start_date, 'end' => $end_date]);
    $inflows = $stmt_in->fetchAll(PDO::FETCH_ASSOC);
    $total_inflow = array_sum(array_column($inflows, 'amount'));

    // 2. GATHER CASH OUTFLOWS (CREDITS TO 1010 AND 1020)
    $stmt_out = $db->prepare("SELECT je.reference_no, je.description, je.entry_date, COALESCE(SUM(ji.credit), 0.00) as amount 
                              FROM journal_items ji 
                              JOIN journal_entries je ON ji.journal_entry_id = je.id 
                              JOIN accounts a ON ji.account_id = a.id 
                              WHERE a.code IN ('1010', '1020') AND ji.credit > 0 
                                AND je.entry_date BETWEEN :start AND :end 
                              GROUP BY je.id ORDER BY je.entry_date ASC");
    $stmt_out->execute(['start' => $start_date, 'end' => $end_date]);
    $outflows = $stmt_out->fetchAll(PDO::FETCH_ASSOC);
    $total_outflow = array_sum(array_column($outflows, 'amount'));

} catch(PDOException $e) {}

$net_cash_position = $total_inflow - $total_outflow;

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<!-- ==========================================
     A. DATE RANGE SELECTOR BAR
     ========================================== -->
<div class="card" style="margin-bottom:24px; padding:16px;">
    <form method="GET" action="cash_flow.php" style="display:flex; gap:16px; align-items:flex-end; flex-wrap:wrap;">
        <div style="flex-grow:1; min-width:200px;">
            <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Start Date</label>
            <input type="date" name="start_date" value="<?php echo $start_date; ?>" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;">
        </div>

        <div style="flex-grow:1; min-width:200px;">
            <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">End Date</label>
            <input type="date" name="end_date" value="<?php echo $end_date; ?>" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px;">
        </div>

        <div>
            <button type="submit" class="btn" style="background:var(--accent); border-color:var(--accent); height:40px; width:auto; font-size:13.5px; padding:0 24px;">
                <i class="bx bx-filter" style="margin-right:4px;"></i> Filter Statement
            </button>
        </div>
    </form>
</div>

<!-- ==========================================
     B. CASH FLOW SHEET CARD
     ========================================== -->
<div class="card" style="max-width: 850px; margin: 0 auto;">
    <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color); display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
        <div class="card-title">
            <i class="bx bx-transfer-alt" style="color:var(--accent);"></i>
            <span>Corporate Cash Flow Statement</span>
        </div>
        <button type="button" class="btn btn-sm" onclick="window.print()" style="background:var(--bg-secondary); border-color:var(--border-color); height:30px; width:auto; font-size:11px; padding:0 12px; color:var(--text-main);">
            <i class="bx bx-printer" style="margin-right:4px;"></i> Print
        </button>
    </div>

    <div style="display:grid; grid-template-columns:1fr 1fr; gap:30px; margin-bottom:24px;">
        
        <!-- INFLOWS -->
        <div>
            <div style="font-weight:800; font-size:15px; color:var(--text-main); border-bottom:2px solid var(--border-color); padding-bottom:4px; margin-bottom:12px; text-transform:uppercase;">CASH INFLOWS</div>
            <div style="display:flex; flex-direction:column; gap:10px; min-height:150px;">
                <?php if (empty($inflows)): ?>
                    <div style="font-size:12.5px; color:var(--text-muted); text-align:center; padding:30px;">No liquid inflows recorded.</div>
                <?php else: ?>
                    <?php foreach($inflows as $inf): ?>
                        <div style="display:flex; justify-content:space-between; font-size:13px; border-bottom:1px dashed var(--border-color); padding-bottom:6px;">
                            <div>
                                <span style="display:block; font-weight:700;"><?php echo htmlspecialchars($inf['description']); ?></span>
                                <span style="font-size:11px; color:var(--text-muted);">Ref: <?php echo htmlspecialchars($inf['reference_no']); ?></span>
                            </div>
                            <strong style="color:var(--accent);">Rs. <?php echo number_format($inf['amount'], 2); ?></strong>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <div style="display:flex; justify-content:space-between; margin-top:20px; border-top:1.5px solid var(--border-color); padding-top:10px; font-weight:900; font-size:14.5px; color:var(--accent);">
                <span>TOTAL INFLOWS (+)</span>
                <span>Rs. <?php echo number_format($total_inflow, 2); ?></span>
            </div>
        </div>

        <!-- OUTFLOWS -->
        <div>
            <div style="font-weight:800; font-size:15px; color:var(--text-main); border-bottom:2px solid var(--border-color); padding-bottom:4px; margin-bottom:12px; text-transform:uppercase;">CASH OUTFLOWS</div>
            <div style="display:flex; flex-direction:column; gap:10px; min-height:150px;">
                <?php if (empty($outflows)): ?>
                    <div style="font-size:12.5px; color:var(--text-muted); text-align:center; padding:30px;">No liquid outflows recorded.</div>
                <?php else: ?>
                    <?php foreach($outflows as $outf): ?>
                        <div style="display:flex; justify-content:space-between; font-size:13px; border-bottom:1px dashed var(--border-color); padding-bottom:6px;">
                            <div>
                                <span style="display:block; font-weight:700;"><?php echo htmlspecialchars($outf['description']); ?></span>
                                <span style="font-size:11px; color:var(--text-muted);">Ref: <?php echo htmlspecialchars($outf['reference_no']); ?></span>
                            </div>
                            <strong style="color:var(--danger);">Rs. <?php echo number_format($outf['amount'], 2); ?></strong>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <div style="display:flex; justify-content:space-between; margin-top:20px; border-top:1.5px solid var(--border-color); padding-top:10px; font-weight:900; font-size:14.5px; color:var(--danger);">
                <span>TOTAL OUTFLOWS (-)</span>
                <span>Rs. <?php echo number_format($total_outflow, 2); ?></span>
            </div>
        </div>

    </div>

    <!-- 3. Net Cash summary block -->
    <div style="display:flex; justify-content:space-between; margin-top:20px; padding:16px; background:var(--bg-secondary); border-radius:var(--radius-sm); border:1.5px solid <?php echo ($net_cash_position >= 0) ? 'var(--accent)' : 'var(--danger)'; ?>;">
        <strong style="font-size:15px; color:var(--text-main);">NET INCREASING LIQUIDITY POSITION</strong>
        <strong style="font-size:20px; color:<?php echo ($net_cash_position >= 0) ? 'var(--accent)' : 'var(--danger)'; ?>;">
            Rs. <?php echo number_format($net_cash_position, 2); ?>
        </strong>
    </div>

</div>

<?php require_once 'includes/footer.php'; ?>
