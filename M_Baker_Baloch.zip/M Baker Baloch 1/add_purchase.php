<?php
/**
 * Purchase & Stock Subsystem - Restocking Terminal Form (Module 5)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = "";

// 1. Process POST incoming Restock Invoice
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $supplier_id = (int)($_POST['supplier_id'] ?? 0);
    $discount = (float)($_POST['discount'] ?? 0);
    $paid_amount = (float)($_POST['paid_amount'] ?? 0);
    $payment_method = sanitize($_POST['payment_method'] ?? 'CASH');
    $notes = sanitize($_POST['notes'] ?? 'Incoming Restock');

    $cart_data = $_POST['purchase_items'] ?? '[]';
    $cart_items = json_decode($cart_data, true);

    if ($supplier_id <= 0) {
        $error_message = "Please select a registered supplier vendor for this purchase.";
    } elseif (empty($cart_items)) {
        $error_message = "Your restocking sheet is empty. Please select products first.";
    } else {
        try {
            $db->beginTransaction();

            $total_amount = 0;
            $items_to_insert = [];

            foreach ($cart_items as $item) {
                $p_id = (int)$item['id'];
                $qty = (int)$item['qty'];
                $cost = (float)$item['cost'];

                if ($qty <= 0 || $cost <= 0) {
                    throw new Exception("Please input positive quantities and cost prices.");
                }

                $subtotal = $cost * $qty;
                $total_amount += $subtotal;

                $items_to_insert[] = [
                    'product_id' => $p_id,
                    'qty' => $qty,
                    'price' => $cost,
                    'total' => $subtotal
                ];
            }

            // Calculations
            $payable_amount = $total_amount - $discount;
            if ($payable_amount < 0) $payable_amount = 0;

            // Payment status tag
            $payment_status = 'UNPAID';
            if ($paid_amount >= $payable_amount) {
                $payment_status = 'PAID';
            } elseif ($paid_amount > 0) {
                $payment_status = 'PARTIAL';
            }

            // Auto Generate Unique Purchase Invoice code
            $purchase_no = 'PUR-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(2)));

            $branch_id = (int)($_SESSION['branch_id'] ?? 1);

            // 1. Insert Purchase Invoice Header
            $ins_pur = $db->prepare("INSERT INTO purchases (branch_id, purchase_no, supplier_id, purchase_date, total_amount, discount, payable_amount, paid_amount, payment_status, payment_method, notes) VALUES (:branch_id, :pur_no, :sup_id, CURRENT_DATE(), :total, :disc, :payable, :paid, :status, :method, :notes)");
            
            $ins_pur->execute([
                'branch_id' => $branch_id,
                'pur_no' => $purchase_no,
                'sup_id' => $supplier_id,
                'total' => $total_amount,
                'disc' => $discount,
                'payable' => $payable_amount,
                'paid' => $paid_amount,
                'status' => $payment_status,
                'method' => $payment_method,
                'notes' => $notes
            ]);
            $purchase_id = $db->lastInsertId();

            // 2. Insert items, increase warehouse stocks, and log histories
            $ins_item = $db->prepare("INSERT INTO purchase_items (purchase_id, product_id, price, qty, total) VALUES (:pur_id, :prod_id, :price, :qty, :total)");
            $increase_stock = $db->prepare("UPDATE products SET stock_qty = stock_qty + :qty WHERE id = :id");
            $log_stock = $db->prepare("INSERT INTO stock_history (product_id, type, qty, reference_id, remarks) VALUES (:prod_id, 'IN', :qty, :ref_id, :remarks)");

            foreach ($items_to_insert as $item) {
                $ins_item->execute([
                    'pur_id' => $purchase_id,
                    'prod_id' => $item['product_id'],
                    'price' => $item['price'],
                    'qty' => $item['qty'],
                    'total' => $item['total']
                ]);

                $increase_stock->execute([
                    'qty' => $item['qty'],
                    'id' => $item['product_id']
                ]);

                $log_stock->execute([
                    'prod_id' => $item['product_id'],
                    'qty' => $item['qty'],
                    'ref_id' => $purchase_id,
                    'remarks' => "Stock Purchase: $purchase_no"
                ]);
            }

            // 3. Update supplier balance if dues are owed to them!
            $remaining_dues = $payable_amount - $paid_amount;
            if ($remaining_dues > 0) {
                $upd_sup = $db->prepare("UPDATE suppliers SET balance = balance + :dues WHERE id = :id");
                $upd_sup->execute(['dues' => $remaining_dues, 'id' => $supplier_id]);
            }

            // 3b. AUTO POST DOUBLE ENTRY ACCOUNTING JOURNAL
            try {
                require_once 'accounting_engine.php';
                $acct = new AccountingEngine($db);
                $acct->postStockPurchaseEntry($purchase_no, $payable_amount, $paid_amount);
            } catch (Exception $e) {}

            $db->commit();

            header("Location: purchase_history.php?success=" . urlencode("Purchase order '$purchase_no' completed successfully. Warehouse inventory replenished."));
            exit;

        } catch (Exception $e) {
            $db->rollBack();
            $error_message = "Restock failed: " . $e->getMessage();
        }
    }
}

// 2. Load Suppliers and Products catalogs for entry form drop lists
$suppliers = [];
$products = [];
try {
    $suppliers = $db->query("SELECT id, name, phone, balance FROM suppliers ORDER BY name ASC")->fetchAll();
    $products = $db->query("SELECT id, name, sku, purchase_price FROM products WHERE status = 'ACTIVE' ORDER BY name ASC")->fetchAll();
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="purchase.css">

<!-- Action Notifications -->
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo $error_message; ?></span>
    </div>
<?php endif; ?>

<div style="margin-bottom: 24px;">
    <a href="purchase.php" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
        <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Purchases Hub
    </a>
</div>

<!-- ==========================================
     PURCHASE TERMINAL SPLIT FORM LAYOUT
     ========================================== -->
<div class="card">
    <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px;">
        <div class="card-title">
            <i class="bx bx-plus-circle"></i>
            <span>Register Inbound Stock restocks Order</span>
        </div>
        <span style="font-size:11px; color:var(--text-muted);">Warehouse ERP</span>
    </div>

    <form id="purchaseForm" method="POST" action="add_purchase.php">
        <input type="hidden" id="purchaseItemsInput" name="purchase_items">

        <div class="purchase-grid-layout">
            
            <!-- Left: Supplier and Product restock rows -->
            <div>
                <!-- Supplier Vendor Select -->
                <div class="form-group">
                    <label class="form-label">Procured Supplier Vendor *</label>
                    <select name="supplier_id" class="select-control" style="width:100%; height:44px;" required>
                        <option value="">-- Choose Registered Vendor --</option>
                        <?php foreach($suppliers as $sup): ?>
                            <option value="<?php echo $sup['id']; ?>">
                                <?php echo htmlspecialchars($sup['name']); ?> 
                                <?php echo ($sup['balance'] > 0) ? ' [Pending Balance Owed: ' . format_currency($sup['balance']) . ']' : ''; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Product multi-injectors -->
                <div style="background:var(--input-bg); border:1px solid var(--border-color); border-radius:var(--radius-sm); padding:15px; margin-bottom:20px;">
                    <h4 style="font-size:13px; font-weight:700; margin-bottom:10px;">Select replenishing product:</h4>
                    
                    <div style="display: flex; gap: 10px;">
                        <select id="purchaseProductSelect" class="select-control" style="flex-grow:1; height:44px;">
                            <option value="">-- Search Registry Products --</option>
                            <?php foreach($products as $p): ?>
                                <option value="<?php echo $p['id']; ?>" 
                                        data-name="<?php echo htmlspecialchars($p['name']); ?>" 
                                        data-sku="<?php echo htmlspecialchars($p['sku']); ?>" 
                                        data-cost="<?php echo $p['purchase_price']; ?>">
                                    <?php echo htmlspecialchars($p['name']); ?> (SKU: <?php echo htmlspecialchars($p['sku']); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        
                        <button type="button" class="btn btn-sm" style="width: auto; height:44px; padding:0 20px;" onclick="addProductToPurchase()">
                            <i class="bx bx-plus-circle"></i> Inject Item
                        </button>
                    </div>
                </div>

                <!-- Active cart table -->
                <div class="table-responsive" style="border: none;">
                    <table class="table" style="font-size:13.5px;">
                        <thead>
                            <tr style="background: var(--bg-primary);">
                                <th>Product Details</th>
                                <th>Restock Qty</th>
                                <th>Buying Cost Price (PKR)</th>
                                <th>Subtotal Line</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody id="purchaseItemsList">
                            <tr>
                                <td colspan="5" style="text-align: center; color: var(--text-muted); padding: 30px;">No products added to procurement sheet.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Right: Checkout billing settings -->
            <div>
                <div class="purchase-cart-card" style="background:var(--bg-base); border-radius:var(--radius-sm); border:1px solid var(--border-color);">
                    <h3 style="font-size:15px; font-weight:800; border-bottom:1.5px dashed var(--border-color); padding-bottom:8px; margin-bottom:15px;">Procurement Summary</h3>
                    
                    <div class="form-group">
                        <label class="form-label">Discount Applied (PKR)</label>
                        <input type="number" id="discountInput" name="discount" class="form-control" style="padding-left:12px; height:44px;" value="0" min="0" onkeyup="recalculatePurchaseTotals()">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Payment Method</label>
                        <select name="payment_method" class="select-control" style="width:100%; height:44px;">
                            <option value="CASH">Cash Drawer Payout</option>
                            <option value="BANK">Bank Remittance / Cheque</option>
                            <option value="CREDIT">Supplier Credit (Outstanding)</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Paid Amount (PKR) *</label>
                        <input type="number" step="0.01" id="paidInput" name="paid_amount" class="form-control" style="padding-left:12px; height:44px;" required placeholder="0.00" onkeyup="recalculatePurchaseTotals()">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Restock Remarks / Notes</label>
                        <textarea name="notes" class="form-control" style="padding:10px; height:60px; resize:none;" placeholder="Supplier receipt reference numbers..."></textarea>
                    </div>

                    <!-- Live tallies drawer -->
                    <div class="purchase-totals-drawer">
                        <div class="purchase-totals-row">
                            <span>Subtotal cost:</span>
                            <strong id="subtotalLabel">PKR 0.00</strong>
                        </div>
                        <div class="purchase-totals-row grand-total">
                            <span>Net Payable:</span>
                            <strong id="payableLabel">PKR 0.00</strong>
                        </div>
                        <div class="purchase-totals-row" style="margin-top: 10px; font-weight:700;">
                            <span id="dueLabel">Dues Owed: PKR 0.00</span>
                        </div>
                    </div>

                    <button type="submit" class="btn" style="height:48px; font-weight:700; font-size:14px; margin-top:20px;">
                        <i class="bx bx-check-shield"></i> Commit Restock Order
                    </button>
                </div>
            </div>

        </div>
    </form>
</div>

<!-- Subsystem JS -->
<script src="purchase.js"></script>

<?php require_once 'includes/footer.php'; ?>
