/**
 * Settings & Admin Control Client Script
 * Shop Name: M.BAKAR BALOCH
 */

document.addEventListener('DOMContentLoaded', () => {
    // Check url hash to auto-open specific tab if present
    const hash = window.location.hash;
    if (hash) {
        switchSettingsTab(hash.replace('#', ''));
    }
});

/**
 * Switch settings sidebar tabs
 */
function switchSettingsTab(tabId) {
    // Update active tab buttons
    const btns = document.querySelectorAll('.settings-tab-btn');
    btns.forEach(btn => {
        if (btn.getAttribute('onclick').includes(tabId)) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });

    // Update active tab contents
    const contents = document.querySelectorAll('.settings-tab-content');
    contents.forEach(content => {
        if (content.id === tabId) {
            content.style.display = 'block';
        } else {
            content.style.display = 'none';
        }
    });

    // Set URL Hash
    window.location.hash = tabId;
}

/**
 * Verify change password credentials matches
 */
function checkSettingsPasswordMatch(event) {
    const newPass = document.getElementById('new_password').value;
    const confirmPass = document.getElementById('confirm_password').value;

    if (newPass !== confirmPass) {
        event.preventDefault();
        alert("The new password and confirmation password do not match. Please type again.");
        return false;
    }
    return true;
}

/**
 * Restore DB file confirm
 */
function confirmDatabaseRestore() {
    return confirm("CAUTION! Restoring a database will completely overwrite all current products, sales invoices, procurement logs, and supplier files. Are you absolutely sure you want to proceed?");
}
