/**
 * Sales POS and Billing Client Engine
 * Shop Name: M.BAKAR BALOCH
 */

let posCart = [];
let taxRate = 0.00;

document.addEventListener('DOMContentLoaded', () => {
    // 1. Fetch system tax rate dynamically from HTML data attribute
    const posForm = document.getElementById('checkoutForm');
    if (posForm) {
        taxRate = parseFloat(posForm.getAttribute('data-tax-rate') || 0);
    }

    // 2. Setup hotkey shortcuts listeners
    initKeyboardShortcuts();

    // 3. Scan inputs check
    initBarcodeScannerSupport();
});

/**
 * Capture hardware hotkeys
 */
function initKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
        // [F2] - Focus product search bar
        if (e.key === 'F2') {
            e.preventDefault();
            const searchInput = document.getElementById('posSearch');
            if (searchInput) searchInput.focus();
        }
        
        // [F8] - Submit checkout form
        if (e.key === 'F8') {
            e.preventDefault();
            const checkoutForm = document.getElementById('checkoutForm');
            if (checkoutForm) checkoutForm.submit();
        }
        
        // [Escape] - Clear cart
        if (e.key === 'Escape') {
            if (confirm("Are you sure you want to completely clear the billing cart?")) {
                clearPosCart();
            }
        }
    });
}

/**
 * Barcode scanner support integration
 */
function initBarcodeScannerSupport() {
    const searchInput = document.getElementById('posSearch');
    if (searchInput) {
        // Hardware scanners typically dump numbers followed by an Enter key.
        // We'll capture keypress and if it matches exact barcodes in cards, auto-add it!
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                const query = searchInput.value.trim();
                
                // Seek product card matching barcode or SKU
                const cards = document.querySelectorAll('.pos-product-card');
                let foundCard = null;

                cards.forEach(card => {
                    const barcode = card.getAttribute('data-barcode');
                    const sku = card.getAttribute('data-sku');
                    if (barcode === query || sku === query) {
                        foundCard = card;
                    }
                });

                if (foundCard) {
                    addToPosCart(foundCard);
                    searchInput.value = ''; // Reset input immediately for next scan!
                }
            }
        });
    }
}

/**
 * Add product to billing cart
 */
function addToPosCart(cardElement) {
    const id = parseInt(cardElement.getAttribute('data-id'));
    const name = cardElement.getAttribute('data-name');
    const sku = cardElement.getAttribute('data-sku');
    const price = parseFloat(cardElement.getAttribute('data-price'));
    const stock = parseInt(cardElement.getAttribute('data-stock'));

    if (stock <= 0) {
        alert("Product is out of stock in the warehouse!");
        return;
    }

    const existing = posCart.find(item => item.id === id);
    if (existing) {
        if (existing.qty >= stock) {
            alert("Exceeds current physical stock (" + stock + " pcs).");
            return;
        }
        existing.qty++;
    } else {
        posCart.push({
            id: id,
            name: name,
            sku: sku,
            price: price,
            qty: 1,
            stock: stock
        });
    }

    renderPosCart();
}

function decrementPosQty(id) {
    const item = posCart.find(item => item.id === id);
    if (item) {
        item.qty--;
        if (item.qty <= 0) {
            removePosItem(id);
        } else {
            renderPosCart();
        }
    }
}

function incrementPosQty(id) {
    const item = posCart.find(item => item.id === id);
    if (item) {
        if (item.qty >= item.stock) {
            alert("Cannot exceed physical stock.");
            return;
        }
        item.qty++;
        renderPosCart();
    }
}

function removePosItem(id) {
    posCart = posCart.filter(item => item.id !== id);
    renderPosCart();
}

function clearPosCart() {
    posCart = [];
    renderPosCart();
}

/**
 * Output items to DOM
 */
function renderPosCart() {
    const list = document.getElementById('cartItemsList');
    if (!list) return;

    if (posCart.length === 0) {
        list.innerHTML = `<tr><td colspan="4" style="text-align: center; color: var(--text-muted); padding: 40px;">No items added to billing receipt.</td></tr>`;
        recalculatePosTotals();
        return;
    }

    list.innerHTML = '';
    posCart.forEach(item => {
        const itemTotal = item.price * item.qty;
        list.innerHTML += `
            <tr class="animate-fade">
                <td>
                    <strong>${item.name}</strong>
                    <span style="display:block; font-size:10px; color:var(--text-muted);">${item.sku}</span>
                </td>
                <td>
                    <div class="cart-item-qty">
                        <button type="button" class="cart-qty-btn" onclick="decrementPosQty(${item.id})">-</button>
                        <span class="cart-qty-input">${item.qty}</span>
                        <button type="button" class="cart-qty-btn" onclick="incrementPosQty(${item.id})">+</button>
                    </div>
                </td>
                <td style="font-weight:600;">PKR ${itemTotal.toFixed(2)}</td>
                <td>
                    <i class="bx bx-trash" style="color:var(--error); cursor:pointer;" onclick="removePosItem(${item.id})"></i>
                </td>
            </tr>
        `;
    });

    recalculatePosTotals();
}

/**
 * Live POS mathematical tallies
 */
function recalculatePosTotals() {
    let subtotal = 0;
    posCart.forEach(item => {
        subtotal += item.price * item.qty;
    });

    // Calculates tax rate
    const taxAmount = subtotal * (taxRate / 100);

    // Calculates discounts
    const discount = parseFloat(document.getElementById('discountInput').value) || 0;
    
    let grandTotal = subtotal + taxAmount - discount;
    if (grandTotal < 0) grandTotal = 0;

    const paid = parseFloat(document.getElementById('paidAmountInput').value) || 0;
    const balance = paid - grandTotal;

    // Fill UI
    document.getElementById('subtotalLabel').innerText = 'PKR ' + subtotal.toFixed(2);
    document.getElementById('taxLabel').innerText = 'PKR ' + taxAmount.toFixed(2) + ' (' + (taxRate * 100).toFixed(0) / 100 + '%)';
    document.getElementById('discountLabel').innerText = '- PKR ' + discount.toFixed(2);
    document.getElementById('payableLabel').innerText = 'PKR ' + grandTotal.toFixed(2);

    const changeLabel = document.getElementById('changeLabel');
    if (changeLabel) {
        if (balance >= 0) {
            changeLabel.innerText = 'Change Returned: PKR ' + balance.toFixed(2);
            changeLabel.style.color = 'var(--accent)';
        } else {
            changeLabel.innerText = 'Remaining Dues: PKR ' + Math.abs(balance).toFixed(2);
            changeLabel.style.color = 'var(--error)';
        }
    }

    // Sync input variables for submission
    document.getElementById('cartItemsInput').value = JSON.stringify(posCart);
}
