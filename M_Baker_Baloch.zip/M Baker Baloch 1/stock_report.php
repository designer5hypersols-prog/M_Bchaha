<?php
/**
 * Reports & Profit/Loss Subsystem - Stock Valuation Report (Module 10)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = "";

// 1. FILTER PARAMETERS
$search = sanitize($_GET['search'] ?? '');
$category_filter = sanitize($_GET['category'] ?? '');

$limit = 15; // Products per page
$page = (int)($_GET['page'] ?? 1);
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

$query_base = "SELECT * FROM products WHERE status = 'ACTIVE'";
$params = [];

if (!empty($search)) {
    $query_base .= " AND (name LIKE :search OR sku LIKE :search OR barcode LIKE :search)";
    $params['search'] = "%$search%";
}

if (!empty($category_filter)) {
    $query_base .= " AND category = :cat";
    $params['cat'] = $category_filter;
}

// Calculate pagination parameters
try {
    $count_query = "SELECT COUNT(*) FROM (" . $query_base . ") as sub";
    $count_stmt = $db->prepare($count_query);
    $count_stmt->execute($params);
    $total_records = (int)$count_stmt->fetchColumn();
} catch (PDOException $e) {
    $total_records = 0;
}

$total_pages = ceil($total_records / $limit);
if ($total_pages < 1) $total_pages = 1;
if ($page > $total_pages) $page = $total_pages;
$offset = ($page - 1) * $limit;

// Load records
try {
    $load_query = $query_base . " ORDER BY name ASC LIMIT $limit OFFSET $offset";
    $load_stmt = $db->prepare($load_query);
    $load_stmt->execute($params);
    $products = $load_stmt->fetchAll();

    // Compute Overall Asset Valuations (Unfiltered overall sum)
    $total_stock_qty = $db->query("SELECT SUM(stock_qty) FROM products WHERE status = 'ACTIVE'")->fetchColumn() ?: 0;
    
    $total_asset_cost = $db->query("SELECT SUM(stock_qty * purchase_price) FROM products WHERE status = 'ACTIVE'")->fetchColumn() ?: 0.00;
    $total_asset_retail = $db->query("SELECT SUM(stock_qty * sell_price) FROM products WHERE status = 'ACTIVE'")->fetchColumn() ?: 0.00;
    
    $potential_profit_yield = $total_asset_retail - $total_asset_cost;

} catch (PDOException $e) {
    $total_stock_qty = $total_asset_cost = $total_asset_retail = $potential_profit_yield = 0;
    $products = [];
}

// Load metadata lists
$categories = [];
try {
    $categories = $db->query("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != ''")->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="reports.css">

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <a href="reports.php" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
            <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Reports Hub
        </a>
    </div>
    
    <div style="display: flex; gap: 10px;">
        <button type="button" class="btn btn-sm btn-secondary" style="width: auto;" onclick="exportReportTableToCSV('stockValuationTable', 'mbakar_baloch_stock_valuation_report')">
            <i class="bx bx-download"></i> Export Valuation CSV
        </button>
    </div>
</div>

<!-- ==========================================
     INVENTORY VALUATIONS STAT CARDS GRID
     ========================================== -->
<div class="reports-kpi-grid" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));">
    <!-- Warehouse Assets Quantities -->
    <div class="stat-card primary">
        <div class="stat-info">
            <span>Overall Stock Quantities</span>
            <h2><?php echo $total_stock_qty; ?> <span style="font-size:12px; font-weight:400; color:var(--text-muted);">items</span></h2>
        </div>
        <div class="stat-icon"><i class="bx bx-cabinet"></i></div>
    </div>

    <!-- Assets Investment Cost -->
    <div class="stat-card danger" style="border-left: 4px solid var(--error);">
        <div class="stat-info">
            <span>Investment Buy Cost Value</span>
            <h2><?php echo format_currency($total_asset_cost); ?></h2>
        </div>
        <div class="stat-icon"><i class="bx bx-wallet-toggle"></i></div>
    </div>

    <!-- Assets Retail Value -->
    <div class="stat-card success" style="border-left: 4px solid var(--accent);">
        <div class="stat-info">
            <span>Potential Retail Value</span>
            <h2><?php echo format_currency($total_asset_retail); ?></h2>
        </div>
        <div class="stat-icon"><i class="bx bx-receipt"></i></div>
    </div>

    <!-- Potential Profit Yield -->
    <div class="stat-card success">
        <div class="stat-info">
            <span>Potential Margin Yield</span>
            <h2><?php echo format_currency($potential_profit_yield); ?></h2>
        </div>
        <div class="stat-icon"><i class="bx bx-line-chart"></i></div>
    </div>
</div>

<!-- ==========================================
     ADVANCED INVENTORY FILTERS
     ========================================== -->
<div class="search-filter-section" style="margin-bottom: 24px;">
    <form method="GET" action="stock_report.php" style="display: flex; flex-grow: 1; flex-wrap: wrap; gap: 15px; width: 100%;">
        
        <div class="search-input-group">
            <i class="bx bx-search"></i>
            <input type="text" name="search" class="search-control" placeholder="Search product name, SKU, barcode..." value="<?php echo htmlspecialchars($search); ?>">
        </div>

        <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
            <!-- Category Filter dropdown -->
            <select name="category" class="select-control" style="width: auto; height: 44px;" onchange="this.form.submit()">
                <option value="">All Catalog Categories</option>
                <?php foreach($categories as $cat): ?>
                    <option value="<?php echo htmlspecialchars($cat); ?>" <?php echo $category_filter === $cat ? 'selected' : ''; ?>><?php echo htmlspecialchars($cat); ?></option>
                <?php endforeach; ?>
            </select>

            <button type="submit" class="btn btn-sm btn-secondary" style="height: 44px;">Filter</button>
        </div>
    </form>
</div>

<!-- ==========================================
     STOCK VALUATION DETAILS TABLE
     ========================================== -->
<div class="card">
    <div class="table-responsive">
        <table class="table" id="stockValuationTable">
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Product SKU</th>
                    <th>Category</th>
                    <th>Stock Qty</th>
                    <th>Buying Cost</th>
                    <th>Retail Selling</th>
                    <th>Total Investment</th>
                    <th>Total Retail Worth</th>
                    <th>Potential Profit</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($products)): ?>
                    <tr>
                        <td colspan="9" style="text-align: center; color: var(--text-muted); padding: 45px;">No active inventory products match current filters.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach($products as $p): 
                        $stock = (int)$p['stock_qty'];
                        $cost = (float)$p['purchase_price'];
                        $retail = (float)$p['sell_price'];
                        
                        $inv_val = $stock * $cost;
                        $ret_val = $stock * $retail;
                        $yield_val = $ret_val - $inv_val;
                    ?>
                        <tr class="animate-fade">
                            <td>
                                <strong><?php echo htmlspecialchars($p['name']); ?></strong>
                                <?php if ($stock <= $p['min_stock_qty']): ?>
                                    <span style="display:inline-block; font-size:10px; padding:2px 6px; background:var(--danger-glow); color:var(--danger); border-radius:4px; font-weight:700; margin-left:6px;">LOW</span>
                                <?php endif; ?>
                            </td>
                            <td style="font-weight: 600; color: var(--accent);"><?php echo htmlspecialchars($p['sku']); ?></td>
                            <td><span class="status-pill info"><?php echo htmlspecialchars($p['category']); ?></span></td>
                            <td style="font-weight:700;"><?php echo $stock; ?> <?php echo htmlspecialchars($p['unit']); ?></td>
                            <td><?php echo format_currency($cost); ?></td>
                            <td><?php echo format_currency($retail); ?></td>
                            <td style="font-weight:600;"><?php echo format_currency($inv_val); ?></td>
                            <td style="font-weight:600;"><?php echo format_currency($ret_val); ?></td>
                            <td style="font-weight: 700; color: var(--accent);"><?php echo format_currency($yield_val); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ==========================================
     PAGINATION CONTROL ROW FOOTER
     ========================================== -->
<div class="pagination" style="margin-top: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <span style="font-size: 13.5px; color: var(--text-secondary);">Showing <strong><?php echo count($products); ?></strong> of <strong><?php echo $total_records; ?></strong> catalog lines.</span>
    
    <div style="display: flex; gap: 5px;">
        <a href="stock_report.php?page=<?php echo ($page - 1); ?>&search=<?php echo urlencode($search); ?>&category=<?php echo urlencode($category_filter); ?>" 
           class="btn btn-sm btn-secondary <?php echo ($page <= 1) ? 'disabled' : ''; ?>" 
           style="width: auto; padding: 6px 12px; pointer-events: <?php echo ($page <= 1) ? 'none' : 'auto'; ?>;">
           &larr; Prev
        </a>

        <?php for($k = 1; $k <= $total_pages; $k++): ?>
            <a href="stock_report.php?page=<?php echo $k; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo urlencode($category_filter); ?>" 
               class="btn btn-sm <?php echo ($page === $k) ? '' : 'btn-secondary'; ?>" 
               style="width: 32px; padding: 6px 0; text-align: center;">
               <?php echo $k; ?>
            </a>
        <?php endfor; ?>

        <a href="stock_report.php?page=<?php echo ($page + 1); ?>&search=<?php echo urlencode($search); ?>&category=<?php echo urlencode($category_filter); ?>" 
           class="btn btn-sm btn-secondary <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>" 
           style="width: auto; padding: 6px 12px; pointer-events: <?php echo ($page >= $total_pages) ? 'none' : 'auto'; ?>;">
           Next &rarr;
        </a>
    </div>
</div>

<!-- Subsystem JS -->
<script src="reports.js"></script>

<?php require_once 'includes/footer.php'; ?>
