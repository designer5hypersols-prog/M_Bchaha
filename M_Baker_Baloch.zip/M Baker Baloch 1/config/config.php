<?php
define('APP_NAME', 'M.BAKAR BALOCH ERP SaaS');
define('APP_URL', 'http://localhost');
define('DB_HOST', 'localhost');
define('DB_NAME', 'mbakar_baloch_erp');
define('DB_USER', 'root');
define('DB_PASS', '');
