<?php
/**
 * Database Connection & Self-Healing Schemas
 * SaaS Module Core - M.BAKAR BALOCH ERP
 */

define('S_DB_HOST', 'localhost');
define('S_DB_USER', 'root');
define('S_DB_PASS', '');
define('S_DB_NAME', 'mbakar_baloch_db');

class SaaSDB {
    private static $instance = null;
    private $conn;

    private function __construct() {
        try {
            $dsn = "mysql:host=" . S_DB_HOST . ";dbname=" . S_DB_NAME . ";charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];
            $this->conn = new PDO($dsn, S_DB_USER, S_DB_PASS, $options);
            $this->bootstrapDatabase();
        } catch (PDOException $e) {
            die("SaaS Database connection failed: " . $e->getMessage());
        }
    }

    public static function getConnection() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance->conn;
    }

    /**
     * Set up essential multi-tenant tables and demo seeds if empty
     */
    private function bootstrapDatabase() {
        // 1. Create Users Table with tenant_id
        $this->conn->exec("CREATE TABLE IF NOT EXISTS `users` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `name` VARCHAR(100) NOT NULL,
            `email` VARCHAR(100) NOT NULL UNIQUE,
            `password` VARCHAR(255) NOT NULL,
            `role` ENUM('admin', 'manager', 'cashier') NOT NULL,
            `tenant_id` INT NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 2. Create Products Table with tenant_id
        $this->conn->exec("CREATE TABLE IF NOT EXISTS `products` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `name` VARCHAR(100) NOT NULL,
            `price` DECIMAL(10,2) NOT NULL,
            `stock` INT NOT NULL,
            `min_stock_level` INT NOT NULL DEFAULT 10,
            `tenant_id` INT NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        try {
            $this->conn->exec("ALTER TABLE `products` ADD COLUMN `min_stock_level` INT NOT NULL DEFAULT 10;");
        } catch (PDOException $e) {
            // Column already exists, safe to ignore
        }

        // 3. Create Sales Table with tenant_id
        $this->conn->exec("CREATE TABLE IF NOT EXISTS `sales` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `invoice_no` VARCHAR(50) NOT NULL UNIQUE,
            `customer_name` VARCHAR(100) NOT NULL,
            `total` DECIMAL(10,2) NOT NULL,
            `discount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            `grand_total` DECIMAL(10,2) NOT NULL,
            `paid` DECIMAL(10,2) NOT NULL,
            `due` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `tenant_id` INT NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 4. Create Sale Items Table
        $this->conn->exec("CREATE TABLE IF NOT EXISTS `sale_items` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `sale_id` INT NOT NULL,
            `product_id` INT NOT NULL,
            `product_name` VARCHAR(100) NOT NULL,
            `price` DECIMAL(10,2) NOT NULL,
            `quantity` INT NOT NULL,
            `subtotal` DECIMAL(10,2) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // Create Purchases Table with tenant_id
        $this->conn->exec("CREATE TABLE IF NOT EXISTS `purchases` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `purchase_no` VARCHAR(50) NOT NULL UNIQUE,
            `supplier_name` VARCHAR(100) NOT NULL,
            `total` DECIMAL(10,2) NOT NULL,
            `paid` DECIMAL(10,2) NOT NULL,
            `due` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `tenant_id` INT NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // Create Purchase Items Table
        $this->conn->exec("CREATE TABLE IF NOT EXISTS `purchase_items` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `purchase_id` INT NOT NULL,
            `product_id` INT NOT NULL,
            `product_name` VARCHAR(100) NOT NULL,
            `cost_price` DECIMAL(10,2) NOT NULL,
            `quantity` INT NOT NULL,
            `subtotal` DECIMAL(10,2) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // Create Stock Logs Table with tenant_id
        $this->conn->exec("CREATE TABLE IF NOT EXISTS `stock_logs` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `product_id` INT NOT NULL,
            `type` ENUM('IN','OUT','ADJUSTMENT') NOT NULL,
            `quantity` INT NOT NULL,
            `reference` VARCHAR(100) NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `tenant_id` INT NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // Create Ledger Table with tenant_id
        $this->conn->exec("CREATE TABLE IF NOT EXISTS `ledger` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `tenant_id` INT NOT NULL,
            `type` ENUM('customer','supplier') NOT NULL,
            `party_name` VARCHAR(100) NOT NULL,
            `party_id` INT DEFAULT NULL,
            `debit` DECIMAL(10,2) DEFAULT 0.00,
            `credit` DECIMAL(10,2) DEFAULT 0.00,
            `balance` DECIMAL(10,2) DEFAULT 0.00,
            `reference` VARCHAR(100) NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // Create Payments Table with tenant_id
        $this->conn->exec("CREATE TABLE IF NOT EXISTS `payments` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `tenant_id` INT NOT NULL,
            `type` ENUM('customer','supplier') NOT NULL,
            `party_name` VARCHAR(100) NOT NULL,
            `amount` DECIMAL(10,2) NOT NULL,
            `payment_method` VARCHAR(50) NOT NULL,
            `reference` VARCHAR(100) NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // Create Accounts Table with tenant_id (Chart of Accounts)
        $this->conn->exec("CREATE TABLE IF NOT EXISTS `accounts` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `tenant_id` INT NOT NULL,
            `account_name` VARCHAR(100) NOT NULL,
            `account_type` ENUM('Asset','Liability','Equity','Income','Expense') NOT NULL,
            `account_code` VARCHAR(20) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // Create Journal Entries Table with tenant_id
        $this->conn->exec("CREATE TABLE IF NOT EXISTS `journal_entries` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `tenant_id` INT NOT NULL,
            `entry_date` DATE NOT NULL,
            `description` TEXT NOT NULL,
            `reference_no` VARCHAR(50) NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // Create Journal Items Table
        $this->conn->exec("CREATE TABLE IF NOT EXISTS `journal_items` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `journal_id` INT NOT NULL,
            `account_id` INT NOT NULL,
            `debit` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            `credit` DECIMAL(10,2) NOT NULL DEFAULT 0.00
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // Seed Chart of Accounts for Tenant 1 & 2
        $acc_count = $this->conn->query("SELECT COUNT(*) FROM `accounts`")->fetchColumn();
        if ($acc_count == 0) {
            $stmt = $this->conn->prepare("INSERT INTO `accounts` (`tenant_id`, `account_name`, `account_type`, `account_code`) VALUES (:tenant, :name, :type, :code)");
            
            $standard_coa = [
                ['name' => 'Cash in Hand', 'type' => 'Asset', 'code' => '1001'],
                ['name' => 'Bank Account Balance', 'type' => 'Asset', 'code' => '1002'],
                ['name' => 'Accounts Receivable (Customer Dues)', 'type' => 'Asset', 'code' => '1003'],
                ['name' => 'Inventory Asset Stock', 'type' => 'Asset', 'code' => '1004'],
                ['name' => 'Accounts Payable (Supplier Liabilities)', 'type' => 'Liability', 'code' => '2001'],
                ['name' => 'Retained Earnings / Capital', 'type' => 'Equity', 'code' => '3001'],
                ['name' => 'Sales Revenue', 'type' => 'Income', 'code' => '4001'],
                ['name' => 'Cost of Goods Sold (COGS)', 'type' => 'Expense', 'code' => '5001'],
                ['name' => 'General & Administrative Expenses', 'type' => 'Expense', 'code' => '5002'],
            ];

            foreach ([1, 2] as $t_id) {
                foreach ($standard_coa as $row) {
                    $stmt->execute([
                        'tenant' => $t_id,
                        'name' => $row['name'],
                        'type' => $row['type'],
                        'code' => $row['code']
                    ]);
                }
            }
        }

        // Seed Ledger defaults
        $ledger_count = $this->conn->query("SELECT COUNT(*) FROM `ledger`")->fetchColumn();
        if ($ledger_count == 0) {
            $stmt = $this->conn->prepare("INSERT INTO `ledger` (`tenant_id`, `type`, `party_name`, `party_id`, `debit`, `credit`, `balance`, `reference`) 
                                         VALUES (:tenant, :type, :party_name, :party_id, :debit, :credit, :balance, :ref)");
                                         
            // Tenant 1
            $stmt->execute(['tenant' => 1, 'type' => 'customer', 'party_name' => 'Ahmed Baloch', 'party_id' => null, 'debit' => 5000.00, 'credit' => 1500.00, 'balance' => 3500.00, 'ref' => 'MBB-20260519-0001']);
            $stmt->execute(['tenant' => 1, 'type' => 'supplier', 'party_name' => 'Balochistan Wholesalers', 'party_id' => null, 'debit' => 4000.00, 'credit' => 12000.00, 'balance' => 8000.00, 'ref' => 'MBP-20260519-0001']);
            
            // Tenant 2
            $stmt->execute(['tenant' => 2, 'type' => 'customer', 'party_name' => 'Quetta Hotel', 'party_id' => null, 'debit' => 8000.00, 'credit' => 3000.00, 'balance' => 5000.00, 'ref' => 'MBB-20260519-0002']);
            $stmt->execute(['tenant' => 2, 'type' => 'supplier', 'party_name' => 'Karan Dry Fruits Supplier', 'party_id' => null, 'debit' => 15000.00, 'credit' => 25000.00, 'balance' => 10000.00, 'ref' => 'MBP-20260519-0002']);
        }

        // 5. Seed Default Accounts (Password is always admin123)
        $user_count = $this->conn->query("SELECT COUNT(*) FROM `users`")->fetchColumn();
        if ($user_count == 0) {
            $hash = password_hash('admin123', PASSWORD_BCRYPT);
            
            $stmt = $this->conn->prepare("INSERT INTO `users` (`name`, `email`, `password`, `role`, `tenant_id`) VALUES (:name, :email, :pass, :role, :tenant)");
            
            // Tenant 1 - M.BAKAR BALOCH Shop
            $stmt->execute(['name' => 'Bakar Baloch Admin', 'email' => 'admin@mbakar.com', 'pass' => $hash, 'role' => 'admin', 'tenant' => 1]);
            $stmt->execute(['name' => 'Kashif Cashier', 'email' => 'cashier@mbakar.com', 'pass' => $hash, 'role' => 'cashier', 'tenant' => 1]);

            // Tenant 2 - Quetta Dry Fruits
            $stmt->execute(['name' => 'Quetta Admin', 'email' => 'admin@quetta.com', 'pass' => $hash, 'role' => 'admin', 'tenant' => 2]);
        }

        // 6. Seed Default Products
        $prod_count = $this->conn->query("SELECT COUNT(*) FROM `products`")->fetchColumn();
        if ($prod_count == 0) {
            $stmt = $this->conn->prepare("INSERT INTO `products` (`name`, `price`, `stock`, `min_stock_level`, `tenant_id`) VALUES (:name, :price, :stock, :min_stock, :tenant)");
            
            // Products for Tenant 1
            $stmt->execute(['name' => 'Premium Nylon Broom', 'price' => 350.00, 'stock' => 150, 'min_stock' => 20, 'tenant' => 1]);
            $stmt->execute(['name' => 'Heavy Floor Wiper', 'price' => 480.00, 'stock' => 8, 'min_stock' => 15, 'tenant' => 1]);
            
            // Products for Tenant 2
            $stmt->execute(['name' => 'Roasted Almonds (1kg)', 'price' => 1800.00, 'stock' => 0, 'min_stock' => 10, 'tenant' => 2]);
            $stmt->execute(['name' => 'Salted Pistachios (500g)', 'price' => 1200.00, 'stock' => 60, 'min_stock' => 12, 'tenant' => 2]);
        }

        // Self-heal already created products to trigger alert warnings for live testing
        $this->conn->exec("UPDATE `products` SET `min_stock_level` = 20 WHERE `name` = 'Premium Nylon Broom' AND `tenant_id` = 1");
        $this->conn->exec("UPDATE `products` SET `min_stock_level` = 15, `stock` = 8 WHERE `name` = 'Heavy Floor Wiper' AND `tenant_id` = 1");
        $this->conn->exec("UPDATE `products` SET `min_stock_level` = 10, `stock` = 0 WHERE `name` = 'Roasted Almonds (1kg)' AND `tenant_id` = 2");
        $this->conn->exec("UPDATE `products` SET `min_stock_level` = 12 WHERE `name` = 'Salted Pistachios (500g)' AND `tenant_id` = 2");
    }
}
