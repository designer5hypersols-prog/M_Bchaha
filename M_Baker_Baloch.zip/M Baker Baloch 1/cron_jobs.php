<?php
/**
 * Automated Notifications Subsystem - CLI Background Cron Script (Module 6)
 * Shop Name: M.BAKAR BALOCH
 */

header('Content-Type: text/plain; charset=UTF-8');

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'message_scheduler.php';

// Enforce secret access key to prevent public browser triggering overload
$secret_key = "MBAKAR_SECURE_CRON";
$given_key = $_GET['secret'] ?? '';

// Check if running in CLI or if the correct secret is provided in web URL
if (php_sapi_name() !== 'cli' && $given_key !== $secret_key) {
    http_response_code(403);
    die("Access Denied: Invalid cron secret key parameter. Run this task over command-line CLI.");
}

echo "==========================================================\n";
echo "M.BAKAR BALOCH ERP - CRON TASKS AUTOMATED DISPATCHER\n";
echo "==========================================================\n";
echo "Starting background cron processes: " . date('Y-m-d H:i:s') . "\n\n";

// Execute Outstanding Dues balance reminders
$scheduler = new MessageScheduler();
$outcome = $scheduler->dispatchDueReminders();

echo $outcome;
echo "\nBackground cron jobs run completed successfully at " . date('Y-m-d H:i:s') . "\n";
echo "==========================================================\n";
