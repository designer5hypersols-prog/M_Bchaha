<?php
/**
 * Customer & Supplier Ledger Subsystem - Suppliers directory (Module 7)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = sanitize($_GET['success'] ?? '');

// 1. SELF-HEALING DATABASE MIGRATION CHECK
try {
    $db->query("SELECT 1 FROM supplier_payments LIMIT 1");
} catch (PDOException $e) {
    // Table doesn't exist, execute migrations!
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS `supplier_payments` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `supplier_id` INT NOT NULL,
            `amount` DECIMAL(10, 2) NOT NULL,
            `payment_date` DATE NOT NULL,
            `payment_method` ENUM('CASH', 'BANK') NOT NULL DEFAULT 'CASH',
            `notes` TEXT DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (PDOException $ex) {}
}

// 2. PROCESS POST ADD SUPPLIER
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $name = sanitize($_POST['name'] ?? '');
    $contact = sanitize($_POST['contact_person'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $address = sanitize($_POST['address'] ?? '');
    $balance = (float)($_POST['balance'] ?? 0.00);

    if (empty($name)) {
        $error_message = "Please input the supplier business name.";
    } else {
        try {
            $ins = $db->prepare("INSERT INTO suppliers (name, contact_person, phone, email, address, balance) VALUES (:name, :contact, :phone, :email, :address, :balance)");
            $ins->execute([
                'name' => $name,
                'contact' => $contact,
                'phone' => $phone,
                'email' => $email,
                'address' => $address,
                'balance' => $balance
            ]);
            $success_message = "Supplier '$name' registered successfully in directories.";
        } catch (PDOException $e) {
            $error_message = "Insert failure: " . $e->getMessage();
        }
    }
}

// 3. LOAD SUPPLIER PROFILES AND AGGREGATE LEDGERS
$search = sanitize($_GET['search'] ?? '');
$suppliers = [];
try {
    $query = "SELECT * FROM suppliers WHERE 1=1";
    $params = [];

    if (!empty($search)) {
        $query .= " AND (name LIKE :search OR contact_person LIKE :search OR phone LIKE :search)";
        $params['search'] = "%$search%";
    }
    
    $query .= " ORDER BY name ASC";
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $raw_suppliers = $stmt->fetchAll();

    // Map aggregates
    foreach ($raw_suppliers as $s) {
        $id = $s['id'];
        
        // Sum total purchases restocks
        $total_purchases = $db->query("SELECT SUM(payable_amount) FROM purchases WHERE supplier_id = $id")->fetchColumn() ?: 0.00;
        
        // Sum total paid restocks + separate clearing payments installments
        $paid_restocks = $db->query("SELECT SUM(paid_amount) FROM purchases WHERE supplier_id = $id")->fetchColumn() ?: 0.00;
        $paid_clearings = $db->query("SELECT SUM(amount) FROM supplier_payments WHERE supplier_id = $id")->fetchColumn() ?: 0.00;
        
        $total_paid = $paid_restocks + $paid_clearings;

        $suppliers[] = [
            'id' => $id,
            'name' => $s['name'],
            'contact_person' => $s['contact_person'],
            'phone' => $s['phone'],
            'address' => $s['address'],
            'balance' => (float)$s['balance'],
            'total_purchases' => $total_purchases,
            'total_paid' => $total_paid
        ];
    }

    // Accounts Payable dues
    $ap_dues = $db->query("SELECT SUM(balance) FROM suppliers")->fetchColumn() ?: 0.00;

} catch (PDOException $e) {
    $ap_dues = 0;
}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="ledger.css">

<!-- Action Notifications -->
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger">
        <i class="bx bx-error-circle"></i>
        <span><?php echo $error_message; ?></span>
    </div>
<?php endif; ?>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success">
        <i class="bx bx-check-circle"></i>
        <span><?php echo $success_message; ?></span>
    </div>
<?php endif; ?>

<!-- ==========================================
     PAYABLES STAT CARD & ACTION HUB
     ========================================== -->
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 24px; align-items: center; flex-wrap: wrap;">
    <div class="stat-card danger" style="margin-bottom:0; max-width: 320px; border-left:4px solid var(--error);">
        <div class="stat-info">
            <span>Outstanding Accounts Payable</span>
            <h2><?php echo format_currency($ap_dues); ?></h2>
        </div>
        <div class="stat-icon"><i class="bx bx-truck"></i></div>
    </div>
    
    <div style="display: flex; gap: 10px; justify-content: flex-end; height: 48px;">
        <button type="button" class="btn btn-secondary" style="width: auto;" onclick="openModal('settleSupplierModal')">
            <i class="bx bx-wallet"></i> Settle Supplier Payout
        </button>
        <button type="button" class="btn" style="width: auto;" onclick="openModal('addSupplierModal')">
            <i class="bx bx-plus-circle"></i> Register Supplier Vendor
        </button>
    </div>
</div>

<!-- Search filter -->
<div class="search-filter-section" style="margin-bottom: 24px;">
    <form method="GET" action="suppliers.php" style="display: flex; width:100%;">
        <div class="search-input-group" style="max-width:100%;">
            <i class="bx bx-search"></i>
            <input type="text" name="search" class="search-control" placeholder="Search supplier name, phone..." value="<?php echo htmlspecialchars($search); ?>">
        </div>
    </form>
</div>

<!-- ==========================================
     SUPPLIER RECORDS DIRECTORY GRID
     ========================================== -->
<div class="card">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Supplier Name</th>
                    <th>Contact Person</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Total restocks</th>
                    <th>Total Payouts</th>
                    <th>Pending Balance Owed</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($suppliers)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 40px;">No supplier records registered.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach($suppliers as $s): ?>
                        <tr class="animate-fade">
                            <td><strong><?php echo htmlspecialchars($s['name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($s['contact_person'] ?: '-'); ?></td>
                            <td><?php echo htmlspecialchars($s['phone'] ?: '-'); ?></td>
                            <td><span style="font-size: 12.5px; color:var(--text-secondary);"><?php echo htmlspecialchars($s['address'] ?: '-'); ?></span></td>
                            <td style="font-weight:600;"><?php echo format_currency($s['total_purchases']); ?></td>
                            <td style="font-weight:600; color:var(--accent);"><?php echo format_currency($s['total_paid']); ?></td>
                            <td>
                                <?php if ($s['balance'] > 0): ?>
                                    <span class="status-indicator due">Dues: <?php echo format_currency($s['balance']); ?></span>
                                <?php else: ?>
                                    <span class="status-indicator paid">Cleared</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="action-btns">
                                    <a href="supplier_ledger.php?id=<?php echo $s['id']; ?>" class="btn-action" title="View Statement Ledger Timeline" style="display:inline-flex; align-items:center; justify-content:center; text-decoration:none;">
                                        <i class="bx bx-receipt"></i>
                                    </a>
                                    <button type="button" class="btn-action" title="Quick pay dues settlement" onclick="triggerSupplierPayModal(<?php echo $s['id']; ?>, <?php echo $s['balance']; ?>)">
                                        <i class="bx bx-wallet"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ==========================================
     ADD SUPPLIER MODAL OVERLAY
     ========================================== -->
<div id="addSupplierModal" class="modal-overlay">
    <div class="modal-content" style="max-width: 520px;">
        <div class="modal-header">
            <h3>Register New Supplier Vendor</h3>
            <i class="bx bx-x modal-close" onclick="closeModal('addSupplierModal')"></i>
        </div>

        <form method="POST" action="suppliers.php">
            <input type="hidden" name="action" value="add">

            <div class="form-group">
                <label class="form-label">Supplier Business Name *</label>
                <input type="text" name="name" class="form-control" style="padding-left:12px; height:44px;" required placeholder="e.g. Lahore Houseware Ltd">
            </div>

            <div class="form-group">
                <label class="form-label">Contact Person</label>
                <input type="text" name="contact_person" class="form-control" style="padding-left:12px; height:44px;" placeholder="e.g. Farhan Ahmed">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div class="form-group">
                    <label class="form-label">Phone Number</label>
                    <input type="text" name="phone" class="form-control" style="padding-left:12px; height:44px;" placeholder="03XXXXXXXXX">
                </div>
                <div class="form-group">
                    <label class="form-label">Email Address</label>
                    <input type="email" name="email" class="form-control" style="padding-left:12px; height:44px;" placeholder="info@supplier.com">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Opening Pending Balance Owed (PKR)</label>
                <input type="number" step="0.01" name="balance" class="form-control" style="padding-left:12px; height:44px;" value="0.00">
            </div>

            <div class="form-group">
                <label class="form-label">Warehouse Address</label>
                <textarea name="address" class="form-control" style="padding:10px; height:60px; resize:none;" placeholder="Supplier address..."></textarea>
            </div>

            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px; border-top:1.5px dashed var(--border-color); padding-top:15px;">
                <button type="button" class="btn btn-sm btn-secondary" onclick="closeModal('addSupplierModal')">Cancel</button>
                <button type="submit" class="btn btn-sm" style="width: auto;">Save Supplier</button>
            </div>
        </form>
    </div>
</div>

<!-- ==========================================
     SETTLE SUPPLIER PAYOUT MODAL OVERLAY
     ========================================== -->
<div id="settleSupplierModal" class="modal-overlay">
    <div class="modal-content" style="max-width: 520px;">
        <div class="modal-header">
            <h3>Settle Supplier Dues installment</h3>
            <i class="bx bx-x modal-close" onclick="closeModal('settleSupplierModal')"></i>
        </div>

        <form method="POST" action="payments.php">
            <input type="hidden" name="type" value="supplier">

            <div class="form-group">
                <label class="form-label">Select Supplier Vendor *</label>
                <select id="settle_supplier_select" name="person_id" class="select-control" style="width:100%; height:44px;" required onchange="updateSelectedSupplierDues()">
                    <option value="">-- Choose Vendor Business --</option>
                    <?php foreach($suppliers as $s): ?>
                        <option value="<?php echo $s['id']; ?>" data-dues="<?php echo $s['balance']; ?>">
                            <?php echo htmlspecialchars($s['name']); ?> [Dues Owed: <?php echo format_currency($s['balance']); ?>]
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group" style="padding: 10px; background:var(--input-bg); border:1px solid var(--border-color); border-radius:var(--radius-sm); margin-bottom:15px;">
                <span>Total Balance Owed to Vendor:</span>
                <strong id="settleDuesLabel" style="color:var(--error); display:block; font-size:16px; margin-top:4px;">PKR 0.00</strong>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div class="form-group">
                    <label class="form-label">Cash Settlement Amount (PKR) *</label>
                    <input type="number" step="0.01" id="settle_payout_amount" name="amount" class="form-control" style="padding-left:12px; height:44px;" required placeholder="0.00">
                </div>
                <div class="form-group">
                    <label class="form-label">Payment Method</label>
                    <select name="payment_method" class="select-control" style="width:100%; height:44px;">
                        <option value="CASH">Cash Drawer Payout</option>
                        <option value="BANK">Online Bank / Cheque</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Payment Notes / Voucher Ref</label>
                <input type="text" name="notes" class="form-control" style="padding-left:12px; height:44px;" placeholder="Payout voucher number...">
            </div>

            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px; border-top:1.5px dashed var(--border-color); padding-top:15px;">
                <button type="button" class="btn btn-sm btn-secondary" onclick="closeModal('settleSupplierModal')">Cancel</button>
                <button type="submit" class="btn btn-sm" style="width: auto;">Apply Payout</button>
            </div>
        </form>
    </div>
</div>

<script>
/**
 * Update selected vendor balance dues labels
 */
function updateSelectedSupplierDues() {
    const selector = document.getElementById('settle_supplier_select');
    if (!selector) return;

    const opt = selector.options[selector.selectedIndex];
    if (!opt || opt.value === '') {
        document.getElementById('settleDuesLabel').innerText = 'PKR 0.00';
        return;
    }

    const dues = parseFloat(opt.getAttribute('data-dues') || 0);
    document.getElementById('settleDuesLabel').innerText = 'PKR ' + dues.toFixed(2);
    document.getElementById('settle_payout_amount').value = dues.toFixed(2);
}

/**
 * Quick trigger
 */
function triggerSupplierPayModal(id, balance) {
    document.getElementById('settle_supplier_select').value = id;
    document.getElementById('settleDuesLabel').innerText = 'PKR ' + balance.toFixed(2);
    document.getElementById('settle_payout_amount').value = balance.toFixed(2);
    openModal('settleSupplierModal');
}
</script>

<!-- Subsystem JS -->
<script src="ledger.js"></script>

<?php require_once 'includes/header.php'; ?>
