<?php
/**
  * Warehouse & Location-Based Inventory System - Shelf Placement Catalog Index
  * Shop Name: M.BAKAR BALOCH
  */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';
require_once 'location_engine.php';

$db = (new Database())->connect();

$filter_warehouse_id = isset($_GET['warehouse_id']) ? $_GET['warehouse_id'] : '';
$search_query = isset($_GET['search']) ? sanitize($_GET['search']) : '';

// 1. Fetch Warehouses for dropdown
$warehouses = [];
try {
    $warehouses = $db->query("SELECT id, name FROM warehouses WHERE status = 'ACTIVE' ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

// 2. Query product shelf placement ledger
$query = "SELECT pl.*, p.name as product_name, p.sku as product_sku, p.barcode as product_barcode, p.unit,
                 w.name as warehouse_name, l.zone, l.rack, l.shelf 
          FROM product_locations pl
          JOIN products p ON pl.product_id = p.id
          JOIN warehouses w ON pl.warehouse_id = w.id
          JOIN locations l ON pl.location_id = l.id
          WHERE 1=1";
$params = [];

if ($filter_warehouse_id !== '') {
    $query .= " AND pl.warehouse_id = :whid";
    $params['whid'] = (int)$filter_warehouse_id;
}
if ($search_query !== '') {
    $query .= " AND (p.name LIKE :q OR p.sku LIKE :q OR p.barcode LIKE :q OR l.zone LIKE :q OR l.rack LIKE :q OR l.shelf LIKE :q)";
    $params['q'] = '%' . $search_query . '%';
}

$query .= " ORDER BY p.name ASC, w.name ASC, l.zone ASC";

$records = [];
try {
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Custom CSS -->
<link rel="stylesheet" href="settings.css">

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="margin: 0; font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Physical Stock Catalog</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Index matching product quantities to physical Zones, Racks, and Shelves.</p>
    </div>
    <div style="display: flex; gap: 10px;">
        <a href="transfer_stock.php" class="btn btn-sm" style="width: auto; background: var(--accent); border-color: var(--accent); color: #fff;">
            <i class="bx bx-transfer-alt"></i> Relocate Stock
        </a>
    </div>
</div>

<!-- ==========================================
     FILTERS BAR
     ========================================== -->
<div class="card" style="margin-bottom: 24px;">
    <form method="GET" action="stock_by_location.php" style="display: flex; gap: 15px; align-items: end; flex-wrap: wrap;">
        
        <div style="flex-grow: 1; min-width: 200px;">
            <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">Filter by Warehouse</label>
            <select name="warehouse_id" style="width: 100%; height: 38px; padding: 0 10px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none; cursor: pointer;">
                <option value="">All Warehouses</option>
                <?php foreach ($warehouses as $wh): ?>
                    <option value="<?php echo $wh['id']; ?>" <?php echo $filter_warehouse_id == $wh['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($wh['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div style="flex-grow: 2; min-width: 250px;">
            <label style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">Search Coordinates or SKU</label>
            <input type="text" name="search" value="<?php echo $search_query; ?>" placeholder="Type product name, SKU, zone, rack, or shelf coordinate..." style="width: 100%; height: 38px; padding: 0 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-main); font-size: 13px; outline: none;">
        </div>

        <button type="submit" class="btn" style="height: 38px; width: 100px; background: var(--accent); border-color: var(--accent); color: #fff;">
            Search
        </button>
    </form>
</div>

<!-- ==========================================
     PHYSICAL COORDINATES INDEX TABLE
     ========================================== -->
<div class="card">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Product Catalog Label</th>
                    <th>Warehouse Room</th>
                    <th>Zone Section</th>
                    <th>Rack / Row</th>
                    <th>Shelf Coordinate</th>
                    <th style="text-align: center;">Shelf Quantity</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 30px; color: var(--text-muted);">
                            <i class="bx bx-cabinet" style="font-size: 48px; display: block; margin-bottom: 10px; opacity: 0.3;"></i>
                            No shelf placements registered for products matching filters.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($records as $rec): 
                        $qty_status = 'status-success';
                        $qty_label = 'In Stock';
                        if ($rec['qty'] <= 0) {
                            $qty_status = 'status-danger';
                            $qty_label = 'Out of Stock';
                        } elseif ($rec['qty'] <= 5) {
                            $qty_status = 'status-warning';
                            $qty_label = 'Low Stock';
                        }
                    ?>
                        <tr class="animate-fade">
                            <td>
                                <strong><?php echo htmlspecialchars($rec['product_name']); ?></strong>
                                <span style="display: block; font-size: 11px; color: var(--text-muted);">
                                    SKU: <code><?php echo htmlspecialchars($rec['product_sku']); ?></code> &bull; Barcode: <code><?php echo htmlspecialchars($rec['product_barcode']); ?></code>
                                </span>
                            </td>
                            <td><strong><?php echo htmlspecialchars($rec['warehouse_name']); ?></strong></td>
                            <td><span style="font-weight: 600; color: var(--accent);"><?php echo htmlspecialchars($rec['zone']); ?></span></td>
                            <td><code><?php echo htmlspecialchars($rec['rack']); ?></code></td>
                            <td><code><?php echo htmlspecialchars($rec['shelf']); ?></code></td>
                            <td style="text-align: center;">
                                <div style="display: flex; flex-direction: column; align-items: center; gap: 4px;">
                                    <strong style="font-size: 15px; color: var(--text-main);"><?php echo number_format($rec['qty']); ?> <?php echo htmlspecialchars($rec['unit']); ?></strong>
                                    <span class="status-badge <?php echo $qty_status; ?>" style="font-size: 10px; padding: 1px 5px;"><?php echo $qty_label; ?></span>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
