import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(const MbakarScannerApp());
}

class MbakarScannerApp extends StatelessWidget {
  const MbakarScannerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'M.BAKAR BALOCH - Scanner POS',
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: const Color(0xFF10B981),
        scaffoldBackgroundColor: const Color(0xFF090D16),
        cardColor: const Color(0xFF0C1220),
        fontFamily: 'Plus Jakarta Sans',
      ),
      home: const LoginPage(),
    );
  }
}

// ==========================================
// 1. MOBILE CREDENTIALS LOGIN PAGE
// ==========================================
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _serverController = TextEditingController(text: 'http://192.168.1.15/m-bakar-baloch');
  bool _isLoading = false;
  String _errorMessage = '';

  Future<void> _attemptLogin() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    final serverUrl = _serverController.text.trim();
    final username = _usernameController.text.trim();
    final password = _passwordController.text;

    try {
      final response = await http.post(
        Uri.parse('$serverUrl/api/login.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': username,
          'password': password,
          'device_name': 'Mobile Scanner Terminal'
        }),
      ).timeout(const Duration(seconds: 10));

      final data = jsonDecode(response.body);

      if (response.statusCode == 200 && data['status'] == 'success') {
        final token = data['data']['api_token'];
        final fullname = data['data']['user']['fullname'];
        final role = data['data']['user']['role'];

        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => ScannerHomePage(
                apiToken: token,
                serverUrl: serverUrl,
                operatorName: fullname,
                operatorRole: role,
              ),
            ),
          );
        }
      } else {
        setState(() {
          _errorMessage = data['message'] ?? 'Login failed. Invalid parameters.';
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Connection timed out. Ensure server host is reachable.';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(28.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Icon(Icons.qr_code_scanner, size: 72, color: Color(0xFF10B981)),
              const SizedBox(height: 16),
              const Text(
                'M.BAKAR BALOCH',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.extrabold, letterSpacing: 1),
              ),
              const Text(
                'Mobile Scanner POS Client',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: Colors.grey),
              ),
              const SizedBox(height: 32),
              TextField(
                controller: _serverController,
                decoration: const InputDecoration(
                  labelText: 'Server Base URL',
                  prefixIcon: Icon(Icons.dns),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _usernameController,
                decoration: const InputDecoration(
                  labelText: 'ERP Username',
                  prefixIcon: Icon(Icons.person),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Security Password',
                  prefixIcon: Icon(Icons.lock),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 24),
              if (_errorMessage.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: Text(
                    _errorMessage,
                    style: const TextStyle(color: Colors.redAccent, fontSize: 13, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                ),
              ElevatedButton(
                onPressed: _isLoading ? null : _attemptLogin,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF10B981),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: _isLoading
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Text('Connect Device', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==========================================
// 2. MAIN ACTIVE APP BARCODE SCANNER INTERFACE
// ==========================================
class ScannerHomePage extends StatefulWidget {
  final String apiToken;
  final String serverUrl;
  final String operatorName;
  final String operatorRole;

  const ScannerHomePage({
    super.key,
    required this.apiToken,
    required this.serverUrl,
    required this.operatorName,
    required this.operatorRole,
  });

  @override
  State<ScannerHomePage> createState() => _ScannerHomePageState();
}

class _ScannerHomePageState extends State<ScannerHomePage> {
  final List<Map<String, dynamic>> _cartItems = [];
  bool _flashlightOn = false;
  bool _isLoadingProduct = false;
  final TextEditingController _testBarcodeController = TextEditingController();

  Future<void> _scanBarcodeLookup(String barcode) async {
    if (barcode.trim().isEmpty) return;

    setState(() {
      _isLoadingProduct = true;
    });

    try {
      final response = await http.get(
        Uri.parse('${widget.serverUrl}/api/get_product.php?barcode=$barcode'),
        headers: {
          'Authorization': 'Bearer ${widget.apiToken}',
          'Content-Type': 'application/json',
        },
      ).timeout(const Duration(seconds: 8));

      final data = jsonDecode(response.body);

      if (response.statusCode == 200 && data['status'] == 'success') {
        final product = data['data'];
        _addProductToCart(product);
      } else {
        _showToast(data['message'] ?? 'Product lookup failed.');
      }
    } catch (e) {
      _showToast('Server lookup connection error.');
    } finally {
      setState(() {
        _isLoadingProduct = false;
        _testBarcodeController.clear();
      });
    }
  }

  void _addProductToCart(Map<String, dynamic> product) {
    setState(() {
      // Look if product is already in cart array
      final index = _cartItems.indexWhere((item) => item['product_id'] == product['id']);

      if (index >= 0) {
        // Increment quantity
        _cartItems[index]['qty']++;
      } else {
        // Insert new cart item
        _cartItems.add({
          'product_id': product['id'],
          'name': product['name'],
          'qty': 1,
          'sell_price': double.parse(product['sell_price'].toString()),
          'purchase_price': double.parse(product['purchase_price'].toString()),
          'discount': 0.00,
        });
      }
    });
    _showToast('${product['name']} added to checkout cart.');
  }

  double _calculateTotal() {
    double total = 0.00;
    for (var item in _cartItems) {
      total += (item['sell_price'] * item['qty']) - item['discount'];
    }
    return total;
  }

  Future<void> _processCheckout() async {
    if (_cartItems.isEmpty) return;

    setState(() {
      _isLoadingProduct = true;
    });

    final total = _calculateTotal();

    try {
      final response = await http.post(
        Uri.parse('${widget.serverUrl}/api/sales.php'),
        headers: {
          'Authorization': 'Bearer ${widget.apiToken}',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'customer_id': 0, // Walk-in customer default
          'items': _cartItems,
          'total_amount': total,
          'discount_amount': 0.00,
          'tax_amount': 0.00,
          'payable_amount': total,
          'paid_amount': total,
          'payment_method': 'CASH',
        }),
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200 && data['status'] == 'success') {
        _showSuccessDialog(data['data']['invoice_no']);
        setState(() {
          _cartItems.clear();
        });
      } else {
        _showToast(data['message'] ?? 'Checkout transaction failed.');
      }
    } catch (e) {
      _showToast('Server connection checkout failed.');
    } finally {
      setState(() {
        _isLoadingProduct = false;
      });
    }
  }

  void _showToast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), duration: const Duration(seconds: 2)),
    );
  }

  void _showSuccessDialog(String invoiceNo) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Color(0xFF10B981)),
            SizedBox(width: 8),
            Text('Checkout Complete'),
          ],
        ),
        content: Text('Invoice #$invoiceNo has been registered and cloud-synced successfully across all terminals.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK', style: TextStyle(color: Color(0xFF10B981))),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('M.BAKAR BALOCH', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text('Operator: ${widget.operatorName} (${widget.operatorRole})', style: const TextStyle(fontSize: 11, color: Colors.grey)),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(_flashlightOn ? Icons.flash_on : Icons.flash_off, color: _flashlightOn ? Colors.yellow : Colors.grey),
            onPressed: () {
              setState(() {
                _flashlightOn = !_flashlightOn;
              });
              _showToast('Flashlight turned ${_flashlightOn ? 'ON' : 'OFF'}');
            },
          ),
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.redAccent),
            onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const LoginPage())),
          ),
        ],
      ),
      body: Column(
        children: [
          // A. MAIN CAMERA SCANNING INTERACTIVE AREA
          Expanded(
            flex: 4,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Simulated camera layout preview with glass grid overlay
                Container(
                  color: Colors.black87,
                  width: double.infinity,
                  child: const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.camera_alt, size: 48, color: Colors.white30),
                        SizedBox(height: 10),
                        Text('Autofocus Scanner Active', style: TextStyle(color: Colors.white30, fontSize: 13)),
                      ],
                    ),
                  ),
                ),
                
                // Glowing Neon target scan area bounds
                Container(
                  width: 240,
                  height: 240,
                  decoration: BoxDecoration(
                    border: Border.all(color: const Color(0xFF10B981), width: 3),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Stack(
                    children: [
                      // Scanning center laser line overlay
                      Center(
                        child: Container(
                          width: double.infinity,
                          height: 2,
                          color: Colors.red,
                        ),
                      ),
                    ],
                  ),
                ),

                // Manual simulator lookup controller for testing
                Positioned(
                  bottom: 20,
                  left: 20,
                  right: 20,
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _testBarcodeController,
                          decoration: const InputDecoration(
                            hintText: 'Simulate barcode lookup (e.g. 890123)',
                            filled: true,
                            fillColor: Colors.black54,
                            border: OutlineInputBorder(),
                          ),
                          onSubmitted: _scanBarcodeLookup,
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton(
                        style: IconButton.styleFrom(backgroundColor: const Color(0xFF10B981)),
                        icon: const Icon(Icons.search, color: Colors.white),
                        onPressed: () => _scanBarcodeLookup(_testBarcodeController.text),
                      ),
                    ],
                  ),
                ),

                if (_isLoadingProduct)
                  const Center(child: CircularProgressIndicator(color: Color(0xFF10B981))),
              ],
            ),
          ),

          // B. CART DETAILS SCREEN AREA
          Expanded(
            flex: 5,
            child: Container(
              color: const Color(0xFF0C1220),
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('CHECKOUT CART ITEMS', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                      Text('${_cartItems.length} Products Scanned', style: const TextStyle(color: Color(0xFF10B981), fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const Divider(color: Colors.white24),
                  
                  // Cart item lists scrolling container
                  Expanded(
                    child: _cartItems.isEmpty
                        ? const Center(child: Text('No scanned items. Aim camera at product barcode.', style: TextStyle(color: Colors.white30)))
                        : ListView.builder(
                            itemCount: _cartItems.length,
                            itemBuilder: (context, index) {
                              final item = _cartItems[index];
                              return Card(
                                margin: const EdgeInsets.only(bottom: 8),
                                color: const Color(0xFF131B2E),
                                child: ListTile(
                                  title: Text(item['name'], style: const TextStyle(fontWeight: FontWeight.bold)),
                                  subtitle: Text('Price: Rs. ${item['sell_price']}'),
                                  trailing: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      IconButton(
                                        icon: const Icon(Icons.remove_circle_outline, color: Colors.grey),
                                        onPressed: () {
                                          setState(() {
                                            if (item['qty'] > 1) {
                                              item['qty']--;
                                            } else {
                                              _cartItems.removeAt(index);
                                            }
                                          });
                                        },
                                      ),
                                      Text('${item['qty']}', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                                      IconButton(
                                        icon: const Icon(Icons.add_circle_outline, color: Color(0xFF10B981)),
                                        onPressed: () {
                                          setState(() {
                                            item['qty']++;
                                          });
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                  ),

                  const Divider(color: Colors.white24),

                  // Total and Checkout buttons row
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('GRAND PAYABLE TOTAL', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.grey)),
                      Text('Rs. ${_calculateTotal().toStringAsFixed(2)}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.extrabold, color: Color(0xFF10B981))),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _cartItems.isEmpty ? null : _processCheckout,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF10B981),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    child: const Text('SYNC CHECKOUT TO ERP', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
