<?php
/**
 * Reports & Profit/Loss Subsystem - Profit & Loss Statement (Module 6)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = "";

// 1. FILTER Presets Date range parsing
$preset = sanitize($_GET['preset'] ?? 'month');
$start_date = sanitize($_GET['start_date'] ?? '');
$end_date = sanitize($_GET['end_date'] ?? '');

$sales_where = "1=1";
$purchase_where = "1=1";
$expense_where = "category != 'Supplier Payment'"; // Safeguard: exclude payouts to avoid double-counting!
$params = [];

if ($preset === 'today') {
    $sales_where .= " AND s.sale_date = CURRENT_DATE()";
    $purchase_where .= " AND p.purchase_date = CURRENT_DATE()";
    $expense_where .= " AND e.expense_date = CURRENT_DATE()";
} elseif ($preset === 'week') {
    $sales_where .= " AND s.sale_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)";
    $purchase_where .= " AND p.purchase_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)";
    $expense_where .= " AND e.expense_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)";
} elseif ($preset === 'month') {
    $sales_where .= " AND s.sale_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)";
    $purchase_where .= " AND p.purchase_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)";
    $expense_where .= " AND e.expense_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)";
} elseif ($preset === 'year') {
    $sales_where .= " AND s.sale_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 365 DAY)";
    $purchase_where .= " AND p.purchase_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 365 DAY)";
    $expense_where .= " AND e.expense_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 365 DAY)";
} elseif ($preset === 'custom' && !empty($start_date) && !empty($end_date)) {
    $sales_where .= " AND s.sale_date BETWEEN :start AND :end";
    $purchase_where .= " AND p.purchase_date BETWEEN :start AND :end";
    $expense_where .= " AND e.expense_date BETWEEN :start AND :end";
    $params['start'] = $start_date;
    $params['end'] = $end_date;
}

try {
    // 1. Gross Sales Revenue
    $sales_stmt = $db->prepare("SELECT SUM(payable_amount) FROM sales s WHERE $sales_where");
    $sales_stmt->execute($params);
    $gross_sales = (float)$sales_stmt->fetchColumn() ?: 0.00;

    // 2. Cost of Goods Sold (Procurements Purchases)
    $pur_stmt = $db->prepare("SELECT SUM(payable_amount) FROM purchases p WHERE $purchase_where");
    $pur_stmt->execute($params);
    $cogs = (float)$pur_stmt->fetchColumn() ?: 0.00;

    // Gross Profit Margin
    $gross_profit = $gross_sales - $cogs;

    // 3. Operational Expenses (Exclude supplier settlements to avoid double count)
    $exp_stmt = $db->prepare("SELECT SUM(amount) FROM expenses e WHERE $expense_where");
    $exp_stmt->execute($params);
    $opex = (float)$exp_stmt->fetchColumn() ?: 0.00;

    // Net Yield Profit / Loss
    $net_profit = $gross_profit - $opex;

    // Margin percentages
    $profit_margin = ($gross_sales > 0) ? ($net_profit / $gross_sales) * 100 : 0;

} catch (PDOException $e) {
    $gross_sales = $cogs = $gross_profit = $opex = $net_profit = $profit_margin = 0;
}

// Fetch Shop Details
$shop_name = BRAND_NAME;
$shop_address = 'Main Bazar Road, Plastic Market, Pakistan';
try {
    $shop_name = $db->query("SELECT key_value FROM settings WHERE key_name = 'shop_name' LIMIT 1")->fetchColumn() ?: BRAND_NAME;
    $shop_address = $db->query("SELECT key_value FROM settings WHERE key_name = 'shop_address' LIMIT 1")->fetchColumn() ?: 'Main Bazar Road, Plastic Market, Pakistan';
} catch(Exception $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profit & Loss Statement - M.BAKAR BALOCH</title>
    <!-- Include Subsystem Styles -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="reports.css">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <style>
        body {
            background: var(--bg-primary);
            padding: 40px 20px;
        }
    </style>
</head>
<body>

<!-- Navigation -->
<div class="no-print" style="max-width:800px; margin: 0 auto 24px auto; display: flex; justify-content: space-between; align-items: center;">
    <a href="reports.php" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
        <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Reports Hub
    </a>
    
    <button type="button" class="btn" style="width: auto; height:40px; padding:0 20px;" onclick="window.print()">
        <i class="bx bx-printer"></i> Print Statement
    </button>
</div>

<!-- ==========================================
     A4 CORPORATE INCOME STATEMENT CARD
     ========================================== -->
<div class="pl-statement-card">
    
    <!-- Corporate Header -->
    <div style="text-align: center; margin-bottom: 30px; border-bottom: 2px solid var(--border-color); padding-bottom: 20px;">
        <h1 style="font-size: 22px; font-weight: 900; color:var(--text-main); margin-bottom:4px;"><?php echo htmlspecialchars($shop_name); ?></h1>
        <p style="font-size:12px; color:var(--text-muted); margin: 3px 0;"><?php echo htmlspecialchars($shop_address); ?></p>
        <h3 style="font-size:15px; font-weight:700; text-transform:uppercase; letter-spacing:1px; margin-top:15px; color:var(--accent);">Profit & Loss Income Statement</h3>
        <span style="font-size:12px; color:var(--text-secondary);">Statement Period: <strong><?php echo ucfirst($preset); ?> Range</strong></span>
    </div>

    <!-- Statement entries -->
    <div>
        <!-- Gross Revenues -->
        <div class="pl-row sub-header">
            <span>I. REVENUES AND TURNOVERS</span>
            <span>VALUE (PKR)</span>
        </div>
        <div class="pl-row" style="padding-left: 20px;">
            <span>Gross Sales Revenue (Receipt Turnover)</span>
            <strong><?php echo format_currency($gross_sales); ?></strong>
        </div>
        <div class="pl-row" style="padding-left: 20px; font-weight: 700;">
            <span>Total Operational Revenue</span>
            <span><?php echo format_currency($gross_sales); ?></span>
        </div>

        <!-- Cost of Goods Sold -->
        <div class="pl-row sub-header">
            <span>II. COST OF GOODS SOLD (COGS)</span>
            <span></span>
        </div>
        <div class="pl-row" style="padding-left: 20px;">
            <span>Warehouse Procurements Cost (Inbound Stock Purchases)</span>
            <strong>- <?php echo format_currency($cogs); ?></strong>
        </div>
        <div class="pl-row" style="padding-left: 20px; font-weight: 700;">
            <span>Total Cost of Goods Sold</span>
            <span>- <?php echo format_currency($cogs); ?></span>
        </div>

        <!-- Gross Margin -->
        <div class="pl-row" style="font-weight: 800; font-size:15px; margin-top:10px; background:var(--input-bg); padding:10px 12px; border-radius:var(--radius-xs);">
            <span>GROSS FINANCIAL MARGIN</span>
            <span style="color: <?php echo ($gross_profit >= 0) ? 'var(--accent)' : 'var(--error)'; ?>;">
                <?php echo format_currency($gross_profit); ?>
            </span>
        </div>

        <!-- Operational Overheads -->
        <div class="pl-row sub-header">
            <span>III. OPERATIONAL OVERHEADS (OPEX)</span>
            <span></span>
        </div>
        <div class="pl-row" style="padding-left: 20px;">
            <span>Business Operating Expenses (Salaries, utilities, logistics)</span>
            <strong>- <?php echo format_currency($opex); ?></strong>
        </div>
        <div class="pl-row" style="padding-left: 20px; font-style: italic; color:var(--text-muted); font-size: 11px;">
            <span>* Note: Supplier repayments have been excluded to prevent double-counting COGS assets.</span>
            <span></span>
        </div>
        <div class="pl-row" style="padding-left: 20px; font-weight: 700;">
            <span>Total Operating Expenses</span>
            <span>- <?php echo format_currency($opex); ?></span>
        </div>

        <!-- Net Profit or Loss Yield -->
        <?php 
        $is_loss = ($net_profit < 0);
        $total_class = $is_loss ? 'loss' : '';
        ?>
        <div class="pl-row total-row <?php echo $total_class; ?>">
            <span>NET OPERATIONAL YIELD (<?php echo $is_loss ? 'LOSS' : 'PROFIT'; ?>)</span>
            <span><?php echo format_currency($net_profit); ?></span>
        </div>

        <!-- Yield Ratio -->
        <div class="pl-row" style="border:none; padding-top: 15px;">
            <span>Calculated Financial Yield Margin Ratio:</span>
            <strong style="color: <?php echo $is_loss ? 'var(--error)' : 'var(--accent)'; ?>;">
                <?php echo number_format($profit_margin, 2); ?>%
            </strong>
        </div>
    </div>

    <!-- Corporate Footer -->
    <div style="margin-top: 50px; text-align: center; border-top: 1px dashed var(--border-color); padding-top: 20px; font-size:11px; color:var(--text-muted);">
        <p>Report compiled dynamically by M.BAKAR BALOCH shop software.</p>
        <p>Confidential Business intelligence statement.</p>
    </div>

</div>

</body>
</html>
