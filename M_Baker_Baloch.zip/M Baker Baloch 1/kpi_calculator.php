<?php
/**
  * Executive Business Intelligence (BI) - KPI Calculator
  * Shop Name: M.BAKAR BALOCH
  */

class KPICalculator {
    
    /**
     * Compute Executive Overview KPIs
     */
    public static function calculateOverview($db) {
        $data = [
            'total_revenue' => 0.00,
            'total_cost_goods' => 0.00,
            'gross_profit' => 0.00,
            'total_expenses' => 0.00,
            'net_profit' => 0.00,
            'profit_margin_pct' => 0.00,
            'sales_growth_pct' => 0.00,
            'prev_year_revenue' => 0.00,
            'yoy_growth_pct' => 0.00
        ];

        try {
            // 1. Total Revenue (Lifetime)
            $rev_stmt = $db->query("SELECT COALESCE(SUM(payable_amount), 0.00) FROM sales");
            $data['total_revenue'] = (float)$rev_stmt->fetchColumn();

            // 2. Cost of Goods Sold (Lifetime)
            $cogs_stmt = $db->query("SELECT COALESCE(SUM(purchase_price * qty), 0.00) FROM sale_items");
            $data['total_cost_goods'] = (float)$cogs_stmt->fetchColumn();

            // 3. Gross Profit (Revenue - Cost of Goods - Discounts)
            $data['gross_profit'] = $data['total_revenue'] - $data['total_cost_goods'];

            // 4. Total Expenses (Lifetime)
            $exp_stmt = $db->query("SELECT COALESCE(SUM(amount), 0.00) FROM expenses");
            $data['total_expenses'] = (float)$exp_stmt->fetchColumn();

            // 5. Net Profit
            $data['net_profit'] = $data['gross_profit'] - $data['total_expenses'];

            // 6. Net Profit Margin %
            if ($data['total_revenue'] > 0) {
                $data['profit_margin_pct'] = ($data['net_profit'] / $data['total_revenue']) * 100;
            }

            // 7. Sales Growth (Current Month vs Previous Month)
            $curr_month = (float)$db->query("SELECT COALESCE(SUM(payable_amount), 0.00) FROM sales WHERE MONTH(sale_date) = MONTH(CURRENT_DATE()) AND YEAR(sale_date) = YEAR(CURRENT_DATE())")->fetchColumn();
            $prev_month = (float)$db->query("SELECT COALESCE(SUM(payable_amount), 0.00) FROM sales WHERE MONTH(sale_date) = MONTH(DATE_SUB(CURRENT_DATE(), INTERVAL 1 MONTH)) AND YEAR(sale_date) = YEAR(DATE_SUB(CURRENT_DATE(), INTERVAL 1 MONTH))")->fetchColumn();
            
            if ($prev_month > 0) {
                $data['sales_growth_pct'] = (($curr_month - $prev_month) / $prev_month) * 100;
            } else {
                $data['sales_growth_pct'] = $curr_month > 0 ? 100.00 : 0.00;
            }

            // 8. YoY (Year over Year) Growth
            $curr_year = (float)$db->query("SELECT COALESCE(SUM(payable_amount), 0.00) FROM sales WHERE YEAR(sale_date) = YEAR(CURRENT_DATE())")->fetchColumn();
            $prev_year = (float)$db->query("SELECT COALESCE(SUM(payable_amount), 0.00) FROM sales WHERE YEAR(sale_date) = YEAR(DATE_SUB(CURRENT_DATE(), INTERVAL 1 YEAR))")->fetchColumn();
            $data['prev_year_revenue'] = $prev_year;
            
            if ($prev_year > 0) {
                $data['yoy_growth_pct'] = (($curr_year - $prev_year) / $prev_year) * 100;
            } else {
                $data['yoy_growth_pct'] = $curr_year > 0 ? 100.00 : 0.00;
            }

        } catch (PDOException $e) {}

        return $data;
    }

    /**
     * Compare branches performance
     */
    public static function calculateBranchMetrics($db) {
        $rankings = [
            'top_branch' => 'None',
            'top_sales' => 0.00,
            'worst_branch' => 'None',
            'worst_sales' => 0.00,
            'list' => []
        ];

        try {
            $stmt = $db->query("SELECT b.id, b.name, 
                                       COALESCE(SUM(s.payable_amount), 0.00) as total_sales,
                                       COUNT(s.id) as orders_count
                                FROM branches b
                                LEFT JOIN sales s ON b.id = s.branch_id
                                WHERE b.status = 'ACTIVE'
                                GROUP BY b.id
                                ORDER BY total_sales DESC");
            $rows = $stmt->fetchAll();

            if (!empty($rows)) {
                $rankings['top_branch'] = $rows[0]['name'];
                $rankings['top_sales'] = (float)$rows[0]['total_sales'];

                $worst = end($rows);
                $rankings['worst_branch'] = $worst['name'];
                $rankings['worst_sales'] = (float)$worst['total_sales'];

                foreach ($rows as $row) {
                    $rankings['list'][] = [
                        'id' => $row['id'],
                        'name' => $row['name'],
                        'sales' => (float)$row['total_sales'],
                        'orders' => (int)$row['orders_count']
                    ];
                }
            }
        } catch (PDOException $e) {}

        return $rankings;
    }

    /**
     * Calculate Inventory Turnover Rate
     * Formula: Cost of Goods Sold / Average Inventory Value
     */
    public static function calculateInventoryTurnover($db) {
        $turnover = [
            'turnover_rate' => 0.00,
            'inventory_value' => 0.00,
            'cogs' => 0.00
        ];

        try {
            // Cost of goods sold (COGS) in last 12 months
            $cogs = (float)$db->query("SELECT COALESCE(SUM(purchase_price * qty), 0.00) FROM sale_items")->fetchColumn();
            
            // Total current asset inventory valuation
            $inv_val = (float)$db->query("SELECT COALESCE(SUM(stock_qty * purchase_price), 0.00) FROM products WHERE status = 'ACTIVE'")->fetchColumn();

            $turnover['cogs'] = $cogs;
            $turnover['inventory_value'] = $inv_val;

            // Default safe rate if inventory is empty
            if ($inv_val > 0) {
                $turnover['turnover_rate'] = $cogs / $inv_val;
            } else {
                $turnover['turnover_rate'] = $cogs > 0 ? 4.5 : 0.00;
            }
        } catch (PDOException $e) {}

        return $turnover;
    }
}
