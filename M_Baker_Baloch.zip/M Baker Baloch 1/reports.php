<?php
/**
 * Reports & Profit/Loss Subsystem - Business Intelligence Landing Hub (Module 9)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = "";

// 1. FILTER Presets Date range parsing
$preset = sanitize($_GET['preset'] ?? 'month');
$start_date = sanitize($_GET['start_date'] ?? '');
$end_date = sanitize($_GET['end_date'] ?? '');

$sales_where = "1=1";
$purchase_where = "1=1";
$expense_where = "1=1";
$params = [];

if ($preset === 'today') {
    $sales_where .= " AND s.sale_date = CURRENT_DATE()";
    $purchase_where .= " AND p.purchase_date = CURRENT_DATE()";
    $expense_where .= " AND e.expense_date = CURRENT_DATE()";
} elseif ($preset === 'week') {
    $sales_where .= " AND s.sale_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)";
    $purchase_where .= " AND p.purchase_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)";
    $expense_where .= " AND e.expense_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)";
} elseif ($preset === 'month') {
    $sales_where .= " AND s.sale_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)";
    $purchase_where .= " AND p.purchase_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)";
    $expense_where .= " AND e.expense_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)";
} elseif ($preset === 'year') {
    $sales_where .= " AND s.sale_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 365 DAY)";
    $purchase_where .= " AND p.purchase_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 365 DAY)";
    $expense_where .= " AND e.expense_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 365 DAY)";
} elseif ($preset === 'custom' && !empty($start_date) && !empty($end_date)) {
    $sales_where .= " AND s.sale_date BETWEEN :start AND :end";
    $purchase_where .= " AND p.purchase_date BETWEEN :start AND :end";
    $expense_where .= " AND e.expense_date BETWEEN :start AND :end";
    $params['start'] = $start_date;
    $params['end'] = $end_date;
}

// Calculate Sums
try {
    // 1. Sales
    $sales_stmt = $db->prepare("SELECT SUM(payable_amount) FROM sales s WHERE $sales_where");
    $sales_stmt->execute($params);
    $total_sales = (float)$sales_stmt->fetchColumn() ?: 0.00;

    // 2. Purchases Restocks
    $pur_stmt = $db->prepare("SELECT SUM(payable_amount) FROM purchases p WHERE $purchase_where");
    $pur_stmt->execute($params);
    $total_purchases = (float)$pur_stmt->fetchColumn() ?: 0.00;

    // 3. Expenses Operational
    $exp_stmt = $db->prepare("SELECT SUM(amount) FROM expenses e WHERE $expense_where");
    $exp_stmt->execute($params);
    $total_expenses = (float)$exp_stmt->fetchColumn() ?: 0.00;

    // Net Profit
    $net_profit = $total_sales - $total_purchases - $total_expenses;

    // 4. Load Monthly Trends aggregates for Visual Curves
    $monthly_trends = $db->query("
        SELECT MONTHNAME(s.sale_date) as month, SUM(s.payable_amount) as sales_sum 
        FROM sales s 
        WHERE YEAR(s.sale_date) = YEAR(CURRENT_DATE()) 
        GROUP BY MONTH(s.sale_date)
        ORDER BY MONTH(s.sale_date) ASC
    ")->fetchAll();

    // 5. Load categorical expenses for Pie Charts
    $exp_breakdown = $db->query("
        SELECT category, SUM(amount) as total_spent 
        FROM expenses 
        GROUP BY category
    ")->fetchAll();

} catch (PDOException $e) {
    $total_sales = $total_purchases = $total_expenses = $net_profit = 0;
    $monthly_trends = $exp_breakdown = [];
}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="reports.css">

<!-- Include ChartJS Library -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- Presets Filters panel -->
<div class="search-filter-section" style="margin-bottom: 25px;">
    <form method="GET" action="reports.php" style="display: flex; gap: 15px; width: 100%; flex-wrap: wrap;">
        
        <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
            <select name="preset" class="select-control" style="width: auto; height: 44px;" onchange="this.form.submit()">
                <option value="today" <?php echo $preset === 'today' ? 'selected' : ''; ?>>Today Preset</option>
                <option value="week" <?php echo $preset === 'week' ? 'selected' : ''; ?>>Weekly Preset</option>
                <option value="month" <?php echo $preset === 'month' ? 'selected' : ''; ?>>Monthly Preset</option>
                <option value="year" <?php echo $preset === 'year' ? 'selected' : ''; ?>>Yearly Preset</option>
                <option value="custom" <?php echo $preset === 'custom' ? 'selected' : ''; ?>>Custom Range...</option>
            </select>

            <?php if ($preset === 'custom'): ?>
                <input type="date" name="start_date" class="form-control" style="width: 140px; height: 44px;" value="<?php echo htmlspecialchars($start_date); ?>" required>
                <span style="color:var(--text-muted);">to</span>
                <input type="date" name="end_date" class="form-control" style="width: 140px; height: 44px;" value="<?php echo htmlspecialchars($end_date); ?>" required>
                <button type="submit" class="btn btn-sm btn-secondary" style="height: 44px; width: auto; padding: 0 15px;">Apply</button>
            <?php endif; ?>
        </div>

        <div style="margin-left: auto; display: flex; gap: 10px;">
            <a href="profit_loss.php?preset=<?php echo $preset; ?>&start_date=<?php echo urlencode($start_date); ?>&end_date=<?php echo urlencode($end_date); ?>" class="btn btn-sm" style="width: auto; text-decoration: none; display: inline-flex; align-items: center; justify-content: center;">
                <i class="bx bx-file-blank" style="margin-right:6px;"></i> Print P&L Statement
            </a>
        </div>
    </form>
</div>

<!-- ==========================================
     REPORTS KPI SUMMARY CARDS GRID
     ========================================== -->
<div class="reports-kpi-grid">
    <!-- Sales Revenue -->
    <div class="stat-card success" style="border-left: 4px solid var(--accent);">
        <div class="stat-info">
            <span>Sales Revenue</span>
            <h2><?php echo format_currency($total_sales); ?></h2>
        </div>
        <div class="stat-icon"><i class="bx bx-trending-up"></i></div>
    </div>
    
    <!-- Purchases Cost -->
    <div class="stat-card danger">
        <div class="stat-info">
            <span>Procurements Cost</span>
            <h2><?php echo format_currency($total_purchases); ?></h2>
        </div>
        <div class="stat-icon"><i class="bx bx-cart-add"></i></div>
    </div>
    
    <!-- Expenses Operational -->
    <div class="stat-card danger" style="border-left:4px solid var(--error);">
        <div class="stat-info">
            <span>Operational Expenses</span>
            <h2><?php echo format_currency($total_expenses); ?></h2>
        </div>
        <div class="stat-icon"><i class="bx bx-receipt"></i></div>
    </div>
    
    <!-- Net Profit / Loss -->
    <div class="stat-card <?php echo ($net_profit >= 0) ? 'success' : 'danger'; ?>" style="border-left: 4px solid <?php echo ($net_profit >= 0) ? 'var(--accent)' : 'var(--error)'; ?>;">
        <div class="stat-info">
            <span>Net Financial Yield</span>
            <h2 style="color: <?php echo ($net_profit >= 0) ? 'var(--accent)' : 'var(--error)'; ?>;">
                <?php echo format_currency($net_profit); ?>
            </h2>
        </div>
        <div class="stat-icon"><i class="bx bx-badge-check"></i></div>
    </div>
</div>

<!-- ==========================================
     SUB-MODULE REPORTS NAVIGATION ROW
     ========================================== -->
<div style="display: flex; gap: 15px; margin-bottom: 30px; flex-wrap: wrap;">
    <a href="sales_report.php" class="btn btn-secondary" style="width: auto; height: 50px; display: inline-flex; align-items: center; justify-content: center; text-decoration: none; padding: 0 25px; font-weight: 600;">
        <i class="bx bx-receipt" style="font-size: 18px; margin-right: 8px;"></i> Sales Turnover Report
    </a>
    <a href="purchase_report.php" class="btn btn-secondary" style="width: auto; height: 50px; display: inline-flex; align-items: center; justify-content: center; text-decoration: none; padding: 0 25px; font-weight: 600;">
        <i class="bx bx-history" style="font-size: 18px; margin-right: 8px;"></i> Purchase restocks Report
    </a>
    <a href="stock_report.php" class="btn btn-secondary" style="width: auto; height: 50px; display: inline-flex; align-items: center; justify-content: center; text-decoration: none; padding: 0 25px; font-weight: 600;">
        <i class="bx bx-cabinet" style="font-size: 18px; margin-right: 8px;"></i> Stock valuation Report
    </a>
</div>

<!-- ==========================================
     INTERACTIVE BI CHARTS DATA ROW
     ========================================== -->
<div class="reports-charts-container">
    
    <!-- Chart A: Sales vs Purchases Comparison -->
    <div class="chart-card">
        <h3 style="font-size: 14.5px; font-weight: 700; margin-bottom: 15px; color: var(--text-main);"><i class="bx bx-trending-up" style="margin-right:6px;"></i> Revenue & Procurements Comparison</h3>
        <div style="position: relative; height: 260px;">
            <canvas id="revenueProcurementChart"></canvas>
        </div>
    </div>
    
    <!-- Chart B: Expenses categorical breakdown -->
    <div class="chart-card">
        <h3 style="font-size: 14.5px; font-weight: 700; margin-bottom: 15px; color: var(--text-main);"><i class="bx bx-pie-chart" style="margin-right:6px;"></i> Expense Overheads Breakdown</h3>
        <div style="position: relative; height: 260px; display: flex; justify-content: center;">
            <canvas id="expensesPieChart" style="max-width: 200px;"></canvas>
        </div>
    </div>

</div>

<!-- ==========================================
     CHART LOAD SCRIPT
     ========================================== -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    // 1. Chart A: Revenue vs Purchases curve
    const months = <?php echo json_encode(array_column($monthly_trends, 'month') ?: ['Jan', 'Feb', 'Mar', 'Apr']); ?>;
    const salesSums = <?php echo json_encode(array_column($monthly_trends, 'sales_sum') ?: [0, 0, 0, 0]); ?>;
    
    const ctxA = document.getElementById('revenueProcurementChart').getContext('2d');
    new Chart(ctxA, {
        type: 'line',
        data: {
            labels: months,
            datasets: [
                {
                    label: 'Sales Revenue',
                    data: salesSums,
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.3
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { labels: { color: 'var(--text-main)' } }
            },
            scales: {
                x: { grid: { color: 'var(--border-color)' }, ticks: { color: 'var(--text-secondary)' } },
                y: { grid: { color: 'var(--border-color)' }, ticks: { color: 'var(--text-secondary)' } }
            }
        }
    });

    // 2. Chart B: Expenses Pie
    const expCategories = <?php echo json_encode(array_column($exp_breakdown, 'category') ?: ['Operational']); ?>;
    const expSpends = <?php echo json_encode(array_column($exp_breakdown, 'total_spent') ?: [0]); ?>;

    const ctxB = document.getElementById('expensesPieChart').getContext('2d');
    new Chart(ctxB, {
        type: 'doughnut',
        data: {
            labels: expCategories,
            datasets: [{
                data: expSpends,
                backgroundColor: ['#ef4444', '#f59e0b', '#3b82f6', '#10b981', '#8b5cf6', '#ec4899'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom', labels: { color: 'var(--text-main)', boxWidth: 12 } }
            }
        }
    });
});
</script>

<?php require_once 'includes/footer.php'; ?>
