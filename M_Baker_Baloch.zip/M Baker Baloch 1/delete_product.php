<?php
/**
 * Product Subsystem - Delete Product Processor
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = (new Database())->connect();
    $id = (int)($_POST['id'] ?? 0);

    if ($id <= 0) {
        header("Location: products.php?error=" . urlencode("Invalid product identification."));
        exit;
    }

    try {
        // 1. Fetch details to see if product image file exists
        $stmt = $db->prepare("SELECT name, image_path FROM products WHERE id = :id LIMIT 1");
        $stmt->execute(['id' => $id]);
        $prod = $stmt->fetch();

        if ($prod) {
            $name = $prod['name'];
            $old_img = $prod['image_path'];

            // Clean up and delete uploaded image file from disk!
            if (!empty($old_img) && file_exists($old_img)) {
                unlink($old_img);
            }

            // 2. Delete database entry
            $del = $db->prepare("DELETE FROM products WHERE id = :id");
            $del->execute(['id' => $id]);

            header("Location: products.php?success=" . urlencode("Product '$name' deleted successfully from registry."));
            exit;
        } else {
            header("Location: products.php?error=" . urlencode("Product not found."));
            exit;
        }

    } catch (PDOException $e) {
        header("Location: products.php?error=" . urlencode("Delete operation failed: " . $e->getMessage()));
        exit;
    }
} else {
    header("Location: products.php");
    exit;
}
