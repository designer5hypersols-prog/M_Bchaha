-- ==========================================================================
-- RELATIONAL DATABASE STRUCTURE - MOBILE BARCODE SCANNING SYSTEM
-- ==========================================================================

USE `mbakar_baloch_db`;

-- 1. Mobile Scan Audit Logs (Tracks device scan operations)
CREATE TABLE IF NOT EXISTS `scan_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `barcode` VARCHAR(100) NOT NULL,
    `product_id` INT DEFAULT NULL,
    `scanned_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Active Mobile Device Sessions
CREATE TABLE IF NOT EXISTS `mobile_sessions` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `device_uuid` VARCHAR(255) NOT NULL,
    `api_token` VARCHAR(255) NOT NULL,
    `last_sync` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
