-- ==========================================================================
-- DATABASE MIGRATION - PRODUCTS REGISTRY COMPATIBILITY UPDATE
-- ==========================================================================

USE `mbakar_baloch_db`;

-- Alter products table to support high-end inventory properties
ALTER TABLE `products`
ADD COLUMN `barcode` VARCHAR(100) DEFAULT NULL AFTER `sku`,
ADD COLUMN `brand` VARCHAR(100) DEFAULT NULL AFTER `category_id`,
ADD COLUMN `image_path` VARCHAR(255) DEFAULT NULL AFTER `description`,
ADD COLUMN `supplier_name` VARCHAR(150) DEFAULT NULL AFTER `image_path`;
