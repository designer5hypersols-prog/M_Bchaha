-- ==========================================================================
-- PERFORMANCE OPTIMIZED SQL QUERIES - REPORTS & BUSINESS INTELLIGENCE
-- ==========================================================================

USE `mbakar_baloch_db`;

-- Add indexing to date columns for lightning-fast range queries
ALTER TABLE `sales` ADD INDEX IF NOT EXISTS `idx_sale_date` (`sale_date`);
ALTER TABLE `purchases` ADD INDEX IF NOT EXISTS `idx_purchase_date` (`purchase_date`);
ALTER TABLE `expenses` ADD INDEX IF NOT EXISTS `idx_expense_date` (`expense_date`);

-- 1. Daily Reports Turnover Sums
-- SELECT SUM(payable_amount) FROM sales WHERE sale_date = :target_date;

-- 2. Sales vs Purchases Comparison (Monthly trends)
-- SELECT MONTHNAME(sale_date) as month, SUM(payable_amount) as sales_sum 
-- FROM sales 
-- WHERE YEAR(sale_date) = YEAR(CURRENT_DATE()) 
-- GROUP BY MONTH(sale_date);

-- 3. Category Expenses distribution (Pie Chart)
-- SELECT category, SUM(amount) as total_spent 
-- FROM expenses 
-- GROUP BY category;

-- 4. Stock valuation and Asset Cost Analysis
-- SELECT 
--     SUM(stock_qty * purchase_price) as total_asset_cost,
--     SUM(stock_qty * sell_price) as total_asset_retail,
--     (SUM(stock_qty * sell_price) - SUM(stock_qty * purchase_price)) as potential_profit_yield
-- FROM products 
-- WHERE status = 'ACTIVE';
