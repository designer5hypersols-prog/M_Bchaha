-- ==========================================================================
-- RELATIONAL DATABASE STRUCTURE - AUTOMATED NOTIFICATIONS SYSTEM
-- ==========================================================================

USE `mbakar_baloch_db`;

-- 1. Editable Message Templates Table
CREATE TABLE IF NOT EXISTS `templates` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `template_key` VARCHAR(50) NOT NULL UNIQUE,
    `template_name` VARCHAR(100) NOT NULL,
    `language` ENUM('ENGLISH', 'URDU') NOT NULL DEFAULT 'ENGLISH',
    `message_body` TEXT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Message Queue Table
CREATE TABLE IF NOT EXISTS `messages` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `customer_id` INT DEFAULT NULL,
    `recipient_number` VARCHAR(20) NOT NULL,
    `channel` ENUM('WHATSAPP', 'SMS') NOT NULL DEFAULT 'WHATSAPP',
    `message_text` TEXT NOT NULL,
    `status` ENUM('PENDING', 'SENT', 'FAILED') NOT NULL DEFAULT 'PENDING',
    `retry_count` INT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Message Delivery Logs
CREATE TABLE IF NOT EXISTS `message_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `message_id` INT DEFAULT NULL,
    `gateway_response` TEXT DEFAULT NULL,
    `status` ENUM('SENT', 'FAILED') NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
