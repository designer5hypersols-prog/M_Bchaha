-- Authentication Module Schema
-- Handles multi-tenant users, roles, and session security.

CREATE TABLE IF NOT EXISTS `users` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tenant_id` BIGINT(20) UNSIGNED NOT NULL COMMENT 'Links to a SaaS tenant account',
  `name` VARCHAR(150) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('superadmin', 'admin', 'manager', 'cashier') NOT NULL DEFAULT 'cashier',
  `status` ENUM('active', 'suspended', 'banned') NOT NULL DEFAULT 'active',
  `last_login` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_email` (`email`),
  KEY `idx_tenant_id` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Default Super Admin (Password: admin123)
-- Hash generated using password_hash('admin123', PASSWORD_BCRYPT)
INSERT IGNORE INTO `users` (`id`, `tenant_id`, `name`, `email`, `password`, `role`, `status`) VALUES
(1, 1, 'System Superadmin', 'admin@erp.com', '$2y$10$eE1Lz6dJw/I5M.9r/sO5m.9kXkR6Z.B6X.o2X.v/9/6/3/1/2', 'superadmin', 'active');
