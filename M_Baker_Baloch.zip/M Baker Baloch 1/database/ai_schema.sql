-- ==========================================================================
-- RELATIONAL DATABASE STRUCTURE - AI SMART ASSISTANT SUBSYSTEM
-- ==========================================================================

USE `mbakar_baloch_db`;

-- 1. Chat History Registry (Persists chat session items)
CREATE TABLE IF NOT EXISTS `ai_chat_history` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `sender` ENUM('USER', 'ASSISTANT') NOT NULL,
    `message` TEXT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. AI Operations Audits Logs
CREATE TABLE IF NOT EXISTS `ai_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT DEFAULT NULL,
    `query_string` TEXT NOT NULL,
    `detected_action` VARCHAR(100) DEFAULT NULL,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
