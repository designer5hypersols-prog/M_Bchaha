-- ==========================================================================
-- RELATIONAL DATABASE STRUCTURE - MULTI BRANCH ERP SYSTEM MIGRATION
-- ==========================================================================

USE `mbakar_baloch_db`;

-- 1. Create Branches Table
CREATE TABLE IF NOT EXISTS `branches` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `address` VARCHAR(255) DEFAULT NULL,
    `phone` VARCHAR(50) DEFAULT NULL,
    `status` ENUM('ACTIVE', 'INACTIVE') NOT NULL DEFAULT 'ACTIVE',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed Default Branches
INSERT IGNORE INTO `branches` (`id`, `name`, `address`, `phone`, `status`) VALUES 
(1, 'Central Head Office', 'Lahore, Pakistan', '+92 42 111-222-333', 'ACTIVE'),
(2, 'Karachi Branch', 'Clifton, Karachi, Pakistan', '+92 21 345-678-901', 'ACTIVE'),
(3, 'Quetta Branch', 'Jinnah Road, Quetta, Pakistan', '+92 81 234-567-890', 'ACTIVE');

-- 2. Alter Users Table to include branch_id and upgrade roles
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `branch_id` INT NOT NULL DEFAULT 1 AFTER `id`;
ALTER TABLE `users` MODIFY COLUMN `role` ENUM('SUPERADMIN', 'ADMIN', 'MANAGER', 'CASHIER') NOT NULL DEFAULT 'CASHIER';

-- 3. Alter Inventory & Products Table
ALTER TABLE `products` ADD COLUMN IF NOT EXISTS `branch_id` INT NOT NULL DEFAULT 1 AFTER `id`;

-- 4. Alter Sales Invoice Table
ALTER TABLE `sales` ADD COLUMN IF NOT EXISTS `branch_id` INT NOT NULL DEFAULT 1 AFTER `id`;

-- 5. Alter Purchases Intake Table
ALTER TABLE `purchases` ADD COLUMN IF NOT EXISTS `branch_id` INT NOT NULL DEFAULT 1 AFTER `id`;

-- 6. Alter Stock Warehouse Movement Logs Table
ALTER TABLE `stock_history` ADD COLUMN IF NOT EXISTS `branch_id` INT NOT NULL DEFAULT 1 AFTER `id`;

-- 7. Add Foreign Key references to enforce relational integrity
ALTER TABLE `users` ADD FOREIGN KEY IF NOT EXISTS (`branch_id`) REFERENCES `branches` (`id`) ON DELETE RESTRICT;
ALTER TABLE `products` ADD FOREIGN KEY IF NOT EXISTS (`branch_id`) REFERENCES `branches` (`id`) ON DELETE RESTRICT;
ALTER TABLE `sales` ADD FOREIGN KEY IF NOT EXISTS (`branch_id`) REFERENCES `branches` (`id`) ON DELETE RESTRICT;
ALTER TABLE `purchases` ADD FOREIGN KEY IF NOT EXISTS (`branch_id`) REFERENCES `branches` (`id`) ON DELETE RESTRICT;
ALTER TABLE `stock_history` ADD FOREIGN KEY IF NOT EXISTS (`branch_id`) REFERENCES `branches` (`id`) ON DELETE RESTRICT;

-- 8. Create Stock Transfers logistics ledger
CREATE TABLE IF NOT EXISTS `stock_transfers` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `product_id` INT NOT NULL,
    `from_branch_id` INT NOT NULL,
    `to_branch_id` INT NOT NULL,
    `qty` INT NOT NULL,
    `status` ENUM('PENDING', 'APPROVED', 'REJECTED') NOT NULL DEFAULT 'PENDING',
    `reference_no` VARCHAR(100) DEFAULT NULL,
    `transfer_date` DATE NOT NULL,
    `notes` TEXT DEFAULT NULL,
    `created_by` INT NOT NULL,
    FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT,
    FOREIGN KEY (`from_branch_id`) REFERENCES `branches` (`id`) ON DELETE RESTRICT,
    FOREIGN KEY (`to_branch_id`) REFERENCES `branches` (`id`) ON DELETE RESTRICT,
    FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
