<?php
/**
 * Double Entry Accounting Subsystem - Trial Balance Sheet (Module 5)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();

// Enforce Access
if ($_SESSION['user_role'] !== 'ADMIN' && $_SESSION['user_role'] !== 'MANAGER') {
    die("Access Denied: You must be an Administrator or Manager to compile financial statements.");
}

// ==========================================
// SUMMATION OF ALL LEDGER BALANCES
// ==========================================
$trial_items = [];
$total_debits_sum = 0.00;
$total_credits_sum = 0.00;

try {
    // Left Join with aggregated journal items to pull balances
    $query = "SELECT a.*, 
                     COALESCE(SUM(ji.debit), 0.00) as total_debit, 
                     COALESCE(SUM(ji.credit), 0.00) as total_credit 
              FROM accounts a 
              LEFT JOIN journal_items ji ON a.id = ji.account_id 
              GROUP BY a.id 
              ORDER BY a.code ASC";
              
    $stmt = $db->query($query);
    $trial_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculate dynamic ledger balance per account code rules
    foreach ($trial_items as &$item) {
        $db_val = (float)$item['total_debit'];
        $cr_val = (float)$item['total_credit'];
        
        $item['debit_bal'] = 0.00;
        $item['credit_bal'] = 0.00;

        $is_debit_nature = in_array($item['type'], ['ASSET', 'EXPENSE']);
        
        if ($is_debit_nature) {
            $net = $db_val - $cr_val;
            if ($net >= 0) $item['debit_bal'] = $net;
            else $item['credit_bal'] = abs($net);
        } else {
            $net = $cr_val - $db_val;
            if ($net >= 0) $item['credit_bal'] = $net;
            else $item['debit_bal'] = abs($net);
        }

        $total_debits_sum += $item['debit_bal'];
        $total_credits_sum += $item['credit_bal'];
    }
} catch(PDOException $e) {}

$is_balanced = abs($total_debits_sum - $total_credits_sum) < 0.05;

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<!-- ==========================================
     A. BALANCED INTEGRITY STATUS BANNER
     ========================================== -->
<?php if ($is_balanced): ?>
    <div class="alert alert-success" style="display:flex; align-items:center; gap:12px; margin-bottom:24px; padding:18px; border-left: 5px solid var(--accent);">
        <i class="bx bx-shield-quarter" style="font-size:26px; color:var(--accent);"></i>
        <div>
            <strong style="display:block; font-size:14px; color:var(--accent);">Ledge Balance Integrity Validated</strong>
            <span style="font-size:13px; color:var(--text-secondary);">Double-entry books are completely balanced. Debit totals exactly match Credit totals (Rs. <?php echo number_format($total_debits_sum, 2); ?>).</span>
        </div>
    </div>
<?php else: ?>
    <div class="alert alert-danger" style="display:flex; align-items:center; gap:12px; margin-bottom:24px; padding:18px; border-left: 5px solid var(--danger);">
        <i class="bx bx-error" style="font-size:26px; color:var(--danger);"></i>
        <div>
            <strong style="display:block; font-size:14px; color:var(--danger);">Ledger Balance Out of Alignment</strong>
            <span style="font-size:13px; color:var(--text-secondary);">CAUTION! Bookkeeping balance mismatch detected. Difference: Rs. <?php echo number_format(abs($total_debits_sum - $total_credits_sum), 2); ?>.</span>
        </div>
    </div>
<?php endif; ?>

<!-- ==========================================
     B. TRIAL BALANCE SHEET
     ========================================== -->
<div class="card">
    <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color); display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
        <div class="card-title">
            <i class="bx bx-select-multiple" style="color:var(--accent);"></i>
            <span>Corporate Trial Balance Statement</span>
        </div>
        <button type="button" class="btn btn-sm" onclick="window.print()" style="background:var(--bg-secondary); border-color:var(--border-color); height:30px; width:auto; font-size:11px; padding:0 12px; color:var(--text-main);">
            <i class="bx bx-printer" style="margin-right:4px;"></i> Print Sheet
        </button>
    </div>

    <div class="table-responsive">
        <table class="table" style="--table-padding: 10px 14px;">
            <thead>
                <tr>
                    <th>Account Code</th>
                    <th>Account Description</th>
                    <th>Classification</th>
                    <th style="text-align:right;">Debit Ledger Balance</th>
                    <th style="text-align:right;">Credit Ledger Balance</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($trial_items as $item): 
                    if ($item['debit_bal'] == 0 && $item['credit_bal'] == 0) continue; // skip zero activity accounts
                    $badge_class = 'primary';
                    if ($item['type'] === 'LIABILITY') $badge_class = 'danger';
                    elseif ($item['type'] === 'EQUITY') $badge_class = 'warning';
                    elseif ($item['type'] === 'INCOME') $badge_class = 'success';
                    elseif ($item['type'] === 'EXPENSE') $badge_class = 'info';
                ?>
                    <tr class="animate-fade">
                        <td><code><?php echo htmlspecialchars($item['code']); ?></code></td>
                        <td><strong><?php echo htmlspecialchars($item['name']); ?></strong></td>
                        <td>
                            <span style="font-size: 9.5px; font-weight:700; padding:2px 8px; border-radius:4px; 
                                background: var(--<?php echo $badge_class; ?>-glow); 
                                color: var(--<?php echo $badge_class; ?>);">
                                <?php echo $item['type']; ?>
                            </span>
                        </td>
                        <td style="text-align:right; font-weight:700;">
                            <?php echo ($item['debit_bal'] > 0) ? 'Rs. ' . number_format($item['debit_bal'], 2) : '-'; ?>
                        </td>
                        <td style="text-align:right; font-weight:700;">
                            <?php echo ($item['credit_bal'] > 0) ? 'Rs. ' . number_format($item['credit_bal'], 2) : '-'; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>

                <!-- Aggregated totals row -->
                <tr style="background:var(--bg-surface); border-top: 2px solid var(--border-color); font-size:14.5px;">
                    <td colspan="3" style="text-align:right; font-weight:800; color:var(--text-main);">AGGREGATE BALANCES TOTAL:</td>
                    <td style="text-align:right; font-weight:900; color:var(--accent);">Rs. <?php echo number_format($total_debits_sum, 2); ?></td>
                    <td style="text-align:right; font-weight:900; color:var(--accent);">Rs. <?php echo number_format($total_credits_sum, 2); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
