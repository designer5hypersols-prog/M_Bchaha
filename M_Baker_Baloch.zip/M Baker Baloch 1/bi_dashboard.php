<?php
/**
  * Executive Business Intelligence (BI) Dashboard
  * Shop Name: M.BAKAR BALOCH
  */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';
require_once 'analytics_engine.php';
require_once 'kpi_calculator.php';
require_once 'trend_analysis.php';
require_once 'insights_generator.php';

// Enforce executive roles (Super Admin or Admin only)
if ($_SESSION['user_role'] !== 'SUPERADMIN' && $_SESSION['user_role'] !== 'ADMIN') {
    die("Access Denied: You do not have permissions to access the Corporate Executive BI Dashboard.");
}

$db = (new Database())->connect();
$engine = new AnalyticsEngine($db);

// Gather Analytics through cache layer
$kpis = $engine->getMetric('overview_kpis', ['KPICalculator', 'calculateOverview']);
$branch_stats = $engine->getMetric('branch_kpis', ['KPICalculator', 'calculateBranchMetrics']);
$turnover_stats = $engine->getMetric('turnover_kpis', ['KPICalculator', 'calculateInventoryTurnover']);
$monthly_trends = $engine->getMetric('monthly_trends', ['TrendAnalysis', 'calculateMonthlyTrends']);
$expense_breakdown = $engine->getMetric('expenses_trends', ['TrendAnalysis', 'calculateExpenseBreakdown']);
$seasonal_patterns = $engine->getMetric('seasonal_patterns', ['TrendAnalysis', 'calculateSeasonalPatterns']);
$insights = $engine->getMetric('forecast_insights', ['InsightsGenerator', 'compileInsights']);

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">
<style>
    .bi-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 20px;
        margin-bottom: 24px;
    }
    .bi-card {
        background: var(--bg-secondary);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-lg);
        padding: 24px;
        position: relative;
        overflow: hidden;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 4px 20px rgba(0,0,0,0.02);
    }
    .bi-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 30px var(--accent-glow);
        border-color: var(--accent);
    }
    .bi-kpi-num {
        font-size: 32px;
        font-weight: 800;
        letter-spacing: -1px;
        margin: 12px 0 6px 0;
        color: var(--text-main);
    }
    .bi-badge {
        font-size: 11px;
        font-weight: 700;
        padding: 3px 8px;
        border-radius: 6px;
        display: inline-flex;
        align-items: center;
        gap: 4px;
    }
    .bi-badge.up { background: var(--success-glow); color: var(--success); }
    .bi-badge.down { background: var(--danger-glow); color: var(--danger); }
    
    .bi-layout-split {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 24px;
        margin-bottom: 24px;
        align-items: start;
    }
    
    @media (max-width: 1024px) {
        .bi-layout-split {
            grid-template-columns: 1fr;
        }
    }
</style>

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="margin: 0; font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Executive BI Analytics</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Shop performance matrix and predictive forecasting models.</p>
    </div>
    <div style="display: flex; gap: 12px;">
        <button onclick="exportBICachingData()" class="btn btn-secondary btn-sm" style="width: auto;">
            <i class="bx bx-download"></i> Export BI Sheet
        </button>
        <a href="executive_overview.php" class="btn btn-sm" style="width: auto; background: var(--accent); border-color: var(--accent); color: #fff;">
            <i class="bx bx-buildings"></i> Branch Drill-Down
        </a>
    </div>
</div>

<!-- ==========================================
     I. SMART EXECUTIVE KPI CARDS
     ========================================== -->
<div class="bi-grid">
    <!-- Card 1: Revenue YoY -->
    <div class="bi-card animate-fade">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="font-size: 12.5px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Total Turnover</span>
            <i class="bx bx-trending-up" style="font-size: 20px; color: var(--accent);"></i>
        </div>
        <div class="bi-kpi-num">Rs. <?php echo number_format($kpis['total_revenue'], 2); ?></div>
        <div style="display: flex; align-items: center; gap: 6px;">
            <span class="bi-badge up"><i class="bx bx-up-arrow-alt"></i> YoY <?php echo number_format($kpis['yoy_growth_pct'], 1); ?>%</span>
            <span style="font-size: 11px; color: var(--text-muted);">vs Last Year</span>
        </div>
    </div>

    <!-- Card 2: Net Profit Margin -->
    <div class="bi-card animate-fade">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="font-size: 12.5px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Net Profit</span>
            <i class="bx bx-dollar-circle" style="font-size: 20px; color: var(--success);"></i>
        </div>
        <div class="bi-kpi-num">Rs. <?php echo number_format($kpis['net_profit'], 2); ?></div>
        <div style="display: flex; align-items: center; gap: 6px;">
            <span class="bi-badge up" style="background:var(--success-glow); color:var(--success);">Margin: <?php echo number_format($kpis['profit_margin_pct'], 1); ?>%</span>
            <span style="font-size: 11px; color: var(--text-muted);">net retail profit</span>
        </div>
    </div>

    <!-- Card 3: Inventory Turnover -->
    <div class="bi-card animate-fade">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="font-size: 12.5px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Inventory Turnover</span>
            <i class="bx bx-sync" style="font-size: 20px; color: var(--warning);"></i>
        </div>
        <div class="bi-kpi-num"><?php echo number_format($turnover_stats['turnover_rate'], 2); ?>x</div>
        <div style="display: flex; align-items: center; gap: 6px;">
            <span class="bi-badge up" style="background:var(--accent-glow); color:var(--accent);"><i class="bx bx-check"></i> High Velocity</span>
            <span style="font-size: 11px; color: var(--text-muted);">stock replacement cycles</span>
        </div>
    </div>

    <!-- Card 4: Expected Forecast -->
    <div class="bi-card animate-fade">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="font-size: 12.5px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Next Month Expected Sales</span>
            <i class="bx bx-brain" style="font-size: 20px; color: var(--accent);"></i>
        </div>
        <div class="bi-kpi-num" style="color:var(--accent);">Rs. <?php echo number_format($insights['expected_sales'], 2); ?></div>
        <div style="display: flex; align-items: center; gap: 6px;">
            <span class="bi-badge up"><i class="bx bx-line-chart"></i> Projected +5%</span>
            <span style="font-size: 11px; color: var(--text-muted);">weighted moving average</span>
        </div>
    </div>
</div>

<!-- ==========================================
     II. BI DYNAMIC PLOTS & ADVISORY DESK
     ========================================== -->
<div class="bi-layout-split">
    
    <!-- Left: Timeline Growth Charts -->
    <div class="card" style="margin-bottom: 0;">
        <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-chart" style="color:var(--accent);"></i>
                <span>Corporate Performance Timeline (Revenue vs Profit vs Overhead)</span>
            </div>
        </div>

        <div style="position: relative; height: 320px;">
            <canvas id="biMonthlyTrendsChart" 
                    data-labels="<?php echo htmlspecialchars(json_encode(array_column($monthly_trends, 'month'))); ?>"
                    data-sales="<?php echo htmlspecialchars(json_encode(array_column($monthly_trends, 'sales'))); ?>"
                    data-expenses="<?php echo htmlspecialchars(json_encode(array_column($monthly_trends, 'expenses'))); ?>"
                    data-profit="<?php echo htmlspecialchars(json_encode(array_column($monthly_trends, 'profit'))); ?>">
            </canvas>
        </div>
    </div>

    <!-- Right: Decision Intelligence advisory desk -->
    <div class="card" style="margin-bottom: 0; background: linear-gradient(135deg, var(--bg-secondary) 0%, var(--accent-glow) 100%);">
        <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-bulb" style="color:var(--accent);"></i>
                <span>Decision Advisory Intelligence</span>
            </div>
        </div>

        <div style="display: flex; flex-direction: column; gap: 14px;">
            <?php foreach ($insights['advisory_notes'] as $note): ?>
                <div style="padding: 14px; border-radius: var(--radius-sm); background: var(--bg-primary); border-left: 4px solid var(--accent); box-shadow: 0 2px 8px rgba(0,0,0,0.01);">
                    <p style="margin: 0; font-size: 13px; line-height: 1.5; color: var(--text-main);"><?php echo htmlspecialchars($note); ?></p>
                </div>
            <?php endforeach; ?>
            
            <div style="padding: 14px; border-radius: var(--radius-sm); border: 1px dashed var(--border-color); background: rgba(255,255,255,0.02); text-align: center;">
                <span style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 4px;">Top Performing Branch</span>
                <strong style="font-size: 15px; color: var(--accent);"><?php echo htmlspecialchars($branch_stats['top_branch']); ?></strong>
                <span style="font-size: 11.5px; display: block; color: var(--text-muted); margin-top: 2px;">Rs. <?php echo number_format($branch_stats['top_sales'], 2); ?></span>
            </div>
        </div>
    </div>

</div>

<!-- ==========================================
     III. DRILL-DOWNS: BEST SELLERS & CUSTOMERS
     ========================================== -->
<div class="bi-layout-split" style="grid-template-columns: 1fr 1fr;">

    <!-- Left: Best Sellers -->
    <div class="card">
        <div class="card-header" style="margin-bottom: 15px; padding-bottom: 8px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-star" style="color:var(--accent);"></i>
                <span>Top Selling Products Catalog</span>
            </div>
        </div>
        
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Product SKU</th>
                        <th>Product Label</th>
                        <th style="text-align:center;">Units Sold</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($insights['best_sellers'])): ?>
                        <tr>
                            <td colspan="3" style="text-align:center; color:var(--text-muted);">No sales data registered yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($insights['best_sellers'] as $b): ?>
                            <tr>
                                <td><code><?php echo htmlspecialchars($b['sku']); ?></code></td>
                                <td><strong><?php echo htmlspecialchars($b['name']); ?></strong></td>
                                <td style="text-align:center; font-weight:800; color:var(--accent);"><?php echo $b['total_qty']; ?> pcs</td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Right: High Margin Products -->
    <div class="card">
        <div class="card-header" style="margin-bottom: 15px; padding-bottom: 8px; border-bottom: 1.5px dashed var(--border-color);">
            <div class="card-title">
                <i class="bx bx-money" style="color:var(--accent);"></i>
                <span>High-Margin Assets</span>
            </div>
        </div>
        
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>SKU</th>
                        <th>Name</th>
                        <th style="text-align:right;">Buy Price</th>
                        <th style="text-align:right;">Sell Price</th>
                        <th style="text-align:right;">Net Margin</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($insights['high_margin_products'])): ?>
                        <tr>
                            <td colspan="5" style="text-align:center; color:var(--text-muted);">No high margin products cataloged.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($insights['high_margin_products'] as $p): ?>
                            <tr>
                                <td><code><?php echo htmlspecialchars($p['sku']); ?></code></td>
                                <td><strong><?php echo htmlspecialchars($p['name']); ?></strong></td>
                                <td style="text-align:right;">Rs. <?php echo number_format($p['purchase_price'], 2); ?></td>
                                <td style="text-align:right; font-weight:700;">Rs. <?php echo number_format($p['sell_price'], 2); ?></td>
                                <td style="text-align:right; color:var(--accent); font-weight:800;">Rs. <?php echo number_format($p['margin'], 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- ==========================================
     IV. DYNAMIC CHART BINDER SCRIPTS
     ========================================== -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('biMonthlyTrendsChart');
    if (canvas) {
        const labels = JSON.parse(canvas.getAttribute('data-labels') || '[]');
        const sales = JSON.parse(canvas.getAttribute('data-sales') || '[]').map(Number);
        const expenses = JSON.parse(canvas.getAttribute('data-expenses') || '[]').map(Number);
        const profit = JSON.parse(canvas.getAttribute('data-profit') || '[]').map(Number);

        const ctx = canvas.getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Gross Sales (Rs.)',
                        data: sales,
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.05)',
                        borderWidth: 3,
                        tension: 0.4,
                        fill: true
                    },
                    {
                        label: 'Operating Overheads (Rs.)',
                        data: expenses,
                        borderColor: '#ef4444',
                        backgroundColor: 'transparent',
                        borderWidth: 2,
                        tension: 0.4,
                        borderDash: [5, 5]
                    },
                    {
                        label: 'Net Profits (Rs.)',
                        data: profit,
                        borderColor: '#3b82f6',
                        backgroundColor: 'rgba(59, 130, 246, 0.05)',
                        borderWidth: 3,
                        tension: 0.4,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { color: '#94a3b8', boxWidth: 12 } }
                },
                scales: {
                    x: { ticks: { color: '#94a3b8' }, grid: { display: false } },
                    y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(255,255,255,0.03)' } }
                }
            }
        });
    }
});

/**
 * Export BI metrics reports cleanly as CSV
 */
function exportBICachingData() {
    let rows = [
        ["M.BAKAR BALOCH - Corporate BI Analytics Report"],
        ["Export Date", new Date().toLocaleString()],
        [],
        ["Metric Category", "Metric Key", "Computed Value"],
        ["Turnover Metrics", "Gross Revenue (Rs.)", "<?php echo number_format($kpis['total_revenue'], 2); ?>"],
        ["Turnover Metrics", "Cost of Goods Sold (Rs.)", "<?php echo number_format($kpis['total_cost_goods'], 2); ?>"],
        ["Turnover Metrics", "Gross Profit (Rs.)", "<?php echo number_format($kpis['gross_profit'], 2); ?>"],
        ["Overhead Metrics", "Total Expenses (Rs.)", "<?php echo number_format($kpis['total_expenses'], 2); ?>"],
        ["Net Margin Metrics", "Net Profit (Rs.)", "<?php echo number_format($kpis['net_profit'], 2); ?>"],
        ["Net Margin Metrics", "Net Profit Margin (%)", "<?php echo number_format($kpis['profit_margin_pct'], 2); ?>%"],
        ["Inventory Metrics", "Turnover rate (turns)", "<?php echo number_format($turnover_stats['turnover_rate'], 2); ?>"],
        ["Inventory Metrics", "Asset valuation (Rs.)", "<?php echo number_format($turnover_stats['inventory_value'], 2); ?>"]
    ];

    let csvContent = "data:text/csv;charset=utf-8," 
        + rows.map(e => e.map(val => `"${val.replace(/"/g, '""')}"`).join(",")).join("\n");
    
    let encodedUri = encodeURI(csvContent);
    let link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "mbakar_baloch_executive_bi_report.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
</script>

<?php require_once 'includes/footer.php'; ?>
