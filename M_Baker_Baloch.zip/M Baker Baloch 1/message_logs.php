<?php
/**
 * Automated Notifications Subsystem - Message Auditing Logs (Module 5)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';

$db = (new Database())->connect();

// Enforce Manager or Admin rights
if ($_SESSION['user_role'] !== 'ADMIN' && $_SESSION['user_role'] !== 'MANAGER') {
    die("Access Denied: You do not have permissions to audit automated customer message logs.");
}

// ==========================================
// LOAD DELIVERY QUEUES HISTORY
// ==========================================
$channel_filter = sanitize($_GET['channel'] ?? '');
$status_filter = sanitize($_GET['status'] ?? '');

$query = "SELECT m.*, c.name as customer_name, ml.gateway_response 
          FROM messages m 
          LEFT JOIN customers c ON m.customer_id = c.id 
          LEFT JOIN message_logs ml ON m.id = ml.message_id 
          WHERE 1=1";
$params = [];

if (!empty($channel_filter)) {
    $query .= " AND m.channel = :channel";
    $params['channel'] = $channel_filter;
}

if (!empty($status_filter)) {
    $query .= " AND m.status = :status";
    $params['status'] = $status_filter;
}

$query .= " ORDER BY m.id DESC LIMIT 100";

try {
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $logs = [];
}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="settings.css">

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <a href="settings.php#subsystems_link" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
            <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Settings Hub
        </a>
    </div>
</div>

<!-- ==========================================
     FILTER SELECTION TOOLBAR
     ========================================== -->
<div class="card" style="margin-bottom:24px; padding:16px;">
    <form method="GET" action="message_logs.php" style="display:flex; gap:16px; align-items:flex-end; flex-wrap:wrap;">
        <div style="flex-grow:1; min-width:200px;">
            <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Filter Channel</label>
            <select name="channel" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px; cursor:pointer;">
                <option value="">All Channels (WhatsApp / SMS)</option>
                <option value="WHATSAPP" <?php echo ($channel_filter === 'WHATSAPP') ? 'selected' : ''; ?>>WhatsApp</option>
                <option value="SMS" <?php echo ($channel_filter === 'SMS') ? 'selected' : ''; ?>>SMS fallback</option>
            </select>
        </div>

        <div style="flex-grow:1; min-width:200px;">
            <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Delivery Status</label>
            <select name="status" style="width:100%; height:40px; padding:0 12px; background:var(--input-bg); border:1px solid var(--input-border); border-radius:var(--radius-sm); color:var(--text-main); font-size:13.5px; cursor:pointer;">
                <option value="">All Delivery Statuses</option>
                <option value="SENT" <?php echo ($status_filter === 'SENT') ? 'selected' : ''; ?>>SENT</option>
                <option value="FAILED" <?php echo ($status_filter === 'FAILED') ? 'selected' : ''; ?>>FAILED</option>
                <option value="PENDING" <?php echo ($status_filter === 'PENDING') ? 'selected' : ''; ?>>PENDING</option>
            </select>
        </div>

        <div>
            <button type="submit" class="btn" style="background:var(--accent); border-color:var(--accent); height:40px; width:auto; font-size:13.5px; padding:0 20px;">
                <i class="bx bx-slider" style="margin-right:4px;"></i> Apply Filters
            </button>
        </div>
    </form>
</div>

<!-- ==========================================
     MESSAGES HISTORY TABLE
     ========================================== -->
<div class="card">
    <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1.5px dashed var(--border-color);">
        <div class="card-title">
            <i class="bx bx-list-check" style="color:var(--accent);"></i>
            <span>Automated Messaging Dispatch logs</span>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Target Customer</th>
                    <th>Mobile Number</th>
                    <th>Channel</th>
                    <th>Message Content</th>
                    <th>Delivery Status</th>
                    <th>Gateway Details</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($logs)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; color: var(--text-muted); padding: 30px;">No automated messages logged yet.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach($logs as $log): ?>
                        <tr class="animate-fade">
                            <td>
                                <strong><?php echo htmlspecialchars($log['customer_name'] ?: 'Walk-in Customer'); ?></strong>
                            </td>
                            <td><code style="font-size:12.5px; font-weight:700;"><?php echo htmlspecialchars($log['recipient_number']); ?></code></td>
                            <td>
                                <span style="font-size:10px; font-weight:700; padding:2px 8px; border-radius:4px; 
                                    background: <?php echo ($log['channel'] === 'WHATSAPP') ? 'var(--accent-glow)' : 'var(--info-glow)'; ?>;
                                    color: <?php echo ($log['channel'] === 'WHATSAPP') ? 'var(--accent)' : 'var(--info)'; ?>;">
                                    <?php echo $log['channel']; ?>
                                </span>
                            </td>
                            <td>
                                <div style="max-width:280px; font-size:12px; line-height:1.4; color:var(--text-secondary); display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;" title="<?php echo htmlspecialchars($log['message_text']); ?>">
                                    <?php echo htmlspecialchars($log['message_text']); ?>
                                </div>
                            </td>
                            <td>
                                <?php if ($log['status'] === 'SENT'): ?>
                                    <span style="font-size: 10px; font-weight:700; padding:2px 8px; background:var(--accent-glow); color:var(--accent); border-radius:4px;">SENT</span>
                                <?php elseif ($log['status'] === 'PENDING'): ?>
                                    <span style="font-size: 10px; font-weight:700; padding:2px 8px; background:var(--warning-glow); color:var(--warning); border-radius:4px;">PENDING</span>
                                <?php else: ?>
                                    <span style="font-size: 10px; font-weight:700; padding:2px 8px; background:var(--danger-glow); color:var(--danger); border-radius:4px;">FAILED</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span style="font-size:11px; color:var(--text-muted); font-family:monospace; display:block; max-width:200px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="<?php echo htmlspecialchars($log['gateway_response']); ?>">
                                    <?php echo htmlspecialchars($log['gateway_response'] ?: 'None'); ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
