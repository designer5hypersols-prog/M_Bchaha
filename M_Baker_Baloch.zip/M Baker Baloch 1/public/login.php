<?php
/**
 * ERP SaaS Login Gateway
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../core/Auth.php';

// Redirect if already logged in
if (Auth::check()) {
    header('Location: ../modules/dashboard/index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $csrf = $_POST['csrf_token'] ?? '';
    
    // Security check: CSRF Validation
    if (!Auth::verifyCsrf($csrf)) {
        $error = "Invalid form submission. Please refresh and try again.";
    } elseif (empty($email) || empty($password)) {
        $error = "Email and Password are required.";
    } else {
        if (Auth::attempt($email, $password)) {
            header('Location: ../modules/dashboard/index.php');
            exit;
        } else {
            $error = "Incorrect email or password, or account suspended.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Access - M.BAKAR BALOCH ERP</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Boxicons -->
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/auth.css">
</head>
<body class="auth-bg">

<div class="container d-flex justify-content-center align-items-center min-vh-100">
    <div class="auth-card p-5 rounded-4 shadow-lg bg-white">
        
        <div class="text-center mb-4">
            <div class="brand-logo mb-3">MB</div>
            <h3 class="fw-bold text-dark">ERP SaaS Portal</h3>
            <p class="text-muted">Sign in to access your business tenant</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger d-flex align-items-center" role="alert">
                <i class='bx bx-error-circle fs-5 me-2'></i>
                <div><?= htmlspecialchars($error) ?></div>
            </div>
        <?php endif; ?>

        <form method="POST" id="loginForm">
            <input type="hidden" name="csrf_token" value="<?= Auth::csrfToken() ?>">
            
            <div class="form-floating mb-3">
                <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" required autocomplete="email" autofocus>
                <label for="email">Email address</label>
            </div>
            
            <div class="form-floating mb-4">
                <input type="password" class="form-control" id="password" name="password" placeholder="Password" required autocomplete="current-password">
                <label for="password">Security Password</label>
            </div>
            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="1" id="rememberMe" name="remember">
                    <label class="form-check-label text-muted" for="rememberMe">
                        Keep me signed in
                    </label>
                </div>
                <a href="#" class="text-decoration-none fw-semibold">Forgot Password?</a>
            </div>

            <button type="submit" class="btn btn-primary w-100 py-3 fw-bold btn-submit" id="submitBtn">
                <span class="btn-text">Authenticate Securely</span>
                <span class="spinner-border spinner-border-sm d-none" id="submitSpinner" role="status" aria-hidden="true"></span>
            </button>
        </form>
        
        <div class="mt-4 text-center text-muted small">
            &copy; <?= date('Y') ?> M.BAKAR BALOCH. Enterprise protected.
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/auth.js"></script>
</body>
</html>
