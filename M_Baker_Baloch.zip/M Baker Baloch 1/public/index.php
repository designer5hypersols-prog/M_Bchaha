<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../core/Auth.php';

$route = $_GET['route'] ?? 'dashboard';

// Check Authentication
if (!Auth::check() && $route !== 'login') {
    header('Location: login.php');
    exit;
}

if ($route === 'dashboard') {
    header('Location: ../modules/dashboard/index.php');
    exit;
}
