<?php
/**
 * Authentication Exit Point
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../core/Auth.php';

Auth::logout();

// Redirect back to login with a generic success parameter
header('Location: login.php?logged_out=1');
exit;
