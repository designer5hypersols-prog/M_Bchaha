<?php
/**
 * Purchase & Stock Subsystem - Stock Movement Audit Ledger (Module 3)
 * Shop Name: M.BAKAR BALOCH
 */

require_once 'config/config.php';
require_once 'config/database.php';

$db = (new Database())->connect();
$error_message = "";
$success_message = "";

// PAGINATION LOGIC
$limit = 12; // Log items per page
$page = (int)($_GET['page'] ?? 1);
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

try {
    // Total logs count
    $total_records = $db->query("SELECT COUNT(*) FROM stock_history")->fetchColumn() ?: 0;
    
    $total_pages = ceil($total_records / $limit);
    if ($total_pages < 1) $total_pages = 1;
    if ($page > $total_pages) $page = $total_pages;
    $offset = ($page - 1) * $limit;

    // Fetch logs joined with product attributes
    $stmt = $db->prepare("SELECT sh.*, p.name as product_name, p.sku as product_sku, p.unit as product_unit FROM stock_history sh JOIN products p ON sh.product_id = p.id ORDER BY sh.id DESC LIMIT :limit OFFSET :offset");
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $logs = $stmt->fetchAll();

} catch (PDOException $e) {
    $total_records = 0;
    $total_pages = 1;
    $logs = [];
}

require_once 'includes/header.php';
?>

<!-- Include CSS -->
<link rel="stylesheet" href="purchase.css">

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <a href="purchase.php" style="text-decoration: none; color: var(--text-muted); font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
            <i class="bx bx-left-arrow-alt" style="font-size: 18px;"></i> Back to Purchases Hub
        </a>
    </div>
    
    <div style="display: flex; gap: 10px;">
        <button type="button" class="btn btn-sm btn-secondary" style="width: auto;" onclick="exportStockLogsToCSV('masterStockLogsTable')">
            <i class="bx bx-download"></i> Export Stock Flow CSV
        </button>
        <a href="stock.php" class="btn btn-sm" style="width: auto; text-decoration: none; display: inline-flex; align-items: center; justify-content: center;">
            <i class="bx bx-cabinet" style="font-size:18px; margin-right:6px;"></i> Current Inventory Levels
        </a>
    </div>
</div>

<!-- ==========================================
     STOCK FLOW MOVEMENT HISTORICAL LEDGER
     ========================================== -->
<div class="card">
    <div class="card-header" style="margin-bottom: 20px; padding-bottom: 10px;">
        <div class="card-title">
            <i class="bx bx-cabinet"></i>
            <span>Real-time Warehouse Stock Inbound / Outbound Movement Audit logs</span>
        </div>
        <span style="font-size:11px; color:var(--text-muted);">Audited log</span>
    </div>

    <div class="table-responsive">
        <table class="table" id="masterStockLogsTable">
            <thead>
                <tr>
                    <th>Log ID</th>
                    <th>Product Name</th>
                    <th>Product SKU</th>
                    <th>Audit Type</th>
                    <th>Quantity Shifted</th>
                    <th>Reference Remarks</th>
                    <th>Log Timestamp</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($logs)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; color: var(--text-muted); padding: 45px;">No inventory logs recorded in ledger.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach($logs as $log): ?>
                        <tr class="animate-fade">
                            <td style="font-weight: 600; color: var(--text-muted);">#<?php echo $log['id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($log['product_name']); ?></strong></td>
                            <td style="font-weight: 600; color: var(--accent);"><?php echo htmlspecialchars($log['product_sku']); ?></td>
                            <td>
                                <?php if ($log['type'] === 'IN'): ?>
                                    <span class="stock-log-badge in"><i class="bx bx-trending-up" style="margin-right:4px;"></i> STOCK IN</span>
                                <?php elseif ($log['type'] === 'OUT'): ?>
                                    <span class="stock-log-badge out"><i class="bx bx-trending-down" style="margin-right:4px;"></i> STOCK OUT</span>
                                <?php else: ?>
                                    <span class="stock-log-badge adjust"><i class="bx bx-git-commit" style="margin-right:4px;"></i> ADJUSTED</span>
                                <?php endif; ?>
                            </td>
                            <td style="font-weight: 700; font-size:14.5px;">
                                <?php echo ($log['type'] === 'IN') ? '+' : (($log['type'] === 'OUT') ? '-' : ''); ?>
                                <?php echo $log['qty']; ?> <?php echo htmlspecialchars($log['product_unit']); ?>
                            </td>
                            <td><span style="font-size:12.5px; color:var(--text-secondary);"><?php echo htmlspecialchars($log['remarks'] ?: '-'); ?></span></td>
                            <td style="font-size:12px; color:var(--text-muted);"><?php echo format_date($log['created_at']) . ' ' . date('h:i A', strtotime($log['created_at'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ==========================================
     PAGINATION CONTROL ROW FOOTER
     ========================================== -->
<div class="pagination" style="margin-top: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <span style="font-size: 13.5px; color: var(--text-secondary);">Showing <strong><?php echo count($logs); ?></strong> of <strong><?php echo $total_records; ?></strong> logs.</span>
    
    <div style="display: flex; gap: 5px;">
        <!-- Previous -->
        <a href="stock_logs.php?page=<?php echo ($page - 1); ?>" 
           class="btn btn-sm btn-secondary <?php echo ($page <= 1) ? 'disabled' : ''; ?>" 
           style="width: auto; padding: 6px 12px; pointer-events: <?php echo ($page <= 1) ? 'none' : 'auto'; ?>;">
           &larr; Prev
        </a>

        <!-- Page numbers -->
        <?php for($i = 1; $i <= $total_pages; $i++): ?>
            <a href="stock_logs.php?page=<?php echo $i; ?>" 
               class="btn btn-sm <?php echo ($page === $i) ? '' : 'btn-secondary'; ?>" 
               style="width: 32px; padding: 6px 0; text-align: center;">
               <?php echo $i; ?>
            </a>
        <?php endfor; ?>

        <!-- Next -->
        <a href="stock_logs.php?page=<?php echo ($page + 1); ?>" 
           class="btn btn-sm btn-secondary <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>" 
           style="width: auto; padding: 6px 12px; pointer-events: <?php echo ($page >= $total_pages) ? 'none' : 'auto'; ?>;">
           Next &rarr;
        </a>
    </div>
</div>

<script>
/**
 * Stock Flow CSV Exporter
 */
function exportStockLogsToCSV(tableId) {
    const csv = [];
    const rows = document.querySelectorAll("#" + tableId + " tr");
    
    for (let i = 0; i < rows.length; i++) {
        const row = [];
        const cols = rows[i].querySelectorAll("td, th");
        
        for (let j = 0; j < cols.length; j++) {
            let data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, "").replace(/,/g, ";").trim();
            row.push('"' + data + '"');
        }
        csv.push(row.join(","));
    }

    const csvFile = new Blob([csv.join("\n")], {type: "text/csv"});
    const link = document.createElement("a");
    link.download = "mbakar_baloch_stock_movement_ledger.csv";
    link.href = window.URL.createObjectURL(csvFile);
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
</script>

<?php require_once 'includes/header.php'; ?>
