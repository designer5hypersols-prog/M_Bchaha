<?php
/**
  * Advanced Security & Audit Trail System - Active User Sessions Tracking
  * Shop Name: M.BAKAR BALOCH
  */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_check.php';
require_once 'security_engine.php';
require_once 'audit_logger.php';

// Enforce admin/executive role
if ($_SESSION['role'] !== 'SUPERADMIN' && $_SESSION['role'] !== 'ADMIN') {
    die("Access Denied: You do not have permissions to monitor user active sessions.");
}

$db = (new Database())->connect();
$message = '';
$error = '';

// Handle Terminate Single Session Action
if (isset($_POST['action']) && $_POST['action'] === 'terminate' && isset($_POST['session_id'])) {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        $error = "CSRF Token Validation Failed.";
    } else {
        $sid = (int)$_POST['session_id'];
        
        // Fetch session operator details for auditing
        try {
            $check = $db->prepare("SELECT s.session_token, u.username, s.ip_address 
                                   FROM user_sessions s 
                                   JOIN users u ON s.user_id = u.id 
                                   WHERE s.id = :id LIMIT 1");
            $check->execute(['id' => $sid]);
            $s_row = $check->fetch();

            if ($s_row) {
                // Lock session in database
                SecurityEngine::terminateSession($sid);
                AuditLogger::logActivity("SECURITY_ALERT", "Forced termination of active session token for operator @" . $s_row['username'] . " from IP: " . $s_row['ip_address']);
                $message = "Session terminated successfully. Operator will be logged out on their next action.";
            } else {
                $error = "Session not found or already expired.";
            }
        } catch (PDOException $e) {
            $error = "System error processing termination.";
        }
    }
}

// Handle Force Logout All Sessions
if (isset($_POST['action']) && $_POST['action'] === 'terminate_all') {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        $error = "CSRF Token Validation Failed.";
    } else {
        $my_token = $_SESSION['session_token'];
        $my_id = $_SESSION['user_id'];

        try {
            SecurityEngine::terminateAllSessions($my_id, $my_token);
            AuditLogger::logActivity("SECURITY_ALERT", "Forced termination of ALL other active sessions for user ID: " . $my_id);
            $message = "All other sessions terminated successfully.";
        } catch (PDOException $e) {
            $error = "Failed to terminate sessions.";
        }
    }
}

// Fetch all active sessions
$sessions = [];
try {
    $sessions = $db->query("SELECT s.*, u.name as operator_name, u.username as operator_username, u.role as operator_role 
                            FROM user_sessions s
                            JOIN users u ON s.user_id = u.id
                            ORDER BY s.last_active_time DESC")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

require_once 'includes/header.php';
?>

<!-- Custom Styles -->
<link rel="stylesheet" href="settings.css">
<style>
    .session-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
        gap: 20px;
        margin-top: 15px;
    }
    .session-card {
        background: var(--bg-secondary);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-sm);
        padding: 20px;
        position: relative;
        overflow: hidden;
        transition: all 0.2s ease;
    }
    .session-card:hover {
        border-color: var(--accent);
        box-shadow: 0 4px 15px rgba(0,0,0,0.02);
    }
    .session-card.current {
        border: 2px solid var(--success);
        background: linear-gradient(135deg, var(--bg-secondary) 0%, var(--success-glow) 100%);
    }
</style>

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="margin: 0; font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Active Staff Sessions</h1>
        <p style="margin: 4px 0 0 0; color: var(--text-secondary); font-size: 13.5px;">Real-time operator connections list. Instantly isolate or terminate rogue devices.</p>
    </div>
    <div style="display: flex; gap: 10px;">
        <form method="POST" action="user_sessions.php" onsubmit="return confirm('Are you sure you want to terminate ALL other active connections for your account?');">
            <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
            <input type="hidden" name="action" value="terminate_all">
            <button type="submit" class="btn btn-secondary btn-sm" style="width: auto; background: var(--danger-glow); border-color: var(--danger); color: var(--danger);">
                <i class="bx bx-power-off"></i> Terminate All Other Sessions
            </button>
        </form>
    </div>
</div>

<!-- ==========================================
     STATUS ALERTS
     ========================================== -->
<?php if ($message): ?>
    <div class="alert alert-success animate-fade" style="margin-bottom: 20px;"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-danger animate-fade" style="margin-bottom: 20px;"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<!-- ==========================================
     SESSIONS LEDGER
     ========================================== -->
<div class="session-grid">
    <?php foreach ($sessions as $s): 
        $is_me = ($s['session_token'] === $_SESSION['session_token']);
    ?>
        <div class="session-card <?php echo $is_me ? 'current' : ''; ?> animate-fade">
            <?php if ($is_me): ?>
                <span style="position: absolute; right: 15px; top: 15px; background: var(--success); color: #fff; font-size: 10px; font-weight: 700; text-transform: uppercase; padding: 2px 6px; border-radius: 4px;">
                    This Connection
                </span>
            <?php endif; ?>

            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 15px;">
                <div style="width: 40px; height: 40px; border-radius: 50%; background: var(--accent-glow); color: var(--accent); display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 16px;">
                    <?php echo strtoupper(substr($s['operator_name'], 0, 2)); ?>
                </div>
                <div>
                    <h3 style="margin: 0; font-size: 15px; font-weight: 700; color: var(--text-main);">
                        <?php echo htmlspecialchars($s['operator_name']); ?>
                    </h3>
                    <span style="font-size: 11.5px; color: var(--text-muted);">
                        @<?php echo htmlspecialchars($s['operator_username']); ?> &bull; <strong><?php echo htmlspecialchars($s['operator_role']); ?></strong>
                    </span>
                </div>
            </div>

            <div style="font-size: 13px; color: var(--text-secondary); display: flex; flex-direction: column; gap: 6px; margin-bottom: 20px;">
                <div>
                    <i class="bx bx-network-chart" style="color: var(--accent); margin-right: 6px;"></i> 
                    IP Address: <code><?php echo htmlspecialchars($s['ip_address']); ?></code>
                </div>
                <div>
                    <i class="bx bx-time" style="color: var(--accent); margin-right: 6px;"></i> 
                    Login time: <?php echo date('d M Y, h:i A', strtotime($s['login_time'])); ?>
                </div>
                <div>
                    <i class="bx bx-pulse" style="color: var(--accent); margin-right: 6px;"></i> 
                    Last Active: <?php echo date('h:i: A', strtotime($s['last_active_time'])); ?>
                </div>
                <div style="font-size: 11px; color: var(--text-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 5px;" title="<?php echo htmlspecialchars($s['device_info']); ?>">
                    <i class="bx bx-laptop"></i> <?php echo htmlspecialchars($s['device_info']); ?>
                </div>
            </div>

            <?php if (!$is_me): ?>
                <form method="POST" action="user_sessions.php" onsubmit="return confirm('Are you sure you want to forcefully terminate this operator connection?');" style="margin-top: 10px;">
                    <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                    <input type="hidden" name="action" value="terminate">
                    <input type="hidden" name="session_id" value="<?php echo $s['id']; ?>">
                    <button type="submit" class="btn" style="width: 100%; height: 34px; font-size: 12px; background: var(--bg-primary); border-color: var(--border-color); color: var(--danger); font-weight: 600;">
                        <i class="bx bx-x-circle"></i> Force Terminate Session
                    </button>
                </form>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

<?php require_once 'includes/footer.php'; ?>
